package com.bsstudio.bscinema;

import android.os.Bundle;
import android.os.Environment;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.net.Uri;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.view.KeyEvent;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.HttpURLConnection;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    private boolean cssInjected = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // FLAG_SECURE — prevent screenshots and screen recording on sensitive screens
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);

        WebView webView = getBridge() != null ? getBridge().getWebView() : null;
        if (webView != null) {
            WebSettings settings = webView.getSettings();
            settings.setTextZoom(100);
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
            settings.setLoadWithOverviewMode(true);
            settings.setUseWideViewPort(true);
            settings.setDomStorageEnabled(true);
            settings.setJavaScriptEnabled(true);
            settings.setMediaPlaybackRequiresUserGesture(false);
            settings.setJavaScriptCanOpenWindowsAutomatically(true);
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);
            settings.setDatabaseEnabled(true);
            settings.setCacheMode(WebSettings.LOAD_DEFAULT);

            // Handle downloads (APK download from About page)
            webView.setDownloadListener(new DownloadListener() {
                @Override
                public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                    if (url == null || url.isEmpty()) return;

                    String fileName = URLUtil.guessFileName(url, contentDisposition, mimetype);
                    if (fileName == null || fileName.isEmpty()) {
                        fileName = "BS-Cinema.apk";
                    }

                    // For local assets (file:///android_asset/...), handle via direct copy
                    if (url.startsWith("file://")) {
                        downloadLocalFile(url, fileName);
                    } else {
                        // For remote URLs, download in background
                        downloadRemoteFile(url, fileName);
                    }
                }
            });
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // Handle back button: navigate WebView history instead of exiting
        WebView webView = getBridge() != null ? getBridge().getWebView() : null;
        if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void downloadLocalFile(String url, String fileName) {
        try {
            // Strip file:///android_asset/ prefix to get the asset path
            String assetPath = url.replace("file:///android_asset/", "");

            // Get the app's external files dir for downloads
            File downloadsDir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "BS_Cinema");
            if (!downloadsDir.exists()) downloadsDir.mkdirs();

            File destFile = new File(downloadsDir, fileName);

            // Copy from assets
            InputStream is = getAssets().open(assetPath);
            FileOutputStream fos = new FileOutputStream(destFile);
            byte[] buffer = new byte[8192];
            int len;
            while ((len = is.read(buffer)) != -1) {
                fos.write(buffer, 0, len);
            }
            fos.close();
            is.close();

            // Open the file for installation
            openApkForInstall(destFile);
        } catch (Exception e) {
            // Fallback: try to open via browser
            try {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(browserIntent);
            } catch (Exception ignored) {}
        }
    }

    private void downloadRemoteFile(String url, String fileName) {
        new Thread(() -> {
            try {
                File downloadsDir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "BS_Cinema");
                if (!downloadsDir.exists()) downloadsDir.mkdirs();
                File destFile = new File(downloadsDir, fileName);

                URL urlObj = new URL(url);
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setRequestProperty("User-Agent", "Mozilla/5.0");
                conn.connect();

                InputStream is = conn.getInputStream();
                FileOutputStream fos = new FileOutputStream(destFile);
                byte[] buffer = new byte[8192];
                int len;
                while ((len = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
                is.close();
                conn.disconnect();

                runOnUiThread(() -> openApkForInstall(destFile));
            } catch (Exception e) {
                // Fallback: open URL in browser
                runOnUiThread(() -> {
                    try {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(browserIntent);
                    } catch (Exception ignored) {}
                });
            }
        }).start();
    }

    private void openApkForInstall(File file) {
        try {
            if (file == null || !file.exists()) return;

            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent installIntent = new Intent(Intent.ACTION_VIEW);
            installIntent.setDataAndType(uri, "application/vnd.android.package-archive");
            installIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            installIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // On Android 8+, may need to request install permission
            if (android.os.Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                Intent settingsIntent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
                settingsIntent.setData(Uri.parse("package:" + getPackageName()));
                settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(settingsIntent);
            }

            startActivity(installIntent);
        } catch (Exception ignored) {}
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!cssInjected) {
            injectAndroidCSS();
        }
    }

    private void injectAndroidCSS() {
        if (getBridge() == null) return;
        WebView webView = getBridge().getWebView();
        if (webView == null) return;

        cssInjected = true;

        webView.evaluateJavascript(
            "(function() {" +
                "if (document.getElementById('capacitor-android-fixes')) return;" +
                "var style = document.createElement('style');" +
                "style.id = 'capacitor-android-fixes';" +
                "style.textContent = '" +

                "h1{font-size:1.6rem!important;line-height:1.25!important;}" +
                "h2{font-size:1.35rem!important;line-height:1.3!important;}" +
                "h3{font-size:1.15rem!important;line-height:1.3!important;}" +
                "h4{font-size:1rem!important;line-height:1.35!important;}" +

                "html{font-size:15px!important;}" +
                "body{font-size:0.875rem!important;}" +

                ".text-4xl{font-size:1.75rem!important;}" +
                ".text-5xl{font-size:2rem!important;}" +
                ".text-6xl{font-size:2.25rem!important;}" +
                ".text-3xl{font-size:1.5rem!important;}" +
                ".text-2xl{font-size:1.25rem!important;}" +

                ".w-12{width:2.5rem!important;height:2.5rem!important;}" +
                ".w-14{width:3rem!important;height:3rem!important;}" +
                ".w-16{width:3.25rem!important;height:3.25rem!important;}" +
                ".w-20{width:3.5rem!important;height:3.5rem!important;}" +
                ".h-12{height:2.5rem!important;width:2.5rem!important;}" +
                ".h-14{height:3rem!important;width:3rem!important;}" +
                ".h-16{height:3.25rem!important;width:3.25rem!important;}" +
                ".h-20{height:3.5rem!important;width:3.5rem!important;}" +

                ".py-12{padding-top:1.5rem!important;padding-bottom:1.5rem!important;}" +
                ".py-16{padding-top:2rem!important;padding-bottom:2rem!important;}" +
                ".py-20{padding-top:2.5rem!important;padding-bottom:2.5rem!important;}" +
                ".py-24{padding-top:2.5rem!important;padding-bottom:2.5rem!important;}" +
                ".py-32{padding-top:3rem!important;padding-bottom:3rem!important;}" +
                ".pt-12{padding-top:1.5rem!important;}" +
                ".pt-16{padding-top:2rem!important;}" +
                ".pt-20{padding-top:2.5rem!important;}" +
                ".pt-24{padding-top:2.5rem!important;}" +
                ".pb-12{padding-bottom:1.5rem!important;}" +
                ".pb-16{padding-bottom:2rem!important;}" +
                ".pb-20{padding-bottom:2.5rem!important;}" +
                ".pb-24{padding-bottom:2.5rem!important;}" +
                ".space-y-12>*+*{margin-top:1.5rem!important;}" +
                ".space-y-16>*+*{margin-top:2rem!important;}" +
                ".gap-12{gap:1.5rem!important;}" +
                ".gap-16{gap:2rem!important;}" +

                ".min-h-screen{min-height:100vh!important;}" +

                ".px-8{padding-left:1.25rem!important;padding-right:1.25rem!important;}" +
                ".px-10{padding-left:1.5rem!important;padding-right:1.5rem!important;}" +
                ".px-12{padding-left:1.75rem!important;padding-right:1.75rem!important;}" +
                ".py-8{padding-top:1rem!important;padding-bottom:1rem!important;}" +
                ".py-10{padding-top:1.25rem!important;padding-bottom:1.25rem!important;}" +

                ".rounded-3xl{border-radius:1rem!important;}" +
                ".rounded-2xl{border-radius:0.75rem!important;}" +

                ".chat-container{max-height:100vh!important;}" +
                ".chat-messages{padding:0.5rem!important;}" +
                ".chat-input{padding:0.5rem!important;font-size:0.875rem!important;}" +
                ".voice-btn{width:2.5rem!important;height:2.5rem!important;}" +

                ".gap-8{gap:1rem!important;}" +
                ".gap-6{gap:0.75rem!important;}" +
                ".mt-8{margin-top:1rem!important;}" +
                ".mb-8{margin-bottom:1rem!important;}" +
                ".mt-12{margin-top:1.5rem!important;}" +
                ".mb-12{margin-bottom:1.5rem!important;}" +

                "';" +
                "document.head.appendChild(style);" +

                "setTimeout(function(){" +
                    "if(!document.getElementById('capacitor-android-fixes-2')){" +
                        "var s2=document.createElement('style');" +
                        "s2.id='capacitor-android-fixes-2';" +
                        "s2.textContent=style.textContent;" +
                        "document.head.appendChild(s2);" +
                    "}" +
                "},1500);" +
            "})();",
            null
        );
    }
}
