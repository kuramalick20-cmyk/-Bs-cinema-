const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { episode_id, language, transcript, source_language } = await req.json();

    if (!episode_id || !language || !transcript || typeof transcript !== "string") {
      return new Response(
        JSON.stringify({ error: "episode_id, language, and transcript string are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (language !== "ku" && language !== "en") {
      return new Response(
        JSON.stringify({ error: "Only 'ku' (Kurdish Sorani) and 'en' (English US) are supported" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const { createClient } = await import("npm:@supabase/supabase-js@2");
    const supabase = createClient(supabaseUrl, serviceKey);

    let finalTranscript = transcript.trim();
    let sourceLang = source_language || "ku";

    // If target language differs from source, translate first
    if (sourceLang !== language) {
      const translateUrl = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(sourceLang)}&tl=${encodeURIComponent(language)}&dt=t&q=${encodeURIComponent(finalTranscript)}`;
      try {
        const resp = await fetch(translateUrl, {
          headers: { "User-Agent": "Mozilla/5.0 (compatible; BSCinema/1.0)" },
        });
        if (resp.ok) {
          const data = await resp.json();
          let translated = "";
          if (Array.isArray(data) && Array.isArray(data[0])) {
            for (const segment of data[0]) {
              if (Array.isArray(segment) && segment[0]) {
                translated += segment[0];
              }
            }
          }
          if (translated) {
            finalTranscript = translated;
          }
        }
      } catch {
        // If translation fails, use original transcript
      }
    }

    // Split transcript into subtitle segments by sentences/lines
    // Split on newlines first, then by sentence-ending punctuation
    const lines = finalTranscript.split(/\n+/).filter((l) => l.trim());
    const segments: string[] = [];
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      // Split long lines by sentence markers
      const sentences = trimmed.split(/(?<=[.!?؟۔])\s+/).filter((s) => s.trim());
      if (sentences.length > 1) {
        for (const s of sentences) {
          if (s.trim().length > 0) segments.push(s.trim());
        }
      } else {
        segments.push(trimmed);
      }
    }

    // If no segments from punctuation, split by length (max ~80 chars)
    if (segments.length === 0) {
      const words = finalTranscript.split(/\s+/);
      let current = "";
      for (const word of words) {
        if ((current + " " + word).length > 80) {
          if (current) segments.push(current.trim());
          current = word;
        } else {
          current = current ? current + " " + word : word;
        }
      }
      if (current) segments.push(current.trim());
    }

    // Assign approximate timestamps (distribute evenly across a default 10 min video)
    const defaultDuration = 600; // 10 minutes in seconds
    const segmentDuration = defaultDuration / Math.max(segments.length, 1);

    const subtitles = segments.map((content, i) => ({
      content,
      start_time: Math.round(i * segmentDuration * 10) / 10,
      end_time: Math.round((i + 1) * segmentDuration * 10 - 0.5 * 10) / 10,
      source_text: transcript.trim(),
    }));

    // Delete existing AI subtitles for this episode + language
    await supabase
      .from("subtitles")
      .delete()
      .eq("item_type", "episode")
      .eq("item_id", episode_id)
      .eq("language", language)
      .eq("is_ai_generated", true);

    // Insert new subtitles
    const rows = subtitles.map((s) => ({
      item_type: "episode",
      item_id: episode_id,
      language,
      content: s.content,
      start_time: s.start_time,
      end_time: s.end_time,
      is_ai_generated: true,
      ai_status: "completed",
      source_text: s.source_text,
    }));

    const { data, error: insertError } = await supabase
      .from("subtitles")
      .insert(rows)
      .select("*");

    if (insertError) {
      return new Response(
        JSON.stringify({ error: insertError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Update job status
    await supabase
      .from("ai_subtitle_jobs")
      .update({ status: "completed", completed_at: new Date().toISOString() })
      .eq("episode_id", episode_id)
      .eq("language", language)
      .eq("status", "processing");

    return new Response(
      JSON.stringify({ success: true, count: data?.length || 0, subtitles }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "AI subtitle generation failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
