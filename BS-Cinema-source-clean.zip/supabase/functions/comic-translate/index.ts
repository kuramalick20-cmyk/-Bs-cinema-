import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const SUPPORTED_LANGS = new Set([
  "en", "ku", "ar", "fa", "tr", "ur", "hi", "ps", "he", "hy", "ka", "ru", "uk",
  "pl", "de", "fr", "es", "pt", "it", "nl", "el", "zh", "ja", "ko", "vi", "th",
  "id", "ms", "bn", "ta", "te", "mr", "pa", "sw",
]);

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { texts, target_lang, source_lang } = await req.json();

    if (!Array.isArray(texts) || texts.length === 0) {
      return new Response(
        JSON.stringify({ error: "texts array is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const target = target_lang || "en";
    if (!SUPPORTED_LANGS.has(target)) {
      return new Response(
        JSON.stringify({ error: `Unsupported target language: ${target}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const sourceParam = source_lang ? `&sl=${encodeURIComponent(source_lang)}` : "&sl=auto";
    const results: Array<{ original: string; translated: string; source_lang: string | null }> = [];

    for (const text of texts) {
      if (!text || typeof text !== "string" || text.trim() === "") {
        results.push({ original: text || "", translated: "", source_lang: null });
        continue;
      }

      const translateUrl = `https://translate.googleapis.com/translate_a/single?client=gtx${sourceParam}&tl=${encodeURIComponent(target)}&dt=t&q=${encodeURIComponent(text)}`;

      try {
        const response = await fetch(translateUrl, {
          headers: { "User-Agent": "Mozilla/5.0 (compatible; BSCinema/1.0)" },
        });

        if (!response.ok) {
          results.push({ original: text, translated: text, source_lang: null });
          continue;
        }

        const data = await response.json();

        let translated = "";
        if (Array.isArray(data) && Array.isArray(data[0])) {
          for (const segment of data[0]) {
            if (Array.isArray(segment) && segment[0]) {
              translated += segment[0];
            }
          }
        }

        const detectedSourceLang = (Array.isArray(data) && data[2]) ? data[2] : null;
        results.push({ original: text, translated: translated || text, source_lang: detectedSourceLang });
      } catch {
        results.push({ original: text, translated: text, source_lang: null });
      }
    }

    return new Response(
      JSON.stringify({ results, target_lang: target }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "Comic translation failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
