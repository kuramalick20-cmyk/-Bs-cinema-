import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { text, target_lang, source_lang } = await req.json();

    if (!text || typeof text !== "string") {
      return new Response(
        JSON.stringify({ error: "Text is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const target = target_lang || "en";

    // Try using a translation API. We use Google Translate's free endpoint
    // (no API key needed for basic translation).
    const sourceParam = source_lang ? `&sl=${encodeURIComponent(source_lang)}` : "&sl=auto";
    const translateUrl = `https://translate.googleapis.com/translate_a/single?client=gtx${sourceParam}&tl=${encodeURIComponent(target)}&dt=t&q=${encodeURIComponent(text)}`;

    const response = await fetch(translateUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; BSCinema/1.0)",
      },
    });

    if (!response.ok) {
      return new Response(
        JSON.stringify({ error: "Translation service unavailable" }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();

    // Google Translate returns nested arrays: [[[translatedText, originalText, ...], ...], [sourceLang]]
    let translated = "";
    if (Array.isArray(data) && Array.isArray(data[0])) {
      for (const segment of data[0]) {
        if (Array.isArray(segment) && segment[0]) {
          translated += segment[0];
        }
      }
    }

    const detectedSourceLang = (Array.isArray(data) && data[2]) ? data[2] : null;

    return new Response(
      JSON.stringify({ translated, source_lang: detectedSourceLang, target_lang: target }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "Translation failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
