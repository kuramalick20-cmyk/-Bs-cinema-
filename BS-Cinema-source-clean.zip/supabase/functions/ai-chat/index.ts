const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ChatMessage {
  role: string;
  content: string;
}

const SYSTEM_PROMPT = `You are BS Assistant, the official AI helper for BS Cinema (بی ئێس سینەما), a Kurdish cinema and entertainment platform. You ONLY talk about BS Cinema and what it offers: movies (فیلم), series (زنجیرە), comics (کۆمیک), anime (ئەنیمی), games (یاری), and entertainment content available on the platform.

Rules:
- Stay focused on BS Cinema. If someone asks about unrelated topics (politics, science, coding, general knowledge, etc.), politely say you can only help with BS Cinema content and steer them back.
- You can help users discover content: if they ask for a comic or series, recommend genres and titles, describe what's available, and explain categories.
- You respond in Kurdish (Sorani) when the user writes in Kurdish, and in English when they write in English.
- Keep responses short, friendly, and engaging.
- You are knowledgeable about movies, series, comics, anime, and games as they relate to what BS Cinema offers.`;

export default async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();

    if (!Array.isArray(messages)) {
      return new Response(
        JSON.stringify({ error: "messages array is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Check for OpenAI API key in ai_provider_settings
    const { createClient } = await import("npm:@supabase/supabase-js@2");
    const supabase = createClient(supabaseUrl, serviceKey);

    let apiKey = "";
    let model = "gpt-4o-mini";

    try {
      const { data: settings } = await supabase
        .from("ai_provider_settings")
        .select("openai_api_key, openai_model, chatgpt_enabled")
        .eq("id", 1)
        .maybeSingle();

      if (settings?.openai_api_key && settings.chatgpt_enabled !== false) {
        apiKey = settings.openai_api_key;
        model = settings.openai_model || "gpt-4o-mini";
      }
    } catch {
      // Table might not have data yet — continue to fallback
    }

    // Check for environment variable fallback
    if (!apiKey) {
      const envKey = Deno.env.get("OPENAI_API_KEY");
      if (envKey) {
        apiKey = envKey;
      }
    }

    const conversation: ChatMessage[] = [
      { role: "system", content: SYSTEM_PROMPT },
      ...messages.map((m: ChatMessage) => ({
        role: m.role === "assistant" ? "assistant" : "user",
        content: m.content,
      })),
    ];

    if (apiKey) {
      // Use OpenAI API
      const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          messages: conversation,
          max_tokens: 800,
          temperature: 0.7,
        }),
      });

      if (openaiResponse.ok) {
        const openaiData = await openaiResponse.json();
        const reply = openaiData.choices?.[0]?.message?.content || "I couldn't generate a response.";
        return new Response(
          JSON.stringify({ reply }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Fallback: use Pollinations AI (free, no API key needed)
    const pollinationsResponse = await fetch("https://text.pollinations.ai/openai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "openai",
        messages: conversation,
        max_tokens: 800,
        temperature: 0.7,
      }),
    });

    if (pollinationsResponse.ok) {
      const contentType = pollinationsResponse.headers.get("content-type") || "";
      if (contentType.includes("application/json")) {
        const pollData = await pollinationsResponse.json();
        const reply = pollData.choices?.[0]?.message?.content || pollData.content || "";
        if (reply) {
          return new Response(
            JSON.stringify({ reply }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      } else {
        const textReply = await pollinationsResponse.text();
        if (textReply && textReply.trim()) {
          return new Response(
            JSON.stringify({ reply: textReply.trim() }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
    }

    // Second fallback: simple text endpoint
    const lastUserMsg = messages.filter((m: ChatMessage) => m.role === "user").pop();
    if (lastUserMsg) {
      const simpleResp = await fetch(
        `https://text.pollinations.ai/${encodeURIComponent(lastUserMsg.content + " (Respond concisely in the same language as the question.)")}`,
        { method: "GET" }
      );
      if (simpleResp.ok) {
        const textReply = await simpleResp.text();
        if (textReply && textReply.trim()) {
          return new Response(
            JSON.stringify({ reply: textReply.trim() }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
    }

    return new Response(
      JSON.stringify({
        reply: "ببورە، لە ئێستادا ناتوانم وەڵام بدەمەوە. تکایە دواتر هەوڵ بدەرەوە.",
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({
        reply: "هەڵەیەک ڕوویدا. تکایە دواتر هەوڵ بدەرەوە.",
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
}

Deno.serve(handler);
