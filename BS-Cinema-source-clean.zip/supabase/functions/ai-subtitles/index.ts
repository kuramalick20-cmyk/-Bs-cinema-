const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { episode_id, language, subtitles } = await req.json();

    if (!episode_id || !language || !Array.isArray(subtitles)) {
      return new Response(
        JSON.stringify({ error: "episode_id, language, and subtitles array are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (language !== "ku" && language !== "en") {
      return new Response(
        JSON.stringify({ error: "Only 'ku' (Kurdish Sorani) and 'en' (English US) are supported" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const { createClient } = await import("npm:@supabase/supabase-js@2");
    const supabase = createClient(supabaseUrl, serviceKey);

    // Delete existing AI subtitles for this episode + language
    await supabase
      .from("subtitles")
      .delete()
      .eq("item_type", "episode")
      .eq("item_id", episode_id)
      .eq("language", language)
      .eq("is_ai_generated", true);

    // Insert new AI-generated subtitles
    const rows = subtitles.map((s: { content: string; start_time: number; end_time: number; source_text?: string }) => ({
      item_type: "episode",
      item_id: episode_id,
      language,
      content: s.content,
      start_time: s.start_time,
      end_time: s.end_time,
      is_ai_generated: true,
      ai_status: "completed",
      source_text: s.source_text || s.content,
    }));

    const { data, error } = await supabase
      .from("subtitles")
      .insert(rows)
      .select("*");

    if (error) {
      return new Response(
        JSON.stringify({ error: error.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Update job status if a job exists
    await supabase
      .from("ai_subtitle_jobs")
      .update({ status: "completed", completed_at: new Date().toISOString() })
      .eq("episode_id", episode_id)
      .eq("language", language)
      .eq("status", "processing");

    return new Response(
      JSON.stringify({ success: true, count: data?.length || 0 }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "AI subtitle generation failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
