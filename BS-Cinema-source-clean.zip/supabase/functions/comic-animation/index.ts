import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const url = new URL(req.url);
    const action = url.searchParams.get("action") || "analyze";

    // === ANALYZE: ChatGPT panel analysis ===
    if (action === "analyze") {
      const { image_url, user_instruction } = await req.json();

      // Get OpenAI API key from settings
      const { data: settings } = await supabase
        .from("ai_provider_settings")
        .select("openai_api_key, openai_model, chatgpt_enabled")
        .limit(1)
        .single();

      if (!settings?.chatgpt_enabled) {
        return new Response(
          JSON.stringify({ error: "ChatGPT analysis is not enabled" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      if (!settings.openai_api_key) {
        return new Response(
          JSON.stringify({ error: "OpenAI API key not configured" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      // Call OpenAI Vision API to analyze the comic panel
      const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${settings.openai_api_key}`,
        },
        body: JSON.stringify({
          model: settings.openai_model || "gpt-4o",
          messages: [
            {
              role: "system",
              content: `You are a comic panel analyzer. Analyze the comic image and return structured JSON with:
{
  "characters": [{"name": "", "description": "", "clothing": "", "hair": "", "eye_color": "", "position": "", "expression": ""}],
  "dialogue": [{"text": "", "character": "", "position": "top|bottom|left|right", "language": "ku|en|ar"}],
  "scene": "description of the scene/background",
  "camera": "recommended camera motion: static|zoom_in|zoom_out|pan_left|pan_right|subtle",
  "motion": ["list of subtle animation instructions preserving the original art"],
  "duration": 4,
  "style": "description of the art style to preserve"
}
IMPORTANT RULES:
- Preserve the EXACT original artwork, characters, and style
- Do NOT suggest creating new characters
- Motion should be subtle: blinking, breathing, hair movement, small head movement
- Never suggest replacing or redrawing characters
- Detect Kurdish Sorani (Arabic script) text and note it
- If user instruction is provided, incorporate it while preserving the original art`,
            },
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: user_instruction
                    ? `Analyze this comic panel. User instruction: ${user_instruction}`
                    : "Analyze this comic panel for animation.",
                },
                {
                  type: "image_url",
                  image_url: { url: image_url },
                },
              ],
            },
          ],
          max_tokens: 1000,
          response_format: { type: "json_object" },
        }),
      });

      if (!openaiResponse.ok) {
        const errText = await openaiResponse.text();
        return new Response(
          JSON.stringify({ error: `OpenAI analysis failed: ${openaiResponse.status}` }),
          { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      const openaiData = await openaiResponse.json();
      const analysisText = openaiData.choices?.[0]?.message?.content || "{}";

      let analysis: Record<string, any>;
      try {
        analysis = JSON.parse(analysisText);
      } catch {
        analysis = { raw: analysisText };
      }

      return new Response(
        JSON.stringify({ analysis }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // === GENERATE: Image-to-Video generation ===
    if (action === "generate") {
      const { panel_id, image_url, duration, camera_motion, animation_prompt, analysis } = await req.json();

      // Get default provider and settings
      const { data: settings } = await supabase
        .from("ai_provider_settings")
        .select("default_video_provider_id, default_duration, max_duration, image_to_video_enabled")
        .limit(1)
        .single();

      if (!settings?.image_to_video_enabled) {
        return new Response(
          JSON.stringify({ error: "Image-to-Video is not enabled" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      // Get the default provider
      let provider;
      if (settings.default_video_provider_id) {
        const { data } = await supabase
          .from("ai_video_providers")
          .select("*")
          .eq("id", settings.default_video_provider_id)
          .maybeSingle();
        provider = data;
      }

      if (!provider) {
        // Fallback: get first enabled provider
        const { data } = await supabase
          .from("ai_video_providers")
          .select("*")
          .eq("is_enabled", true)
          .limit(1)
          .maybeSingle();
        provider = data;
      }

      if (!provider || !provider.api_key) {
        return new Response(
          JSON.stringify({ error: "No AI video provider configured. Add a provider in Admin > AI Settings." }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      // Create animation job record
      const { data: job } = await supabase
        .from("comic_panel_animations")
        .insert({
          panel_id,
          status: "processing",
          provider_id: provider.id,
          provider_name: provider.name,
          model_used: provider.model_name,
          duration: Math.min(duration || settings.default_duration, settings.max_duration),
          camera_motion: camera_motion || "static",
          animation_prompt: animation_prompt || "",
          chatgpt_analysis: analysis || null,
        })
        .select("*")
        .single();

      // Build the prompt for the video generation
      const fullPrompt = buildVideoPrompt(animation_prompt, camera_motion, analysis, duration || settings.default_duration);

      // Call the provider's API
      try {
        const videoUrl = await callVideoProvider(provider, image_url, fullPrompt, Math.min(duration || settings.default_duration, settings.max_duration));

        // Update job as completed
        await supabase
          .from("comic_panel_animations")
          .update({
            status: "completed",
            video_url: videoUrl,
            completed_at: new Date().toISOString(),
          })
          .eq("id", job.id);

        // Update the panel's video_url
        await supabase
          .from("comic_panels")
          .update({ video_url: videoUrl })
          .eq("id", panel_id);

        return new Response(
          JSON.stringify({ success: true, video_url: videoUrl, job_id: job.id }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      } catch (genErr: any) {
        await supabase
          .from("comic_panel_animations")
          .update({
            status: "failed",
            error_message: genErr.message || "Generation failed",
          })
          .eq("id", job.id);

        return new Response(
          JSON.stringify({ error: genErr.message || "Video generation failed", job_id: job.id }),
          { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
    }

    // === STATUS: Check job status ===
    if (action === "status") {
      const { job_id } = await req.json();
      const { data: job } = await supabase
        .from("comic_panel_animations")
        .select("*")
        .eq("id", job_id)
        .maybeSingle();

      if (!job) {
        return new Response(
          JSON.stringify({ error: "Job not found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      return new Response(
        JSON.stringify({ job }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // === IMPROVE PROMPT: ChatGPT improves animation instructions ===
    if (action === "improve-prompt") {
      const { image_url, user_instruction, current_analysis } = await req.json();

      const { data: settings } = await supabase
        .from("ai_provider_settings")
        .select("openai_api_key, openai_model, chatgpt_enabled")
        .limit(1)
        .single();

      if (!settings?.chatgpt_enabled || !settings.openai_api_key) {
        return new Response(
          JSON.stringify({ error: "ChatGPT is not enabled or API key not set" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${settings.openai_api_key}`,
        },
        body: JSON.stringify({
          model: settings.openai_model || "gpt-4o",
          messages: [
            {
              role: "system",
              content: `You are an animation prompt engineer for image-to-video AI models.
Given a comic panel image and a user instruction, create a clean, detailed animation prompt.
RULES:
- Preserve the EXACT original artwork and characters
- Do NOT suggest creating new characters or changing the art style
- Motion must be subtle and natural
- Return JSON: {"prompt": "the animation prompt", "camera": "recommended camera motion", "duration": 4, "motion": ["list of motions"]}`,
            },
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: `User instruction: ${user_instruction || "Make the scene feel alive with subtle motion"}\n\nCurrent analysis: ${JSON.stringify(current_analysis || {})}`,
                },
                {
                  type: "image_url",
                  image_url: { url: image_url },
                },
              ],
            },
          ],
          max_tokens: 500,
          response_format: { type: "json_object" },
        }),
      });

      if (!openaiResponse.ok) {
        return new Response(
          JSON.stringify({ error: "OpenAI prompt improvement failed" }),
          { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      const openaiData = await openaiResponse.json();
      const resultText = openaiData.choices?.[0]?.message?.content || "{}";

      let result: Record<string, any>;
      try {
        result = JSON.parse(resultText);
      } catch {
        result = { prompt: resultText };
      }

      return new Response(
        JSON.stringify({ result }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ error: "Unknown action" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err: any) {
    return new Response(
      JSON.stringify({ error: err.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});

function buildVideoPrompt(
  animationPrompt: string | null,
  cameraMotion: string,
  analysis: Record<string, any> | null,
  duration: number,
): string {
  const parts: string[] = [];

  parts.push("Preserve the exact original image, characters, and art style.");
  parts.push("Do not redraw or replace any characters.");

  if (analysis) {
    if (analysis.scene) parts.push(`Scene: ${analysis.scene}`);
    if (analysis.motion && Array.isArray(analysis.motion)) {
      parts.push(`Motion: ${analysis.motion.join(", ")}`);
    }
    if (analysis.characters && Array.isArray(analysis.characters)) {
      for (const char of analysis.characters) {
        if (char.name) parts.push(`Character "${char.name}": ${char.description || ""} ${char.expression ? `expression: ${char.expression}` : ""}`);
      }
    }
  }

  if (animationPrompt) {
    parts.push(`Additional instructions: ${animationPrompt}`);
  }

  if (cameraMotion && cameraMotion !== "static") {
    const cameraMap: Record<string, string> = {
      zoom_in: "slow zoom in",
      zoom_out: "slow zoom out",
      pan_left: "slow pan left",
      pan_right: "slow pan right",
      subtle: "subtle camera movement",
    };
    parts.push(`Camera: ${cameraMap[cameraMotion] || cameraMotion}`);
  }

  parts.push(`Duration: ${duration} seconds`);
  parts.push("Subtle, natural motion only. No character replacement.");

  return parts.join("\n");
}

async function callVideoProvider(
  provider: any,
  imageUrl: string,
  prompt: string,
  duration: number,
): Promise<string> {
  const config = provider.config || {};
  const endpoint = provider.api_endpoint;

  // Generic provider call — supports common image-to-video API patterns
  // This handles several known provider formats via the config field
  const body: Record<string, any> = {
    image: imageUrl,
    prompt,
    duration,
    ...config,
  };

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${provider.api_key}`,
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const errText = await response.text().catch(() => "");
    throw new Error(`Provider ${provider.name} returned ${response.status}: ${errText}`);
  }

  const data = await response.json();

  // Try common response field patterns
  const videoUrl =
    data.video_url ||
    data.url ||
    data.output_url ||
    data.result?.video_url ||
    data.result?.url ||
    data.data?.video_url ||
    data.data?.url ||
    null;

  if (!videoUrl) {
    // Some providers return a job ID for async polling
    if (data.id || data.job_id || data.task_id) {
      const jobId = data.id || data.job_id || data.task_id;
      return await pollProviderForResult(provider, jobId, 120000);
    }
    throw new Error("Provider did not return a video URL or job ID");
  }

  return videoUrl;
}

async function pollProviderForResult(
  provider: any,
  jobId: string,
  timeoutMs: number,
): Promise<string> {
  const startTime = Date.now();
  const pollInterval = 5000;

  while (Date.now() - startTime < timeoutMs) {
    await new Promise((resolve) => setTimeout(resolve, pollInterval));

    const statusUrl = provider.api_endpoint.replace(/\/generate$/, `/${jobId}`);
    const response = await fetch(statusUrl, {
      headers: {
        "Authorization": `Bearer ${provider.api_key}`,
      },
    });

    if (!response.ok) continue;

    const data = await response.json();
    const status = data.status || data.state;

    if (status === "completed" || status === "succeeded" || status === "done") {
      const videoUrl =
        data.video_url ||
        data.url ||
        data.output_url ||
        data.result?.video_url ||
        data.result?.url ||
        null;
      if (videoUrl) return videoUrl;
      throw new Error("Provider completed but no video URL returned");
    }

    if (status === "failed" || status === "error") {
      throw new Error(data.error || data.message || "Provider generation failed");
    }
  }

  throw new Error("Provider polling timed out");
}
