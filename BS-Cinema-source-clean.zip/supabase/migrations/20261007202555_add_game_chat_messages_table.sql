/*
# Add game_chat_messages table for in-game real-time text chat

## Purpose
Allows players in a multiplayer game match to send real-time text messages to each other.
Messages are associated with a specific game match and only accessible to players of that match.

## New Tables
- `game_chat_messages`
  - `id` (uuid, primary key)
  - `match_id` (uuid, foreign key to game_matches.id, ON DELETE CASCADE)
  - `sender_id` (uuid, not null, defaults to auth.uid())
  - `text` (text, not null)
  - `created_at` (timestamptz, defaults to now())

## Security
- RLS enabled on game_chat_messages
- SELECT: only players of the match (player_white or player_black) can read messages
- INSERT: only players of the match can send messages, sender_id must match auth.uid()
- DELETE: only the sender can delete their own messages
- UPDATE: not allowed (messages are immutable once sent)
*/

CREATE TABLE IF NOT EXISTS game_chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id uuid NOT NULL REFERENCES game_matches(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL DEFAULT auth.uid(),
  text text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE game_chat_messages ENABLE ROW LEVEL SECURITY;

-- SELECT: only match participants can read messages
DROP POLICY IF EXISTS "select_game_chat_messages" ON game_chat_messages;
CREATE POLICY "select_game_chat_messages"
ON game_chat_messages FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM game_matches
    WHERE game_matches.id = game_chat_messages.match_id
    AND (game_matches.player_white = auth.uid() OR game_matches.player_black = auth.uid())
  )
);

-- INSERT: only match participants can send messages, must be the sender
DROP POLICY IF EXISTS "insert_game_chat_messages" ON game_chat_messages;
CREATE POLICY "insert_game_chat_messages"
ON game_chat_messages FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = sender_id
  AND EXISTS (
    SELECT 1 FROM game_matches
    WHERE game_matches.id = game_chat_messages.match_id
    AND (game_matches.player_white = auth.uid() OR game_matches.player_black = auth.uid())
  )
);

-- DELETE: only sender can delete their own messages
DROP POLICY IF EXISTS "delete_game_chat_messages" ON game_chat_messages;
CREATE POLICY "delete_game_chat_messages"
ON game_chat_messages FOR DELETE
TO authenticated
USING (auth.uid() = sender_id);

-- Index for efficient querying by match
CREATE INDEX IF NOT EXISTS idx_game_chat_messages_match_id ON game_chat_messages(match_id, created_at);
