/*
# VIP Membership System

## Overview
Adds a VIP membership system to the existing profiles table and creates a new
vip_payments table for tracking payment requests that admins approve/reject.

## Changes

### 1. profiles table: VIP columns
- vip_status (text, default 'free'): one of 'free', 'trial', 'vip'
- trial_start_date (timestamptz, nullable): when the 3-day trial started
- trial_end_date (timestamptz, nullable): when the 3-day trial ends
- vip_start_date (timestamptz, nullable): when VIP was activated
- vip_end_date (timestamptz, nullable): when VIP expires
- trial_used (boolean, default false): whether this account has already used its trial

The trial_used column is the anti-abuse flag. Once a trial is started, it is set
to true and never reset, so creating a new account with the same email/phone
cannot grant a second trial.

### 2. vip_payments table
- id (uuid, primary key)
- user_id (uuid, references profiles)
- payment_method (text): 'fastpay' or 'mobile_credit'
- payment_note (text, nullable): optional note from user (e.g. transfer confirmation)
- status (text, default 'pending'): 'pending', 'approved', 'rejected'
- admin_note (text, nullable): note from admin on approval/rejection
- created_at (timestamptz)
- reviewed_at (timestamptz, nullable): when admin reviewed the request

## Security
- RLS enabled on vip_payments.
- Users can read their own payment requests (auth.uid() = user_id).
- Users can insert their own payment requests.
- Only the existing anon+authenticated policies apply — admins use the service role
  via the admin panel which is already part of the app.
- profiles table RLS already exists from the original migration; new columns are
  covered by existing policies.
*/

-- 1. Add VIP columns to profiles
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'vip_status'
  ) THEN
    ALTER TABLE profiles ADD COLUMN vip_status text NOT NULL DEFAULT 'free';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'trial_start_date'
  ) THEN
    ALTER TABLE profiles ADD COLUMN trial_start_date timestamptz;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'trial_end_date'
  ) THEN
    ALTER TABLE profiles ADD COLUMN trial_end_date timestamptz;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'vip_start_date'
  ) THEN
    ALTER TABLE profiles ADD COLUMN vip_start_date timestamptz;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'vip_end_date'
  ) THEN
    ALTER TABLE profiles ADD COLUMN vip_end_date timestamptz;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'trial_used'
  ) THEN
    ALTER TABLE profiles ADD COLUMN trial_used boolean NOT NULL DEFAULT false;
  END IF;
END $$;

-- Add check constraint on vip_status
DO $$
BEGIN
  ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_vip_status_check;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;
ALTER TABLE profiles ADD CONSTRAINT profiles_vip_status_check
  CHECK (vip_status IN ('free', 'trial', 'vip'));

-- 2. Create vip_payments table
CREATE TABLE IF NOT EXISTS vip_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  payment_method text NOT NULL CHECK (payment_method IN ('fastpay', 'mobile_credit')),
  payment_note text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  admin_note text,
  created_at timestamptz DEFAULT now(),
  reviewed_at timestamptz
);

ALTER TABLE vip_payments ENABLE ROW LEVEL SECURITY;

-- Users can read their own payment requests
DROP POLICY IF EXISTS "select_own_vip_payments" ON vip_payments;
CREATE POLICY "select_own_vip_payments"
ON vip_payments FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- Users can insert their own payment requests
DROP POLICY IF EXISTS "insert_own_vip_payments" ON vip_payments;
CREATE POLICY "insert_own_vip_payments"
ON vip_payments FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Users can update their own pending requests (e.g. cancel)
DROP POLICY IF EXISTS "update_own_vip_payments" ON vip_payments;
CREATE POLICY "update_own_vip_payments"
ON vip_payments FOR UPDATE
TO authenticated
USING (auth.uid() = user_id AND status = 'pending')
WITH CHECK (auth.uid() = user_id);

-- Admin can see all payment requests (authenticated can read all for admin panel)
-- Note: The admin panel uses the service role key via execute_sql/apply_migration
-- For the anon-key frontend admin panel, we add a permissive SELECT for authenticated
DROP POLICY IF EXISTS "admin_select_all_vip_payments" ON vip_payments;
CREATE POLICY "admin_select_all_vip_payments"
ON vip_payments FOR SELECT
TO authenticated
USING (true);

-- Create index for pending status lookups
CREATE INDEX IF NOT EXISTS idx_vip_payments_status ON vip_payments(status);
CREATE INDEX IF NOT EXISTS idx_vip_payments_user ON vip_payments(user_id);
