/*
# Add Views, Stars, and Comments System

## Overview
Adds a persistent view counter, star/favorite system, and comment section
to every content item, episode, and comic chapter in BS Cinema.

## New Tables

1. **views** — Records every view event (one row per view)
   - id (uuid PK)
   - item_type (text: 'content' | 'episode' | 'comic_chapter')
   - item_id (uuid, the referenced entity's id)
   - user_id (uuid, nullable — the viewer if signed in)
   - device_id (text, nullable — anonymous device fingerprint)
   - created_at (timestamptz)

2. **stars** — Records star/favorite actions (one per user/device per item)
   - id (uuid PK)
   - item_type (text: 'content' | 'episode' | 'comic_chapter')
   - item_id (uuid)
   - user_id (uuid, nullable — the starrer if signed in)
   - device_id (text, nullable — anonymous device fingerprint)
   - created_at (timestamptz)
   - UNIQUE constraint on (item_type, item_id, user_id) and (item_type, item_id, device_id)

3. **comments** — User comments on any item
   - id (uuid PK)
   - item_type (text: 'content' | 'episode' | 'comic_chapter')
   - item_id (uuid)
   - user_id (uuid, NOT NULL, references auth.users)
   - text (text, NOT NULL, max 2000 chars)
   - created_at (timestamptz)

## RPC Functions

1. **increment_view(item_type, item_id, device_id)** — Inserts a view row and returns total view count for that item.
2. **toggle_star(item_type, item_id, device_id)** — Toggles a star for the given user/device. Returns { starred: boolean, star_count: bigint }.
3. **get_star_count(item_type, item_id)** — Returns total star count for an item.
4. **has_starred(item_type, item_id, device_id)** — Returns boolean whether current user/device has starred.

## Security
- views: public read + insert (anon + authenticated). No update/delete needed.
- stars: public read + insert + delete (anon + authenticated). Users/devices can only delete their own stars.
- comments: public read (anon + authenticated). Only authenticated users can insert. Users can only delete their own comments.
- All RPC functions are SECURITY DEFINER so they can operate across the tables regardless of RLS.
*/

-- ============================================================
-- VIEWS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_type text NOT NULL CHECK (item_type IN ('content', 'episode', 'comic_chapter')),
  item_id uuid NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  device_id text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE views ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_views" ON views;
CREATE POLICY "public_select_views" ON views FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_views" ON views;
CREATE POLICY "public_insert_views" ON views FOR INSERT
  TO anon, authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_views_item ON views(item_type, item_id);
CREATE INDEX IF NOT EXISTS idx_views_created ON views(created_at);

-- ============================================================
-- STARS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS stars (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_type text NOT NULL CHECK (item_type IN ('content', 'episode', 'comic_chapter')),
  item_id uuid NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  device_id text,
  created_at timestamptz DEFAULT now()
);

-- Prevent duplicate stars: one per user OR one per device
CREATE UNIQUE INDEX IF NOT EXISTS uniq_star_user ON stars(item_type, item_id, user_id) WHERE user_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uniq_star_device ON stars(item_type, item_id, device_id) WHERE device_id IS NOT NULL AND user_id IS NULL;

ALTER TABLE stars ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_stars" ON stars;
CREATE POLICY "public_select_stars" ON stars FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_stars" ON stars;
CREATE POLICY "public_insert_stars" ON stars FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_delete_stars" ON stars;
CREATE POLICY "public_delete_stars" ON stars FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_stars_item ON stars(item_type, item_id);

-- ============================================================
-- COMMENTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_type text NOT NULL CHECK (item_type IN ('content', 'episode', 'comic_chapter')),
  item_id uuid NOT NULL,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  text text NOT NULL CHECK (length(text) > 0 AND length(text) <= 2000),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_comments" ON comments;
CREATE POLICY "public_select_comments" ON comments FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_comments" ON comments;
CREATE POLICY "auth_insert_comments" ON comments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "auth_delete_own_comments" ON comments;
CREATE POLICY "auth_delete_own_comments" ON comments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_comments_item ON comments(item_type, item_id, created_at);

-- ============================================================
-- RPC: increment_view
-- ============================================================
CREATE OR REPLACE FUNCTION increment_view(
  p_item_type text,
  p_item_id uuid,
  p_device_id text DEFAULT NULL
)
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_count bigint;
  v_user_id uuid := auth.uid();
BEGIN
  INSERT INTO views (item_type, item_id, user_id, device_id)
  VALUES (p_item_type, p_item_id, v_user_id, p_device_id);

  SELECT count(*) INTO v_count
  FROM views
  WHERE item_type = p_item_type AND item_id = p_item_id;

  RETURN v_count;
END;
$$;

-- ============================================================
-- RPC: toggle_star
-- ============================================================
CREATE OR REPLACE FUNCTION toggle_star(
  p_item_type text,
  p_item_id uuid,
  p_device_id text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_existing record;
  v_count bigint;
  v_starred boolean;
BEGIN
  -- Check if already starred
  IF v_user_id IS NOT NULL THEN
    SELECT * INTO v_existing
    FROM stars
    WHERE item_type = p_item_type AND item_id = p_item_id AND user_id = v_user_id;
  ELSE
    SELECT * INTO v_existing
    FROM stars
    WHERE item_type = p_item_type AND item_id = p_item_id AND device_id = p_device_id AND user_id IS NULL;
  END IF;

  IF v_existing IS NOT NULL THEN
    -- Unstar
    DELETE FROM stars WHERE id = v_existing.id;
    v_starred := false;
  ELSE
    -- Star
    INSERT INTO stars (item_type, item_id, user_id, device_id)
    VALUES (p_item_type, p_item_id, v_user_id, p_device_id);
    v_starred := true;
  END IF;

  SELECT count(*) INTO v_count
  FROM stars
  WHERE item_type = p_item_type AND item_id = p_item_id;

  RETURN jsonb_build_object('starred', v_starred, 'star_count', v_count);
END;
$$;

-- ============================================================
-- RPC: get_star_count
-- ============================================================
CREATE OR REPLACE FUNCTION get_star_count(
  p_item_type text,
  p_item_id uuid
)
RETURNS bigint
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT count(*) FROM stars WHERE item_type = $1 AND item_id = $2;
$$;

-- ============================================================
-- RPC: has_starred
-- ============================================================
CREATE OR REPLACE FUNCTION has_starred(
  p_item_type text,
  p_item_id uuid,
  p_device_id text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_existing record;
BEGIN
  IF v_user_id IS NOT NULL THEN
    SELECT * INTO v_existing
    FROM stars
    WHERE item_type = p_item_type AND item_id = p_item_id AND user_id = v_user_id;
  ELSE
    SELECT * INTO v_existing
    FROM stars
    WHERE item_type = p_item_type AND item_id = p_item_id AND device_id = p_device_id AND user_id IS NULL;
  END IF;

  RETURN v_existing IS NOT NULL;
END;
$$;

-- ============================================================
-- RPC: get_view_count
-- ============================================================
CREATE OR REPLACE FUNCTION get_view_count(
  p_item_type text,
  p_item_id uuid
)
RETURNS bigint
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT count(*) FROM views WHERE item_type = $1 AND item_id = $2;
$$;
