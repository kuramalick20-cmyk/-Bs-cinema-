/*
# Fix VIP payments admin update policy

## Summary
The existing `update_own_vip_payments` policy only allows users to update their own
pending payments. Admins need to approve/reject ANY user's payment. This migration
adds an admin-specific UPDATE policy on vip_payments.

## Changes
- Added `admin_update_vip_payments` policy allowing admin users to update any payment.
- Added `admin_update_profiles` policy allowing admin users to update any profile
  (needed for VIP approval: admin sets vip_status, vip_start_date, vip_end_date).
*/

-- Admin can update any vip_payment
DROP POLICY IF EXISTS "admin_update_vip_payments" ON vip_payments;
CREATE POLICY "admin_update_vip_payments"
ON vip_payments FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());

-- Admin can update any profile (for VIP approval)
DROP POLICY IF EXISTS "admin_update_profiles" ON profiles;
CREATE POLICY "admin_update_profiles"
ON profiles FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());
