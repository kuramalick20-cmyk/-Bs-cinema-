/*
# Fix comment submission: add direct FK from comments.user_id to profiles.id

Problem: PostgREST cannot infer the join path from comments -> profiles
because both tables reference auth.users(id) in the auth schema, and
PostgREST does not expose cross-schema relationships through auth.users.

This means queries like:
  .select('*, profiles:profiles(username, avatar_url)')
fail silently — the insert succeeds but the returning query returns null
because the embedded join cannot be resolved.

Fix: Add a direct foreign key from comments.user_id to profiles.id
so PostgREST can detect the relationship and resolve the join.

The existing FK comments.user_id -> auth.users(id) ON DELETE CASCADE
remains in place. The new FK is additive and does not change existing
behavior — it only enables PostgREST to detect the join path.
*/

-- Add FK from comments.user_id to profiles.id
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'comments_user_id_profiles_fkey'
    AND conrelid = 'comments'::regclass
  ) THEN
    ALTER TABLE comments
      ADD CONSTRAINT comments_user_id_profiles_fkey
      FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE;
  END IF;
END $$;
