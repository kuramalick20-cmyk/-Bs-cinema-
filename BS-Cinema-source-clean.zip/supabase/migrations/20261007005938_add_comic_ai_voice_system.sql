/*
# Comic AI Voice System

1. New Tables
- `comic_characters` — defines characters within a comic content item, each with a voice type.
  - `id` (uuid, primary key)
  - `content_id` (uuid, FK to content, ON DELETE CASCADE)
  - `name` (text, character name)
  - `voice_type` (text, 'male' or 'female', default 'male')
  - `voice_language` (text, default language code for this character's voice, e.g. 'ku')
  - `color` (text, optional color identifier for visual association)
  - `created_at` (timestamptz)

- `comic_speech_bubbles` — stores speech bubble text for each panel, linked to a character.
  - `id` (uuid, primary key)
  - `panel_id` (uuid, FK to comic_panels, ON DELETE CASCADE)
  - `character_id` (uuid, FK to comic_characters, ON DELETE SET NULL, nullable)
  - `text` (text, the original text in the speech bubble)
  - `translated_text` (text, optional translated text)
  - `target_language` (text, optional target language code for translation)
  - `region_x` (float, relative X position 0-1)
  - `region_y` (float, relative Y position 0-1)
  - `region_width` (float, relative width 0-1)
  - `region_height` (float, relative height 0-1)
  - `bubble_order` (int, order within the panel for sequential reading)
  - `created_at` (timestamptz)

2. Security
- Enable RLS on both tables.
- Anyone can read (anon + authenticated) — comic content is public.
- Only authenticated users can insert/update — admin manages characters and bubbles.
*/

CREATE TABLE IF NOT EXISTS comic_characters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id uuid NOT NULL REFERENCES content(id) ON DELETE CASCADE,
  name text NOT NULL,
  voice_type text NOT NULL DEFAULT 'male' CHECK (voice_type IN ('male', 'female')),
  voice_language text DEFAULT 'ku',
  color text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE comic_characters ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_comic_characters" ON comic_characters;
CREATE POLICY "read_comic_characters"
ON comic_characters FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_comic_characters" ON comic_characters;
CREATE POLICY "insert_comic_characters"
ON comic_characters FOR INSERT
TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_comic_characters" ON comic_characters;
CREATE POLICY "update_comic_characters"
ON comic_characters FOR UPDATE
TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_comic_characters" ON comic_characters;
CREATE POLICY "delete_comic_characters"
ON comic_characters FOR DELETE
TO authenticated USING (true);

CREATE TABLE IF NOT EXISTS comic_speech_bubbles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  panel_id uuid NOT NULL REFERENCES comic_panels(id) ON DELETE CASCADE,
  character_id uuid REFERENCES comic_characters(id) ON DELETE SET NULL,
  text text NOT NULL,
  translated_text text,
  target_language text,
  region_x float DEFAULT 0.1,
  region_y float DEFAULT 0.1,
  region_width float DEFAULT 0.6,
  region_height float DEFAULT 0.12,
  bubble_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE comic_speech_bubbles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_comic_speech_bubbles" ON comic_speech_bubbles;
CREATE POLICY "read_comic_speech_bubbles"
ON comic_speech_bubbles FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_comic_speech_bubbles" ON comic_speech_bubbles;
CREATE POLICY "insert_comic_speech_bubbles"
ON comic_speech_bubbles FOR INSERT
TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_comic_speech_bubbles" ON comic_speech_bubbles;
CREATE POLICY "update_comic_speech_bubbles"
ON comic_speech_bubbles FOR UPDATE
TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_comic_speech_bubbles" ON comic_speech_bubbles;
CREATE POLICY "delete_comic_speech_bubbles"
ON comic_speech_bubbles FOR DELETE
TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_comic_characters_content ON comic_characters(content_id);
CREATE INDEX IF NOT EXISTS idx_comic_speech_bubbles_panel ON comic_speech_bubbles(panel_id);
CREATE INDEX IF NOT EXISTS idx_comic_speech_bubbles_character ON comic_speech_bubbles(character_id);
