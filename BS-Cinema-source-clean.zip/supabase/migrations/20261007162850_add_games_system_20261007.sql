/*
# Add Multiplayer Games System (Chess + Dominoes)

1. New Tables
- `game_matches` — stores chess and dominoes matches between authenticated users or vs bots
- `game_moves` — individual moves within a match (for realtime sync and history)
- `game_invites` — pending game invitations between users

2. Security
- Enable RLS on all three tables.
- Both players in a match can read and update game state.
- Users can only create invites from themselves.
- All policies use auth.uid() ownership checks.
*/

-- Game matches table
CREATE TABLE IF NOT EXISTS game_matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_type text NOT NULL CHECK (game_type IN ('chess', 'dominoes')),
  mode text NOT NULL DEFAULT 'multiplayer' CHECK (mode IN ('multiplayer', 'bot')),
  status text NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'active', 'completed', 'resigned')),
  player_white uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  player_black uuid REFERENCES profiles(id) ON DELETE CASCADE,
  bot_elo int,
  current_turn text NOT NULL DEFAULT 'white' CHECK (current_turn IN ('white', 'black')),
  game_state jsonb NOT NULL DEFAULT '{}'::jsonb,
  move_history jsonb NOT NULL DEFAULT '[]'::jsonb,
  result text CHECK (result IN ('white_wins', 'black_wins', 'draw')),
  result_reason text,
  winner_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  invited_player uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE game_matches ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_matches" ON game_matches;
CREATE POLICY "select_own_matches"
ON game_matches FOR SELECT
TO authenticated
USING (
  auth.uid() = player_white OR
  auth.uid() = player_black OR
  auth.uid() = invited_player
);

DROP POLICY IF EXISTS "insert_matches" ON game_matches;
CREATE POLICY "insert_matches"
ON game_matches FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = player_white OR
  auth.uid() = invited_player
);

DROP POLICY IF EXISTS "update_matches" ON game_matches;
CREATE POLICY "update_matches"
ON game_matches FOR UPDATE
TO authenticated
USING (
  auth.uid() = player_white OR
  auth.uid() = player_black OR
  auth.uid() = invited_player
)
WITH CHECK (
  auth.uid() = player_white OR
  auth.uid() = player_black OR
  auth.uid() = invited_player
);

DROP POLICY IF EXISTS "delete_matches" ON game_matches;
CREATE POLICY "delete_matches"
ON game_matches FOR DELETE
TO authenticated
USING (
  auth.uid() = player_white OR
  auth.uid() = player_black
);

-- Game moves table
CREATE TABLE IF NOT EXISTS game_moves (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id uuid NOT NULL REFERENCES game_matches(id) ON DELETE CASCADE,
  move_number int NOT NULL,
  player_id uuid NOT NULL,
  move_data jsonb NOT NULL,
  notation text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE game_moves ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_match_moves" ON game_moves;
CREATE POLICY "select_match_moves"
ON game_moves FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM game_matches
    WHERE game_matches.id = game_moves.match_id
    AND (game_matches.player_white = auth.uid() OR game_matches.player_black = auth.uid())
  )
);

DROP POLICY IF EXISTS "insert_match_moves" ON game_moves;
CREATE POLICY "insert_match_moves"
ON game_moves FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = player_id AND
  EXISTS (
    SELECT 1 FROM game_matches
    WHERE game_matches.id = game_moves.match_id
    AND (game_matches.player_white = auth.uid() OR game_matches.player_black = auth.uid())
    AND game_matches.status = 'active'
  )
);

-- Game invites table
CREATE TABLE IF NOT EXISTS game_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_type text NOT NULL CHECK (game_type IN ('chess', 'dominoes')),
  from_user uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  to_user uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined', 'expired')),
  match_id uuid REFERENCES game_matches(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  responded_at timestamptz
);

ALTER TABLE game_invites ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_game_invites" ON game_invites;
CREATE POLICY "select_game_invites"
ON game_invites FOR SELECT
TO authenticated
USING (
  auth.uid() = from_user OR auth.uid() = to_user
);

DROP POLICY IF EXISTS "insert_game_invites" ON game_invites;
CREATE POLICY "insert_game_invites"
ON game_invites FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = from_user);

DROP POLICY IF EXISTS "update_game_invites" ON game_invites;
CREATE POLICY "update_game_invites"
ON game_invites FOR UPDATE
TO authenticated
USING (
  auth.uid() = from_user OR auth.uid() = to_user
)
WITH CHECK (
  auth.uid() = from_user OR auth.uid() = to_user
);

DROP POLICY IF EXISTS "delete_game_invites" ON game_invites;
CREATE POLICY "delete_game_invites"
ON game_invites FOR DELETE
TO authenticated
USING (
  auth.uid() = from_user OR auth.uid() = to_user
);

CREATE INDEX IF NOT EXISTS idx_game_matches_player_white ON game_matches(player_white);
CREATE INDEX IF NOT EXISTS idx_game_matches_player_black ON game_matches(player_black);
CREATE INDEX IF NOT EXISTS idx_game_matches_status ON game_matches(status);
CREATE INDEX IF NOT EXISTS idx_game_moves_match_id ON game_moves(match_id);
CREATE INDEX IF NOT EXISTS idx_game_invites_to_user ON game_invites(to_user, status);
CREATE INDEX IF NOT EXISTS idx_game_invites_from_user ON game_invites(from_user);
