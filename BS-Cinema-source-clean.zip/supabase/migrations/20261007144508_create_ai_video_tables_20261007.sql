/*
# Comic Image-to-Video Animation System - Table Creation

Creates 5 new tables for the AI comic animation system.
No existing tables are modified. No data is lost.
*/

-- 1. AI Video Providers — configurable video generation providers
CREATE TABLE IF NOT EXISTS ai_video_providers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  provider_type text NOT NULL DEFAULT 'image-to-video' CHECK (provider_type IN ('image-to-video', 'text-to-video')),
  api_key text,
  api_endpoint text NOT NULL,
  model_name text NOT NULL DEFAULT '',
  is_enabled boolean NOT NULL DEFAULT false,
  is_default boolean NOT NULL DEFAULT false,
  config jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE ai_video_providers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ai_video_providers_select" ON ai_video_providers;
CREATE POLICY "ai_video_providers_select" ON ai_video_providers
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "ai_video_providers_insert" ON ai_video_providers;
CREATE POLICY "ai_video_providers_insert" ON ai_video_providers
  FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "ai_video_providers_update" ON ai_video_providers;
CREATE POLICY "ai_video_providers_update" ON ai_video_providers
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "ai_video_providers_delete" ON ai_video_providers;
CREATE POLICY "ai_video_providers_delete" ON ai_video_providers
  FOR DELETE TO authenticated USING (true);

-- 2. AI Provider Settings — global AI config (single row)
CREATE TABLE IF NOT EXISTS ai_provider_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  openai_api_key text,
  openai_model text NOT NULL DEFAULT 'gpt-4o',
  default_video_provider_id uuid REFERENCES ai_video_providers(id) ON DELETE SET NULL,
  default_duration int NOT NULL DEFAULT 4,
  max_duration int NOT NULL DEFAULT 10,
  image_to_video_enabled boolean NOT NULL DEFAULT false,
  chatgpt_enabled boolean NOT NULL DEFAULT false,
  subtitle_ai_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE ai_provider_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ai_provider_settings_select" ON ai_provider_settings;
CREATE POLICY "ai_provider_settings_select" ON ai_provider_settings
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "ai_provider_settings_insert" ON ai_provider_settings;
CREATE POLICY "ai_provider_settings_insert" ON ai_provider_settings
  FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "ai_provider_settings_update" ON ai_provider_settings;
CREATE POLICY "ai_provider_settings_update" ON ai_provider_settings
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- 3. Comic Panel Animations — generation jobs per panel
CREATE TABLE IF NOT EXISTS comic_panel_animations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  panel_id uuid NOT NULL REFERENCES comic_panels(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'cancelled')),
  provider_id uuid REFERENCES ai_video_providers(id) ON DELETE SET NULL,
  provider_name text,
  model_used text,
  video_url text,
  duration int NOT NULL DEFAULT 4,
  camera_motion text NOT NULL DEFAULT 'static' CHECK (camera_motion IN ('static', 'zoom_in', 'zoom_out', 'pan_left', 'pan_right', 'subtle')),
  animation_prompt text,
  chatgpt_analysis jsonb,
  error_message text,
  retry_count int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);
ALTER TABLE comic_panel_animations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "comic_panel_animations_select" ON comic_panel_animations;
CREATE POLICY "comic_panel_animations_select" ON comic_panel_animations
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "comic_panel_animations_insert" ON comic_panel_animations;
CREATE POLICY "comic_panel_animations_insert" ON comic_panel_animations
  FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "comic_panel_animations_update" ON comic_panel_animations;
CREATE POLICY "comic_panel_animations_update" ON comic_panel_animations
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "comic_panel_animations_delete" ON comic_panel_animations;
CREATE POLICY "comic_panel_animations_delete" ON comic_panel_animations
  FOR DELETE TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_comic_panel_animations_panel ON comic_panel_animations(panel_id);

-- 4. Comic Panel Subtitles — timed subtitles for animated panels
CREATE TABLE IF NOT EXISTS comic_panel_subtitles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  panel_id uuid NOT NULL REFERENCES comic_panels(id) ON DELETE CASCADE,
  text text NOT NULL,
  start_time float NOT NULL DEFAULT 0,
  end_time float NOT NULL DEFAULT 0,
  language text NOT NULL DEFAULT 'ku',
  position_x float NOT NULL DEFAULT 0.5,
  position_y float NOT NULL DEFAULT 0.85,
  font_family text NOT NULL DEFAULT 'sans-serif',
  font_size int NOT NULL DEFAULT 16,
  text_color text NOT NULL DEFAULT '#ffffff',
  bg_color text NOT NULL DEFAULT '#000000',
  bg_opacity float NOT NULL DEFAULT 0.75,
  text_align text NOT NULL DEFAULT 'center' CHECK (text_align IN ('left', 'center', 'right')),
  is_ai_generated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE comic_panel_subtitles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "comic_panel_subtitles_select" ON comic_panel_subtitles;
CREATE POLICY "comic_panel_subtitles_select" ON comic_panel_subtitles
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "comic_panel_subtitles_insert" ON comic_panel_subtitles;
CREATE POLICY "comic_panel_subtitles_insert" ON comic_panel_subtitles
  FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "comic_panel_subtitles_update" ON comic_panel_subtitles;
CREATE POLICY "comic_panel_subtitles_update" ON comic_panel_subtitles
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "comic_panel_subtitles_delete" ON comic_panel_subtitles;
CREATE POLICY "comic_panel_subtitles_delete" ON comic_panel_subtitles
  FOR DELETE TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_comic_panel_subtitles_panel ON comic_panel_subtitles(panel_id);

-- 5. Comic Character Refs — extended character reference data
CREATE TABLE IF NOT EXISTS comic_character_refs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id uuid NOT NULL REFERENCES content(id) ON DELETE CASCADE,
  character_id uuid REFERENCES comic_characters(id) ON DELETE SET NULL,
  name text NOT NULL,
  description text,
  clothing text,
  hair text,
  eye_color text,
  reference_image_url text,
  dialogue_sample text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE comic_character_refs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "comic_character_refs_select" ON comic_character_refs;
CREATE POLICY "comic_character_refs_select" ON comic_character_refs
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "comic_character_refs_insert" ON comic_character_refs;
CREATE POLICY "comic_character_refs_insert" ON comic_character_refs
  FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "comic_character_refs_update" ON comic_character_refs;
CREATE POLICY "comic_character_refs_update" ON comic_character_refs
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "comic_character_refs_delete" ON comic_character_refs;
CREATE POLICY "comic_character_refs_delete" ON comic_character_refs
  FOR DELETE TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_comic_character_refs_content ON comic_character_refs(content_id);
