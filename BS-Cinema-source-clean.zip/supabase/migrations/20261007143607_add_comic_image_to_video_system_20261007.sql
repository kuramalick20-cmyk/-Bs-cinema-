/*
# Comic Image-to-Video Animation System

## Summary
Adds a complete AI-powered comic animation system that converts static comic panels into short animated videos.
Supports configurable AI providers (Image-to-Video + ChatGPT/OpenAI), per-panel animation settings,
camera motion, subtitle timing, timeline management, and export tracking.

## New Tables

### 1. `ai_video_providers` — Configurable AI video generation providers
- `id` (uuid PK)
- `name` (text) — display name (e.g. "Runway", "Stable Video Diffusion")
- `provider_type` (text) — 'image-to-video' or 'text-to-video'
- `api_key` (text, nullable) — stored encrypted server-side, never exposed to client
- `api_endpoint` (text) — the provider's API URL
- `model_name` (text) — model identifier
- `is_enabled` (boolean, default false)
- `is_default` (boolean, default false) — only one provider should be default
- `config` (jsonb) — extra provider-specific settings
- `created_at`, `updated_at` (timestamps)

### 2. `ai_provider_settings` — Global AI settings (single-row config table)
- `id` (uuid PK)
- `openai_api_key` (text, nullable) — ChatGPT/OpenAI key for panel analysis
- `openai_model` (text, default 'gpt-4o')
- `default_video_provider_id` (uuid, FK to ai_video_providers, nullable)
- `default_duration` (int, default 4) — seconds per panel
- `max_duration` (int, default 10)
- `image_to_video_enabled` (boolean, default false)
- `chatgpt_enabled` (boolean, default false)
- `subtitle_ai_enabled` (boolean, default true)
- `created_at`, `updated_at` (timestamps)

### 3. `comic_panel_animations` — Animation generation jobs per panel
- `id` (uuid PK)
- `panel_id` (uuid FK→comic_panels CASCADE)
- `status` (text) — 'pending', 'processing', 'completed', 'failed', 'cancelled'
- `provider_id` (uuid, FK to ai_video_providers, nullable)
- `provider_name` (text) — snapshot of provider used
- `model_used` (text) — snapshot of model name
- `video_url` (text, nullable) — generated video URL
- `duration` (int, default 4) — requested duration in seconds
- `camera_motion` (text, default 'static') — static, zoom_in, zoom_out, pan_left, pan_right, subtle
- `animation_prompt` (text) — the prompt sent to the video model
- `chatgpt_analysis` (jsonb) — structured analysis from ChatGPT
- `error_message` (text, nullable)
- `retry_count` (int, default 0)
- `created_at`, `updated_at`, `completed_at` (timestamps)

### 4. `comic_panel_subtitles` — Timed subtitles for animated panels
- `id` (uuid PK)
- `panel_id` (uuid FK→comic_panels CASCADE)
- `text` (text) — subtitle content
- `start_time` (float) — seconds from panel start
- `end_time` (float) — seconds from panel start
- `language` (text, default 'ku')
- `position_x`, `position_y` (float, default 0.5, 0.85) — relative position 0-1
- `font_family` (text, default 'sans-serif')
- `font_size` (int, default 16)
- `text_color` (text, default '#ffffff')
- `bg_color` (text, default '#000000')
- `bg_opacity` (float, default 0.75)
- `text_align` (text, default 'center')
- `is_ai_generated` (boolean, default false)
- `created_at` (timestamp)

### 5. `comic_character_refs` — Extended character reference data
- `id` (uuid PK)
- `content_id` (uuid FK→content CASCADE)
- `character_id` (uuid, FK→comic_characters SET NULL, nullable)
- `name` (text)
- `description` (text, nullable)
- `clothing` (text, nullable)
- `hair` (text, nullable)
- `eye_color` (text, nullable)
- `reference_image_url` (text, nullable) — uploaded reference image
- `dialogue_sample` (text, nullable)
- `created_at`, `updated_at` (timestamps)

## Modified Tables
None — all existing tables remain unchanged. `comic_panels.video_url` already exists and will be updated when animation completes.

## Security
- RLS enabled on all new tables.
- `ai_video_providers` and `ai_provider_settings`: SELECT restricted to authenticated users (admin only in practice), CRUD to authenticated. API keys are stored but the client never queries raw key values — the edge function reads them server-side.
- `comic_panel_animations`, `comic_panel_subtitles`, `comic_character_refs`: public SELECT (anon + authenticated) so readers can view animations; CRUD to authenticated.

## Notes
1. API keys in `ai_video_providers.api_key` and `ai_provider_settings.openai_api_key` are only read by edge functions using the service role key — the frontend never queries these columns directly.
2. The `comic_panel_animations` table tracks each generation attempt so retries don't lose history.
3. `chatgpt_analysis` stores the structured JSON from ChatGPT panel analysis (characters, dialogue, scene, motion, etc.).
*/
