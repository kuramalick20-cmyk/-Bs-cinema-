/*
# Kurdish Channel Content System

1. New Tables
- `kurdish_channel_content` — stores content items (movies, series, programs, episodes, trailers) 
  associated with Kurdish TV channels (Kurdsat, KurdMax, NRT, NRT2, AVA Media, Afrin Kids, WWE).
  - `id` (uuid, primary key)
  - `channel_id` (text, not null) — channel identifier (kurdsat, kurdmax, nrt, nrt2, ava-media, afrin-kids, wwe)
  - `title` (text, not null) — content title
  - `description` (text, nullable) — content description
  - `content_type` (text, not null) — one of: movie, series, program, episode, trailer, live
  - `video_type` (text, not null) — one of: upload, link, gdrive
  - `video_url` (text, not null) — URL to the video (uploaded file, YouTube link, or Google Drive link)
  - `thumbnail_url` (text, nullable) — cover/thumbnail image URL
  - `episode_number` (integer, nullable) — episode number for episodic content
  - `is_active` (boolean, default true) — whether the content is visible
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `kurdish_channel_content`.
- Public read: anyone (anon + authenticated) can view active content.
- Admin-only write: only authenticated users with is_admin=true can insert, update, delete.
  Uses a SECURITY DEFINER function `is_admin_user()` to check admin status safely.

3. Indexes
- Index on `channel_id` for fast channel-based filtering.
- Index on `content_type` for fast category-based filtering.
*/

CREATE TABLE IF NOT EXISTS kurdish_channel_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id text NOT NULL,
  title text NOT NULL,
  description text,
  content_type text NOT NULL DEFAULT 'program',
  video_type text NOT NULL DEFAULT 'link',
  video_url text NOT NULL,
  thumbnail_url text,
  episode_number integer,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE kurdish_channel_content ENABLE ROW LEVEL SECURITY;

-- Helper function to check if the current user is an admin
CREATE OR REPLACE FUNCTION is_admin_user()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  );
$$;

-- Public read policy
DROP POLICY IF EXISTS "public_read_channel_content" ON kurdish_channel_content;
CREATE POLICY "public_read_channel_content"
ON kurdish_channel_content FOR SELECT
TO anon, authenticated
USING (is_active = true);

-- Admin insert policy
DROP POLICY IF EXISTS "admin_insert_channel_content" ON kurdish_channel_content;
CREATE POLICY "admin_insert_channel_content"
ON kurdish_channel_content FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

-- Admin update policy
DROP POLICY IF EXISTS "admin_update_channel_content" ON kurdish_channel_content;
CREATE POLICY "admin_update_channel_content"
ON kurdish_channel_content FOR UPDATE
TO authenticated
USING (is_admin_user()) WITH CHECK (is_admin_user());

-- Admin delete policy
DROP POLICY IF EXISTS "admin_delete_channel_content" ON kurdish_channel_content;
CREATE POLICY "admin_delete_channel_content"
ON kurdish_channel_content FOR DELETE
TO authenticated
USING (is_admin_user());

-- Indexes
CREATE INDEX IF NOT EXISTS idx_kcc_channel_id ON kurdish_channel_content(channel_id);
CREATE INDEX IF NOT EXISTS idx_kcc_content_type ON kurdish_channel_content(content_type);
CREATE INDEX IF NOT EXISTS idx_kcc_created_at ON kurdish_channel_content(created_at DESC);
