/*
# Add Comic Chapter Videos

## Overview
Adds a new table `comic_chapter_videos` for storing separate videos that belong
to a comic chapter. These videos are completely separate from comic image panels —
they do NOT become panels and panels do NOT become videos. A chapter can have both
comic images (in `comic_panels`) and separate videos (in `comic_chapter_videos`).

## New Tables
1. **comic_chapter_videos** — separate video entries for a comic chapter
   - `id` (uuid, primary key)
   - `chapter_id` (uuid, FK to comic_chapters, ON DELETE CASCADE)
   - `title` (text, optional title for the video)
   - `video_type` (text: 'upload', 'link', or 'gdrive')
   - `video_url` (text, URL to the video file or external link)
   - `video_order` (int, for sorting multiple videos within a chapter)
   - `created_at` (timestamptz)

## Security
- Enable RLS on `comic_chapter_videos`.
- Public read (anon + authenticated) — comic content is public, same as other comic tables.
- Public write (anon + authenticated) — admin manages videos, same pattern as comic_panels.

## Important Notes
1. This table is completely separate from `comic_panels`.
2. Videos uploaded here do NOT appear as comic image panels.
3. A chapter can have both images (comic_panels) and videos (comic_chapter_videos).
4. Multiple videos can be added to a single chapter.
5. No existing tables or data are modified.
*/

CREATE TABLE IF NOT EXISTS comic_chapter_videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chapter_id uuid NOT NULL REFERENCES comic_chapters(id) ON DELETE CASCADE,
  title text,
  video_type text NOT NULL DEFAULT 'upload' CHECK (video_type IN ('upload', 'link', 'gdrive')),
  video_url text NOT NULL,
  video_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE comic_chapter_videos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_comic_chapter_videos" ON comic_chapter_videos;
CREATE POLICY "public_select_comic_chapter_videos" ON comic_chapter_videos FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_comic_chapter_videos" ON comic_chapter_videos;
CREATE POLICY "public_insert_comic_chapter_videos" ON comic_chapter_videos FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_update_comic_chapter_videos" ON comic_chapter_videos;
CREATE POLICY "public_update_comic_chapter_videos" ON comic_chapter_videos FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "public_delete_comic_chapter_videos" ON comic_chapter_videos;
CREATE POLICY "public_delete_comic_chapter_videos" ON comic_chapter_videos FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_comic_chapter_videos_chapter ON comic_chapter_videos(chapter_id);

-- Also allow anon to write to videos bucket (for admin panel when not signed in)
DROP POLICY IF EXISTS "anon_write_chapter_videos" ON storage.objects;
CREATE POLICY "anon_write_chapter_videos" ON storage.objects FOR INSERT
  TO anon WITH CHECK (bucket_id = 'videos');
