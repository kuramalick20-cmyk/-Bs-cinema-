/*
# Add chat message features: media, edit, delete, reactions

1. Modified Tables
- `chat_messages`
  - `image_url` (text, nullable) — URL of sent image in chat-media storage bucket
  - `video_url` (text, nullable) — URL of sent short video (max 60s) in chat-media bucket
  - `edited_at` (timestamptz, nullable) — timestamp when message was last edited
  - `deleted_at` (timestamptz, nullable) — soft-delete timestamp; message content is cleared
  - `reactions` (jsonb, nullable) — map of user_id -> emoji string for reactions

2. New Storage Bucket
- `chat-media` — for storing images and short videos sent in chat
  - INSERT policy: authenticated users can upload
  - SELECT policy: public read (anon + authenticated)
  - DELETE policy: owner can delete their own uploads

3. Security Changes
- Update existing INSERT policy on chat_messages to allow new columns (already open to authenticated).
- Add UPDATE policy so users can edit/delete their own messages (set edited_at / deleted_at / reactions).
- No new RLS on chat_messages table itself — existing policies already cover SELECT/INSERT.
- Storage policies for chat-media bucket added.

4. Important Notes
- `message_type` column already exists as text; we extend its meaning to include 'image' and 'video'.
  No ALTER needed — the text column accepts any string value.
- `reactions` is a jsonb column storing { "user_uuid": "emoji" } pairs.
- Soft delete: when a user deletes their message, `deleted_at` is set and `text`/`image_url`/`video_url` are nulled.
  The message row remains so conversation history stays intact.
- Existing data is untouched — all new columns are nullable with no NOT NULL constraint.
*/

-- Add new columns to chat_messages
ALTER TABLE chat_messages
  ADD COLUMN IF NOT EXISTS image_url text,
  ADD COLUMN IF NOT EXISTS video_url text,
  ADD COLUMN IF NOT EXISTS edited_at timestamptz,
  ADD COLUMN IF NOT EXISTS deleted_at timestamptz,
  ADD COLUMN IF NOT EXISTS reactions jsonb;

-- Allow users to update their own messages (edit text, soft-delete, add reactions)
DROP POLICY IF EXISTS "user_update_own_messages" ON chat_messages;
CREATE POLICY "user_update_own_messages"
ON chat_messages FOR UPDATE
TO authenticated
USING (sender_id = auth.uid())
WITH CHECK (sender_id = auth.uid());

-- Allow users to delete their own messages (hard delete if needed, though soft-delete preferred)
DROP POLICY IF EXISTS "user_delete_own_messages" ON chat_messages;
CREATE POLICY "user_delete_own_messages"
ON chat_messages FOR DELETE
TO authenticated
USING (sender_id = auth.uid());

-- Create chat-media storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-media', 'chat-media', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for chat-media bucket
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'chat_media_upload_authenticated' AND tablename = 'objects') THEN
    CREATE POLICY "chat_media_upload_authenticated"
    ON storage.objects FOR INSERT TO authenticated
    WITH CHECK (bucket_id = 'chat-media');
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'chat_media_read_public' AND tablename = 'objects') THEN
    CREATE POLICY "chat_media_read_public"
    ON storage.objects FOR SELECT TO anon, authenticated
    USING (bucket_id = 'chat-media');
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'chat_media_delete_owner' AND tablename = 'objects') THEN
    CREATE POLICY "chat_media_delete_owner"
    ON storage.objects FOR DELETE TO authenticated
    USING (bucket_id = 'chat-media' AND owner = auth.uid());
  END IF;
END $$;
