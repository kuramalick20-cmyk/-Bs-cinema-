/*
# Add new notification types for game invites and comments

## Changes
1. notifications: Expand the `type` CHECK constraint to include 'game_invite' and 'comment_reply' types
2. This allows the app to create notifications when:
   - A user invites another user to a chess/domino game
   - A user replies to content with a comment

## Security
- No RLS policy changes — existing policies still apply
- The insert policy allows anon+authenticated to insert (needed for client-side notification creation)
*/

ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_type_check;

ALTER TABLE notifications ADD CONSTRAINT notifications_type_check
CHECK (type IN ('new_content', 'new_episode', 'new_chapter', 'new_vip_content', 'chat_message', 'game_invite', 'comment_reply'));
