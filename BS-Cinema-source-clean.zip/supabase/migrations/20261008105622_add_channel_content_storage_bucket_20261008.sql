/*
# Storage bucket for Kurdish channel content

1. New Storage Bucket
- `channel-content` — stores video files and thumbnail images uploaded for 
  Kurdish channel content (movies, series, programs, episodes, trailers).

2. Storage Policies
- Public read: anyone can view channel content files.
- Authenticated write: any logged-in user can upload (admin gating is enforced 
  at the database RLS level on kurdish_channel_content table).
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('channel-content', 'channel-content', true)
ON CONFLICT (id) DO NOTHING;

-- Public read policy
DROP POLICY IF EXISTS "public_read_channel_content_bucket" ON storage.objects;
CREATE POLICY "public_read_channel_content_bucket"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'channel-content');

-- Authenticated upload policy
DROP POLICY IF EXISTS "auth_upload_channel_content_bucket" ON storage.objects;
CREATE POLICY "auth_upload_channel_content_bucket"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'channel-content');

-- Authenticated update policy (for replacing thumbnails)
DROP POLICY IF EXISTS "auth_update_channel_content_bucket" ON storage.objects;
CREATE POLICY "auth_update_channel_content_bucket"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'channel-content') WITH CHECK (bucket_id = 'channel-content');

-- Authenticated delete policy
DROP POLICY IF EXISTS "auth_delete_channel_content_bucket" ON storage.objects;
CREATE POLICY "auth_delete_channel_content_bucket"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'channel-content');
