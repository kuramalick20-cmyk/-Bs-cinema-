/*
# Storage policy for chat-audio bucket — voice messages
*/

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'chat_audio_upload_authenticated' AND tablename = 'objects') THEN
    CREATE POLICY "chat_audio_upload_authenticated"
    ON storage.objects FOR INSERT TO authenticated
    WITH CHECK (bucket_id = 'chat-audio');
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'chat_audio_read_public' AND tablename = 'objects') THEN
    CREATE POLICY "chat_audio_read_public"
    ON storage.objects FOR SELECT TO anon, authenticated
    USING (bucket_id = 'chat-audio');
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'chat_audio_delete_owner' AND tablename = 'objects') THEN
    CREATE POLICY "chat_audio_delete_owner"
    ON storage.objects FOR DELETE TO authenticated
    USING (bucket_id = 'chat-audio' AND owner = auth.uid());
  END IF;
END $$;
