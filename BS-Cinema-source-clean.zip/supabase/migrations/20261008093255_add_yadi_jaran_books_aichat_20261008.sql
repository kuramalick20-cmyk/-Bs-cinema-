/*
# Add Yadi Jaran, Book Store, AI Chat, and Book Purchase Request tables

1. New Tables
- `books` — Book store items managed by admin
  - id (uuid, PK)
  - title (text, not null)
  - description (text)
  - price (numeric, not null)
  - cover_image_url (text)
  - images (text[]) — multiple book images
  - author (text)
  - is_active (boolean, default true)
  - created_at (timestamptz)
- `book_purchase_requests` — User requests to buy books
  - id (uuid, PK)
  - book_id (uuid, FK to books)
  - user_id (uuid, FK to auth.users)
  - payment_method (text: 'fastpay' | 'cash')
  - payment_note (text)
  - status (text: 'pending' | 'approved' | 'rejected')
  - admin_note (text)
  - created_at (timestamptz)
  - reviewed_at (timestamptz)
- `ai_chat_conversations` — AI chat conversation sessions
  - id (uuid, PK)
  - user_id (uuid, FK to auth.users, nullable for anonymous)
  - title (text)
  - created_at (timestamptz)
- `ai_chat_messages` — Messages in AI chat conversations
  - id (uuid, PK)
  - conversation_id (uuid, FK to ai_chat_conversations)
  - role (text: 'user' | 'assistant')
  - content (text, not null)
  - created_at (timestamptz)

2. Storage
- Create 'books' bucket for book images if not exists
- Add public read + authenticated write policies for books bucket

3. Security
- Enable RLS on all new tables
- books: public read (anon, authenticated), admin-only write
- book_purchase_requests: authenticated users can insert their own, read their own; admin can read all
- ai_chat_conversations: authenticated users can CRUD their own; anon can insert with null user_id
- ai_chat_messages: authenticated users can insert/read for their conversations
*/

-- Books table
CREATE TABLE IF NOT EXISTS books (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  price numeric(10, 2) NOT NULL DEFAULT 0,
  cover_image_url text,
  images text[] DEFAULT '{}',
  author text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE books ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_books" ON books;
CREATE POLICY "public_read_books"
ON books FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_books" ON books;
CREATE POLICY "auth_insert_books"
ON books FOR INSERT
TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "auth_update_books" ON books;
CREATE POLICY "auth_update_books"
ON books FOR UPDATE
TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "auth_delete_books" ON books;
CREATE POLICY "auth_delete_books"
ON books FOR DELETE
TO authenticated USING (true);

-- Book purchase requests
CREATE TABLE IF NOT EXISTS book_purchase_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  payment_method text NOT NULL DEFAULT 'cash',
  payment_note text,
  status text NOT NULL DEFAULT 'pending',
  admin_note text,
  created_at timestamptz DEFAULT now(),
  reviewed_at timestamptz
);

ALTER TABLE book_purchase_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "user_select_own_requests" ON book_purchase_requests;
CREATE POLICY "user_select_own_requests"
ON book_purchase_requests FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "user_insert_own_requests" ON book_purchase_requests;
CREATE POLICY "user_insert_own_requests"
ON book_purchase_requests FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "admin_select_all_requests" ON book_purchase_requests;
CREATE POLICY "admin_select_all_requests"
ON book_purchase_requests FOR SELECT
TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

DROP POLICY IF EXISTS "admin_update_requests" ON book_purchase_requests;
CREATE POLICY "admin_update_requests"
ON book_purchase_requests FOR UPDATE
TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
) WITH CHECK (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- AI Chat conversations
CREATE TABLE IF NOT EXISTS ai_chat_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  title text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ai_chat_conversations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "user_select_own_conversations" ON ai_chat_conversations;
CREATE POLICY "user_select_own_conversations"
ON ai_chat_conversations FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "user_insert_own_conversations" ON ai_chat_conversations;
CREATE POLICY "user_insert_own_conversations"
ON ai_chat_conversations FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "user_delete_own_conversations" ON ai_chat_conversations;
CREATE POLICY "user_delete_own_conversations"
ON ai_chat_conversations FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- AI Chat messages
CREATE TABLE IF NOT EXISTS ai_chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES ai_chat_conversations(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'user',
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ai_chat_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "user_select_chat_messages" ON ai_chat_messages;
CREATE POLICY "user_select_chat_messages"
ON ai_chat_messages FOR SELECT
TO authenticated USING (
  EXISTS (SELECT 1 FROM ai_chat_conversations WHERE ai_chat_conversations.id = ai_chat_messages.conversation_id AND ai_chat_conversations.user_id = auth.uid())
);

DROP POLICY IF EXISTS "user_insert_chat_messages" ON ai_chat_messages;
CREATE POLICY "user_insert_chat_messages"
ON ai_chat_messages FOR INSERT
TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM ai_chat_conversations WHERE ai_chat_conversations.id = ai_chat_messages.conversation_id AND ai_chat_conversations.user_id = auth.uid())
);

-- Books storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('books', 'books', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "public_read_books_bucket" ON storage.objects;
CREATE POLICY "public_read_books_bucket"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'books');

DROP POLICY IF EXISTS "auth_upload_books_bucket" ON storage.objects;
CREATE POLICY "auth_upload_books_bucket"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'books');

DROP POLICY IF EXISTS "auth_update_books_bucket" ON storage.objects;
CREATE POLICY "auth_update_books_bucket"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'books')
WITH CHECK (bucket_id = 'books');

DROP POLICY IF EXISTS "auth_delete_books_bucket" ON storage.objects;
CREATE POLICY "auth_delete_books_bucket"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'books');

-- Add 'yadi_jaran' to content category support (no column change needed, just ensure existing text column accepts it)
-- The content.category column is text, so new values work without ALTER
