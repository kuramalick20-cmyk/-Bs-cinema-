/*
# Fix profiles SELECT policies for admin and chat

## Summary
The profiles table only allows users to SELECT their own profile. Admins need to
see all profiles (for VIP management), and authenticated users need to search
other users by username for the chat feature. This migration adds:
- Admin SELECT all profiles
- Authenticated users can SELECT id, username, avatar_url (for user search in chat)

## Changes
- Added `admin_select_all_profiles` policy
- Added `select_profiles_for_chat` policy allowing authenticated users to see
  basic profile info (needed for finding users to chat with)
*/

-- Admin can see all profiles
DROP POLICY IF EXISTS "admin_select_all_profiles" ON profiles;
CREATE POLICY "admin_select_all_profiles"
ON profiles FOR SELECT
TO authenticated
USING (is_admin_user());

-- Authenticated users can see other profiles for chat user search
DROP POLICY IF EXISTS "select_profiles_for_chat" ON profiles;
CREATE POLICY "select_profiles_for_chat"
ON profiles FOR SELECT
TO authenticated
USING (true);
