/*
# Chat Safety Moderation System

## Purpose
Automatically detect and remove messages containing other users' social-media contact
information (TikTok, Snapchat, Instagram, Facebook, Messenger, phone numbers, etc.)
in private chat. Track repeat violations and permanently ban users after 3 strikes.
For images/videos, the system cannot inspect pixel content, so any image/video message
that contains social-media contact info in its caption or that is flagged will also
trigger immediate moderation.

## 1. New Tables
- `chat_violations` — one row per violation event
  - `id` (uuid, PK)
  - `user_id` (uuid, FK -> profiles.id) — the user who committed the violation
  - `message_id` (uuid, FK -> chat_messages.id) — the moderated message
  - `conversation_id` (uuid, FK -> chat_conversations.id)
  - `reason` (text) — which pattern was matched (e.g. "tiktok", "phone_number")
  - `matched_text` (text) — the snippet that triggered the violation
  - `message_type` (text) — 'text', 'image', 'video', 'voice'
  - `created_at` (timestamptz, default now())

## 2. Modified Tables
- `profiles`
  - `banned_at` (timestamptz, nullable) — set when user is permanently banned (3rd violation)
  - `ban_reason` (text, nullable) — reason for ban
- `chat_messages`
  - `moderation_status` (text, nullable, default null) — 'flagged' when auto-moderated
  - `moderation_reason` (text, nullable) — what pattern triggered the flag

## 3. Security
- `chat_violations` table: RLS enabled. Users can read their own violations.
  INSERT is done via SECURITY DEFINER function (service-role level), not direct client inserts.
- New SECURITY DEFINER function `moderate_chat_message`:
  - Called by a trigger AFTER INSERT on chat_messages
  - Scans message text for social-media contact patterns
  - If matched: soft-deletes the message, records a violation, bans on 3rd strike
  - Runs with elevated privileges so it can update any user's message and profiles
- UPDATE policy on chat_messages is tightened: the function uses SECURITY DEFINER
  to bypass RLS for moderation actions. Users can still update/delete their own messages.
- Profiles UPDATE policy: existing policies remain. The ban is applied via the
  SECURITY DEFINER function, not client-side.

## 4. How It Works
1. User sends a chat message (text, image, video, or voice).
2. AFTER INSERT trigger calls `moderate_chat_message(NEW)`.
3. The function checks the message text/caption for patterns:
   - TikTok: tiktok.com, @tiktok, tiktok username
   - Snapchat: snapchat.com, @snapchat, snapchat add
   - Instagram: instagram.com, @instagram, insta
   - Facebook: facebook.com, fb.com, messenger
   - Phone: phone number patterns (international and local)
   - Other: telegram, whatsapp, viber, signal handles
4. If a pattern matches:
   a. The message is soft-deleted (deleted_at set, text/media URLs nulled, moderation_status='flagged')
   b. A row is inserted into chat_violations
   c. The user's violation count is checked
   d. 1st & 2nd: warning (message deleted, user sees warning)
   e. 3rd: banned_at set on profiles, user can no longer send messages
5. For image/video messages: if the text/caption contains contact info, same flow.
   If no caption, the message is allowed (we cannot inspect image pixels server-side).

## 5. Important Notes
- Enforcement is entirely backend (trigger + SECURITY DEFINER function). It cannot
  be bypassed by modifying frontend code.
- The trigger runs synchronously during INSERT, so the moderated message is deleted
  before the client ever sees it in the realtime feed.
- Banned users (banned_at IS NOT NULL) are blocked from inserting new messages via
  a CHECK constraint on the INSERT path (the function raises an exception).
- The function is idempotent: if called twice for the same message, it does nothing.
*/

-- ============================================================
-- 1. Add banned_at and ban_reason to profiles
-- ============================================================
ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS banned_at timestamptz,
  ADD COLUMN IF NOT EXISTS ban_reason text;

-- ============================================================
-- 2. Add moderation columns to chat_messages
-- ============================================================
ALTER TABLE chat_messages
  ADD COLUMN IF NOT EXISTS moderation_status text,
  ADD COLUMN IF NOT EXISTS moderation_reason text;

-- ============================================================
-- 3. Create chat_violations table
-- ============================================================
CREATE TABLE IF NOT EXISTS chat_violations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  message_id uuid REFERENCES chat_messages(id) ON DELETE CASCADE,
  conversation_id uuid NOT NULL REFERENCES chat_conversations(id) ON DELETE CASCADE,
  reason text NOT NULL,
  matched_text text,
  message_type text DEFAULT 'text',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE chat_violations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_violations" ON chat_violations;
CREATE POLICY "select_own_violations"
ON chat_violations FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE INDEX IF NOT EXISTS idx_chat_violations_user ON chat_violations(user_id, created_at DESC);

-- ============================================================
-- 4. Block banned users from inserting chat messages
-- ============================================================
-- We tighten the existing INSERT policy to also check the user is not banned.
DROP POLICY IF EXISTS "insert_own_messages" ON chat_messages;
CREATE POLICY "insert_own_messages"
ON chat_messages FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = sender_id
  AND EXISTS (
    SELECT 1 FROM chat_conversations
    WHERE chat_conversations.id = chat_messages.conversation_id
    AND (chat_conversations.user1_id = auth.uid() OR chat_conversations.user2_id = auth.uid())
  )
  AND NOT EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND banned_at IS NOT NULL
  )
);

-- ============================================================
-- 5. SECURITY DEFINER function: moderate_chat_message
-- ============================================================
-- This function is called by a trigger AFTER INSERT on chat_messages.
-- It scans the message for social-media contact patterns and takes action.
CREATE OR REPLACE FUNCTION moderate_chat_message()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  v_pattern text;
  v_matched text;
  v_violation_count integer;
  v_reason text;
  v_text_to_check text;
BEGIN
  -- Skip if already moderated
  IF NEW.moderation_status = 'flagged' THEN
    RETURN NEW;
  END IF;

  -- Build the text to scan: message text + any caption-like content
  v_text_to_check := COALESCE(NEW.text, '');

  -- If empty text and no media, nothing to check
  IF v_text_to_check = '' AND NEW.image_url IS NULL AND NEW.video_url IS NULL AND NEW.audio_url IS NULL THEN
    RETURN NEW;
  END IF;

  -- Check for social media contact patterns (case-insensitive)
  -- Using a series of regex checks to find the first match
  v_pattern := NULL;
  v_matched := NULL;
  v_reason := NULL;

  -- TikTok
  IF v_text_to_check ~* '(tiktok\.com\/|tiktok\.com$|@[a-z0-9_.]+\s*(?:on\s+)?tiktok|tiktok\s*[:@]\s*@?[a-z0-9_.]+|add\s+me\s+(?:on\s+)?tiktok|tiktok\s+id)' THEN
    v_pattern := 'tiktok';
    v_reason := 'TikTok contact information detected';
    v_matched := SUBSTRING(v_text_to_check FROM '(tiktok[^\s]*|@[a-z0-9_.]+\s*(?:on\s+)?tiktok[a-z0-9_.]*|tiktok\s*[:@]\s*@?[a-z0-9_.]+)');
  -- Snapchat
  ELSIF v_text_to_check ~* '(snapchat\.com\/|snapchat\.com$|@[a-z0-9_.]+\s*(?:on\s+)?snapchat|snap\s*[:@]\s*@?[a-z0-9_.]+|add\s+me\s+(?:on\s+)?snapchat|snapchat\s+id|snap\s+chat)' THEN
    v_pattern := 'snapchat';
    v_reason := 'Snapchat contact information detected';
    v_matched := SUBSTRING(v_text_to_check FROM '(snapchat[^\s]*|@[a-z0-9_.]+\s*(?:on\s+)?snapchat[a-z0-9_.]*|snap\s*[:@]\s*@?[a-z0-9_.]+)');
  -- Instagram
  ELSIF v_text_to_check ~* '(instagram\.com\/|instagram\.com$|@[a-z0-9_.]+\s*(?:on\s+)?insta(?:gram)?|insta(?:gram)?\s*[:@]\s*@?[a-z0-9_.]+|add\s+me\s+(?:on\s+)?insta(?:gram)?|insta(?:gram)?\s+id)' THEN
    v_pattern := 'instagram';
    v_reason := 'Instagram contact information detected';
    v_matched := SUBSTRING(v_text_to_check FROM '(instagram[^\s]*|@[a-z0-9_.]+\s*(?:on\s+)?insta(?:gram)?[a-z0-9_.]*|insta(?:gram)?\s*[:@]\s*@?[a-z0-9_.]+)');
  -- Facebook / Messenger
  ELSIF v_text_to_check ~* '(facebook\.com\/|facebook\.com$|fb\.com\/|fb\.me\/|@[a-z0-9_.]+\s*(?:on\s+)?facebook|messenger\s*[:@]\s*@?[a-z0-9_.]+|add\s+me\s+(?:on\s+)?facebook|m\.me\/[a-z0-9_.]+|messenger\s+id)' THEN
    v_pattern := 'facebook';
    v_reason := 'Facebook/Messenger contact information detected';
    v_matched := SUBSTRING(v_text_to_check FROM '(facebook[^\s]*|fb\.(com|me)[^\s]*|@[a-z0-9_.]+\s*(?:on\s+)?facebook[a-z0-9_.]*|m\.me/[a-z0-9_.]+|messenger\s*[:@]\s*@?[a-z0-9_.]+)');
  -- Phone numbers (international format +964, +963, +90, +1, etc. or local 07XX XXX XXXX)
  ELSIF v_text_to_check ~* '(\+?\d[\d\s\-()]{7,}\d)' AND v_text_to_check ~* '(\+\d{1,3}[\s\-]?\d|07[3-9]\d{1}\s?\d{3}\s?\d{3,4})' THEN
    v_pattern := 'phone_number';
    v_reason := 'Phone number detected';
    v_matched := SUBSTRING(v_text_to_check FROM '(\+?\d[\d\s\-()]{7,}\d)');
  -- Telegram
  ELSIF v_text_to_check ~* '(t\.me\/[a-z0-9_]+|telegram\.me\/[a-z0-9_]+|@[a-z0-9_]+\s*(?:on\s+)?telegram|telegram\s*[:@]\s*@?[a-z0-9_]+|add\s+me\s+(?:on\s+)?telegram)' THEN
    v_pattern := 'telegram';
    v_reason := 'Telegram contact information detected';
    v_matched := SUBSTRING(v_text_to_check FROM '(t\.me/[a-z0-9_]+|telegram\.me/[a-z0-9_]+|@[a-z0-9_]+\s*(?:on\s+)?telegram[a-z0-9_]*|telegram\s*[:@]\s*@?[a-z0-9_]+)');
  -- WhatsApp
  ELSIF v_text_to_check ~* '(wa\.me\/\d+|whatsapp\s*[:@]\s*@?[a-z0-9_]+|@[a-z0-9_]+\s*(?:on\s+)?whatsapp|add\s+me\s+(?:on\s+)?whatsapp|whats\s*app\s+number)' THEN
    v_pattern := 'whatsapp';
    v_reason := 'WhatsApp contact information detected';
    v_matched := SUBSTRING(v_text_to_check FROM '(wa\.me/\d+|whatsapp[^\s]*|@[a-z0-9_]+\s*(?:on\s+)?whatsapp[a-z0-9_]*|whatsapp\s*[:@]\s*@?[a-z0-9_]+)');
  -- Viber
  ELSIF v_text_to_check ~* '(viber\s*[:@]\s*@?[a-z0-9_]+|@[a-z0-9_]+\s*(?:on\s+)?viber|add\s+me\s+(?:on\s+)?viber)' THEN
    v_pattern := 'viber';
    v_reason := 'Viber contact information detected';
    v_matched := SUBSTRING(v_text_to_check FROM '(viber[^\s]*|@[a-z0-9_]+\s*(?:on\s+)?viber[a-z0-9_]*|viber\s*[:@]\s*@?[a-z0-9_]+)');
  -- Signal
  ELSIF v_text_to_check ~* '(signal\.org\/|s\.sg\/|@[a-z0-9_]+\s*(?:on\s+)?signal|signal\s*[:@]\s*@?[a-z0-9_]+|add\s+me\s+(?:on\s+)?signal)' THEN
    v_pattern := 'signal';
    v_reason := 'Signal contact information detected';
    v_matched := SUBSTRING(v_text_to_check FROM '(signal[^\s]*|@[a-z0-9_]+\s*(?:on\s+)?signal[a-z0-9_]*|signal\s*[:@]\s*@?[a-z0-9_]+)');
  -- Twitter / X
  ELSIF v_text_to_check ~* '(twitter\.com\/|x\.com\/|@[a-z0-9_]+\s*(?:on\s+)?twitter|twitter\s*[:@]\s*@?[a-z0-9_]+|add\s+me\s+(?:on\s+)?twitter)' THEN
    v_pattern := 'twitter';
    v_reason := 'Twitter/X contact information detected';
    v_matched := SUBSTRING(v_text_to_check FROM '(twitter[^\s]*|x\.com/[a-z0-9_]+|@[a-z0-9_]+\s*(?:on\s+)?twitter[a-z0-9_]*|twitter\s*[:@]\s*@?[a-z0-9_]+)');
  END IF;

  -- If no pattern matched, allow the message
  IF v_pattern IS NULL THEN
    RETURN NEW;
  END IF;

  -- Pattern matched: moderate the message
  -- 1. Soft-delete the message content
  UPDATE chat_messages
  SET
    deleted_at = now(),
    text = NULL,
    image_url = NULL,
    video_url = NULL,
    audio_url = NULL,
    moderation_status = 'flagged',
    moderation_reason = v_pattern
  WHERE id = NEW.id;

  -- 2. Record the violation
  INSERT INTO chat_violations (user_id, message_id, conversation_id, reason, matched_text, message_type)
  VALUES (NEW.sender_id, NEW.id, NEW.conversation_id, v_pattern, v_matched, NEW.message_type);

  -- 3. Count prior violations for this user (excluding the one we just inserted)
  SELECT count(*) INTO v_violation_count
  FROM chat_violations
  WHERE user_id = NEW.sender_id;

  -- 4. On 3rd violation, ban the user
  IF v_violation_count >= 3 THEN
    UPDATE profiles
    SET banned_at = now(), ban_reason = 'Automatic ban: 3 chat violations (' || v_pattern || ')'
    WHERE id = NEW.sender_id AND banned_at IS NULL;
  END IF;

  -- Return the modified NEW (so the trigger sees the updated state)
  NEW.deleted_at := now();
  NEW.text := NULL;
  NEW.image_url := NULL;
  NEW.video_url := NULL;
  NEW.audio_url := NULL;
  NEW.moderation_status := 'flagged';
  NEW.moderation_reason := v_pattern;

  RETURN NEW;
END;
$$;

-- ============================================================
-- 6. Trigger: auto-moderate after insert
-- ============================================================
DROP TRIGGER IF EXISTS trg_moderate_chat_message ON chat_messages;
CREATE TRIGGER trg_moderate_chat_message
AFTER INSERT ON chat_messages
FOR EACH ROW
EXECUTE FUNCTION moderate_chat_message();

-- ============================================================
-- 7. Grant execute on the moderation function
-- ============================================================
GRANT EXECUTE ON FUNCTION moderate_chat_message() TO authenticated;

-- ============================================================
-- 8. Index for faster violation counting
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_chat_violations_user_count ON chat_violations(user_id);
