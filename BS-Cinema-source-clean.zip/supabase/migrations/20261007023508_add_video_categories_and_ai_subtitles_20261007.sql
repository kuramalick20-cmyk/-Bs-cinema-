/*
# Add Video Categories and AI Subtitle Support

## Overview
1. Expands the content category constraint to include new video categories:
   - cartoon_series, animation_series, anime_movies, movies
2. Adds AI subtitle generation support columns to the existing subtitles table:
   - is_ai_generated (boolean, whether subtitle was AI-generated)
   - ai_status (text: 'pending', 'processing', 'completed', 'failed')
   - source_text (text, the original transcribed text before translation)
3. Adds an ai_subtitle_jobs table to track subtitle generation requests.

## Modified Tables
1. **content** — category CHECK constraint updated to allow new values
2. **subtitles** — 3 new columns added (is_ai_generated, ai_status, source_text)

## New Tables
1. **ai_subtitle_jobs** — tracks AI subtitle generation requests
   - id (uuid PK)
   - episode_id (uuid FK to episodes, CASCADE)
   - language (text: 'ku' or 'en')
   - status (text: 'pending', 'processing', 'completed', 'failed')
   - error_message (text, nullable)
   - created_at (timestamptz)
   - completed_at (timestamptz, nullable)

## Security
- ai_subtitle_jobs: public read/write (same pattern as other content tables)
- subtitles: existing policies remain unchanged; new columns are accessible

## Important Notes
1. No existing data is modified or deleted.
2. The category constraint is dropped and recreated to include new values.
3. The subtitles table gains columns but existing rows are unaffected (new columns default appropriately).
4. 'movie' category is retained as 'General Movies' alongside new 'anime_movies' and 'movies'.
*/

-- === Update content category constraint ===
ALTER TABLE content DROP CONSTRAINT IF EXISTS content_category_check;

ALTER TABLE content ADD CONSTRAINT content_category_check
  CHECK (category IN ('comic', 'series', 'movie', 'anime', 'anime_series', 'animation',
    'cartoon_series', 'animation_series', 'anime_movies', 'movies'));

-- === Add AI subtitle columns to subtitles table ===
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'subtitles' AND column_name = 'is_ai_generated') THEN
    ALTER TABLE subtitles ADD COLUMN is_ai_generated boolean DEFAULT false;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'subtitles' AND column_name = 'ai_status') THEN
    ALTER TABLE subtitles ADD COLUMN ai_status text DEFAULT NULL;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'subtitles' AND column_name = 'source_text') THEN
    ALTER TABLE subtitles ADD COLUMN source_text text;
  END IF;
END $$;

-- === Create AI subtitle jobs table ===
CREATE TABLE IF NOT EXISTS ai_subtitle_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  episode_id uuid NOT NULL REFERENCES episodes(id) ON DELETE CASCADE,
  language text NOT NULL DEFAULT 'ku' CHECK (language IN ('ku', 'en')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  error_message text,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE ai_subtitle_jobs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_ai_subtitle_jobs" ON ai_subtitle_jobs;
CREATE POLICY "public_select_ai_subtitle_jobs" ON ai_subtitle_jobs FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_ai_subtitle_jobs" ON ai_subtitle_jobs;
CREATE POLICY "public_insert_ai_subtitle_jobs" ON ai_subtitle_jobs FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_update_ai_subtitle_jobs" ON ai_subtitle_jobs;
CREATE POLICY "public_update_ai_subtitle_jobs" ON ai_subtitle_jobs FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "public_delete_ai_subtitle_jobs" ON ai_subtitle_jobs;
CREATE POLICY "public_delete_ai_subtitle_jobs" ON ai_subtitle_jobs FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_ai_subtitle_jobs_episode ON ai_subtitle_jobs(episode_id);
