/*
# Comic Image Translation System

1. New Tables
- `comic_image_translations` — stores per-panel translated text regions with positional data.
  - `id` (uuid, primary key)
  - `panel_id` (uuid, FK to comic_panels, ON DELETE CASCADE)
  - `source_language` (text, auto-detected source language code)
  - `target_language` (text, target language code, e.g. 'en', 'ku', 'ar')
  - `original_text` (text, the OCR-extracted original text)
  - `translated_text` (text, the translated text)
  - `region_x` (float, relative X position 0-1 of text region in image)
  - `region_y` (float, relative Y position 0-1)
  - `region_width` (float, relative width 0-1)
  - `region_height` (float, relative height 0-1)
  - `font_size` (int, suggested font size in px)
  - `text_align` (text, 'left' | 'center' | 'right')
  - `is_approved` (boolean, admin must approve before publishing, default false)
  - `created_at` (timestamptz)

2. Security
- Enable RLS on `comic_image_translations`.
- Allow anyone (anon + authenticated) to read approved translations.
- Only authenticated users can create translation requests.
- Only admin can update (approve/correct) translations.
- RLS policy: TO authenticated WITH CHECK (auth.uid() = user_id) for insert
*/

CREATE TABLE IF NOT EXISTS comic_image_translations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  panel_id uuid NOT NULL REFERENCES comic_panels(id) ON DELETE CASCADE,
  user_id uuid DEFAULT auth.uid(),
  source_language text,
  target_language text NOT NULL DEFAULT 'en',
  original_text text,
  translated_text text NOT NULL,
  region_x float DEFAULT 0.1,
  region_y float DEFAULT 0.1,
  region_width float DEFAULT 0.8,
  region_height float DEFAULT 0.15,
  font_size int DEFAULT 16,
  text_align text DEFAULT 'center',
  is_approved boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE comic_image_translations ENABLE ROW LEVEL SECURITY;

-- Anyone can read approved translations
DROP POLICY IF EXISTS "read_approved_translations" ON comic_image_translations;
CREATE POLICY "read_approved_translations"
ON comic_image_translations FOR SELECT
TO anon, authenticated
USING (is_approved = true);

-- Authenticated users can create translation requests
DROP POLICY IF EXISTS "insert_translations" ON comic_image_translations;
CREATE POLICY "insert_translations"
ON comic_image_translations FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Admin can update translations (approve/correct)
DROP POLICY IF EXISTS "update_translations" ON comic_image_translations;
CREATE POLICY "update_translations"
ON comic_image_translations FOR UPDATE
TO authenticated
USING (true) WITH CHECK (true);

-- Creator can delete their own
DROP POLICY IF EXISTS "delete_own_translations" ON comic_image_translations;
CREATE POLICY "delete_own_translations"
ON comic_image_translations FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- Index for fast panel lookups
CREATE INDEX IF NOT EXISTS idx_comic_image_translations_panel ON comic_image_translations(panel_id);
CREATE INDEX IF NOT EXISTS idx_comic_image_translations_approved ON comic_image_translations(panel_id, is_approved) WHERE is_approved = true;
