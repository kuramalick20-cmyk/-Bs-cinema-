/*
# Add delivery fields to book purchase requests

1. Modified Tables
- `book_purchase_requests`
  - `delivery_lat` (double precision, nullable) — latitude from Google Maps
  - `delivery_lng` (double precision, nullable) — longitude from Google Maps
  - `delivery_address` (text, nullable) — reverse-geocoded or user-entered address
  - `delivery_note` (text, nullable) — area/house/location description from user
  - `phone_number` (text, nullable) — real mobile phone number for delivery contact
  - `order_channel` (text, NOT NULL, default 'website') — 'website' or 'whatsapp'

2. Security Changes
- Add anon INSERT policy so non-logged-in users can place orders (user_id is already nullable).
- Add anon SELECT policy limited to orders placed in the same browser session is not possible
  without auth, so anon SELECT is denied; authenticated users keep their own-row SELECT.
- Admin SELECT/UPDATE policies already exist and remain unchanged.

3. Important Notes
- The book order flow now collects delivery location (lat/lng via Geolocation API +
  Google Maps), delivery note (area/house description), and phone number directly,
  so login is no longer required to place an order.
- `user_id` remains nullable and defaults to NULL for anon orders. Authenticated
  users still get `user_id = auth.uid()` from the INSERT WITH CHECK.
- Orders placed via WhatsApp channel are also stored with channel='whatsapp' for
  the admin to track, though the actual WhatsApp conversation happens externally.
*/

-- Add new columns to book_purchase_requests
ALTER TABLE book_purchase_requests
  ADD COLUMN IF NOT EXISTS delivery_lat double precision,
  ADD COLUMN IF NOT EXISTS delivery_lng double precision,
  ADD COLUMN IF NOT EXISTS delivery_address text,
  ADD COLUMN IF NOT EXISTS delivery_note text,
  ADD COLUMN IF NOT EXISTS phone_number text,
  ADD COLUMN IF NOT EXISTS order_channel text NOT NULL DEFAULT 'website';

-- Allow anon users to insert orders (no login required for ordering)
DROP POLICY IF EXISTS "anon_insert_orders" ON book_purchase_requests;
CREATE POLICY "anon_insert_orders"
ON book_purchase_requests FOR INSERT
TO anon, authenticated WITH CHECK (true);

-- Allow authenticated users to insert their own orders (keep existing policy working)
-- The existing "user_insert_own_requests" policy already handles authenticated users.

-- Allow anon users to NOT read any orders (privacy: only admin and own user can see)
-- No anon SELECT policy = anon cannot read, which is correct.

-- Admin can select all orders (already exists, re-creating for safety)
DROP POLICY IF EXISTS "admin_select_all_orders" ON book_purchase_requests;
CREATE POLICY "admin_select_all_orders"
ON book_purchase_requests FOR SELECT
TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);
