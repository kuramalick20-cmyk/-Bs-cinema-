/*
# Add panel sound and voice messages support

## Changes
1. comic_panels: Add `sound_url` column (text, nullable) for individual panel audio/sound effects
2. chat_messages: Add `audio_url` column (text, nullable) for voice message audio file URL
3. chat_messages: Add `message_type` column (text, default 'text') to distinguish text vs voice messages
4. chat_messages: Make `text` column nullable (voice messages may not have text)

## Security
- No new tables created
- Existing RLS policies on chat_messages still apply — only conversation participants can insert/select/update
- comic_panels policies unchanged — admin-only writes via existing admin policies
*/

-- Add sound_url to comic_panels for per-panel audio
ALTER TABLE comic_panels ADD COLUMN IF NOT EXISTS sound_url text;

-- Add audio_url and message_type to chat_messages for voice messages
ALTER TABLE chat_messages ADD COLUMN IF NOT EXISTS audio_url text;
ALTER TABLE chat_messages ADD COLUMN IF NOT EXISTS message_type text NOT NULL DEFAULT 'text';

-- Make text nullable so voice-only messages can omit it
ALTER TABLE chat_messages ALTER COLUMN text DROP NOT NULL;
