/*
# BS Cinema - Full Schema

## Overview
Creates the complete database schema for BS Cinema, a Kurdish (Sorani) streaming platform
with comics, series, movies, anime, and anime series. Includes content management,
episodes, comic chapters with panels, user profiles, and storage buckets for media uploads.

## New Tables

1. **content** — Main content items (movies, series, anime, comics)
   - id (uuid PK)
   - title (text, required)
   - description (text, story summary)
   - category (text: comic, series, movie, anime, anime_series)
   - cover_image_url (text, URL to uploaded cover image)
   - tags (text[], optional genre tags)
   - dubbing_group (text, name of dubbing group)
   - created_at (timestamptz)

2. **episodes** — Video episodes for series/anime/anime_series
   - id (uuid PK)
   - content_id (uuid FK → content, CASCADE on delete)
   - episode_number (integer)
   - title (text, optional episode title)
   - video_type (text: upload or link)
   - video_url (text, URL to uploaded file or external link)
   - created_at (timestamptz)

3. **comic_chapters** — Chapters within a comic
   - id (uuid PK)
   - content_id (uuid FK → content, CASCADE on delete)
   - chapter_number (integer)
   - title (text, optional)
   - background_music_url (text, URL to uploaded music file)
   - created_at (timestamptz)

4. **comic_panels** — Individual image panels within a comic chapter
   - id (uuid PK)
   - chapter_id (uuid FK → comic_chapters, CASCADE on delete)
   - image_url (text, URL to uploaded panel image)
   - panel_order (integer, for sorting)
   - created_at (timestamptz)

5. **profiles** — User profile data
   - id (uuid PK, references auth.users, CASCADE on delete)
   - username (text)
   - avatar_url (text)
   - phone (text)
   - created_at (timestamptz)

## Storage Buckets
- covers (public) — cover images for content
- videos (public) — uploaded video files
- panels (public) — comic panel images
- music (public) — background music for comic chapters
- avatars (public) — user avatar images

## Security
- Content, episodes, comic_chapters, comic_panels: public read (anon + authenticated),
  public write (anon + authenticated) — admin access is gated by password in the UI.
- Profiles: owner-scoped CRUD (authenticated only, auth.uid() = id).
- Storage buckets: public read, authenticated write for all media buckets.
*/

-- Content table
CREATE TABLE IF NOT EXISTS content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  category text NOT NULL CHECK (category IN ('comic', 'series', 'movie', 'anime', 'anime_series')),
  cover_image_url text,
  tags text[] DEFAULT '{}',
  dubbing_group text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE content ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_content" ON content;
CREATE POLICY "public_select_content" ON content FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_content" ON content;
CREATE POLICY "public_insert_content" ON content FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_update_content" ON content;
CREATE POLICY "public_update_content" ON content FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "public_delete_content" ON content;
CREATE POLICY "public_delete_content" ON content FOR DELETE
  TO anon, authenticated USING (true);

-- Episodes table
CREATE TABLE IF NOT EXISTS episodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id uuid NOT NULL REFERENCES content(id) ON DELETE CASCADE,
  episode_number integer NOT NULL DEFAULT 1,
  title text,
  video_type text NOT NULL CHECK (video_type IN ('upload', 'link')),
  video_url text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE episodes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_episodes" ON episodes;
CREATE POLICY "public_select_episodes" ON episodes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_episodes" ON episodes;
CREATE POLICY "public_insert_episodes" ON episodes FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_update_episodes" ON episodes;
CREATE POLICY "public_update_episodes" ON episodes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "public_delete_episodes" ON episodes;
CREATE POLICY "public_delete_episodes" ON episodes FOR DELETE
  TO anon, authenticated USING (true);

-- Comic chapters table
CREATE TABLE IF NOT EXISTS comic_chapters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id uuid NOT NULL REFERENCES content(id) ON DELETE CASCADE,
  chapter_number integer NOT NULL DEFAULT 1,
  title text,
  background_music_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE comic_chapters ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_comic_chapters" ON comic_chapters;
CREATE POLICY "public_select_comic_chapters" ON comic_chapters FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_comic_chapters" ON comic_chapters;
CREATE POLICY "public_insert_comic_chapters" ON comic_chapters FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_update_comic_chapters" ON comic_chapters;
CREATE POLICY "public_update_comic_chapters" ON comic_chapters FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "public_delete_comic_chapters" ON comic_chapters;
CREATE POLICY "public_delete_comic_chapters" ON comic_chapters FOR DELETE
  TO anon, authenticated USING (true);

-- Comic panels table
CREATE TABLE IF NOT EXISTS comic_panels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chapter_id uuid NOT NULL REFERENCES comic_chapters(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  panel_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE comic_panels ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_comic_panels" ON comic_panels;
CREATE POLICY "public_select_comic_panels" ON comic_panels FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_comic_panels" ON comic_panels;
CREATE POLICY "public_insert_comic_panels" ON comic_panels FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_update_comic_panels" ON comic_panels;
CREATE POLICY "public_update_comic_panels" ON comic_panels FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "public_delete_comic_panels" ON comic_panels;
CREATE POLICY "public_delete_comic_panels" ON comic_panels FOR DELETE
  TO anon, authenticated USING (true);

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text,
  avatar_url text,
  phone text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_content_category ON content(category);
CREATE INDEX IF NOT EXISTS idx_episodes_content_id ON episodes(content_id);
CREATE INDEX IF NOT EXISTS idx_comic_chapters_content_id ON comic_chapters(content_id);
CREATE INDEX IF NOT EXISTS idx_comic_panels_chapter_id ON comic_panels(chapter_id);

-- Storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES ('covers', 'covers', true)
  ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('videos', 'videos', true)
  ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('panels', 'panels', true)
  ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('music', 'music', true)
  ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true)
  ON CONFLICT (id) DO NOTHING;

-- Storage policies: public read, authenticated write
DROP POLICY IF EXISTS "public_read_covers" ON storage.objects;
CREATE POLICY "public_read_covers" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'covers');

DROP POLICY IF EXISTS "auth_write_covers" ON storage.objects;
CREATE POLICY "auth_write_covers" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'covers');

DROP POLICY IF EXISTS "auth_update_covers" ON storage.objects;
CREATE POLICY "auth_update_covers" ON storage.objects FOR UPDATE
  TO authenticated USING (bucket_id = 'covers');

DROP POLICY IF EXISTS "public_read_videos" ON storage.objects;
CREATE POLICY "public_read_videos" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'videos');

DROP POLICY IF EXISTS "auth_write_videos" ON storage.objects;
CREATE POLICY "auth_write_videos" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'videos');

DROP POLICY IF EXISTS "auth_update_videos" ON storage.objects;
CREATE POLICY "auth_update_videos" ON storage.objects FOR UPDATE
  TO authenticated USING (bucket_id = 'videos');

DROP POLICY IF EXISTS "public_read_panels" ON storage.objects;
CREATE POLICY "public_read_panels" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'panels');

DROP POLICY IF EXISTS "auth_write_panels" ON storage.objects;
CREATE POLICY "auth_write_panels" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'panels');

DROP POLICY IF EXISTS "auth_update_panels" ON storage.objects;
CREATE POLICY "auth_update_panels" ON storage.objects FOR UPDATE
  TO authenticated USING (bucket_id = 'panels');

DROP POLICY IF EXISTS "public_read_music" ON storage.objects;
CREATE POLICY "public_read_music" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'music');

DROP POLICY IF EXISTS "auth_write_music" ON storage.objects;
CREATE POLICY "auth_write_music" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'music');

DROP POLICY IF EXISTS "auth_update_music" ON storage.objects;
CREATE POLICY "auth_update_music" ON storage.objects FOR UPDATE
  TO authenticated USING (bucket_id = 'music');

DROP POLICY IF EXISTS "public_read_avatars" ON storage.objects;
CREATE POLICY "public_read_avatars" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'avatars');

DROP POLICY IF EXISTS "auth_write_avatars" ON storage.objects;
CREATE POLICY "auth_write_avatars" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'avatars');

DROP POLICY IF EXISTS "auth_update_avatars" ON storage.objects;
CREATE POLICY "auth_update_avatars" ON storage.objects FOR UPDATE
  TO authenticated USING (bucket_id = 'avatars');

-- Also allow anon to write to all buckets (for admin panel when not signed in)
DROP POLICY IF EXISTS "anon_write_covers" ON storage.objects;
CREATE POLICY "anon_write_covers" ON storage.objects FOR INSERT
  TO anon WITH CHECK (bucket_id = 'covers');

DROP POLICY IF EXISTS "anon_write_videos" ON storage.objects;
CREATE POLICY "anon_write_videos" ON storage.objects FOR INSERT
  TO anon WITH CHECK (bucket_id = 'videos');

DROP POLICY IF EXISTS "anon_write_panels" ON storage.objects;
CREATE POLICY "anon_write_panels" ON storage.objects FOR INSERT
  TO anon WITH CHECK (bucket_id = 'panels');

DROP POLICY IF EXISTS "anon_write_music" ON storage.objects;
CREATE POLICY "anon_write_music" ON storage.objects FOR INSERT
  TO anon WITH CHECK (bucket_id = 'music');

DROP POLICY IF EXISTS "anon_write_avatars" ON storage.objects;
CREATE POLICY "anon_write_avatars" ON storage.objects FOR INSERT
  TO anon WITH CHECK (bucket_id = 'avatars');

-- Trigger to auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, username, avatar_url, phone)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    NEW.raw_user_meta_data->>'avatar_url',
    NEW.raw_user_meta_data->>'phone'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();