/*
# Add Animation Category, Google Drive Video Type, and Comic Info Fields

## Overview
1. Adds a new content category 'animation' (Animation & Cartoons) to the existing content table.
2. Expands the video_type constraint on episodes to include 'gdrive' for Google Drive video links.
3. Adds two new columns to the content table specifically for comics: author_name and chapter_notice.

## Changes

### 1. Content table: new category 'animation'
The content table already has a category column with a CHECK constraint. We need to expand
the constraint to include 'animation'.

### 2. Episodes table: new video_type 'gdrive'
The episodes table has a video_type column with a CHECK constraint. We expand it to allow
'gdrive' in addition to 'upload' and 'link'.

### 3. Content table: comic info fields
- author_name (text, nullable): author of a comic — only used when category = 'comic'
- chapter_notice (text, nullable): a notice/announcement displayed on comic chapters

## Security
No security changes — the existing RLS policies on content and episodes remain unchanged.
The new columns are covered by the existing anon+authenticated CRUD policies.
*/

-- 1. Expand content category constraint to include 'animation'
DO $$
BEGIN
  -- Drop the old constraint if it exists
  ALTER TABLE content DROP CONSTRAINT IF EXISTS content_category_check;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Add the new constraint with 'animation' included
ALTER TABLE content ADD CONSTRAINT content_category_check
  CHECK (category IN ('comic', 'series', 'movie', 'anime', 'anime_series', 'animation'));

-- 2. Expand episodes video_type constraint to include 'gdrive'
DO $$
BEGIN
  ALTER TABLE episodes DROP CONSTRAINT IF EXISTS episodes_video_type_check;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

ALTER TABLE episodes ADD CONSTRAINT episodes_video_type_check
  CHECK (video_type IN ('upload', 'link', 'gdrive'));

-- 3. Add comic info columns to content table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'content' AND column_name = 'author_name'
  ) THEN
    ALTER TABLE content ADD COLUMN author_name text;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'content' AND column_name = 'chapter_notice'
  ) THEN
    ALTER TABLE content ADD COLUMN chapter_notice text;
  END IF;
END $$;
