/*
# Secure Admin Write Access + Backend VIP Content Protection

## Summary
This migration locks down database write access so that only authenticated admin users
can modify content, episodes, comic chapters, ads, and other admin-managed tables.
It also enforces VIP content protection at the database (RLS) level so non-VIP users
cannot read VIP content even if they bypass the frontend UI.

## Changes

### 1. profiles table — add is_admin column
- Added `is_admin boolean NOT NULL DEFAULT false` column to `profiles`.
- Set the known admin user "ares" (id = 979629a8-c019-4597-bab4-75b319b27662) to `is_admin = true`.
- Added a helper function `is_admin_user()` that checks if the current auth user has `is_admin = true`.

### 2. content table — fix RLS policies
- Replaced permissive `public_*` write policies (INSERT/UPDATE/DELETE with `true`) with
  admin-only policies using `is_admin_user()`.
- Fixed SELECT policy: non-VIP users can only see `is_vip = false` content; VIP/trial users
  and admins can see all content.
- Removed duplicate permissive policies.

### 3. episodes table — fix RLS policies
- Replaced permissive write policies with admin-only policies.

### 4. comic_chapters table — fix RLS policies
- Replaced permissive write policies with admin-only policies.

### 5. comic_panels table — fix RLS policies
- Replaced permissive write policies with admin-only policies.

### 6. comic_music_tracks table — fix RLS policies
- Replaced permissive write policies with admin-only policies.

### 7. ads table — fix RLS policies
- Kept SELECT for active ads visible to all.
- Replaced permissive INSERT/UPDATE/DELETE with admin-only policies.

### 8. site_settings table — fix RLS policies
- Replaced permissive write policies with admin-only policies.

### 9. notifications table — fix RLS policies
- Kept user-scoped SELECT (users see their own notifications).
- Restricted INSERT to admin-only (only admins can broadcast notifications).

## Security Impact
- Non-authenticated users can no longer create, modify, or delete content/ads.
- Non-VIP users cannot read VIP content at the database level.
- Only authenticated admin users can perform administrative write operations.
- All existing data, users, and relationships are preserved.
*/

-- === 1. Add is_admin column to profiles ===
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_admin boolean NOT NULL DEFAULT false;

-- Set known admin user
UPDATE profiles SET is_admin = true WHERE username = 'ares';

-- Helper function to check admin status
CREATE OR REPLACE FUNCTION is_admin_user()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT is_admin FROM profiles WHERE id = auth.uid()),
    false
  );
$$;

-- === 2. content table — fix policies ===
DROP POLICY IF EXISTS "anon_delete_content" ON content;
DROP POLICY IF EXISTS "anon_insert_content" ON content;
DROP POLICY IF EXISTS "anon_update_content" ON content;
DROP POLICY IF EXISTS "public_delete_content" ON content;
DROP POLICY IF EXISTS "public_insert_content" ON content;
DROP POLICY IF EXISTS "public_update_content" ON content;
DROP POLICY IF EXISTS "anon_select_content" ON content;
DROP POLICY IF EXISTS "public_select_content" ON content;

-- SELECT: non-VIP users see only free content; VIP/trial/admin see all
CREATE POLICY "select_content"
ON content FOR SELECT
TO anon, authenticated
USING (
  is_vip = false
  OR (auth.uid() IS NOT NULL AND (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND (vip_status = 'vip' OR vip_status = 'trial' OR is_admin = true))
  ))
  OR is_admin_user()
);

-- INSERT/UPDATE/DELETE: admin only
CREATE POLICY "admin_insert_content"
ON content FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

CREATE POLICY "admin_update_content"
ON content FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());

CREATE POLICY "admin_delete_content"
ON content FOR DELETE
TO authenticated
USING (is_admin_user());

-- === 3. episodes table — fix policies ===
DROP POLICY IF EXISTS "anon_delete_episodes" ON episodes;
DROP POLICY IF EXISTS "anon_insert_episodes" ON episodes;
DROP POLICY IF EXISTS "anon_update_episodes" ON episodes;
DROP POLICY IF EXISTS "public_delete_episodes" ON episodes;
DROP POLICY IF EXISTS "public_insert_episodes" ON episodes;
DROP POLICY IF EXISTS "public_update_episodes" ON episodes;

-- SELECT: same VIP logic as content (join to content for is_vip check)
CREATE POLICY "select_episodes"
ON episodes FOR SELECT
TO anon, authenticated
USING (
  NOT EXISTS (SELECT 1 FROM content WHERE content.id = episodes.content_id AND content.is_vip = true)
  OR (auth.uid() IS NOT NULL AND (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND (vip_status = 'vip' OR vip_status = 'trial' OR is_admin = true))
  ))
  OR is_admin_user()
);

CREATE POLICY "admin_insert_episodes"
ON episodes FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

CREATE POLICY "admin_update_episodes"
ON episodes FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());

CREATE POLICY "admin_delete_episodes"
ON episodes FOR DELETE
TO authenticated
USING (is_admin_user());

-- === 4. comic_chapters table — fix policies ===
DROP POLICY IF EXISTS "anon_delete_chapters" ON comic_chapters;
DROP POLICY IF EXISTS "anon_insert_chapters" ON comic_chapters;
DROP POLICY IF EXISTS "anon_update_chapters" ON comic_chapters;
DROP POLICY IF EXISTS "public_delete_chapters" ON comic_chapters;
DROP POLICY IF EXISTS "public_insert_chapters" ON comic_chapters;
DROP POLICY IF EXISTS "public_update_chapters" ON comic_chapters;

CREATE POLICY "select_chapters"
ON comic_chapters FOR SELECT
TO anon, authenticated
USING (
  NOT EXISTS (SELECT 1 FROM content WHERE content.id = comic_chapters.content_id AND content.is_vip = true)
  OR (auth.uid() IS NOT NULL AND (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND (vip_status = 'vip' OR vip_status = 'trial' OR is_admin = true))
  ))
  OR is_admin_user()
);

CREATE POLICY "admin_insert_chapters"
ON comic_chapters FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

CREATE POLICY "admin_update_chapters"
ON comic_chapters FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());

CREATE POLICY "admin_delete_chapters"
ON comic_chapters FOR DELETE
TO authenticated
USING (is_admin_user());

-- === 5. comic_panels table — fix policies ===
DROP POLICY IF EXISTS "anon_delete_panels" ON comic_panels;
DROP POLICY IF EXISTS "anon_insert_panels" ON comic_panels;
DROP POLICY IF EXISTS "anon_update_panels" ON comic_panels;
DROP POLICY IF EXISTS "public_delete_panels" ON comic_panels;
DROP POLICY IF EXISTS "public_insert_panels" ON comic_panels;
DROP POLICY IF EXISTS "public_update_panels" ON comic_panels;

CREATE POLICY "select_panels"
ON comic_panels FOR SELECT
TO anon, authenticated
USING (
  NOT EXISTS (
    SELECT 1 FROM comic_chapters
    JOIN content ON content.id = comic_chapters.content_id
    WHERE comic_chapters.id = comic_panels.chapter_id AND content.is_vip = true
  )
  OR (auth.uid() IS NOT NULL AND (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND (vip_status = 'vip' OR vip_status = 'trial' OR is_admin = true))
  ))
  OR is_admin_user()
);

CREATE POLICY "admin_insert_panels"
ON comic_panels FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

CREATE POLICY "admin_update_panels"
ON comic_panels FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());

CREATE POLICY "admin_delete_panels"
ON comic_panels FOR DELETE
TO authenticated
USING (is_admin_user());

-- === 6. comic_music_tracks table — fix policies ===
DROP POLICY IF EXISTS "anon_delete_tracks" ON comic_music_tracks;
DROP POLICY IF EXISTS "anon_insert_tracks" ON comic_music_tracks;
DROP POLICY IF EXISTS "anon_update_tracks" ON comic_music_tracks;
DROP POLICY IF EXISTS "public_delete_tracks" ON comic_music_tracks;
DROP POLICY IF EXISTS "public_insert_tracks" ON comic_music_tracks;
DROP POLICY IF EXISTS "public_update_tracks" ON comic_music_tracks;

CREATE POLICY "select_tracks"
ON comic_music_tracks FOR SELECT
TO anon, authenticated
USING (true);

CREATE POLICY "admin_insert_tracks"
ON comic_music_tracks FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

CREATE POLICY "admin_update_tracks"
ON comic_music_tracks FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());

CREATE POLICY "admin_delete_tracks"
ON comic_music_tracks FOR DELETE
TO authenticated
USING (is_admin_user());

-- === 7. ads table — fix policies ===
DROP POLICY IF EXISTS "delete_ads" ON ads;
DROP POLICY IF EXISTS "insert_ads" ON ads;
DROP POLICY IF EXISTS "update_ads" ON ads;
DROP POLICY IF EXISTS "select_ads" ON ads;

-- SELECT: anyone can see active ads
CREATE POLICY "select_active_ads"
ON ads FOR SELECT
TO anon, authenticated
USING (is_active = true);

-- Write: admin only
CREATE POLICY "admin_insert_ads"
ON ads FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

CREATE POLICY "admin_update_ads"
ON ads FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());

CREATE POLICY "admin_delete_ads"
ON ads FOR DELETE
TO authenticated
USING (is_admin_user());

-- === 8. site_settings table — fix policies ===
DROP POLICY IF EXISTS "delete_settings" ON site_settings;
DROP POLICY IF EXISTS "insert_settings" ON site_settings;
DROP POLICY IF EXISTS "update_settings" ON site_settings;
DROP POLICY IF EXISTS "select_settings" ON site_settings;

CREATE POLICY "select_site_settings"
ON site_settings FOR SELECT
TO anon, authenticated
USING (true);

CREATE POLICY "admin_insert_site_settings"
ON site_settings FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

CREATE POLICY "admin_update_site_settings"
ON site_settings FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());

CREATE POLICY "admin_delete_site_settings"
ON site_settings FOR DELETE
TO authenticated
USING (is_admin_user());

-- === 9. notifications table — fix INSERT policy ===
DROP POLICY IF EXISTS "insert_notifications" ON notifications;
DROP POLICY IF EXISTS "anon_insert_notifications" ON notifications;

CREATE POLICY "admin_insert_notifications"
ON notifications FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

-- === 10. comic_characters table — admin-only writes ===
DROP POLICY IF EXISTS "anon_insert_characters" ON comic_characters;
DROP POLICY IF EXISTS "anon_update_characters" ON comic_characters;
DROP POLICY IF EXISTS "anon_delete_characters" ON comic_characters;
DROP POLICY IF EXISTS "public_insert_characters" ON comic_characters;
DROP POLICY IF EXISTS "public_update_characters" ON comic_characters;
DROP POLICY IF EXISTS "public_delete_characters" ON comic_characters;

CREATE POLICY "select_characters"
ON comic_characters FOR SELECT
TO anon, authenticated
USING (true);

CREATE POLICY "admin_insert_characters"
ON comic_characters FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

CREATE POLICY "admin_update_characters"
ON comic_characters FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());

CREATE POLICY "admin_delete_characters"
ON comic_characters FOR DELETE
TO authenticated
USING (is_admin_user());

-- === 11. comic_speech_bubbles table — admin-only writes ===
DROP POLICY IF EXISTS "anon_insert_bubbles" ON comic_speech_bubbles;
DROP POLICY IF EXISTS "anon_update_bubbles" ON comic_speech_bubbles;
DROP POLICY IF EXISTS "anon_delete_bubbles" ON comic_speech_bubbles;
DROP POLICY IF EXISTS "public_insert_bubbles" ON comic_speech_bubbles;
DROP POLICY IF EXISTS "public_update_bubbles" ON comic_speech_bubbles;
DROP POLICY IF EXISTS "public_delete_bubbles" ON comic_speech_bubbles;

CREATE POLICY "select_bubbles"
ON comic_speech_bubbles FOR SELECT
TO anon, authenticated
USING (true);

CREATE POLICY "admin_insert_bubbles"
ON comic_speech_bubbles FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

CREATE POLICY "admin_update_bubbles"
ON comic_speech_bubbles FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());

CREATE POLICY "admin_delete_bubbles"
ON comic_speech_bubbles FOR DELETE
TO authenticated
USING (is_admin_user());

-- === 12. comic_image_translations table — admin-only writes ===
DROP POLICY IF EXISTS "anon_insert_image_translations" ON comic_image_translations;
DROP POLICY IF EXISTS "anon_update_image_translations" ON comic_image_translations;
DROP POLICY IF EXISTS "anon_delete_image_translations" ON comic_image_translations;

CREATE POLICY "select_image_translations"
ON comic_image_translations FOR SELECT
TO anon, authenticated
USING (true);

CREATE POLICY "admin_insert_image_translations"
ON comic_image_translations FOR INSERT
TO authenticated
WITH CHECK (is_admin_user());

CREATE POLICY "admin_update_image_translations"
ON comic_image_translations FOR UPDATE
TO authenticated
USING (is_admin_user())
WITH CHECK (is_admin_user());

CREATE POLICY "admin_delete_image_translations"
ON comic_image_translations FOR DELETE
TO authenticated
USING (is_admin_user());
