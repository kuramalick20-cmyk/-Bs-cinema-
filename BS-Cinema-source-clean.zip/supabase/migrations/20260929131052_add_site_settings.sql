/*
# Add Site Settings Table

## Overview
Creates a single-row table for site-wide settings: social media links and
advertisement enable/disable toggle. Also adds an ad_placement column concept
via the settings JSON for future expansion.

## New Tables

1. **site_settings** — Single-row settings table (key/value style)
   - id (int PK, always 1)
   - social_links (jsonb): { telegram, snapchat, tiktok, whatsapp, fastpay }
   - ads_enabled (boolean, default true)
   - ad_provider (text, default 'adsense' — ready for Google AdSense)
   - ad_client_id (text, nullable — for AdSense publisher ID)
   - updated_at (timestamptz)

## Security
- site_settings: public read (anon + authenticated). Only admin can update
  (we use the same anon-write pattern as other tables since admin is gated
  by password in the UI, consistent with existing content/episodes tables).
*/

CREATE TABLE IF NOT EXISTS site_settings (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  social_links jsonb NOT NULL DEFAULT '{
    "telegram": "https://t.me/lordarys",
    "snapchat": "https://www.snapchat.com/add/lord.aries1",
    "tiktok": "https://www.tiktok.com/@bsstudio.offical",
    "whatsapp": "https://wa.me/9647511590023",
    "fastpay_number": "07511590023"
  }'::jsonb,
  ads_enabled boolean NOT NULL DEFAULT true,
  ad_provider text NOT NULL DEFAULT 'adsense',
  ad_client_id text,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_site_settings" ON site_settings;
CREATE POLICY "public_select_site_settings" ON site_settings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_update_site_settings" ON site_settings;
CREATE POLICY "public_update_site_settings" ON site_settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "public_insert_site_settings" ON site_settings;
CREATE POLICY "public_insert_site_settings" ON site_settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

-- Insert default row if not exists
INSERT INTO site_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
