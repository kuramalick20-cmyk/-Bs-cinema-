/*
# BS Cinema Upgrade - Add New Features

## Summary
This migration adds support for: VIP content protection, comic panel videos, comic formats,
multiple music tracks per chapter, subtitles, chat, notifications, and ad management.
All changes are additive — no existing columns or tables are modified or deleted.

## New Columns on Existing Tables
1. `content.is_vip` (boolean, default false) — marks content as VIP-only
2. `comic_panels.video_url` (text, nullable) — optional video for a comic panel
3. `comic_panels.aspect_ratio` (text, default 'default') — panel format: 'default', '9:16', '16:9'
4. `comic_chapters.format` (text, default 'default') — chapter format

## New Tables
1. `comic_music_tracks` — multiple music tracks per chapter with start/end times
2. `subtitles` — subtitle tracks for episodes and comic panels
3. `chat_conversations` — 1-on-1 chat conversations between users
4. `chat_messages` — individual messages in conversations
5. `notifications` — user notifications for new content and chat messages
6. `ads` — admin-managed advertisements

## Security
- RLS enabled on all new tables
- VIP content protected via RLS: free users cannot SELECT VIP-flagged content
- Chat messages only visible to conversation participants
- Notifications only visible to the notified user
- Ads visible to all (anon + authenticated)
- Subtitles: VIP subtitles only visible to VIP users
*/

-- ============================================================
-- 1. Add is_vip column to content table
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'content' AND column_name = 'is_vip') THEN
    ALTER TABLE content ADD COLUMN is_vip boolean NOT NULL DEFAULT false;
  END IF;
END $$;

-- Update RLS policy on content to restrict VIP content for non-VIP users
-- First drop old policies, then recreate with VIP check
DROP POLICY IF EXISTS "anon_select_content" ON content;
DROP POLICY IF EXISTS "auth_select_content" ON content;
DROP POLICY IF EXISTS "anon_insert_content" ON content;
DROP POLICY IF EXISTS "auth_insert_content" ON content;
DROP POLICY IF EXISTS "anon_update_content" ON content;
DROP POLICY IF EXISTS "auth_update_content" ON content;
DROP POLICY IF EXISTS "anon_delete_content" ON content;
DROP POLICY IF EXISTS "auth_delete_content" ON content;

-- Non-VIP users can only see non-VIP content; VIP users see everything
CREATE POLICY "anon_select_content"
ON content FOR SELECT
TO anon, authenticated
USING (is_vip = false);

-- Admin can see all content (handled via service role key in edge functions)
-- For authenticated users who are VIP, they can see VIP content too
-- We use a SECURITY DEFINER function to check VIP status
CREATE OR REPLACE FUNCTION public.is_user_vip(p_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = p_user_id
    AND vip_status = 'vip'
    AND vip_end_date IS NOT NULL
    AND vip_end_date > now()
  );
$$;

-- Re-create select policy with VIP check
DROP POLICY IF EXISTS "anon_select_content" ON content;
CREATE POLICY "anon_select_content"
ON content FOR SELECT
TO anon, authenticated
USING (
  is_vip = false
  OR (auth.uid() IS NOT NULL AND public.is_user_vip(auth.uid()))
);

-- Write policies (anyone can create/update/delete — admin manages via app)
CREATE POLICY "anon_insert_content"
ON content FOR INSERT
TO anon, authenticated
WITH CHECK (true);

CREATE POLICY "anon_update_content"
ON content FOR UPDATE
TO anon, authenticated
USING (true) WITH CHECK (true);

CREATE POLICY "anon_delete_content"
ON content FOR DELETE
TO anon, authenticated
USING (true);

-- ============================================================
-- 2. Add video_url and aspect_ratio to comic_panels
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'comic_panels' AND column_name = 'video_url') THEN
    ALTER TABLE comic_panels ADD COLUMN video_url text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'comic_panels' AND column_name = 'aspect_ratio') THEN
    ALTER TABLE comic_panels ADD COLUMN aspect_ratio text NOT NULL DEFAULT 'default';
  END IF;
END $$;

-- ============================================================
-- 3. Add format to comic_chapters
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'comic_chapters' AND column_name = 'format') THEN
    ALTER TABLE comic_chapters ADD COLUMN format text NOT NULL DEFAULT 'default';
  END IF;
END $$;

-- ============================================================
-- 4. comic_music_tracks — multiple music per chapter
-- ============================================================
CREATE TABLE IF NOT EXISTS comic_music_tracks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chapter_id uuid NOT NULL REFERENCES comic_chapters(id) ON DELETE CASCADE,
  track_url text NOT NULL,
  track_name text,
  start_time numeric DEFAULT 0,
  end_time numeric,
  start_panel integer DEFAULT 0,
  end_panel integer,
  track_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE comic_music_tracks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_music_tracks" ON comic_music_tracks;
CREATE POLICY "select_music_tracks"
ON comic_music_tracks FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_music_tracks" ON comic_music_tracks;
CREATE POLICY "insert_music_tracks"
ON comic_music_tracks FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_music_tracks" ON comic_music_tracks;
CREATE POLICY "update_music_tracks"
ON comic_music_tracks FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_music_tracks" ON comic_music_tracks;
CREATE POLICY "delete_music_tracks"
ON comic_music_tracks FOR DELETE
TO anon, authenticated USING (true);

-- ============================================================
-- 5. subtitles — for episodes and comic panels
-- ============================================================
CREATE TABLE IF NOT EXISTS subtitles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_type text NOT NULL CHECK (item_type IN ('episode', 'comic_panel')),
  item_id uuid NOT NULL,
  language text NOT NULL CHECK (language IN ('ku', 'en')),
  content text NOT NULL,
  start_time numeric,
  end_time numeric,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE subtitles ENABLE ROW LEVEL SECURITY;

-- Subtitles for non-VIP content: everyone can see
-- Subtitles for VIP content: only VIP users
-- We check via the parent content's is_vip flag
DROP POLICY IF EXISTS "select_subtitles" ON subtitles;
CREATE POLICY "select_subtitles"
ON subtitles FOR SELECT
TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "insert_subtitles" ON subtitles;
CREATE POLICY "insert_subtitles"
ON subtitles FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_subtitles" ON subtitles;
CREATE POLICY "update_subtitles"
ON subtitles FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_subtitles" ON subtitles;
CREATE POLICY "delete_subtitles"
ON subtitles FOR DELETE
TO anon, authenticated USING (true);

-- ============================================================
-- 6. chat_conversations — 1-on-1 chats
-- ============================================================
CREATE TABLE IF NOT EXISTS chat_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user1_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  user2_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user1_id, user2_id)
);

ALTER TABLE chat_conversations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_conversations" ON chat_conversations;
CREATE POLICY "select_own_conversations"
ON chat_conversations FOR SELECT
TO authenticated
USING (auth.uid() = user1_id OR auth.uid() = user2_id);

DROP POLICY IF EXISTS "insert_own_conversations" ON chat_conversations;
CREATE POLICY "insert_own_conversations"
ON chat_conversations FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user1_id OR auth.uid() = user2_id);

DROP POLICY IF EXISTS "delete_own_conversations" ON chat_conversations;
CREATE POLICY "delete_own_conversations"
ON chat_conversations FOR DELETE
TO authenticated
USING (auth.uid() = user1_id OR auth.uid() = user2_id);

-- ============================================================
-- 7. chat_messages — individual messages
-- ============================================================
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES chat_conversations(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  text text NOT NULL,
  read_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- Messages visible only to conversation participants
DROP POLICY IF EXISTS "select_own_messages" ON chat_messages;
CREATE POLICY "select_own_messages"
ON chat_messages FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM chat_conversations
    WHERE chat_conversations.id = chat_messages.conversation_id
    AND (chat_conversations.user1_id = auth.uid() OR chat_conversations.user2_id = auth.uid())
  )
);

DROP POLICY IF EXISTS "insert_own_messages" ON chat_messages;
CREATE POLICY "insert_own_messages"
ON chat_messages FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = sender_id
  AND EXISTS (
    SELECT 1 FROM chat_conversations
    WHERE chat_conversations.id = chat_messages.conversation_id
    AND (chat_conversations.user1_id = auth.uid() OR chat_conversations.user2_id = auth.uid())
  )
);

DROP POLICY IF EXISTS "update_read_status" ON chat_messages;
CREATE POLICY "update_read_status"
ON chat_messages FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM chat_conversations
    WHERE chat_conversations.id = chat_messages.conversation_id
    AND (chat_conversations.user1_id = auth.uid() OR chat_conversations.user2_id = auth.uid())
  )
) WITH CHECK (true);

-- ============================================================
-- 8. notifications — user notifications
-- ============================================================
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('new_content', 'new_episode', 'new_chapter', 'new_vip_content', 'chat_message')),
  title text NOT NULL,
  body text,
  link_id uuid,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_notifications" ON notifications;
CREATE POLICY "select_own_notifications"
ON notifications FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_notifications" ON notifications;
CREATE POLICY "insert_notifications"
ON notifications FOR INSERT
TO anon, authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "update_own_notifications" ON notifications;
CREATE POLICY "update_own_notifications"
ON notifications FOR UPDATE
TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_notifications" ON notifications;
CREATE POLICY "delete_own_notifications"
ON notifications FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- Index for faster notification queries
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread ON notifications(user_id, is_read) WHERE is_read = false;

-- ============================================================
-- 9. ads — admin-managed advertisements
-- ============================================================
CREATE TABLE IF NOT EXISTS ads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text,
  image_url text,
  link_url text,
  position text NOT NULL DEFAULT 'home' CHECK (position IN ('home', 'content', 'sidebar', 'between')),
  is_active boolean NOT NULL DEFAULT true,
  impressions integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ads ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_ads" ON ads;
CREATE POLICY "select_ads"
ON ads FOR SELECT
TO anon, authenticated
USING (is_active = true);

DROP POLICY IF EXISTS "insert_ads" ON ads;
CREATE POLICY "insert_ads"
ON ads FOR INSERT
TO anon, authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "update_ads" ON ads;
CREATE POLICY "update_ads"
ON ads FOR UPDATE
TO anon, authenticated
USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_ads" ON ads;
CREATE POLICY "delete_ads"
ON ads FOR DELETE
TO anon, authenticated
USING (true);

-- ============================================================
-- 10. Add index on content.is_vip for faster filtering
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_content_is_vip ON content(is_vip);

-- ============================================================
-- 11. Add index on chat_messages.conversation_id
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_chat_messages_conversation ON chat_messages(conversation_id, created_at);
