import { useState, useRef, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { uploadFile } from '@/lib/storage';
import { useAdmin } from '@/context/AdminContext';
import {
  Tv, Play, Pause, Volume2, VolumeX, Maximize2, Minimize2,
  ExternalLink, Radio, Film, List, Clapperboard, Video,
  Plus, X, Edit2, Trash2, Save, Loader2, Upload, Image as ImageIcon,
} from 'lucide-react';

interface KurdishChannel {
  id: string;
  name: string;
  nameEn: string;
  youtubeChannelId?: string;
  youtubeHandle?: string;
  website?: string;
  embeddable: boolean;
  description: string;
}

interface ChannelContent {
  id: string;
  channel_id: string;
  title: string;
  description: string | null;
  content_type: 'movie' | 'series' | 'program' | 'episode' | 'trailer' | 'live';
  video_type: 'upload' | 'link' | 'gdrive';
  video_url: string;
  thumbnail_url: string | null;
  episode_number: number | null;
  is_active: boolean;
  created_at: string;
}

const CONTENT_TYPES: { key: ChannelContent['content_type']; label: string; icon: typeof Film }[] = [
  { key: 'movie', label: 'فیلم', icon: Film },
  { key: 'series', label: 'زنجیرە', icon: Clapperboard },
  { key: 'program', label: 'بەرنامه', icon: Tv },
  { key: 'episode', label: 'ئەلقە', icon: List },
  { key: 'trailer', label: 'ترەیلەر', icon: Video },
  { key: 'live', label: 'ڕاستەوخۆ', icon: Radio },
];

const CHANNELS: KurdishChannel[] = [
  {
    id: 'kurdsat',
    name: 'کوردسات',
    nameEn: 'Kurdsat',
    youtubeChannelId: 'UCBJFKdoWYrKp6F-_hLtaDpw',
    youtubeHandle: '@TheKurdsat',
    website: 'https://kurdbin.kurdsat.tv/',
    embeddable: false,
    description: 'یەکێک لە کۆنترین کەناڵە کوردییەکان لە سلێمانی',
  },
  {
    id: 'kurdmax',
    name: 'کۆردماکس',
    nameEn: 'KurdMax',
    youtubeChannelId: 'UC2-BKWY5KBdnfsd7HIgRrgg',
    youtubeHandle: '@Kurdmax',
    website: 'https://www.kurdmax.tv/live-stream',
    embeddable: false,
    description: 'کەناڵی کەیفی و دابەشکردنی کوردی لە هەولێر',
  },
  {
    id: 'nrt',
    name: 'NRT',
    nameEn: 'NRT',
    youtubeHandle: '@NRT_PROGRAM',
    website: 'https://www.nrttv.com/',
    embeddable: false,
    description: 'کەناڵی هەواڵ و سیاسیی کوردی',
  },
  {
    id: 'nrt2',
    name: 'NRT2',
    nameEn: 'NRT2',
    youtubeHandle: '@NRT2tvchannel',
    website: 'https://nrttv.com/nrt2/',
    embeddable: false,
    description: 'کەناڵی سینەما و کەیفی',
  },
  {
    id: 'ava-media',
    name: 'ئاڤا میدیا',
    nameEn: 'AVA Media',
    youtubeChannelId: 'UCl2vffa9EyOQg_9jBXklIQw',
    youtubeHandle: '@AvaMedia_TV',
    website: 'https://ava.news/',
    embeddable: false,
    description: 'کەناڵی هەواڵ و کەیفی لە هەولێر',
  },
  {
    id: 'afrin-kids',
    name: 'ئەفرین کیدز',
    nameEn: 'Afrin Kids',
    youtubeHandle: '@AfrinKids',
    website: 'https://www.youtube.com/@AfrinKids',
    embeddable: false,
    description: 'کەناڵی منداڵانی کوردی',
  },
  {
    id: 'afrin-tv',
    name: 'ئەفرین تیڤی',
    nameEn: 'Afrin TV',
    youtubeHandle: '@AfrinTV',
    website: 'https://afarin.tv/Live.aspx',
    embeddable: false,
    description: 'کەناڵی ئەفرین تیڤی',
  },
  {
    id: 'wwe',
    name: 'WWE',
    nameEn: 'WWE',
    youtubeChannelId: '',
    youtubeHandle: '@WWE',
    website: 'https://www.wwe.com/',
    embeddable: false,
    description: 'یاری زۆرانبازی پیشەیی WWE',
  },
];

type ViewMode = 'live' | 'content';
type ContentTab = 'all' | ChannelContent['content_type'];

export default function KurdishChannels() {
  const { isAdmin } = useAdmin();
  const [selectedId, setSelectedId] = useState(CHANNELS[0].id);
  const [viewMode, setViewMode] = useState<ViewMode>('live');
  const [contentTab, setContentTab] = useState<ContentTab>('all');
  const [channelContent, setChannelContent] = useState<ChannelContent[]>([]);
  const [contentLoading, setContentLoading] = useState(false);
  const [playingContent, setPlayingContent] = useState<ChannelContent | null>(null);

  // Live player state
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(100);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [iframeError, setIframeError] = useState(false);
  const [iframeLoading, setIframeLoading] = useState(false);
  const iframeTimeoutRef = useRef<number | null>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const playerContainerRef = useRef<HTMLDivElement>(null);

  // Admin form state
  const [showForm, setShowForm] = useState(false);
  const [editItem, setEditItem] = useState<ChannelContent | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formType, setFormType] = useState<ChannelContent['content_type']>('program');
  const [formVideoType, setFormVideoType] = useState<'upload' | 'link' | 'gdrive'>('link');
  const [formVideoUrl, setFormVideoUrl] = useState('');
  const [formThumb, setFormThumb] = useState('');
  const [formEpNum, setFormEpNum] = useState('');
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [uploadingThumb, setUploadingThumb] = useState(false);
  const [saving, setSaving] = useState(false);

  const selectedChannel = CHANNELS.find((c) => c.id === selectedId) || CHANNELS[0];

  // === Live player controls ===
  const sendCommand = useCallback((func: string, args: string = '') => {
    const iframe = iframeRef.current;
    if (!iframe?.contentWindow) return;
    iframe.contentWindow.postMessage(JSON.stringify({ event: 'command', func, args }), '*');
  }, []);

  const togglePlay = useCallback(() => {
    if (isPlaying) { sendCommand('pauseVideo'); setIsPlaying(false); }
    else { sendCommand('playVideo'); setIsPlaying(true); }
  }, [isPlaying, sendCommand]);

  const toggleMute = useCallback(() => {
    if (isMuted) { sendCommand('unMute'); setIsMuted(false); }
    else { sendCommand('mute'); setIsMuted(true); }
  }, [isMuted, sendCommand]);

  const handleVolumeChange = useCallback((v: number) => {
    setVolume(v);
    sendCommand('setVolume', String(v));
    if (v === 0) { setIsMuted(true); sendCommand('mute'); }
    else if (isMuted) { setIsMuted(false); sendCommand('unMute'); }
  }, [isMuted, sendCommand]);

  const toggleFullscreen = useCallback(() => {
    const container = playerContainerRef.current;
    if (!container) return;
    if (document.fullscreenElement) document.exitFullscreen();
    else container.requestFullscreen?.();
  }, []);

  useEffect(() => {
    const onFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  useEffect(() => {
    setIsPlaying(true);
    setIsMuted(false);
    setVolume(100);
    setIframeError(false);
    setIframeLoading(true);
    if (iframeTimeoutRef.current) clearTimeout(iframeTimeoutRef.current);
    // If iframe doesn't fire onLoad in 8 seconds, assume it's blocked
    iframeTimeoutRef.current = window.setTimeout(() => {
      setIframeError(true);
      setIframeLoading(false);
    }, 8000);
  }, [selectedId]);

  const handleIframeLoad = useCallback(() => {
    if (iframeTimeoutRef.current) {
      clearTimeout(iframeTimeoutRef.current);
      iframeTimeoutRef.current = null;
    }
    setIframeLoading(false);
    setIframeError(false);
    const iframe = iframeRef.current;
    if (!iframe?.contentWindow) return;
    // Try to detect if the iframe content is accessible (blocked sites throw)
    try {
      // Cross-origin iframes will throw on contentDocument access
      const _ = iframe.contentDocument;
    } catch {
      // This is expected for cross-origin — the iframe may still work
    }
    iframe.contentWindow.postMessage(JSON.stringify({ event: 'listening' }), '*');
    setTimeout(() => sendCommand('setVolume', '100'), 500);
  }, [sendCommand]);

  const embedUrl = selectedChannel.youtubeChannelId
    ? `https://www.youtube.com/embed/live_stream?channel=${selectedChannel.youtubeChannelId}&enablejsapi=1&autoplay=0&playsinline=1`
    : null;

  // === Channel content loading ===
  useEffect(() => {
    if (viewMode !== 'content') return;
    loadChannelContent();
  }, [viewMode, selectedId, contentTab]);

  const loadChannelContent = async () => {
    setContentLoading(true);
    let query = supabase
      .from('kurdish_channel_content')
      .select('*')
      .eq('channel_id', selectedId)
      .eq('is_active', true)
      .order('created_at', { ascending: false });
    if (contentTab !== 'all') {
      query = query.eq('content_type', contentTab);
    }
    const { data } = await query;
    setChannelContent((data as ChannelContent[]) || []);
    setContentLoading(false);
  };

  // === Admin CRUD ===
  const resetForm = () => {
    setShowForm(false);
    setEditItem(null);
    setFormTitle('');
    setFormDesc('');
    setFormType('program');
    setFormVideoType('link');
    setFormVideoUrl('');
    setFormThumb('');
    setFormEpNum('');
  };

  const startEdit = (item: ChannelContent) => {
    setEditItem(item);
    setFormTitle(item.title);
    setFormDesc(item.description || '');
    setFormType(item.content_type);
    setFormVideoType(item.video_type);
    setFormVideoUrl(item.video_url);
    setFormThumb(item.thumbnail_url || '');
    setFormEpNum(item.episode_number ? String(item.episode_number) : '');
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!formTitle.trim() || !formVideoUrl.trim()) return;
    setSaving(true);
    const payload = {
      channel_id: selectedId,
      title: formTitle.trim(),
      description: formDesc.trim() || null,
      content_type: formType,
      video_type: formVideoType,
      video_url: formVideoUrl.trim(),
      thumbnail_url: formThumb.trim() || null,
      episode_number: formEpNum ? parseInt(formEpNum) : null,
      is_active: true,
    };
    if (editItem) {
      await supabase.from('kurdish_channel_content').update(payload).eq('id', editItem.id);
    } else {
      await supabase.from('kurdish_channel_content').insert(payload);
    }
    setSaving(false);
    resetForm();
    loadChannelContent();
  };

  const handleDelete = async (id: string) => {
    await supabase.from('kurdish_channel_content').delete().eq('id', id);
    loadChannelContent();
  };

  const handleVideoUpload = async (file: File) => {
    setUploadingVideo(true);
    const url = await uploadFile('channel-content', file);
    if (url) setFormVideoUrl(url);
    setUploadingVideo(false);
  };

  const handleThumbUpload = async (file: File) => {
    setUploadingThumb(true);
    const url = await uploadFile('channel-content', file);
    if (url) setFormThumb(url);
    setUploadingThumb(false);
  };

  // === Video embed helpers for content player ===
  const getYouTubeId = (url: string): string | null => {
    const m = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/);
    return m ? m[1] : null;
  };
  const getVimeoId = (url: string): string | null => {
    const m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
    return m ? m[1] : null;
  };
  const getGdriveId = (url: string): string | null => {
    const patterns = [
      /drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/,
      /drive\.google\.com\/open\?id=([a-zA-Z0-9_-]+)/,
      /docs\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/,
    ];
    for (const p of patterns) { const m = url.match(p); if (m) return m[1]; }
    return null;
  };

  const renderContentVideo = (item: ChannelContent) => {
    const ytId = item.video_type === 'link' ? getYouTubeId(item.video_url) : null;
    const vimeoId = item.video_type === 'link' && !ytId ? getVimeoId(item.video_url) : null;
    const gdriveId = item.video_type === 'gdrive' ? getGdriveId(item.video_url) : null;

    if (ytId) {
      return (
        <iframe
          src={`https://www.youtube.com/embed/${ytId}?rel=0&modestbranding=1&autoplay=1`}
          title={item.title}
          className="w-full h-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          loading="lazy"
        />
      );
    }
    if (vimeoId) {
      return (
        <iframe
          src={`https://player.vimeo.com/video/${vimeoId}?autoplay=1`}
          title={item.title}
          className="w-full h-full"
          allow="autoplay; fullscreen; picture-in-picture"
          allowFullScreen
          loading="lazy"
        />
      );
    }
    if (gdriveId) {
      return (
        <iframe
          src={`https://drive.google.com/file/d/${gdriveId}/preview`}
          title={item.title}
          className="w-full h-full"
          allow="autoplay; fullscreen; picture-in-picture"
          allowFullScreen
          loading="lazy"
        />
      );
    }
    return (
      <video
        src={item.video_url}
        className="w-full h-full object-contain"
        controls
        autoPlay
        playsInline
      />
    );
  };

  const filteredContent = contentTab === 'all'
    ? channelContent
    : channelContent.filter((c) => c.content_type === contentTab);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent/20 to-accent/5 border border-accent/20 flex items-center justify-center flex-shrink-0 shadow-glow">
            <Tv className="w-6 h-6 text-accent" />
          </div>
          <div>
            <h2 className="text-2xl md:text-4xl font-black text-primary tracking-tight flex items-center gap-3">
              <span className="w-1.5 h-8 rounded-full bg-accent/60" />
              کەناڵە کوردیەکان
            </h2>
            <p className="text-secondary text-sm mt-1">پەخشی ڕاستەوخۆ و ناوەڕۆکی کەناڵەکان</p>
          </div>
        </div>
        <div className="flag-divider mt-4" />
      </div>

      {/* View mode tabs */}
      <div className="flex gap-2 mb-6">
        <button
          onClick={() => { setViewMode('live'); setPlayingContent(null); }}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
            viewMode === 'live' ? 'btn-cinema text-black' : 'bg-card border border-default text-secondary hover:text-primary hover:border-bright'
          }`}
        >
          <Radio className="w-4 h-4" /> ڕاستەوخۆ
        </button>
        <button
          onClick={() => { setViewMode('content'); setPlayingContent(null); }}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
            viewMode === 'content' ? 'btn-cinema text-black' : 'bg-card border border-default text-secondary hover:text-primary hover:border-bright'
          }`}
        >
          <Film className="w-4 h-4" /> ناوەڕۆک
        </button>
      </div>

      {/* Channel selector */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 sm:gap-3 mb-6">
        {CHANNELS.map((channel) => (
          <button
            key={channel.id}
            onClick={() => { setSelectedId(channel.id); setPlayingContent(null); }}
            className={`p-3 sm:p-4 rounded-xl border transition-all text-right ${
              channel.id === selectedId
                ? 'bg-accent/10 border-accent ring-1 ring-accent/30'
                : 'bg-card border-default hover:border-bright hover:bg-hover'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className={`font-bold text-xs sm:text-sm ${channel.id === selectedId ? 'text-accent' : 'text-primary'}`}>
                {channel.name}
              </span>
              {viewMode === 'live' && (
                <span className="flex items-center gap-1 text-[10px] text-red-500 font-medium flex-shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                  LIVE
                </span>
              )}
            </div>
            <p className="text-[10px] sm:text-xs text-muted truncate">{channel.nameEn}</p>
          </button>
        ))}
      </div>

      {/* === LIVE VIEW === */}
      {viewMode === 'live' && (
        <>
          <div
            ref={playerContainerRef}
            className="relative w-full aspect-video bg-black rounded-2xl overflow-hidden mb-6 shadow-2xl"
          >
            {/* Try YouTube embed first if available, then try website iframe, then show fallback card */}
            {embedUrl && !iframeError ? (
              <>
                <iframe
                  ref={iframeRef}
                  src={embedUrl}
                  className="w-full h-full"
                  frameBorder="0"
                  allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
                  allowFullScreen
                  loading="lazy"
                  onLoad={handleIframeLoad}
                  title={selectedChannel.name}
                />
                {/* Loading overlay */}
                {iframeLoading && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/60">
                    <Loader2 className="w-8 h-8 text-accent animate-spin" />
                  </div>
                )}
                <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/70 to-transparent p-4 flex items-center justify-between pointer-events-none">
                  <div className="flex items-center gap-2">
                    <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-600 text-white text-xs font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                      LIVE
                    </span>
                    <span className="text-white font-bold text-sm md:text-base">{selectedChannel.name}</span>
                  </div>
                  <span className="text-white/60 text-xs hidden sm:block">{selectedChannel.nameEn}</span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3 md:p-4 flex items-center gap-2 md:gap-3">
                  <button onClick={togglePlay} className="p-2 md:p-2.5 rounded-full glass text-white hover:text-accent transition-colors flex-shrink-0" title={isPlaying ? 'وەستان' : 'لێدان'}>
                    {isPlaying ? <Pause className="w-4 h-4 md:w-5 md:h-5" /> : <Play className="w-4 h-4 md:w-5 md:h-5" />}
                  </button>
                  <button onClick={toggleMute} className="p-2 md:p-2.5 rounded-full glass text-white hover:text-accent transition-colors flex-shrink-0" title={isMuted ? 'دەنگ بکەرەوە' : 'بێدەنگ'}>
                    {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 md:w-5 md:h-5" /> : <Volume2 className="w-4 h-4 md:w-5 md:h-5" />}
                  </button>
                  <input
                    type="range" min="0" max="100"
                    value={isMuted ? 0 : volume}
                    onChange={(e) => handleVolumeChange(Number(e.target.value))}
                    className="w-12 sm:w-16 md:w-24 h-1 accent-accent cursor-pointer flex-shrink-0"
                    title="ئاستی دەنگ"
                  />
                  <div className="flex-1" />
                  <button onClick={toggleFullscreen} className="p-2 md:p-2.5 rounded-full glass text-white hover:text-accent transition-colors flex-shrink-0" title="تەواوی شاشە">
                    {isFullscreen ? <Minimize2 className="w-4 h-4 md:w-5 md:h-5" /> : <Maximize2 className="w-4 h-4 md:w-5 md:h-5" />}
                  </button>
                </div>
              </>
            ) : selectedChannel.website && !iframeError && !embedUrl ? (
              <>
                <iframe
                  ref={iframeRef}
                  src={selectedChannel.website}
                  className="w-full h-full"
                  frameBorder="0"
                  allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
                  allowFullScreen
                  loading="lazy"
                  onLoad={handleIframeLoad}
                  title={selectedChannel.name}
                  sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
                />
                {iframeLoading && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/60">
                    <div className="flex flex-col items-center gap-3">
                      <Loader2 className="w-8 h-8 text-accent animate-spin" />
                      <p className="text-white/70 text-sm">بارکردنی {selectedChannel.name}...</p>
                    </div>
                  </div>
                )}
                <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/70 to-transparent p-4 flex items-center justify-between pointer-events-none">
                  <div className="flex items-center gap-2">
                    <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-600 text-white text-xs font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                      LIVE
                    </span>
                    <span className="text-white font-bold text-sm md:text-base">{selectedChannel.name}</span>
                  </div>
                  <a
                    href={selectedChannel.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full glass text-white text-xs font-medium hover:text-accent transition-colors pointer-events-auto"
                  >
                    <ExternalLink className="w-3.5 h-3.5" /> ماڵپەڕی فەرمی
                  </a>
                </div>
              </>
            ) : (
              /* Beautiful fallback card when iframe is blocked */
              <div className="w-full h-full flex flex-col items-center justify-center text-center p-6 sm:p-8 bg-gradient-to-br from-secondary via-primary to-black">
                <div className="absolute inset-0 opacity-20" style={{ background: 'radial-gradient(ellipse at 50% 40%, var(--accent-dim) 0%, transparent 60%)' }} />
                <div className="relative z-10 flex flex-col items-center">
                  <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-gradient-to-br from-accent/20 to-accent/5 border border-accent/20 flex items-center justify-center mb-4 shadow-glow">
                    <Radio className="w-10 h-10 sm:w-12 sm:h-12 text-accent" />
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-600/90 text-white text-xs font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                      LIVE
                    </span>
                    <h3 className="text-xl sm:text-2xl font-bold text-primary">{selectedChannel.name}</h3>
                  </div>
                  <p className="text-secondary text-sm mb-1 max-w-md" dir="auto">{selectedChannel.description}</p>
                  <p className="text-muted text-xs mb-6 max-w-sm">پەخشی ڕاستەوخۆی ئەم کەناڵە لە ناو ماڵپەڕدا بەردەست نییە بەهۆی سنووردارکردنی کەناڵەکە</p>
                  <div className="flex gap-3 flex-wrap justify-center">
                    <a
                      href={selectedChannel.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-accent to-[var(--accent-hover)] text-white text-sm font-bold hover:scale-105 transition-transform shadow-glow"
                    >
                      <ExternalLink className="w-4 h-4" /> ماڵپەڕی فەرمی
                    </a>
                    {selectedChannel.youtubeHandle && (
                      <a
                        href={`https://www.youtube.com/${selectedChannel.youtubeHandle}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 px-5 py-3 rounded-xl bg-red-600 text-white text-sm font-bold hover:bg-red-700 transition-colors"
                      >
                        <ExternalLink className="w-4 h-4" /> YouTube
                      </a>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Channel info card */}
          <div className="glass-card border border-default rounded-2xl p-4 sm:p-5">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h3 className="text-lg font-bold text-primary mb-1">{selectedChannel.name}</h3>
                <p className="text-secondary text-sm" dir="auto">{selectedChannel.description}</p>
              </div>
              <div className="flex gap-2 flex-wrap">
                {selectedChannel.website && (
                  <a
                    href={selectedChannel.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-accent/10 border border-accent/20 text-accent text-xs font-medium hover:bg-accent/20 transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" /> ماڵپەڕی فەرمی
                  </a>
                )}
                {selectedChannel.youtubeHandle && (
                  <a
                    href={`https://www.youtube.com/${selectedChannel.youtubeHandle}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-red-600/10 border border-red-600/20 text-red-400 text-xs font-medium hover:bg-red-600/20 transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" /> YouTube
                  </a>
                )}
              </div>
            </div>
          </div>
        </>
      )}

      {/* === CONTENT VIEW === */}
      {viewMode === 'content' && (
        <>
          {/* Content type tabs */}
          <div className="flex items-center gap-1.5 mb-5 overflow-x-auto scrollbar-hide pb-1">
            <button
              onClick={() => setContentTab('all')}
              className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all ${contentTab === 'all' ? 'btn-cinema text-black' : 'bg-card border border-default text-secondary hover:text-primary hover:border-bright'}`}
            >
              هەموو
            </button>
            {CONTENT_TYPES.map((ct) => {
              const Icon = ct.icon;
              return (
                <button
                  key={ct.key}
                  onClick={() => setContentTab(ct.key)}
                  className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all ${contentTab === ct.key ? 'btn-cinema text-black' : 'bg-card border border-default text-secondary hover:text-primary hover:border-bright'}`}
                >
                  <Icon className="w-4 h-4" /> {ct.label}
                </button>
              );
            })}
          </div>

          {/* Content player */}
          {playingContent && (
            <div className="relative w-full aspect-video bg-black rounded-2xl overflow-hidden mb-6 shadow-2xl">
              {renderContentVideo(playingContent)}
              <button
                onClick={() => setPlayingContent(null)}
                className="absolute top-3 right-3 p-2 rounded-full glass text-white hover:text-accent transition-colors z-10"
                title="داخستن"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/70 to-transparent p-4 flex items-center gap-2 pointer-events-none">
                <span className="text-white font-bold text-sm md:text-base">{playingContent.title}</span>
                {playingContent.episode_number && (
                  <span className="text-white/60 text-xs">ئەلقە {playingContent.episode_number}</span>
                )}
              </div>
            </div>
          )}

          {/* Admin: Add content button */}
          {isAdmin && !showForm && (
            <button
              onClick={() => { resetForm(); setShowForm(true); }}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-accent text-white font-medium text-sm hover:bg-[var(--accent-hover)] transition-all mb-4"
            >
              <Plus className="w-4 h-4" /> زیادکردنی ناوەڕۆک
            </button>
          )}

          {/* Admin: Content form */}
          {isAdmin && showForm && (
            <div className="bg-card border border-default rounded-xl p-4 mb-6 space-y-3 animate-scale-in">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-primary">
                  {editItem ? 'دەستکاریکردنی ناوەڕۆک' : 'ناوەڕۆکی نوێ'} — {selectedChannel.name}
                </h3>
                <button onClick={resetForm} className="text-secondary hover:text-primary"><X className="w-4 h-4" /></button>
              </div>
              <input type="text" value={formTitle} onChange={(e) => setFormTitle(e.target.value)} placeholder="ناونیشان" className="w-full px-3 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
              <textarea value={formDesc} onChange={(e) => setFormDesc(e.target.value)} placeholder="وەسف (ئیختیاری)" rows={2} className="w-full px-3 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent resize-none" />
              <div className="grid grid-cols-2 gap-3">
                <select value={formType} onChange={(e) => setFormType(e.target.value as ChannelContent['content_type'])} className="px-3 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent">
                  {CONTENT_TYPES.map((ct) => <option key={ct.key} value={ct.key}>{ct.label}</option>)}
                </select>
                <input type="number" value={formEpNum} onChange={(e) => setFormEpNum(e.target.value)} placeholder="ژمارەی ئەلقە (ئیختیاری)" className="px-3 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
              </div>
              <div className="flex flex-wrap gap-2">
                <button onClick={() => setFormVideoType('upload')} className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${formVideoType === 'upload' ? 'bg-accent text-white' : 'bg-secondary text-secondary border border-default'}`}>
                  <Upload className="w-3.5 h-3.5" /> بارکردن
                </button>
                <button onClick={() => setFormVideoType('link')} className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${formVideoType === 'link' ? 'bg-accent text-white' : 'bg-secondary text-secondary border border-default'}`}>
                  <ExternalLink className="w-3.5 h-3.5" /> YouTube/Vimeo
                </button>
                <button onClick={() => setFormVideoType('gdrive')} className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${formVideoType === 'gdrive' ? 'bg-accent text-white' : 'bg-secondary text-secondary border border-default'}`}>
                  <ExternalLink className="w-3.5 h-3.5" /> Google Drive
                </button>
              </div>
              {formVideoType === 'upload' ? (
                <div className="space-y-2">
                  <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-hover text-secondary cursor-pointer text-sm">
                    {uploadingVideo ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />} ڤیدیۆ باربکە
                    <input type="file" accept="video/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleVideoUpload(e.target.files[0])} />
                  </label>
                  {formVideoUrl && <p className="text-xs text-green-400">ڤیدیۆ ئامادەیە</p>}
                </div>
              ) : (
                <input type="text" value={formVideoUrl} onChange={(e) => setFormVideoUrl(e.target.value)} placeholder={formVideoType === 'gdrive' ? 'لینکی Google Drive' : 'لینکی YouTube/Vimeo'} className="w-full px-3 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
              )}
              {/* Thumbnail upload */}
              <div className="flex items-center gap-2">
                <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-hover text-secondary cursor-pointer text-sm">
                  {uploadingThumb ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />} وێنەی بەرگ
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleThumbUpload(e.target.files[0])} />
                </label>
                {formThumb && <img src={formThumb} alt="thumb" className="w-12 h-16 object-cover rounded" />}
              </div>
              <button onClick={handleSave} disabled={saving || !formTitle.trim() || !formVideoUrl.trim()} className="w-full py-2.5 rounded-lg bg-green-600 text-white text-sm font-medium disabled:opacity-50 flex items-center justify-center gap-2">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} پاشەکەوتکردن
              </button>
            </div>
          )}

          {/* Content grid */}
          {contentLoading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="w-8 h-8 text-accent animate-spin" />
            </div>
          ) : filteredContent.length === 0 ? (
            <div className="text-center py-20 text-secondary">
              <Tv className="w-12 h-12 mx-auto mb-4 text-muted" />
              <p className="text-lg">هیچ ناوەڕۆکێک نییە</p>
              <p className="text-sm text-muted mt-2">ناوەڕۆکی {selectedChannel.name} بەم زووانە زیاد دەکرێت</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 md:gap-4">
              {filteredContent.map((item, i) => {
                const typeInfo = CONTENT_TYPES.find((ct) => ct.key === item.content_type);
                const Icon = typeInfo?.icon || Play;
                return (
                  <div key={item.id} className="animate-slide-up" style={{ animationDelay: `${Math.min(i * 0.03, 0.45)}s`, opacity: 0 }}>
                    <div className="group cursor-pointer" onClick={() => setPlayingContent(item)}>
                      <div className="relative aspect-video rounded-xl overflow-hidden bg-card border border-default group-hover:border-accent/50 transition-all">
                        {item.thumbnail_url ? (
                          <img src={item.thumbnail_url} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-hover">
                            <Icon className="w-10 h-10 text-muted" />
                          </div>
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                        <div className="absolute top-2 right-2 px-2 py-1 rounded-lg glass-dark text-[10px] font-medium text-white/90">
                          {typeInfo?.label}
                        </div>
                        {item.episode_number && (
                          <div className="absolute top-2 left-2 px-2 py-1 rounded-lg bg-accent/80 text-white text-[10px] font-bold">
                            ئەلقە {item.episode_number}
                          </div>
                        )}
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="w-12 h-12 rounded-full bg-accent flex items-center justify-center shadow-glow">
                            <Play className="w-5 h-5 text-black ml-0.5" fill="black" />
                          </div>
                        </div>
                        <div className="absolute bottom-0 left-0 right-0 p-2">
                          <p className="text-white text-xs font-medium truncate" dir="auto">{item.title}</p>
                        </div>
                      </div>
                    </div>
                    {/* Admin controls */}
                    {isAdmin && (
                      <div className="flex items-center gap-1 mt-1">
                        <button onClick={(e) => { e.stopPropagation(); startEdit(item); }} className="p-1.5 rounded text-secondary hover:text-accent"><Edit2 className="w-3.5 h-3.5" /></button>
                        <button onClick={(e) => { e.stopPropagation(); handleDelete(item.id); }} className="p-1.5 rounded text-secondary hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Admin: Manage existing content list */}
          {isAdmin && channelContent.length > 0 && !showForm && (
            <div className="mt-6 bg-card border border-default rounded-xl p-4">
              <h3 className="text-sm font-semibold text-primary mb-3">بەڕێوبەردنی ناوەڕۆکی {selectedChannel.name}</h3>
              <div className="space-y-1.5">
                {channelContent.map((item) => (
                  <div key={item.id} className="flex items-center gap-2 p-2 rounded-lg bg-secondary text-sm">
                    <span className="text-primary flex-1 min-w-0 truncate">{item.title}</span>
                    <span className="text-xs text-muted flex-shrink-0">{CONTENT_TYPES.find((ct) => ct.key === item.content_type)?.label}</span>
                    <button onClick={() => startEdit(item)} className="p-1.5 rounded text-secondary hover:text-accent transition-colors"><Edit2 className="w-3.5 h-3.5" /></button>
                    <button onClick={() => handleDelete(item.id)} className="p-1.5 rounded text-secondary hover:text-red-400 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
