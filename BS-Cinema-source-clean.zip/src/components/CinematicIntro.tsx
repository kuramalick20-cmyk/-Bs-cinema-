import { useState, useEffect } from 'react';

const INTRO_DURATION = 5000;

const SUN_RAYS = Array.from({ length: 21 }).map((_, i) => {
  const angle = (i * 360) / 21;
  const rad = (angle * Math.PI) / 180;
  const cx = 50, cy = 50;
  const inner = 30, outer = 42;
  const spread = 0.05;
  const x1 = cx + Math.cos(rad - spread) * inner;
  const y1 = cy + Math.sin(rad - spread) * inner;
  const x2 = cx + Math.cos(rad) * outer;
  const y2 = cy + Math.sin(rad) * outer;
  const x3 = cx + Math.cos(rad + spread) * inner;
  const y3 = cy + Math.sin(rad + spread) * inner;
  return `${x1},${y1} ${x2},${y2} ${x3},${y3}`;
});

export default function CinematicIntro({ onFinish }: { onFinish: () => void }) {
  const [fadingOut, setFadingOut] = useState(false);

  useEffect(() => {
    const fadeTimer = setTimeout(() => setFadingOut(true), INTRO_DURATION - 400);
    const doneTimer = setTimeout(onFinish, INTRO_DURATION);
    return () => { clearTimeout(fadeTimer); clearTimeout(doneTimer); };
  }, [onFinish]);

  return (
    <div
      className="fixed inset-0 z-[200] flex flex-col items-center justify-center overflow-hidden"
      style={{
        background: '#050508',
        animation: fadingOut ? 'introFadeOut 0.4s ease forwards' : 'none',
      }}
    >
      {/* Vignette */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center, transparent 30%, rgba(0,0,0,0.6) 100%)',
          animation: 'introVignette 1s ease forwards',
        }}
      />

      {/* Ambient golden sun glow */}
      <div
        className="absolute pointer-events-none"
        style={{
          top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
          width: '70vw', height: '70vw', maxWidth: '420px', maxHeight: '420px',
          background: 'radial-gradient(circle, rgba(107,159,255,0.08) 0%, rgba(167,139,255,0.06) 40%, transparent 70%)',
          animation: 'introBgGlow 3s ease forwards',
        }}
      />

      {/* Light sweep */}
      <div
        className="absolute pointer-events-none"
        style={{
          top: 0, bottom: 0, width: '40%',
          background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.03) 50%, transparent 100%)',
          animation: 'introLightSweep 2.5s ease-in-out forwards',
        }}
      />

      {/* Rotating Kurdistan sun rays silhouette */}
      <svg
        className="absolute pointer-events-none"
        style={{
          width: '85vw', maxWidth: '340px', height: 'auto',
          animation: 'introReelRotate 5s linear forwards',
        }}
        viewBox="0 0 100 100"
        aria-hidden="true"
      >
        {SUN_RAYS.map((points, i) => (
          <polygon key={i} points={points} fill="rgba(249,227,0,0.04)" />
        ))}
      </svg>

      {/* Center content */}
      <div className="relative z-10 flex flex-col items-center">
        {/* BS monogram with Kurdistan flag gradient */}
        <div
          className="relative rounded-[28px] flex items-center justify-center overflow-hidden"
          style={{
            width: 'clamp(72px, 22vw, 120px)',
            height: 'clamp(72px, 22vw, 120px)',
            background: 'linear-gradient(135deg, #ef3340 0%, #ef3340 30%, #1a1a26 50%, #2bb24c 100%)',
            animation: 'introMonogramIn 1.2s cubic-bezier(0.16,1,0.3,1) forwards, introMonogramGlow 2s ease 1s forwards',
          }}
        >
          {/* White center band (Kurdistan flag) */}
          <div
            className="absolute left-0 right-0"
            style={{
              top: '38%', height: '24%',
              background: 'rgba(255,255,255,0.9)',
            }}
          />
          {/* Sun rays on the monogram */}
          <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full opacity-30" aria-hidden="true">
            {SUN_RAYS.map((points, i) => (
              <polygon key={i} points={points} fill="var(--accent)" />
            ))}
          </svg>
          <span
            className="relative font-black text-white"
            style={{
              fontFamily: "'Cairo', system-ui, sans-serif",
              fontSize: 'clamp(30px, 9vw, 52px)',
              letterSpacing: '-0.05em',
              textShadow: '0 2px 4px rgba(0,0,0,0.6)',
            }}
          >
            BS
          </span>
          {/* Light sweep across monogram */}
          <div className="absolute inset-0 rounded-[28px] overflow-hidden pointer-events-none">
            <div
              className="absolute top-0 bottom-0"
              style={{
                width: '50%',
                background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent)',
                animation: 'introLightSweep 2s ease-in-out 1s forwards',
              }}
            />
          </div>
        </div>

        {/* Wordmark */}
        <div
          className="mt-6 text-center"
          style={{ animation: 'introWordmarkIn 0.8s ease 1.4s forwards', opacity: 0 }}
        >
          <h1
            className="font-black text-white"
            style={{
              fontFamily: "'Cairo', system-ui, sans-serif",
              fontSize: 'clamp(28px, 8vw, 48px)',
              letterSpacing: '0.05em',
            }}
          >
            BS <span style={{ color: '#6b9fff' }}>Cinema</span>
          </h1>
        </div>

        {/* Tagline */}
        <p
          className="text-white/60 font-medium uppercase tracking-widest mt-2"
          style={{
            fontFamily: "'Cairo', system-ui, sans-serif",
            fontSize: 'clamp(8px, 2.5vw, 12px)',
            animation: 'introSubIn 0.6s ease 2s forwards',
            opacity: 0,
          }}
        >
          Kurdistan
        </p>

        {/* Decorative bar with flag colors */}
        <div
          className="mt-5 flex items-center gap-1"
          style={{ animation: 'introBarExpand 0.8s ease 2.2s forwards', opacity: 0 }}
        >
          <div className="h-[2px] w-8 rounded-full" style={{ background: '#ef3340' }} />
          <div className="h-[2px] w-12 rounded-full" style={{ background: 'rgba(255,255,255,0.7)' }} />
          <div className="h-[2px] w-8 rounded-full" style={{ background: '#2bb24c' }} />
        </div>
      </div>

      {/* Progress bar at bottom with flag colors */}
      <div
        className="absolute bottom-0 left-0 h-[3px]"
        style={{
          background: 'linear-gradient(90deg, #ef3340 0%, #6b9fff 50%, #2bb24c 100%)',
          animation: 'introProgress 5s linear forwards',
        }}
      />
    </div>
  );
}
