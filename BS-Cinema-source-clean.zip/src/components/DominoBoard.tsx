import { type DominoGameState, type DominoTile, type Placement, canPlaceTile, getPipPositions } from '@/lib/dominoEngine';

interface DominoBoardProps {
  state: DominoGameState;
  playerHand: DominoTile[];
  isMyTurn: boolean;
  onPlaceTile: (tile: DominoTile, placement: Placement, flipped: boolean) => void;
  onDraw: () => void;
  onPass: () => void;
  opponentHandCount: number;
}

function PipFace({ value, size = 'normal' }: { value: number; size?: 'normal' | 'small' }) {
  const pips = getPipPositions(value);
  const dotSize = size === 'small' ? 'w-1.5 h-1.5' : 'w-2.5 h-2.5';

  return (
    <div className={`relative ${size === 'small' ? 'w-8 h-8' : 'w-12 h-12'} rounded-lg bg-[#f5f0e0] flex items-center justify-center`}>
      <div className="grid grid-cols-3 gap-0.5" style={{ width: size === 'small' ? '24px' : '32px', height: size === 'small' ? '24px' : '32px' }}>
        {Array.from({ length: 9 }).map((_, i) => {
          const row = Math.floor(i / 3);
          const col = i % 3;
          const hasPip = pips.some(([pr, pc]) => pr === row && pc === col);
          return (
            <div key={i} className="flex items-center justify-center">
              {hasPip && <div className={`${dotSize} rounded-full bg-[#1a1a26]`} />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function TileView({ tile, flipped, onClick, highlight, disabled, size = 'normal' }: {
  tile: DominoTile;
  flipped?: boolean;
  onClick?: () => void;
  highlight?: boolean;
  disabled?: boolean;
  size?: 'normal' | 'small';
}) {
  const left = flipped ? tile.right : tile.left;
  const right = flipped ? tile.left : tile.right;

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`flex rounded-lg overflow-hidden border-2 transition-all ${
        highlight ? 'border-accent shadow-glow scale-105' : 'border-[#d0c8a0]'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105 cursor-pointer'} bg-[#f5f0e0]`}
    >
      <div className="border-r-2 border-[#d0c8a0]">
        <PipFace value={left} size={size} />
      </div>
      <div>
        <PipFace value={right} size={size} />
      </div>
    </button>
  );
}

export default function DominoBoard({ state, playerHand, isMyTurn, onPlaceTile, onDraw, onPass, opponentHandCount }: DominoBoardProps) {
  const canPlay = playerHand.some((tile) => canPlaceTile(state, tile).length > 0);

  return (
    <div className="w-full max-w-[min(95vw,700px)] mx-auto space-y-4">
      {/* Opponent hand (face down) */}
      <div className="flex justify-center gap-1 flex-wrap">
        {Array.from({ length: opponentHandCount }).map((_, i) => (
          <div key={i} className="w-12 h-12 rounded-lg bg-card border border-bright flex items-center justify-center">
            <div className="w-8 h-8 rounded bg-elevated border border-default" />
          </div>
        ))}
        {opponentHandCount === 0 && <p className="text-sm text-muted">بەکارهێنەر دەست خاڵی کرد</p>}
      </div>

      {/* Boneyard count */}
      <div className="text-center">
        <span className="text-xs text-muted">کۆگا: {state.boneyard.length} خشتە</span>
      </div>

      {/* Board */}
      <div className="min-h-[80px] rounded-xl bg-secondary border border-default p-3 overflow-x-auto carousel-hide-scroll">
        {state.board.length === 0 ? (
          <div className="flex items-center justify-center h-[80px] text-sm text-muted">
            یاریەکە دەستپێبکە — یەکەم خشتە دابنە
          </div>
        ) : (
          <div className="flex gap-1 items-center flex-wrap justify-center">
            {state.board.map((bt, i) => (
              <div key={i} className="flex-shrink-0">
                <TileView tile={bt.tile} size="small" disabled />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* End indicators */}
      {state.board.length > 0 && (
        <div className="flex justify-between text-xs text-muted px-2">
          <span>سەرەوە: {state.leftEnd}</span>
          <span>کۆتایی: {state.rightEnd}</span>
        </div>
      )}

      {/* Player hand */}
      <div className="space-y-2">
        <p className="text-xs text-secondary text-center">دەستی تۆ ({playerHand.length} خشتە)</p>
        <div className="flex justify-center gap-1.5 flex-wrap">
          {playerHand.map((tile) => {
            const options = canPlaceTile(state, tile);
            const canPlace = options.length > 0 && isMyTurn;
            // For simplicity, pick the first available placement
            const firstOption = options[0];
            return (
              <TileView
                key={tile.id}
                tile={tile}
                flipped={firstOption?.flipped}
                highlight={canPlace}
                disabled={!canPlace}
                onClick={() => {
                  if (firstOption) {
                    onPlaceTile(tile, firstOption.placement!, firstOption.flipped!);
                  }
                }}
              />
            );
          })}
          {playerHand.length === 0 && <p className="text-sm text-accent">دەست بەتاڵە — یاریزانی براوە!</p>}
        </div>
      </div>

      {/* Actions */}
      <div className="flex justify-center gap-3">
        {!canPlay && isMyTurn && state.boneyard.length > 0 && (
          <button
            onClick={onDraw}
            className="px-5 py-2.5 rounded-xl bg-accent text-black text-sm font-bold hover:bg-[var(--accent-hover)] transition-all"
          >
            خشتە کێش بکە
          </button>
        )}
        {!canPlay && isMyTurn && state.boneyard.length === 0 && (
          <button
            onClick={onPass}
            className="px-5 py-2.5 rounded-xl bg-card border border-bright text-primary text-sm font-medium hover:bg-hover transition-all"
          >
            پاس بکە
          </button>
        )}
      </div>
    </div>
  );
}
