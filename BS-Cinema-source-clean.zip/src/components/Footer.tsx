import { Lock, Crown } from 'lucide-react';
import Logo from './Logo';
import SocialLinks from './SocialLinks';
import { isNativeApp } from '@/lib/platform';

interface FooterProps {
  onOpenAbout: () => void;
  onOpenSettings: () => void;
  onOpenAdmin: () => void;
  onOpenVip: () => void;
}

export default function Footer({ onOpenAbout, onOpenSettings, onOpenAdmin, onOpenVip }: FooterProps) {
  const hideAdmin = isNativeApp();
  return (
    <footer className="mt-8 sm:mt-14 border-t border-default bg-secondary relative overflow-hidden" style={{ paddingBottom: 'calc(1.5rem + var(--safe-bottom))' }}>
      {/* Flag gradient divider line — preserved */}
      <div className="flag-divider absolute top-0 left-0 right-0" />
      {/* Subtle amber glow at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-px" style={{ background: 'linear-gradient(90deg, var(--flag-red), var(--flag-yellow), var(--flag-green))', opacity: 0.4 }} />

      <div className="max-w-7xl mx-auto px-4 py-6 sm:py-10 md:py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {/* Logo & description */}
          <div>
            <Logo size="md" />
            <p className="text-sm text-secondary mt-4 max-w-xs leading-relaxed">
              ماڵپەڕی سینەمای کوردی بۆ فیلم، زنجیرە، ئەنیمی و کۆمیک
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-sm font-semibold text-primary mb-4 tracking-wide">بەستەرەکان</h4>
            <div className="space-y-3">
              <button onClick={onOpenAbout} className="block text-sm text-secondary hover:text-accent transition-colors">
                دەربارە
              </button>
              <button onClick={onOpenSettings} className="block text-sm text-secondary hover:text-accent transition-colors">
                ڕێکخستنەکان
              </button>
              <button onClick={onOpenVip} className="flex items-center gap-1.5 text-sm text-secondary hover:text-accent transition-colors">
                <Crown className="w-4 h-4" /> ئەندامی VIP
              </button>
            </div>
          </div>

          {/* Social */}
          <div>
            <h4 className="text-sm font-semibold text-primary mb-4 tracking-wide">بەدوامان بکە</h4>
            <SocialLinks variant="footer" />
          </div>
        </div>

        <div className="mt-6 sm:mt-8 pt-4 sm:pt-6 border-t border-default flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-muted">© 2026 BS Cinema — هەموو مافەکان پارێزراون</p>
          <a href="https://bscinema.com" target="_blank" rel="noopener noreferrer" className="text-xs text-muted hover:text-accent transition-colors">
            bscinema.com
          </a>
          {!hideAdmin && (
            <button
              onClick={onOpenAdmin}
              className="p-1.5 rounded-md text-muted/30 hover:text-accent transition-all"
              title=""
            >
              <Lock className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </footer>
  );
}
