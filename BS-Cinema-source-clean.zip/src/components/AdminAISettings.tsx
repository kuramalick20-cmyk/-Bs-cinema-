import { useState, useEffect, useCallback } from 'react';
import { Plus, Trash2, Edit2, Check, X, Loader2, Save, Key, Video, MessageSquare, Eye, EyeOff, Star } from 'lucide-react';
import {
  fetchProviderSettings, updateProviderSettings,
  fetchVideoProviders, createVideoProvider, updateVideoProvider, deleteVideoProvider,
} from '@/lib/comicAnimation';
import type { AiVideoProvider, AiProviderSettings } from '@/lib/supabase';

export default function AdminAISettings() {
  const [settings, setSettings] = useState<AiProviderSettings | null>(null);
  const [providers, setProviders] = useState<AiVideoProvider[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState(false);
  const [showOpenAiKey, setShowOpenAiKey] = useState(false);
  const [editingProvider, setEditingProvider] = useState<AiVideoProvider | null>(null);
  const [showProviderForm, setShowProviderForm] = useState(false);
  const [showProviderKeys, setShowProviderKeys] = useState<Record<string, boolean>>({});

  const load = useCallback(async () => {
    setLoading(true);
    const [s, p] = await Promise.all([fetchProviderSettings(), fetchVideoProviders()]);
    setSettings(s);
    setProviders(p);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSaveSettings = async () => {
    if (!settings) return;
    setSaving(true);
    await updateProviderSettings({
      openai_api_key: settings.openai_api_key,
      openai_model: settings.openai_model,
      default_duration: settings.default_duration,
      max_duration: settings.max_duration,
      image_to_video_enabled: settings.image_to_video_enabled,
      chatgpt_enabled: settings.chatgpt_enabled,
      subtitle_ai_enabled: settings.subtitle_ai_enabled,
      default_video_provider_id: settings.default_video_provider_id,
    });
    setSaving(false);
    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 2000);
  };

  const handleSaveProvider = async (provider: Partial<AiVideoProvider>) => {
    if (editingProvider) {
      await updateVideoProvider(editingProvider.id, provider);
    } else {
      await createVideoProvider(provider as Omit<AiVideoProvider, 'id' | 'created_at' | 'updated_at'>);
    }
    setEditingProvider(null);
    setShowProviderForm(false);
    load();
  };

  const handleDeleteProvider = async (id: string) => {
    if (!confirm('ئەم دابینکەرە بسڕدرێتەوە؟')) return;
    await deleteVideoProvider(id);
    load();
  };

  const handleSetDefault = async (id: string) => {
    await updateVideoProvider(id, { is_default: true });
    load();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 text-accent animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Global AI Settings */}
      <div className="bg-card rounded-xl border border-default p-5">
        <div className="flex items-center gap-2 mb-4">
          <Key className="w-5 h-5 text-accent" />
          <h3 className="text-lg font-bold text-primary">ڕێکخستنی AI</h3>
        </div>

        {/* OpenAI / ChatGPT Settings */}
        <div className="space-y-3 mb-4">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-primary">ChatGPT / OpenAI</span>
            <label className="ml-auto flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={settings?.chatgpt_enabled || false}
                onChange={(e) => setSettings((s: AiProviderSettings | null) => s ? { ...s, chatgpt_enabled: e.target.checked } : s)}
                className="w-4 h-4 accent-accent"
              />
              <span className="text-xs text-secondary">چالاککردن</span>
            </label>
          </div>

          <div>
            <label className="text-xs text-secondary mb-1 block">OpenAI API Key</label>
            <div className="flex gap-2">
              <input
                type={showOpenAiKey ? 'text' : 'password'}
                value={settings?.openai_api_key || ''}
                onChange={(e) => setSettings((s: AiProviderSettings | null) => s ? { ...s, openai_api_key: e.target.value } : s)}
                placeholder="sk-..."
                className="flex-1 px-3 py-2 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent"
                dir="ltr"
              />
              <button
                onClick={() => setShowOpenAiKey(!showOpenAiKey)}
                className="px-3 py-2 rounded-lg bg-secondary border border-default text-secondary hover:text-primary"
              >
                {showOpenAiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="text-xs text-secondary mb-1 block">OpenAI Model</label>
            <select
              value={settings?.openai_model || 'gpt-4o'}
              onChange={(e) => setSettings((s: AiProviderSettings | null) => s ? { ...s, openai_model: e.target.value } : s)}
              className="w-full px-3 py-2 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent"
            >
              <option value="gpt-4o">GPT-4o (Vision)</option>
              <option value="gpt-4o-mini">GPT-4o Mini</option>
              <option value="gpt-4-turbo">GPT-4 Turbo</option>
              <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
            </select>
          </div>
        </div>

        <div className="border-t border-default pt-4 space-y-3">
          {/* Image-to-Video Settings */}
          <div className="flex items-center gap-2">
            <Video className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-primary">Image-to-Video</span>
            <label className="ml-auto flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={settings?.image_to_video_enabled || false}
                onChange={(e) => setSettings((s: AiProviderSettings | null) => s ? { ...s, image_to_video_enabled: e.target.checked } : s)}
                className="w-4 h-4 accent-accent"
              />
              <span className="text-xs text-secondary">چالاککردن</span>
            </label>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-secondary mb-1 block">ماوەی بنەڕەت (چرکە)</label>
              <input
                type="number"
                min={1}
                max={30}
                value={settings?.default_duration || 4}
                onChange={(e) => setSettings((s: AiProviderSettings | null) => s ? { ...s, default_duration: parseInt(e.target.value) || 4 } : s)}
                className="w-full px-3 py-2 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent"
              />
            </div>
            <div>
              <label className="text-xs text-secondary mb-1 block">زۆرترین ماوە (چرکە)</label>
              <input
                type="number"
                min={1}
                max={60}
                value={settings?.max_duration || 10}
                onChange={(e) => setSettings((s: AiProviderSettings | null) => s ? { ...s, max_duration: parseInt(e.target.value) || 10 } : s)}
                className="w-full px-3 py-2 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-secondary mb-1 block">دابینکەری بنەڕەت</label>
            <select
              value={settings?.default_video_provider_id || ''}
              onChange={(e) => setSettings((s: AiProviderSettings | null) => s ? { ...s, default_video_provider_id: e.target.value || null } : s)}
              className="w-full px-3 py-2 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent"
            >
              <option value="">— هەڵبژێرە —</option>
              {providers.filter(p => p.is_enabled).map(p => (
                <option key={p.id} value={p.id}>{p.name} ({p.model_name})</option>
              ))}
            </select>
          </div>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={settings?.subtitle_ai_enabled ?? true}
              onChange={(e) => setSettings((s: AiProviderSettings | null) => s ? { ...s, subtitle_ai_enabled: e.target.checked } : s)}
              className="w-4 h-4 accent-accent"
            />
            <span className="text-xs text-secondary">ژێرنووسی AI چالاککراو</span>
          </label>
        </div>

        <button
          onClick={handleSaveSettings}
          disabled={saving}
          className="mt-4 flex items-center gap-2 px-4 py-2 rounded-lg bg-accent text-white text-sm font-medium disabled:opacity-50"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {savedMsg ? 'پاشەکەوتکرا!' : 'پاشەکەوتکردنی ڕێکخستن'}
        </button>
      </div>

      {/* Video Providers */}
      <div className="bg-card rounded-xl border border-default p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Video className="w-5 h-5 text-accent" />
            <h3 className="text-lg font-bold text-primary">دابینکەری ڤیدیۆ AI</h3>
          </div>
          <button
            onClick={() => { setEditingProvider(null); setShowProviderForm(true); }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-accent text-white text-sm font-medium"
          >
            <Plus className="w-4 h-4" /> زیادکردن
          </button>
        </div>

        {providers.length === 0 && !showProviderForm && (
          <p className="text-sm text-muted text-center py-6">هیچ دابینکەرێک زیادنەکراوە. کلیک لەسەر "زیادکردن" بکە.</p>
        )}

        <div className="space-y-2">
          {providers.map((p) => (
            <div key={p.id} className="flex items-center gap-3 p-3 rounded-lg bg-secondary border border-default">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-primary">{p.name}</span>
                  {p.is_default && <Star className="w-3.5 h-3.5 text-accent fill-[var(--accent)]" />}
                  <span className={`text-xs px-2 py-0.5 rounded ${p.is_enabled ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>
                    {p.is_enabled ? 'چالاک' : 'ناچالاک'}
                  </span>
                </div>
                <div className="text-xs text-muted mt-0.5">
                  {p.provider_type} • {p.model_name}
                </div>
                <div className="text-xs text-muted truncate max-w-md" dir="ltr">{p.api_endpoint}</div>
              </div>
              <button
                onClick={() => setShowProviderKeys(s => ({ ...s, [p.id]: !s[p.id] }))}
                className="p-1.5 rounded text-secondary hover:text-primary"
                title={showProviderKeys[p.id] ? 'شاردنەوەی کلیل' : 'پیشاندانی کلیل'}
              >
                {showProviderKeys[p.id] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
              <span className="text-xs text-muted font-mono" dir="ltr">
                {showProviderKeys[p.id] ? p.api_key : '••••••••'}
              </span>
              <button
                onClick={() => { setEditingProvider(p); setShowProviderForm(true); }}
                className="p-1.5 rounded text-secondary hover:text-accent"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              {!p.is_default && (
                <button
                  onClick={() => handleSetDefault(p.id)}
                  className="p-1.5 rounded text-secondary hover:text-accent"
                  title="کردن بە بنەڕەت"
                >
                  <Star className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={() => handleDeleteProvider(p.id)}
                className="p-1.5 rounded text-secondary hover:text-red-400"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {showProviderForm && (
          <ProviderForm
            provider={editingProvider}
            onSave={handleSaveProvider}
            onCancel={() => { setShowProviderForm(false); setEditingProvider(null); }}
          />
        )}
      </div>
    </div>
  );
}

function ProviderForm({
  provider,
  onSave,
  onCancel,
}: {
  provider: AiVideoProvider | null;
  onSave: (p: Partial<AiVideoProvider>) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState(provider?.name || '');
  const [type, setType] = useState<'image-to-video' | 'text-to-video'>(provider?.provider_type || 'image-to-video');
  const [apiKey, setApiKey] = useState(provider?.api_key || '');
  const [endpoint, setEndpoint] = useState(provider?.api_endpoint || '');
  const [model, setModel] = useState(provider?.model_name || '');
  const [enabled, setEnabled] = useState(provider?.is_enabled ?? true);
  const [isDefault, setIsDefault] = useState(provider?.is_default ?? false);

  return (
    <div className="mt-4 p-4 rounded-lg bg-secondary border border-accent/30 space-y-3">
      <h4 className="text-sm font-medium text-primary">{provider ? 'دەستکاریکردن' : 'زیادکردنی دابینکەر'}</h4>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-secondary mb-1 block">ناو</label>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Runway / Kling / etc." className="w-full px-3 py-2 rounded-lg bg-primary/5 border border-default text-primary text-sm outline-none focus:border-accent" dir="ltr" />
        </div>
        <div>
          <label className="text-xs text-secondary mb-1 block">جۆر</label>
          <select value={type} onChange={(e) => setType(e.target.value as any)} className="w-full px-3 py-2 rounded-lg bg-primary/5 border border-default text-primary text-sm outline-none focus:border-accent">
            <option value="image-to-video">Image-to-Video</option>
            <option value="text-to-video">Text-to-Video</option>
          </select>
        </div>
      </div>

      <div>
        <label className="text-xs text-secondary mb-1 block">API Endpoint URL</label>
        <input value={endpoint} onChange={(e) => setEndpoint(e.target.value)} placeholder="https://api.provider.com/v1/generate" className="w-full px-3 py-2 rounded-lg bg-primary/5 border border-default text-primary text-sm outline-none focus:border-accent" dir="ltr" />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-secondary mb-1 block">Model Name</label>
          <input value={model} onChange={(e) => setModel(e.target.value)} placeholder="gen3 / svd / etc." className="w-full px-3 py-2 rounded-lg bg-primary/5 border border-default text-primary text-sm outline-none focus:border-accent" dir="ltr" />
        </div>
        <div>
          <label className="text-xs text-secondary mb-1 block">API Key</label>
          <input type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="sk-..." className="w-full px-3 py-2 rounded-lg bg-primary/5 border border-default text-primary text-sm outline-none focus:border-accent" dir="ltr" />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} className="w-4 h-4 accent-accent" />
          <span className="text-xs text-secondary">چالاک</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={isDefault} onChange={(e) => setIsDefault(e.target.checked)} className="w-4 h-4 accent-accent" />
          <span className="text-xs text-secondary">کردن بە بنەڕەت</span>
        </label>
      </div>

      <div className="flex items-center justify-end gap-2">
        <button onClick={onCancel} className="px-3 py-1.5 rounded-lg bg-secondary text-secondary text-sm flex items-center gap-1">
          <X className="w-4 h-4" /> هەڵوەشاندنەوە
        </button>
        <button
          onClick={() => onSave({
            name, provider_type: type, api_key: apiKey, api_endpoint: endpoint,
            model_name: model, is_enabled: enabled, is_default: isDefault,
            config: provider?.config || null,
          })}
          disabled={!name || !endpoint || !apiKey}
          className="px-3 py-1.5 rounded-lg bg-accent text-white text-sm flex items-center gap-1 disabled:opacity-50"
        >
          <Check className="w-4 h-4" /> پاشەکەوت
        </button>
      </div>
    </div>
  );
}
