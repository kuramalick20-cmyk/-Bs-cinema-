import { useState, useEffect, useCallback, useRef } from 'react';
import { X, Gamepad2, Crown, Bot, Users, Search, Loader2, ArrowLeft, RefreshCw, Flag, MessageSquare, Send, MessagesSquare } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { type Profile, type GameChatMessage } from '@/lib/supabase';
import { supabase } from '@/lib/supabase';
import {
  type GameState, initialState, applyMove, getLegalMoves, getGameResult, moveToNotation,
  serializeState, deserializeState, type Move, type PieceColor, isInCheck,
} from '@/lib/chessEngine';
import { getBotMove, BOT_ELO_LEVELS } from '@/lib/chessBot';
import {
  type DominoGameState, newGameState, placeTile, drawTile, passTurn, canPlaceTile,
  serializeDominoState, deserializeDominoState, getDominoBotMove, type Placement,
} from '@/lib/dominoEngine';
import {
  type GameMatch, createGameInvite, acceptGameInvite, declineGameInvite,
  getPendingInvites, createBotMatch, getActiveMatches, getMatchHistory,
  submitChessMove, submitDominoMove, resignMatch, subscribeToMatch,
  subscribeToInvites, getMatch, getProfile,
  fetchGameChatMessages, sendGameChatMessage, subscribeToGameChat,
} from '@/lib/gameSync';
import ChessBoard from './ChessBoard';
import DominoBoard from './DominoBoard';
import KirkukGame from './KirkukGame';
import WarbandGame from './WarbandGame';

type View = 'hub' | 'chess-game' | 'domino-game' | 'invite' | 'history' | 'rpg';
type GameMode = 'bot' | 'multiplayer';

interface ActiveChessGame {
  matchId: string | null;
  state: GameState;
  playerColor: PieceColor;
  mode: GameMode;
  botElo?: number;
  opponentProfile?: Profile | null;
  moveHistory: string[];
  lastMove: { from: string; to: string } | null;
  result: string | null;
  resultReason: string | null;
}

interface ActiveDominoGame {
  matchId: string | null;
  state: DominoGameState;
  playerNum: 'player1' | 'player2';
  mode: GameMode;
  opponentProfile?: Profile | null;
  result: string | null;
}

interface GamesHubProps {
  onClose: () => void;
}

export default function GamesHub({ onClose }: GamesHubProps) {
  const { user, profile } = useAuth();
  const [view, setView] = useState<View>('hub');
  const [gameType, setGameType] = useState<'chess' | 'dominoes'>('chess');
  const [pendingInvites, setPendingInvites] = useState<any[]>([]);
  const [activeMatches, setActiveMatches] = useState<GameMatch[]>([]);
  const [history, setHistory] = useState<GameMatch[]>([]);
  const [loading, setLoading] = useState(false);
  const [chessGame, setChessGame] = useState<ActiveChessGame | null>(null);
  const [dominoGame, setDominoGame] = useState<ActiveDominoGame | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [botElo, setBotElo] = useState(800);
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'ai'; text: string }[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [showRpg, setShowRpg] = useState(false);
  const [showWarband, setShowWarband] = useState(false);
  const [playerChatMessages, setPlayerChatMessages] = useState<GameChatMessage[]>([]);
  const [playerChatInput, setPlayerChatInput] = useState('');
  const [showPlayerChat, setShowPlayerChat] = useState(false);

  const loadInvites = useCallback(async () => {
    if (!user) return;
    const invites = await getPendingInvites(user.id);
    const withProfiles = await Promise.all(
      invites.map(async (inv) => {
        const p = await getProfile(inv.from_user);
        return { ...inv, from_profile: p };
      })
    );
    setPendingInvites(withProfiles);
  }, [user]);

  const loadActiveMatches = useCallback(async () => {
    if (!user) return;
    const matches = await getActiveMatches(user.id);
    setActiveMatches(matches);
  }, [user]);

  const loadHistory = useCallback(async () => {
    if (!user) return;
    const matches = await getMatchHistory(user.id);
    setHistory(matches);
  }, [user]);

  useEffect(() => {
    loadInvites();
    loadActiveMatches();
  }, [loadInvites, loadActiveMatches]);

  // Realtime invite subscription
  useEffect(() => {
    if (!user) return;
    const unsub = subscribeToInvites(user.id, () => {
      loadInvites();
      loadActiveMatches();
    });
    return unsub;
  }, [user, loadInvites, loadActiveMatches]);

  // User search for invites — uses the same profiles table as chat
  useEffect(() => {
    if (!searchQuery.trim() || !user) {
      setSearchResults([]);
      return;
    }
    const sanitized = searchQuery.trim().replace(/[%_\\]/g, '');
    const timer = setTimeout(async () => {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .ilike('username', `%${sanitized}%`)
        .neq('id', user.id)
        .limit(10);
      setSearchResults((data as Profile[]) || []);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery, user]);

  // Start a chess bot game
  const startChessBot = async (elo: number) => {
    if (!user) return;
    setLoading(true);
    const match = await createBotMatch(user.id, 'chess', elo);
    if (match) {
      setChessGame({
        matchId: match.id,
        state: deserializeState(JSON.stringify(match.game_state)),
        playerColor: 'w',
        mode: 'bot',
        botElo: elo,
        opponentProfile: null,
        moveHistory: [],
        lastMove: null,
        result: null,
        resultReason: null,
      });
      setGameType('chess');
      setView('chess-game');
    }
    setLoading(false);
  };

  // Start a domino bot game
  const startDominoBot = async () => {
    if (!user) return;
    setLoading(true);
    const match = await createBotMatch(user.id, 'dominoes', 0);
    if (match) {
      const state = deserializeDominoState(JSON.stringify(match.game_state));
      setDominoGame({
        matchId: match.id,
        state,
        playerNum: 'player1',
        mode: 'bot',
        opponentProfile: null,
        result: null,
      });
      setGameType('dominoes');
      setView('domino-game');
    }
    setLoading(false);
  };

  // Send a chess invite
  const sendChessInvite = async (toUser: Profile) => {
    if (!user) return;
    setLoading(true);
    await createGameInvite(user.id, toUser.id, gameType);
    setSearchQuery('');
    setSearchResults([]);
    setLoading(false);
  };

  // Accept an invite
  const acceptInvite = async (invite: any) => {
    if (!user) return;
    setLoading(true);
    const match = await acceptGameInvite(invite.id, invite.from_user, user.id, invite.game_type);
    if (match) {
      await loadInvites();
      await loadActiveMatches();
      joinMatch(match);
    }
    setLoading(false);
  };

  const declineInvite = async (inviteId: string) => {
    await declineGameInvite(inviteId);
    await loadInvites();
  };

  // Join an existing match
  const joinMatch = (match: GameMatch) => {
    if (match.game_type === 'chess') {
      const state = deserializeState(JSON.stringify(match.game_state));
      const isWhite = match.player_white === user?.id;
      setChessGame({
        matchId: match.id,
        state,
        playerColor: isWhite ? 'w' : 'b',
        mode: 'multiplayer',
        opponentProfile: null,
        moveHistory: match.move_history || [],
        lastMove: null,
        result: match.result,
        resultReason: match.result_reason,
      });
      // Load opponent profile
      const opponentId = isWhite ? match.player_black : match.player_white;
      if (opponentId) {
        getProfile(opponentId).then((p) => {
          setChessGame((prev) => prev ? { ...prev, opponentProfile: p } : prev);
        });
      }
      setGameType('chess');
      setView('chess-game');
    } else {
      const state = deserializeDominoState(JSON.stringify(match.game_state));
      const isPlayer1 = match.player_white === user?.id;
      setDominoGame({
        matchId: match.id,
        state,
        playerNum: isPlayer1 ? 'player1' : 'player2',
        mode: 'multiplayer',
        opponentProfile: null,
        result: match.result,
      });
      const opponentId = isPlayer1 ? match.player_black : match.player_white;
      if (opponentId) {
        getProfile(opponentId).then((p) => {
          setDominoGame((prev) => prev ? { ...prev, opponentProfile: p } : prev);
        });
      }
      setGameType('dominoes');
      setView('domino-game');
    }
  };

  // Load and subscribe to player chat for multiplayer matches
  useEffect(() => {
    const matchId = chessGame?.matchId || dominoGame?.matchId;
    const isMultiplayer = (chessGame?.mode === 'multiplayer') || (dominoGame?.mode === 'multiplayer');
    if (!matchId || !isMultiplayer) {
      setPlayerChatMessages([]);
      setShowPlayerChat(false);
      return;
    }
    fetchGameChatMessages(matchId).then(setPlayerChatMessages);
    const unsub = subscribeToGameChat(matchId, (msg) => {
      setPlayerChatMessages((prev) => [...prev, msg]);
    });
    return () => { unsub(); };
  }, [chessGame?.matchId, chessGame?.mode, dominoGame?.matchId, dominoGame?.mode]);

  // Realtime subscription for active match
  useEffect(() => {
    if (!chessGame?.matchId || chessGame.mode !== 'multiplayer') return;
    const unsub = subscribeToMatch(chessGame.matchId, (match) => {
      const state = deserializeState(JSON.stringify(match.game_state));
      setChessGame((prev) => prev ? {
        ...prev,
        state,
        result: match.result,
        resultReason: match.result_reason,
        moveHistory: match.move_history || [],
      } : prev);
    });
    return unsub;
  }, [chessGame?.matchId, chessGame?.mode]);

  useEffect(() => {
    if (!dominoGame?.matchId || dominoGame.mode !== 'multiplayer') return;
    const unsub = subscribeToMatch(dominoGame.matchId, (match) => {
      const state = deserializeDominoState(JSON.stringify(match.game_state));
      setDominoGame((prev) => prev ? {
        ...prev,
        state,
        result: match.result,
      } : prev);
    });
    return unsub;
  }, [dominoGame?.matchId, dominoGame?.mode]);

  // Handle chess move
  const handleChessMove = async (move: Move) => {
    if (!chessGame || !user) return;
    const newState = applyMove(chessGame.state, move);
    const notation = moveToNotation(chessGame.state, move);
    const result = getGameResult(newState, []);
    const newHistory = [...chessGame.moveHistory, notation];

    setChessGame({
      ...chessGame,
      state: newState,
      lastMove: { from: move.from, to: move.to },
      moveHistory: newHistory,
      result: result?.result || null,
      resultReason: result?.reason || null,
    });

    // Submit to server if multiplayer
    if (chessGame.matchId && chessGame.mode === 'multiplayer') {
      await submitChessMove(chessGame.matchId, user.id, chessGame.state, move, newHistory.length);
    }

    // Bot response
    if (chessGame.mode === 'bot' && !result) {
      setTimeout(() => {
        const botMove = getBotMove(newState, 'b', chessGame.botElo || 800);
        if (botMove) {
          const botNewState = applyMove(newState, botMove);
          const botNotation = moveToNotation(newState, botMove);
          const botResult = getGameResult(botNewState, []);
          setChessGame((prev) => prev ? {
            ...prev,
            state: botNewState,
            lastMove: { from: botMove.from, to: botMove.to },
            moveHistory: [...prev.moveHistory, botNotation],
            result: botResult?.result || null,
            resultReason: botResult?.reason || null,
          } : prev);
        }
      }, 300 + Math.random() * 500);
    }
  };

  // Handle domino move
  const handleDominoPlace = async (tile: any, placement: Placement, flipped: boolean) => {
    if (!dominoGame || !user) return;
    const newState = placeTile(dominoGame.state, tile, placement, flipped, dominoGame.playerNum);

    setDominoGame({ ...dominoGame, state: newState, result: newState.status === 'completed' ? (newState.winner === 'draw' ? 'draw' : newState.winner === dominoGame.playerNum ? 'win' : 'loss') : null });

    if (dominoGame.matchId && dominoGame.mode === 'multiplayer') {
      await submitDominoMove(dominoGame.matchId, user.id, newState, { type: 'place', tileId: tile.id, placement, flipped }, newState.board.length);
    }

    // Bot response
    if (dominoGame.mode === 'bot' && newState.status === 'playing') {
      setTimeout(() => {
        const botPlayer = dominoGame.playerNum === 'player1' ? 'player2' : 'player1';
        let botState = newState;
        let botAction = getDominoBotMove(botState, botPlayer);

        // Bot draws until it can play or boneyard is empty
        while ('draw' in botAction && botState.boneyard.length > 0) {
          botState = drawTile(botState, botPlayer);
          botAction = getDominoBotMove(botState, botPlayer);
        }

        if ('tile' in botAction) {
          botState = placeTile(botState, botAction.tile, botAction.placement, botAction.flipped, botPlayer);
        } else if ('pass' in botAction) {
          botState = passTurn(botState, botPlayer);
        }

        setDominoGame((prev) => prev ? {
          ...prev,
          state: botState,
          result: botState.status === 'completed' ? (botState.winner === 'draw' ? 'draw' : botState.winner === prev.playerNum ? 'win' : 'loss') : null,
        } : prev);
      }, 400 + Math.random() * 400);
    }
  };

  const handleDominoDraw = async () => {
    if (!dominoGame || !user) return;
    const newState = drawTile(dominoGame.state, dominoGame.playerNum);
    setDominoGame({ ...dominoGame, state: newState });
  };

  const handleDominoPass = async () => {
    if (!dominoGame || !user) return;
    const newState = passTurn(dominoGame.state, dominoGame.playerNum);
    setDominoGame({ ...dominoGame, state: newState, result: newState.status === 'completed' ? (newState.winner === 'draw' ? 'draw' : newState.winner === dominoGame.playerNum ? 'win' : 'loss') : null });

    if (dominoGame.mode === 'bot' && newState.status === 'playing') {
      setTimeout(() => {
        const botPlayer = dominoGame.playerNum === 'player1' ? 'player2' : 'player1';
        let botState = newState;
        let botAction = getDominoBotMove(botState, botPlayer);
        while ('draw' in botAction && botState.boneyard.length > 0) {
          botState = drawTile(botState, botPlayer);
          botAction = getDominoBotMove(botState, botPlayer);
        }
        if ('tile' in botAction) {
          botState = placeTile(botState, botAction.tile, botAction.placement, botAction.flipped, botPlayer);
        } else if ('pass' in botAction) {
          botState = passTurn(botState, botPlayer);
        }
        setDominoGame((prev) => prev ? {
          ...prev,
          state: botState,
          result: botState.status === 'completed' ? (botState.winner === 'draw' ? 'draw' : botState.winner === prev.playerNum ? 'win' : 'loss') : null,
        } : prev);
      }, 400);
    }
  };

  const handleResign = async () => {
    if (!user) return;
    if (chessGame?.matchId && chessGame.mode === 'multiplayer') {
      const oppId = chessGame.playerColor === 'w' ? chessGame.opponentProfile?.id : null;
      await resignMatch(chessGame.matchId, user.id, oppId || null);
    }
    setChessGame(null);
    setDominoGame(null);
    setView('hub');
    loadActiveMatches();
  };

  const handleRematch = () => {
    if (chessGame?.mode === 'bot') {
      startChessBot(chessGame.botElo || 800);
    } else if (dominoGame?.mode === 'bot') {
      startDominoBot();
    }
  };

  // AI Chat for games
  const sendChatMessage = async () => {
    if (!chatInput.trim()) return;
    const userMsg = chatInput.trim();
    setChatMessages((prev) => [...prev, { role: 'user', text: userMsg }]);
    setChatInput('');
    setChatLoading(true);

    // Build context about the current game
    let gameContext = '';
    if (chessGame) {
      const turn = chessGame.state.turn === 'w' ? 'White' : 'Black';
      const inCheckText = isInCheck(chessGame.state, chessGame.state.turn) ? ' The current player is in check.' : '';
      gameContext = `Current chess game context: It is ${turn}'s turn.${inCheckText} Move history: ${chessGame.moveHistory.join(', ') || 'none yet'}. The player is playing as ${chessGame.playerColor === 'w' ? 'White' : 'Black'}.`;
    } else if (dominoGame) {
      gameContext = `Current dominoes game context: Board has ${dominoGame.state.board.length} tiles. Left end: ${dominoGame.state.leftEnd}, Right end: ${dominoGame.state.rightEnd}. Player has ${dominoGame.state.player1Hand.length} tiles, opponent has ${dominoGame.state.player2Hand.length} tiles.`;
    }

    // Call the AI via edge function or local knowledge
    const aiResponse = generateGameAIResponse(userMsg, gameContext, gameType);
    setChatMessages((prev) => [...prev, { role: 'ai', text: aiResponse }]);
    setChatLoading(false);
  };

  // Send player-to-player chat message in multiplayer games
  const handleSendPlayerChat = async () => {
    if (!playerChatInput.trim()) return;
    const matchId = chessGame?.matchId || dominoGame?.matchId;
    if (!matchId) return;
    const text = playerChatInput.trim();
    setPlayerChatInput('');
    await sendGameChatMessage(matchId, text);
  };

  if (!user) {
    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-primary animate-fade-in">
        <div className="text-center space-y-4">
          <Gamepad2 className="w-12 h-12 text-muted mx-auto" />
          <p className="text-secondary">تکایە پێشتر بچۆ ژوورەوە بۆ یاریکردن</p>
          <button onClick={onClose} className="px-4 py-2 rounded-lg bg-accent text-black text-sm font-bold">داخستن</button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[60] bg-primary flex flex-col animate-fade-in">
      {/* Header */}
      <div className="glass-dark border-b border-default px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {view !== 'hub' && (
            <button onClick={() => { setView('hub'); setChessGame(null); setDominoGame(null); }} className="p-2 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all">
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <h2 className="text-lg font-bold text-primary flex items-center gap-2">
            <Gamepad2 className="w-5 h-5 text-accent" /> یاریەکان
          </h2>
        </div>
        <button onClick={onClose} className="p-2 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* HUB VIEW */}
        {view === 'hub' && (
          <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
            {/* Pending invites */}
            {pendingInvites.length > 0 && (
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-primary">بانگهێشتی یاری</h3>
                {pendingInvites.map((inv) => (
                  <div key={inv.id} className="flex items-center justify-between bg-card border border-bright rounded-xl p-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                        {inv.from_profile?.avatar_url ? (
                          <img src={inv.from_profile.avatar_url} alt="" className="w-10 h-10 rounded-full object-cover" />
                        ) : (
                          <span className="text-accent font-bold text-sm">{(inv.from_profile?.username || '?')[0]}</span>
                        )}
                      </div>
                      <div>
                        <p className="text-sm text-primary font-medium">{inv.from_profile?.username || 'بەکارهێنەر'}</p>
                        <p className="text-xs text-muted">{inv.game_type === 'chess' ? 'شەترەنج' : 'دۆمینۆ'}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => acceptInvite(inv)} className="px-4 py-1.5 rounded-lg bg-accent text-black text-xs font-bold hover:bg-[var(--accent-hover)] transition-all">قبولکردن</button>
                      <button onClick={() => declineInvite(inv.id)} className="px-4 py-1.5 rounded-lg bg-card border border-default text-secondary text-xs font-medium hover:bg-hover transition-all">ڕەتکردن</button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Game selection cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Chess */}
              <button
                onClick={() => { setGameType('chess'); setView('invite'); }}
                className="group relative rounded-2xl overflow-hidden bg-card border border-default hover:border-accent p-6 text-right transition-all hover:scale-[1.02] shadow-card"
              >
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-accent scale-x-0 group-hover:scale-x-100 transition-transform origin-right" />
                <div className="text-5xl mb-3 text-accent">♚</div>
                <h3 className="text-xl font-bold text-primary mb-1">شەترەنج</h3>
                <p className="text-sm text-secondary">یاری شەترەنج لەگەڵ بۆت یان یاریزانی ڕاستەقینە</p>
              </button>

              {/* Dominoes */}
              <button
                onClick={() => { setGameType('dominoes'); setView('invite'); }}
                className="group relative rounded-2xl overflow-hidden bg-card border border-default hover:border-accent p-6 text-right transition-all hover:scale-[1.02] shadow-card"
              >
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-accent scale-x-0 group-hover:scale-x-100 transition-transform origin-right" />
                <div className="text-5xl mb-3 text-accent">⬛</div>
                <h3 className="text-xl font-bold text-primary mb-1">دۆمینۆ</h3>
                <p className="text-sm text-secondary">یاری دۆمینۆ لەگەڵ بۆت یان یاریزانی ڕاستەقینە</p>
              </button>

              {/* Kirkuk RPG */}
              <button
                onClick={() => setShowRpg(true)}
                className="group relative rounded-2xl overflow-hidden bg-card border border-default hover:border-accent p-6 text-right transition-all hover:scale-[1.02] shadow-card sm:col-span-2"
              >
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-accent scale-x-0 group-hover:scale-x-100 transition-transform origin-right" />
                <div className="flex items-center gap-4">
                  <div className="text-5xl text-accent">🏰</div>
                  <div>
                    <h3 className="text-xl font-bold text-primary mb-1">پاشای کەرکووک</h3>
                    <p className="text-sm text-secondary">جیهانی کراوە لە شاری کەرکووک. بگەڕێ، بشڕ، پارە کۆبکەرەوە، لە پاسنگەرەکان ڕابکە!</p>
                  </div>
                </div>
              </button>

              {/* Warband RPG */}
              <button
                onClick={() => setShowWarband(true)}
                className="group relative rounded-2xl overflow-hidden bg-gradient-to-br from-[#1a1525] to-[#0d0a14] border border-amber-900/40 hover:border-amber-500/60 p-6 text-right transition-all hover:scale-[1.02] shadow-card sm:col-span-2"
              >
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-amber-500 scale-x-0 group-hover:scale-x-100 transition-transform origin-right" />
                <div className="flex items-center gap-4">
                  <div className="text-5xl">⚔️</div>
                  <div>
                    <h3 className="text-xl font-bold text-amber-100 mb-1">Warband: Conquest of Empires</h3>
                    <p className="text-sm text-amber-200/60">Choose your champion, conquer cities, recruit companions, marry for alliances, and build your empire across 6 ancient factions.</p>
                  </div>
                </div>
              </button>
            </div>

            {/* Active matches */}
            {activeMatches.length > 0 && (
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-primary">یاری چالاکەکان</h3>
                {activeMatches.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => joinMatch(m)}
                    className="w-full flex items-center justify-between bg-card border border-default rounded-xl p-3 hover:border-bright transition-all text-right"
                  >
                    <div>
                      <p className="text-sm text-primary font-medium">{m.game_type === 'chess' ? 'شەترەنج' : 'دۆمینۆ'} — {m.mode === 'bot' ? `بۆت ${m.bot_elo || ''}` : 'فرەیاریزانی'}</p>
                      <p className="text-xs text-muted">{m.status === 'waiting' ? 'چاوەڕێی یاریزان' : `نۆرەی ${m.current_turn === 'white' ? 'سپی' : 'ڕەش'}`}</p>
                    </div>
                    <span className="text-xs text-accent">بەردەوام بە</span>
                  </button>
                ))}
              </div>
            )}

            {/* History */}
            <div>
              <button onClick={() => { loadHistory(); setView('history'); }} className="text-sm text-accent hover:underline">
                مێژووی یاریەکان →
              </button>
            </div>
          </div>
        )}

        {/* INVITE VIEW — choose bot or multiplayer */}
        {view === 'invite' && (
          <div className="max-w-2xl mx-auto p-4 sm:p-6 space-y-6">
            <h3 className="text-lg font-bold text-primary">
              {gameType === 'chess' ? 'شەترەنج' : 'دۆمینۆ'} — جۆری یاری هەڵبژێرە
            </h3>

            {/* Bot mode */}
            <div className="bg-card border border-default rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-accent" />
                <h4 className="font-semibold text-primary">یاری لەگەڵ بۆت</h4>
              </div>
              {gameType === 'chess' ? (
                <>
                  <p className="text-sm text-secondary">ئاستی بۆت هەڵبژێرە:</p>
                  <div className="grid grid-cols-3 gap-2">
                    {BOT_ELO_LEVELS.map((elo) => (
                      <button
                        key={elo}
                        onClick={() => startChessBot(elo)}
                        disabled={loading}
                        className={`py-2.5 rounded-lg text-sm font-bold transition-all ${
                          botElo === elo ? 'bg-accent text-black' : 'bg-hover text-secondary hover:text-primary border border-default'
                        }`}
                      >
                        {elo} ELO
                      </button>
                    ))}
                  </div>
                </>
              ) : (
                <button
                  onClick={startDominoBot}
                  disabled={loading}
                  className="w-full py-3 rounded-xl bg-accent text-black font-bold hover:bg-[var(--accent-hover)] transition-all"
                >
                  دەستپێبکە لەگەڵ بۆت
                </button>
              )}
            </div>

            {/* Multiplayer mode */}
            <div className="bg-card border border-default rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-accent" />
                <h4 className="font-semibold text-primary">یاری لەگەڵ یاریزانی تر</h4>
              </div>
              <p className="text-sm text-secondary">گەڕان بکە بۆ بەکارهێنەر و بانگهێشتی بکە:</p>
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ناوی بەکارهێنەر..."
                  className="w-full pr-10 pl-4 py-2.5 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent"
                />
              </div>
              {searchResults.length > 0 && (
                <div className="space-y-1">
                  {searchResults.map((p) => (
                    <div key={p.id} className="flex items-center justify-between bg-hover rounded-lg p-2.5">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center overflow-hidden">
                          {p.avatar_url ? <img src={p.avatar_url} alt="" className="w-8 h-8 rounded-full object-cover" /> : <span className="text-accent text-xs font-bold">{(p.username || '?')[0]}</span>}
                        </div>
                        <span className="text-sm text-primary">{p.username}</span>
                      </div>
                      <button
                        onClick={() => sendChessInvite(p)}
                        disabled={loading}
                        className="px-3 py-1 rounded-lg bg-accent text-black text-xs font-bold hover:bg-[var(--accent-hover)] transition-all"
                      >
                        بانگهێشت
                      </button>
                    </div>
                  ))}
                </div>
              )}
              {searchQuery && searchResults.length === 0 && (
                <p className="text-sm text-muted text-center py-4">هیچ بەکارهێنەرێک نەدۆزرایەوە</p>
              )}
            </div>
          </div>
        )}

        {/* CHESS GAME VIEW */}
        {view === 'chess-game' && chessGame && (
          <div className="max-w-3xl mx-auto p-4 space-y-4">
            {/* Game status bar */}
            <div className="flex items-center justify-between bg-card border border-default rounded-xl p-3">
              <div className="flex items-center gap-2">
                {chessGame.mode === 'bot' ? (
                  <span className="text-sm text-primary flex items-center gap-1.5"><Bot className="w-4 h-4 text-accent" /> بۆت {chessGame.botElo} ELO</span>
                ) : (
                  <span className="text-sm text-primary flex items-center gap-1.5"><Users className="w-4 h-4 text-accent" /> {chessGame.opponentProfile?.username || 'یاریزان'}</span>
                )}
              </div>
              <div className="text-sm font-medium text-accent">
                {chessGame.result ? (
                  <span className="flex items-center gap-1">
                    {chessGame.result === 'white_wins' ? 'سپی بردووە' : chessGame.result === 'black_wins' ? 'ڕەش بردووە' : 'یەکسان'}
                    {chessGame.resultReason && <span className="text-muted text-xs">({chessGame.resultReason})</span>}
                  </span>
                ) : (
                  <span>نۆرەی {chessGame.state.turn === 'w' ? 'سپی' : 'ڕەش'}</span>
                )}
              </div>
            </div>

            {/* Chess board */}
            <ChessBoard
              state={chessGame.state}
              playerColor={chessGame.playerColor}
              onMove={handleChessMove}
              disabled={!!chessGame.result}
              lastMove={chessGame.lastMove}
            />

            {/* Game actions */}
            <div className="flex justify-center gap-3">
              {!chessGame.result && (
                <button onClick={handleResign} className="px-4 py-2 rounded-lg bg-card border border-default text-red-400 text-sm font-medium hover:bg-hover transition-all flex items-center gap-1.5">
                  <Flag className="w-4 h-4" /> خۆت بدە
                </button>
              )}
              {chessGame.result && chessGame.mode === 'bot' && (
                <button onClick={handleRematch} className="px-4 py-2 rounded-lg bg-accent text-black text-sm font-bold hover:bg-[var(--accent-hover)] transition-all flex items-center gap-1.5">
                  <RefreshCw className="w-4 h-4" /> دووبارە یاری بکە
                </button>
              )}
            </div>

            {/* Move history */}
            {chessGame.moveHistory.length > 0 && (
              <div className="bg-card border border-default rounded-xl p-3 max-h-32 overflow-y-auto">
                <p className="text-xs text-muted mb-2">مێژووی جوڵەکان</p>
                <div className="flex flex-wrap gap-2 text-xs text-secondary" dir="ltr">
                  {chessGame.moveHistory.map((m, i) => (
                    <span key={i} className="px-2 py-0.5 rounded bg-hover">{Math.floor(i / 2) + 1}{i % 2 === 0 ? '.' : '...'} {m}</span>
                  ))}
                </div>
              </div>
            )}

            {/* AI Chat */}
            <GameChat
              messages={chatMessages}
              input={chatInput}
              setInput={setChatInput}
              onSend={sendChatMessage}
              loading={chatLoading}
              gameType="chess"
            />

            {/* Player chat for multiplayer */}
            {chessGame.mode === 'multiplayer' && chessGame.matchId && (
              <PlayerChatPanel
                messages={playerChatMessages}
                input={playerChatInput}
                setInput={setPlayerChatInput}
                onSend={handleSendPlayerChat}
                currentUserId={user.id}
                opponentName={chessGame.opponentProfile?.username || 'یاریزان'}
                showPlayerChat={showPlayerChat}
                setShowPlayerChat={setShowPlayerChat}
              />
            )}
          </div>
        )}

        {/* DOMINO GAME VIEW */}
        {view === 'domino-game' && dominoGame && (
          <div className="max-w-3xl mx-auto p-4 space-y-4">
            <div className="flex items-center justify-between bg-card border border-default rounded-xl p-3">
              <div className="flex items-center gap-2">
                {dominoGame.mode === 'bot' ? (
                  <span className="text-sm text-primary flex items-center gap-1.5"><Bot className="w-4 h-4 text-accent" /> بۆت</span>
                ) : (
                  <span className="text-sm text-primary flex items-center gap-1.5"><Users className="w-4 h-4 text-accent" /> {dominoGame.opponentProfile?.username || 'یاریزان'}</span>
                )}
              </div>
              <div className="text-sm font-medium text-accent">
                {dominoGame.result ? (
                  <span>{dominoGame.result === 'win' ? 'تۆ بردووتە' : dominoGame.result === 'loss' ? 'تۆ دۆراوە' : 'یەکسان'}</span>
                ) : (
                  <span>{dominoGame.state.currentTurn === dominoGame.playerNum ? 'نۆرەی تۆ' : 'نۆرەی بەرامبەر'}</span>
                )}
              </div>
            </div>

            <DominoBoard
              state={dominoGame.state}
              playerHand={dominoGame.playerNum === 'player1' ? dominoGame.state.player1Hand : dominoGame.state.player2Hand}
              opponentHandCount={dominoGame.playerNum === 'player1' ? dominoGame.state.player2Hand.length : dominoGame.state.player1Hand.length}
              isMyTurn={dominoGame.state.currentTurn === dominoGame.playerNum && !dominoGame.result}
              onPlaceTile={handleDominoPlace}
              onDraw={handleDominoDraw}
              onPass={handleDominoPass}
            />

            <div className="flex justify-center gap-3">
              {!dominoGame.result && (
                <button onClick={handleResign} className="px-4 py-2 rounded-lg bg-card border border-default text-red-400 text-sm font-medium hover:bg-hover transition-all flex items-center gap-1.5">
                  <Flag className="w-4 h-4" /> خۆت بدە
                </button>
              )}
              {dominoGame.result && dominoGame.mode === 'bot' && (
                <button onClick={handleRematch} className="px-4 py-2 rounded-lg bg-accent text-black text-sm font-bold hover:bg-[var(--accent-hover)] transition-all flex items-center gap-1.5">
                  <RefreshCw className="w-4 h-4" /> دووبارە یاری بکە
                </button>
              )}
            </div>

            <GameChat
              messages={chatMessages}
              input={chatInput}
              setInput={setChatInput}
              onSend={sendChatMessage}
              loading={chatLoading}
              gameType="dominoes"
            />

            {/* Player chat for multiplayer */}
            {dominoGame.mode === 'multiplayer' && dominoGame.matchId && (
              <PlayerChatPanel
                messages={playerChatMessages}
                input={playerChatInput}
                setInput={setPlayerChatInput}
                onSend={handleSendPlayerChat}
                currentUserId={user.id}
                opponentName={dominoGame.opponentProfile?.username || 'یاریزان'}
                showPlayerChat={showPlayerChat}
                setShowPlayerChat={setShowPlayerChat}
              />
            )}
          </div>
        )}

        {/* KIRKUK RPG VIEW */}
        {showRpg && (
          <KirkukGame onClose={() => { setShowRpg(false); setView('hub'); }} />
        )}

        {/* WARBAND RPG VIEW */}
        {showWarband && (
          <WarbandGame onClose={() => { setShowWarband(false); setView('hub'); }} />
        )}

        {/* HISTORY VIEW */}
        {view === 'history' && (
          <div className="max-w-2xl mx-auto p-4 sm:p-6 space-y-3">
            <h3 className="text-lg font-bold text-primary">مێژووی یاریەکان</h3>
            {history.length === 0 ? (
              <p className="text-sm text-muted text-center py-8">هیچ یاریەکی پێشتر نییە</p>
            ) : (
              history.map((m) => (
                <div key={m.id} className="flex items-center justify-between bg-card border border-default rounded-xl p-3">
                  <div>
                    <p className="text-sm text-primary font-medium">{m.game_type === 'chess' ? 'شەترەنج' : 'دۆمینۆ'} — {m.mode === 'bot' ? `بۆت ${m.bot_elo || ''}` : 'فرەیاریزانی'}</p>
                    <p className="text-xs text-muted">{new Date(m.completed_at || m.created_at).toLocaleDateString()}</p>
                  </div>
                  <span className={`text-xs font-medium ${m.result === 'white_wins' ? 'text-accent' : m.result === 'draw' ? 'text-muted' : 'text-secondary'}`}>
                    {m.result === 'white_wins' ? 'سپی بردووە' : m.result === 'black_wins' ? 'ڕەش بردووە' : 'یەکسان'}
                  </span>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// AI Chat component for games
function GameChat({ messages, input, setInput, onSend, loading, gameType }: {
  messages: { role: 'user' | 'ai'; text: string }[];
  input: string;
  setInput: (v: string) => void;
  onSend: () => void;
  loading: boolean;
  gameType: string;
}) {
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="bg-card border border-default rounded-xl overflow-hidden">
      <div className="px-3 py-2 border-b border-default flex items-center gap-2">
        <MessageSquare className="w-4 h-4 text-accent" />
        <span className="text-sm font-medium text-primary">یاریدەدەری AI</span>
      </div>
      <div className="max-h-48 overflow-y-auto p-3 space-y-2">
        {messages.length === 0 ? (
          <p className="text-xs text-muted text-center py-3">پرسیار بکە دەربارەی یاریەکە، قواعدەکان، یان ستراتیژ...</p>
        ) : (
          messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}>
              <div className={`max-w-[85%] rounded-xl px-3 py-2 text-xs break-words ${
                msg.role === 'user' ? 'bg-accent text-black' : 'bg-hover text-primary border border-default'
              }`} dir="auto">
                {msg.text}
              </div>
            </div>
          ))
        )}
        {loading && <div className="flex justify-end"><div className="bg-hover rounded-xl px-3 py-2"><Loader2 className="w-4 h-4 text-accent animate-spin" /></div></div>}
        <div ref={chatEndRef} />
      </div>
      <div className="border-t border-default p-2 flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && onSend()}
          placeholder="پرسیار بکە..."
          className="flex-1 px-3 py-2 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-xs outline-none focus:border-accent"
          dir="auto"
        />
        <button onClick={onSend} disabled={!input.trim() || loading} className="p-2 rounded-lg bg-accent text-black disabled:opacity-50">
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

// Player-to-player real-time chat panel for multiplayer games
function PlayerChatPanel({ messages, input, setInput, onSend, currentUserId, opponentName, showPlayerChat, setShowPlayerChat }: {
  messages: GameChatMessage[];
  input: string;
  setInput: (v: string) => void;
  onSend: () => void;
  currentUserId: string;
  opponentName: string;
  showPlayerChat: boolean;
  setShowPlayerChat: (v: boolean) => void;
}) {
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="bg-card border border-default rounded-xl overflow-hidden">
      <button
        onClick={() => setShowPlayerChat(!showPlayerChat)}
        className="w-full px-3 py-2 border-b border-default flex items-center justify-between"
      >
        <div className="flex items-center gap-2">
          <MessagesSquare className="w-4 h-4 text-accent" />
          <span className="text-sm font-medium text-primary">گفتوگۆ لەگەڵ {opponentName}</span>
        </div>
        {messages.length > 0 && !showPlayerChat && (
          <span className="w-5 h-5 rounded-full bg-accent text-white text-[10px] flex items-center justify-center font-bold">{messages.length}</span>
        )}
      </button>

      {showPlayerChat && (
        <>
          <div className="max-h-48 overflow-y-auto p-3 space-y-2">
            {messages.length === 0 ? (
              <p className="text-xs text-muted text-center py-3">پەیام بنێرە بۆ یاریزانەکە...</p>
            ) : (
              messages.map((msg) => {
                const isMine = msg.sender_id === currentUserId;
                return (
                  <div key={msg.id} className={`flex ${isMine ? 'justify-start' : 'justify-end'}`}>
                    <div className={`max-w-[85%] rounded-xl px-3 py-2 text-xs break-words ${
                      isMine ? 'bg-accent text-black' : 'bg-hover text-primary border border-default'
                    }`} dir="auto">
                      {msg.text}
                    </div>
                  </div>
                );
              })
            )}
            <div ref={chatEndRef} />
          </div>
          <div className="border-t border-default p-2 flex items-center gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && onSend()}
              placeholder="نووسینی پەیام..."
              className="flex-1 px-3 py-2 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-xs outline-none focus:border-accent"
              dir="auto"
            />
            <button onClick={onSend} disabled={!input.trim()} className="p-2 rounded-lg bg-accent text-black disabled:opacity-50">
              <Send className="w-4 h-4" />
            </button>
          </div>
        </>
      )}
    </div>
  );
}

// Generate AI responses for game questions
function generateGameAIResponse(question: string, gameContext: string, gameType: string): string {
  const q = question.toLowerCase();

  if (gameType === 'chess') {
    if (q.includes('rule') || q.includes('قاعید') || q.includes('قوانین') || q.includes('چۆن')) {
      return 'شەترەنج یاریەکە بۆ دوو یاریزان. هەر یاریزان ١٦ خشتەی هەیە (١ پاشا، ١ ملکە، ٢ قەلەنگە، ٢ ئەسپ، ٢ فیل، ٨ سەپا). ئامانج برینی پاشای بەرامبەرە (چێکمەیت). پاشا تەنها یەک خولاێن دەجوڵێت. فیل بە یەک لا دەجوڵێت. ئەسپ بە شێوەی L دەجوڵێت. قەلەنگە بە سترایت و ئاستی. ملکە بە هەموو لا. سەپا بەرەو پێشەوە دەجوڵێت و لە یەکەم خولی بە دوو خولاێن.';
    }
    if (q.includes('castle') || q.includes('قلعە')) {
      return 'قلعە (Castling) جوڵەیەکی تایبەتە کە پاشا و قەلەنگە لە یەک کاتدا دەجوڵێن. پاشا دوو خولاێن بەرەو قەلەنگە و قەلەنگە دێتە لای پاشا. مەرجەکان: پاشا و قەلەنگە نەجوڵاون، هیچ خشتەیەک لە نێوانیان نەبێت، پاشا لە چێک نەبێت و نەچێتە چێک.';
    }
    if (q.includes('passant') || q.includes('ئەن پاسان')) {
      return 'ئەن پاسان (En Passant): کاتێک سەپای بەرامبەر دوو خولاێن دەجوڵێت و لە تەنیشت سەپای تۆ دەوەستێت، دەتوانیت سەپاکەی بگریت وەک ئەوەی یەک خولاێن جوڵابای. تەنها لە یەکەم دووری یاریەکە کار دەکات.';
    }
    if (q.includes('promot') || q.includes('پرومۆت') || q.includes('سەپا') && q.includes('کۆتا')) {
      return 'کاتێک سەپا دەگاتە کۆتایی تەختە، دەتوانیت بگۆڕیت بۆ ملکە، قەلەنگە، فیل، یان ئەسپ. زۆربەی کات ملکە باشترین هەڵبژاردنە.';
    }
    if (q.includes('check') || q.includes('چێک') || q.includes('شاخ')) {
      return 'چێک (Check) واتە پاشا لە مەترسیدایە. یاریزان دەبێت خۆی بگرێت: یان پاشا بجوڵێت، خشتەیەک بخاتە نێوان، یان خشتەی هێرشبەر بگرێت. چێکمەیت (Checkmate) واتە ناتوانێت خۆی بگرێت — یاری کۆتایی دێت.';
    }
    if (q.includes('strategy') || q.includes('ستراتیژ') || q.includes('چۆن ببەوە')) {
      return 'ستراتیژی شەترەنج: ١) ناوەندی تەختە کۆنترۆڵ بکە. ٢) خشتەکان خێرا گەشە بکە (ئەسپ و فیل پێشتر بجوڵێت). ٣) پاشا بپارێزە بە قەلەنگە (قلعە بکە). ٤) خشتە نەبەخشە بە بێ قەرەبوو. ٥) لە کۆتایی یاری، ملکە و قەلەنگە بەکار بهێنە بۆ برین.';
    }
    if (q.includes('illegal') || q.includes('نایاسایی') || q.includes('نادروست')) {
      return 'جوڵەی نایاسایی: ناتوانیت خشتە بخەیتە شوێنێک کە پاشای تۆ لە چێک دابنێت. ناتوانیت خشتەی خۆت بگریت. هەروەها ناتوانیت دوو خشتە لە یەک خولاێن بیجوڵێنی (بێ قلعە).';
    }
    if (q.includes('draw') || q.includes('یەکسان') || q.includes('ستەڵمات')) {
      return 'یەکسان (Draw) لە شەترەنج: ١) ستەڵمات — یاریزان هیچ جوڵەیەکی نییە و پاشای لە چێک نەبێت. ٢) مادەی نەسێر — ناتوانیت ببریت (تەنها پاشا و مادەی کەم). ٣) یاسای ٥٠ جوڵە بێ گرتنی خشتە. ٤) سێ جار دووبارەبوونی هەمان شوێن.';
    }
    if (gameContext) {
      return `دەربارەی یاریەکەی ئێستا: ${gameContext} ئەگەر پرسیاری تایبەتیت هەیە دەربارەی جوڵەیەک یان ستراتیژ، پرسیار بکە.`;
    }
    return 'من یاریدەدەری شەترەنجم. دەتوانم قواعدەکان، ستراتیژ، یان یاریەکەی ئێستا ڕاڤە بکەم. پرسیار بکە!';
  } else {
    if (q.includes('rule') || q.includes('قاعید') || q.includes('قوانین') || q.includes('چۆن')) {
      return 'دۆمینۆ یاریەکە بە ٢٨ خشتە (٠ تا ٦ پۆینت لە هەر لا). هەر یاریزان ٧ خشتە وەردەگرێت. یەکەم یاریزان خشتە دەخات، پاشان هەر یاریزان خشتەیەک دەخات کە ژمارەکەی لەگەڵ یەکێک لە کۆتاییەکانی تەختە بگونجێت. ئەگەر هیچ خشتەیەک نەبێت، لە کۆگا کێش دەکەیت. ئەگەر کۆگا بەتاڵ بێت، پاس دەکەیت. ئامانج خستنی هەموو خشتەکانتە.';
    }
    if (q.includes('score') || q.includes('خاڵ') || q.includes('پۆینت')) {
      return 'خاڵدان لە دۆمینۆ: کاتێک یاریزان هەموو خشتەکانی دەخات، براوە دەبێت و خاڵ وەردەگرێت بە کۆی پۆینتەکانی دەستی بەرامبەر. ئەگەر یاری بلۆک بێت (هەردوو یاریزان پاس بکەن)، کەمترین پۆینت دەست دەباتەوە.';
    }
    if (q.includes('strategy') || q.includes('ستراتیژ')) {
      return 'ستراتیژی دۆمینۆ: ١) خشتە بەرزەکان (ژمارە گەورە) زوو بخە. ٢) دووانەکان (doubles) زوو بەکار بهێنە. ٣) خشتەکانت هاوبەش بکە بۆ ئەوەی زیاتر بژوڵێت. ٤) کۆتایی یاری بە دیقەت یاری بکە.';
    }
    if (gameContext) {
      return `دەربارەی یاریەکەی ئێستا: ${gameContext} پرسیاری زیاتر بکە دەربارەی ستراتیژ یان خشتەکان.`;
    }
    return 'من یاریدەدەری دۆمینۆم. دەتوانم قواعدەکان، ستراتیژ، یان یاریەکەی ئێستا ڕاڤە بکەم. پرسیار بکە!';
  }
}
