import { useState, useEffect, useRef } from 'react';
import { X, Plus, Trash2, Save, Loader2, MessageSquareText, User, Mic } from 'lucide-react';
import type { ComicPanel, ComicCharacter, ComicSpeechBubble } from '@/lib/supabase';
import { supabase } from '@/lib/supabase';
import { fetchComicCharacters, saveCharacter, deleteCharacter, saveBubble, deleteBubble, updateBubble } from '@/lib/comicVoice';

interface BubbleEditorProps {
  panel: ComicPanel;
  panelIndex: number;
  contentId: string;
  onClose: () => void;
  onBubblesChanged: () => void;
}

export default function BubbleEditor({ panel, panelIndex, contentId, onClose, onBubblesChanged }: BubbleEditorProps) {
  const [characters, setCharacters] = useState<ComicCharacter[]>([]);
  const [bubbles, setBubbles] = useState<ComicSpeechBubble[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCharForm, setShowCharForm] = useState(false);
  const [charName, setCharName] = useState('');
  const [charVoiceType, setCharVoiceType] = useState<'male' | 'female'>('male');
  const [charVoiceLang, setCharVoiceLang] = useState('ku');
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [region, setRegion] = useState<{ x: number; y: number; width: number; height: number } | null>(null);
  const [newBubbleText, setNewBubbleText] = useState('');
  const [newBubbleChar, setNewBubbleChar] = useState<string>('');
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    loadData();
  }, [contentId]);

  const loadData = async () => {
    setLoading(true);
    const chars = await fetchComicCharacters(contentId);
    setCharacters(chars);
    const { data } = await supabase
      .from('comic_speech_bubbles')
      .select('*, character:comic_characters(*)')
      .eq('panel_id', panel.id)
      .order('bubble_order', { ascending: true });
    setBubbles((data as ComicSpeechBubble[]) || []);
    setLoading(false);
  };

  const handleAddCharacter = async () => {
    if (!charName.trim()) return;
    setSaving(true);
    const ch = await saveCharacter(contentId, charName.trim(), charVoiceType, charVoiceLang);
    if (ch) {
      setCharacters((prev) => [...prev, ch]);
      setCharName('');
      setShowCharForm(false);
    }
    setSaving(false);
  };

  const handleDeleteCharacter = async (id: string) => {
    await deleteCharacter(id);
    setCharacters((prev) => prev.filter((c) => c.id !== id));
  };

  const handleImgMouseDown = (e: React.MouseEvent) => {
    if (!imgRef.current) return;
    const rect = imgRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    setDragStart({ x, y });
    setRegion({ x, y, width: 0, height: 0 });
  };

  const handleImgMouseMove = (e: React.MouseEvent) => {
    if (!dragStart || !imgRef.current) return;
    const rect = imgRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    setRegion({
      x: Math.min(dragStart.x, x),
      y: Math.min(dragStart.y, y),
      width: Math.abs(x - dragStart.x),
      height: Math.abs(y - dragStart.y),
    });
  };

  const handleImgMouseUp = () => {
    setDragStart(null);
  };

  const handleImgTouchStart = (e: React.TouchEvent) => {
    if (!imgRef.current || !e.touches[0]) return;
    const rect = imgRef.current.getBoundingClientRect();
    const x = (e.touches[0].clientX - rect.left) / rect.width;
    const y = (e.touches[0].clientY - rect.top) / rect.height;
    setDragStart({ x, y });
    setRegion({ x, y, width: 0, height: 0 });
  };

  const handleImgTouchMove = (e: React.TouchEvent) => {
    if (!dragStart || !imgRef.current || !e.touches[0]) return;
    e.preventDefault();
    const rect = imgRef.current.getBoundingClientRect();
    const x = (e.touches[0].clientX - rect.left) / rect.width;
    const y = (e.touches[0].clientY - rect.top) / rect.height;
    setRegion({
      x: Math.min(dragStart.x, x),
      y: Math.min(dragStart.y, y),
      width: Math.abs(x - dragStart.x),
      height: Math.abs(y - dragStart.y),
    });
  };

  const handleAddBubble = async () => {
    if (!newBubbleText.trim()) return;
    const reg = region && region.width > 0.02 && region.height > 0.02 ? region : { x: 0.1, y: 0.1, width: 0.6, height: 0.1 };
    setSaving(true);
    const bubble = await saveBubble(
      panel.id,
      newBubbleText.trim(),
      newBubbleChar || null,
      reg,
      bubbles.length
    );
    if (bubble) {
      setBubbles((prev) => [...prev, bubble]);
      setNewBubbleText('');
      setRegion(null);
      onBubblesChanged();
    }
    setSaving(false);
  };

  const handleDeleteBubble = async (id: string) => {
    await deleteBubble(id);
    setBubbles((prev) => prev.filter((b) => b.id !== id));
    onBubblesChanged();
  };

  const handleUpdateBubbleText = async (id: string, text: string) => {
    await updateBubble(id, { text });
  };

  const handleUpdateBubbleChar = async (id: string, charId: string) => {
    await updateBubble(id, { character_id: charId || null });
    loadData();
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-black/90">
      <div className="flex items-center justify-between px-3 py-2 bg-black/80 border-b border-white/10">
        <div className="flex items-center gap-2">
          <MessageSquareText className="w-4 h-4 text-accent" />
          <span className="text-white text-xs font-medium">دەستکاری دەق — پەنال {panelIndex + 1}</span>
        </div>
        <button onClick={onClose} className="p-2 rounded-lg text-white hover:text-accent">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Character management */}
        <div className="p-3 border-b border-white/10">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-white/70 flex items-center gap-1"><User className="w-3 h-3" /> کەسایەتیەکان</span>
            <button onClick={() => setShowCharForm(!showCharForm)} className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-accent text-white text-xs">
              <Plus className="w-3.5 h-3.5" /> زیادکردن
            </button>
          </div>
          {showCharForm && (
            <div className="flex flex-wrap gap-2 mb-2 p-2 bg-white/5 rounded-lg">
              <input type="text" placeholder="ناو" value={charName} onChange={(e) => setCharName(e.target.value)} className="flex-1 min-w-[100px] px-2 py-2 rounded bg-white/10 text-white text-xs outline-none" />
              <select value={charVoiceType} onChange={(e) => setCharVoiceType(e.target.value as 'male' | 'female')} className="px-2 py-2 rounded bg-white/10 text-white text-xs outline-none">
                <option value="male" className="bg-gray-800">پیاو</option>
                <option value="female" className="bg-gray-800">ژن</option>
              </select>
              <select value={charVoiceLang} onChange={(e) => setCharVoiceLang(e.target.value)} className="px-2 py-2 rounded bg-white/10 text-white text-xs outline-none">
                <option value="ku" className="bg-gray-800">کوردی</option>
                <option value="ar" className="bg-gray-800">عەرەبی</option>
                <option value="en" className="bg-gray-800">ئینگلیزی</option>
                <option value="fa" className="bg-gray-800">فارسی</option>
                <option value="tr" className="bg-gray-800">تورکی</option>
              </select>
              <button onClick={handleAddCharacter} disabled={saving || !charName.trim()} className="px-3 py-2 rounded bg-green-600 text-white text-xs disabled:opacity-50">
                {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              </button>
            </div>
          )}
          <div className="flex flex-wrap gap-2">
            {characters.map((ch) => (
              <div key={ch.id} className="flex items-center gap-1 px-2 py-1 rounded bg-white/10 text-xs">
                <Mic className={`w-3 h-3 ${ch.voice_type === 'female' ? 'text-pink-400' : 'text-blue-400'}`} />
                <span className="text-white">{ch.name}</span>
                <button onClick={() => handleDeleteCharacter(ch.id)} className="text-white/40 hover:text-red-400 p-1">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            {characters.length === 0 && <span className="text-xs text-white/40">هیچ کەسایەتیەک نییە</span>}
          </div>
        </div>

        {/* Image with bubble regions */}
        <div className="relative flex items-center justify-center p-4 bg-black/50">
          <div className="relative" style={{ maxWidth: '100%' }}>
            <img
              ref={imgRef}
              src={panel.image_url}
              alt={`پەنال ${panelIndex + 1}`}
              className="max-w-full max-h-[40vh] block"
              onMouseDown={handleImgMouseDown}
              onMouseMove={handleImgMouseMove}
              onMouseUp={handleImgMouseUp}
              onMouseLeave={handleImgMouseUp}
              onTouchStart={handleImgTouchStart}
              onTouchMove={handleImgTouchMove}
              onTouchEnd={handleImgMouseUp}
              style={{ userSelect: 'none', touchAction: 'none', cursor: 'crosshair' }}
            />
            {bubbles.map((b) => (
              <div
                key={b.id}
                className="absolute border border-accent/60 bg-black/60 rounded flex items-center justify-center px-1 py-0.5 overflow-hidden"
                style={{ left: `${b.region_x * 100}%`, top: `${b.region_y * 100}%`, width: `${b.region_width * 100}%`, minHeight: `${b.region_height * 100}%` }}
              >
                <p className="text-white text-xs leading-tight text-center truncate">{b.text}</p>
                <button onClick={() => handleDeleteBubble(b.id)} className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center">
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
            {region && region.width > 0 && (
              <div
                className="absolute border-2 border-accent bg-accent/20 pointer-events-none"
                style={{ left: `${region.x * 100}%`, top: `${region.y * 100}%`, width: `${region.width * 100}%`, height: `${region.height * 100}%` }}
              />
            )}
          </div>
        </div>

        {/* Add new bubble */}
        <div className="p-3 border-t border-white/10 space-y-2">
          <p className="text-xs text-white/60">بۆ زیادکردنی دەق، لەسەر وێنەکە هەڵبژێرە (دراگ بکە) یان تەنها دەق بنووسە</p>
          <textarea
            value={newBubbleText}
            onChange={(e) => setNewBubbleText(e.target.value)}
            placeholder="دەقی قسەکردن بنووسە..."
            rows={2}
            className="w-full px-3 py-2 rounded-lg bg-white/10 text-white text-sm outline-none resize-none placeholder:text-white/30"
            dir="auto"
          />
          <div className="flex gap-2">
            <select value={newBubbleChar} onChange={(e) => setNewBubbleChar(e.target.value)} className="flex-1 px-2 py-1.5 rounded bg-white/10 text-white text-xs outline-none">
              <option value="" className="bg-gray-800">بێ کەسایەتی</option>
              {characters.map((ch) => (
                <option key={ch.id} value={ch.id} className="bg-gray-800">{ch.name} ({ch.voice_type === 'female' ? '♀' : '♂'})</option>
              ))}
            </select>
            <button onClick={handleAddBubble} disabled={saving || !newBubbleText.trim()} className="flex items-center gap-1 px-4 py-2.5 rounded-lg bg-accent text-white text-xs font-medium disabled:opacity-50">
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />} زیادکردن
            </button>
          </div>
        </div>

        {/* Existing bubbles list */}
        {bubbles.length > 0 && (
          <div className="p-3 border-t border-white/10 space-y-2">
            <span className="text-xs text-white/70">دەقەکانی ئەم پەنالە ({bubbles.length})</span>
            {bubbles.map((b, i) => (
              <div key={b.id} className="flex gap-2 p-2 rounded bg-white/5">
                <span className="text-xs text-white/40 flex-shrink-0 w-6">{i + 1}</span>
                <div className="flex-1 space-y-1">
                  <input
                    type="text"
                    defaultValue={b.text}
                    onBlur={(e) => handleUpdateBubbleText(b.id, e.target.value)}
                    className="w-full px-2 py-1 rounded bg-white/10 text-white text-xs outline-none"
                    dir="auto"
                  />
                  <select
                    value={b.character_id || ''}
                    onChange={(e) => handleUpdateBubbleChar(b.id, e.target.value)}
                    className="w-full px-2 py-1 rounded bg-white/10 text-white text-xs outline-none"
                  >
                    <option value="" className="bg-gray-800">بێ کەسایەتی</option>
                    {characters.map((ch) => (
                      <option key={ch.id} value={ch.id} className="bg-gray-800">{ch.name}</option>
                    ))}
                  </select>
                </div>
                <button onClick={() => handleDeleteBubble(b.id)} className="p-1.5 text-white/40 hover:text-red-400 flex-shrink-0">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
