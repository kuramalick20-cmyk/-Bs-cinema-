import { useState, useEffect, useRef } from 'react';
import { X, Mail, Lock, User, AlertCircle, Loader2, KeyRound } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { renderGoogleButton } from '@/lib/googleAuth';
import { supabase } from '@/lib/supabase';
import { isNativeApp } from '@/lib/platform';

interface AuthModalProps {
  onClose: () => void;
}

const GOOGLE_BTN_ID = 'google-signin-btn';

export default function AuthModal({ onClose }: AuthModalProps) {
  const { signIn, signUp, signInWithGoogle } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [otpMode, setOtpMode] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [info, setInfo] = useState<string | null>(null);
  const googleRendered = useRef(false);
  const native = isNativeApp();

  useEffect(() => {
    if (native) return; // GIS doesn't work in Android WebView
    if (googleRendered.current) return;
    googleRendered.current = true;

    let mounted = true;
    renderGoogleButton(
      GOOGLE_BTN_ID,
      async (idToken) => {
        if (!mounted) return;
        setLoading(true);
        const { data, error: idError } = await supabase.auth.signInWithIdToken({
          provider: 'google',
          token: idToken,
        });
        if (idError) {
          await signInWithGoogle();
        }
        if (data.user) {
          onClose();
        }
        setLoading(false);
      },
      () => {}
    );

    return () => { mounted = false; };
  }, [native]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setLoading(true);

    if (native && mode === 'signup') {
      // On native app signup: send OTP via Supabase email verification
      const { data, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { username } },
      });
      if (signUpError) {
        setError(signUpError.message);
        setLoading(false);
        return;
      }
      // If no immediate session, enter OTP verification mode
      if (!data.session) {
        setInfo('کۆدێکی پشتڕاستکردنەوە نێردرا بۆ ئیمەیڵەکەت. تکایە کۆدەکە بنووسە.');
        setOtpMode(true);
        setLoading(false);
        return;
      }
      // Session created immediately — proceed
      if (data.user) {
        const trialStart = new Date();
        const trialEnd = new Date(trialStart.getTime() + 3 * 24 * 60 * 60 * 1000);
        await supabase.from('profiles').upsert({
          id: data.user.id,
          username,
          phone: null,
          vip_status: 'trial',
          trial_start_date: trialStart.toISOString(),
          trial_end_date: trialEnd.toISOString(),
          trial_used: true,
          is_admin: false,
        }, { onConflict: 'id' });
        onClose();
      }
      setLoading(false);
      return;
    }

    if (native && otpMode) {
      // Verify OTP code
      const { data, error: verifyError } = await supabase.auth.verifyOtp({
        email,
        token: otpCode,
        type: 'signup',
      });
      if (verifyError) {
        setError(verifyError.message);
        setLoading(false);
        return;
      }
      if (data.user) {
        const trialStart = new Date();
        const trialEnd = new Date(trialStart.getTime() + 3 * 24 * 60 * 60 * 1000);
        await supabase.from('profiles').upsert({
          id: data.user.id,
          username,
          phone: null,
          vip_status: 'trial',
          trial_start_date: trialStart.toISOString(),
          trial_end_date: trialEnd.toISOString(),
          trial_used: true,
          is_admin: false,
        }, { onConflict: 'id' });
        onClose();
      }
      setLoading(false);
      return;
    }

    // Standard web flow
    if (mode === 'login') {
      const { error } = await signIn(email, password);
      if (error) setError(error);
      else onClose();
    } else {
      const { error } = await signUp(email, password, username);
      if (error) setError(error);
      else onClose();
    }
    setLoading(false);
  };

  const handleResendOtp = async () => {
    setError(null);
    setLoading(true);
    const { error: resendError } = await supabase.auth.resend({
      type: 'signup',
      email,
    });
    if (resendError) {
      setError(resendError.message);
    } else {
      setInfo('کۆدەکە دووبارە نێردرایەوە بۆ ئیمەیڵەکەت.');
    }
    setLoading(false);
  };

  const handleGoogleFallback = async () => {
    setError(null);
    setLoading(true);
    const { error } = await signInWithGoogle();
    if (error) {
      setError(error);
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 animate-fade-in overflow-y-auto">
      <div className="absolute inset-0 bg-black/85 backdrop-blur-md" onClick={onClose} />
      <div className="relative w-full max-w-md bg-secondary rounded-3xl border border-default shadow-2xl p-6 md:p-8 animate-scale-in my-8 max-h-[90vh] overflow-y-auto">
        <button onClick={onClose} className="absolute top-4 left-4 p-1 text-secondary hover:text-primary transition-colors z-10">
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-primary mb-1">
            {otpMode ? 'پشتڕاستکردنەوەی ئیمەیڵ' : mode === 'login' ? 'چوونەژوورەوە' : 'دروستکردنی هەژمار'}
          </h2>
          <p className="text-sm text-secondary">
            {otpMode ? 'کۆدی پشتڕاستکردنەوە بنووسە' : mode === 'login' ? 'بەخێرایی بێیتەوە بۆ BS Cinema' : 'هەژمارێکی نوێ دروست بکە'}
          </p>
        </div>

        {/* Google button — only on web (GIS), native uses fallback OAuth */}
        {!otpMode && (
          <div id={GOOGLE_BTN_ID} className="w-full flex justify-center mb-4 min-h-[44px]">
            <button
              onClick={handleGoogleFallback}
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 py-3 rounded-full bg-white text-gray-800 font-medium text-sm hover:bg-gray-100 transition-all disabled:opacity-50"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              بەردەوام بە بە Google
            </button>
          </div>
        )}

        {!otpMode && (
          <div className="flex items-center gap-3 mb-4">
            <div className="flex-1 h-px bg-default" />
            <span className="text-xs text-muted">یان</span>
            <div className="flex-1 h-px bg-default" />
          </div>
        )}

        {otpMode ? (
          <form onSubmit={handleSubmit} className="space-y-3">
            {info && (
              <div className="flex items-start gap-2 text-accent text-sm bg-accent/10 rounded-lg p-3">
                <KeyRound className="w-4 h-4 flex-shrink-0 mt-0.5" /> {info}
              </div>
            )}
            <div className="relative">
              <KeyRound className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
              <input
                type="text"
                inputMode="numeric"
                placeholder="کۆدی پشتڕاستکردنەوە"
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value)}
                required
                maxLength={6}
                className="w-full pr-10 pl-4 py-3 rounded-xl bg-card border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent transition-colors text-center tracking-widest"
              />
            </div>
            {error && (
              <div className="flex items-center gap-2 text-red-400 text-sm bg-red-400/10 rounded-lg p-3">
                <AlertCircle className="w-4 h-4 flex-shrink-0" /> {error}
              </div>
            )}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl btn-cinema text-white font-semibold text-sm transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              پشتڕاستکردنەوە
            </button>
            <button
              type="button"
              onClick={handleResendOtp}
              disabled={loading}
              className="w-full py-2 text-sm text-accent hover:text-primary transition-colors"
            >
              دووبارە ناردنی کۆد
            </button>
          </form>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3">
            {mode === 'signup' && (
              <div className="relative">
                <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
                <input
                  type="text"
                  placeholder="ناوی بەکارهێنەر"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="w-full pr-10 pl-4 py-3 rounded-xl bg-card border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent transition-colors"
                />
              </div>
            )}
            <div className="relative">
              <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
              <input
                type="email"
                placeholder="ئیمەیڵ"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full pr-10 pl-4 py-3 rounded-xl bg-card border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent transition-colors"
              />
            </div>
            <div className="relative">
              <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
              <input
                type="password"
                placeholder="وشەی نهێنی"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                className="w-full pr-10 pl-4 py-3 rounded-xl bg-card border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent transition-colors"
              />
            </div>
            {error && (
              <div className="flex items-center gap-2 text-red-400 text-sm bg-red-400/10 rounded-lg p-3">
                <AlertCircle className="w-4 h-4 flex-shrink-0" /> {error}
              </div>
            )}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl btn-cinema text-white font-semibold text-sm transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {mode === 'login' ? 'چوونەژوورەوە' : 'دروستکردنی هەژمار'}
            </button>
          </form>
        )}

        {/* Toggle mode */}
        {!otpMode && (
          <p className="text-center text-sm text-secondary mt-4">
            {mode === 'login' ? 'هەژمارت نییە؟ ' : 'هەژمارت هەیە؟ '}
            <button
              onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(null); }}
              className="text-accent font-medium hover:underline"
            >
              {mode === 'login' ? 'دروستی بکە' : 'چوە ژوورەوە'}
            </button>
          </p>
        )}
      </div>
    </div>
  );
}
