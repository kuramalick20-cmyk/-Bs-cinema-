import { useState, useEffect, useRef, useCallback } from 'react';
import {
  X, Heart, Coins, Sword, Shield, Zap, MapPin, Crown, ShoppingBag, Users,
  Home, Sparkles, ChevronLeft, ScrollText, Star, Backpack, Crosshair,
  Footprints, Utensils, Flag, Heart as HeartIcon,
} from 'lucide-react';
import type {
  WarbandGameState, GameCharacter, WorldLocation, CombatAction, Item,
  Enemy, Companion, Quest, MarriageCandidate, Faction, FactionId,
} from '@/lib/warbandTypes';
import WarbandExplore from './WarbandExplore';
import {
  enterExplore, exitExplore, updateWorld3D, updateCamera, toggleCamera,
} from '@/lib/warband3D';
import {
  CHARACTERS, SHOP_ITEMS, FACTIONS, createInitialState, startBattle,
  performCombatAction, travelTo, conquerLocation, buyItem, equipItem,
  usePotion, recruitCompanion, marryCandidate, rest, claimQuestReward,
} from '@/lib/warbandEngine';

// ============================================================
// WarbandGame — Mount & Blade: Warband-inspired medieval RPG
// Fully self-contained, responsive 9:16 mobile component.
// ============================================================

interface WarbandGameProps {
  onClose: () => void;
}

type TownTab = 'tavern' | 'shop' | 'castle' | 'residence';

// ---- helpers ---------------------------------------------------------------

const MAX_XP_PER_LEVEL = 200;

function xpForLevel(level: number): number {
  return (level - 1) * MAX_XP_PER_LEVEL;
}

function locationIcon(type: WorldLocation['type']): string {
  switch (type) {
    case 'city': return '🏛️';
    case 'castle': return '🏰';
    case 'village': return '🏘️';
    case 'camp': return '⛺';
    case 'ruins': return '🏚️';
    case 'forest': return '🌲';
    case 'mountain': return '⛰️';
    case 'field': return '⚔️';
    default: return '📍';
  }
}

function factionColor(factions: Faction[], id: FactionId): string {
  return factions.find((f) => f.id === id)?.color ?? '#666';
}

function factionBanner(factions: Faction[], id: FactionId): string {
  return factions.find((f) => f.id === id)?.banner ?? '?';
}

function factionName(factions: Faction[], id: FactionId): string {
  return factions.find((f) => f.id === id)?.name ?? 'Unknown';
}

function isEnemyFaction(state: WarbandGameState, loc: WorldLocation): boolean {
  const fac = state.factions.find((f) => f.id === state.playerFaction);
  if (!fac) return loc.faction !== state.playerFaction;
  return fac.atWarWith.includes(loc.faction);
}

function hpColor(pct: number): string {
  if (pct > 60) return 'bg-emerald-500';
  if (pct > 30) return 'bg-amber-500';
  return 'bg-rose-600';
}

function statBarColor(pct: number): string {
  if (pct > 66) return 'bg-sky-400';
  if (pct > 33) return 'bg-indigo-400';
  return 'bg-violet-500';
}

// ============================================================
// Main component
// ============================================================

export default function WarbandGame({ onClose }: WarbandGameProps) {
  const [state, setState] = useState<WarbandGameState | null>(null);
  const [selectedChar, setSelectedChar] = useState<GameCharacter | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [selectedMapLoc, setSelectedMapLoc] = useState<string | null>(null);
  const [townTab, setTownTab] = useState<TownTab>('tavern');
  const [showQuests, setShowQuests] = useState(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const battleLogRef = useRef<HTMLDivElement>(null);

  // ---- toast auto-clear ----------------------------------------------------
  useEffect(() => {
    if (!state?.message) return;
    setToast(state.message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => {
      setToast(null);
      setState((prev) => (prev ? { ...prev, message: null } : prev));
    }, 3000);
    return () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, [state?.message]);

  // ---- battle log auto-scroll ---------------------------------------------
  useEffect(() => {
    if (battleLogRef.current) {
      battleLogRef.current.scrollTop = battleLogRef.current.scrollHeight;
    }
  }, [state?.battleLog]);

  // ---- generic engine wrapper ---------------------------------------------
  const applyEngine = useCallback(
    <T,>(fn: (s: WarbandGameState, ...args: never[]) => T, ...args: unknown[]): T | null => {
      if (!state) return null;
      const result = fn(state, ...(args as never[]));
      if (result && typeof result === 'object' && 'screen' in result) {
        setState(result as unknown as WarbandGameState);
        return result as unknown as T;
      }
      return result;
    },
    [state],
  );

  // ---- character select ----------------------------------------------------
  const handleSelectCharacter = useCallback((char: GameCharacter) => {
    setSelectedChar(char);
    setState(createInitialState(char));
  }, []);

  const handleRestart = useCallback(() => {
    setState(null);
    setSelectedChar(null);
    setSelectedMapLoc(null);
    setTownTab('tavern');
    setShowQuests(false);
    setToast(null);
  }, []);

  // ---- world map actions ---------------------------------------------------
  const handleMapLocTap = useCallback((locId: string) => {
    setSelectedMapLoc(locId);
  }, []);

  const handleTravel = useCallback(
    (locId: string) => {
      applyEngine(travelTo as (s: WarbandGameState, id: string) => WarbandGameState, locId);
      setSelectedMapLoc(null);
    },
    [applyEngine],
  );

  const handleEnterLocation = useCallback(() => {
    if (!state) return;
    const loc = state.locations.find((l) => l.id === state.currentLocationId);
    if (!loc) return;
    if (loc.type === 'city' || loc.type === 'castle' || loc.type === 'village') {
      setState((prev) => (prev ? { ...prev, screen: 'town' } : prev));
      setTownTab('tavern');
    } else {
      // Wilderness — start a battle
      applyEngine(startBattle as (s: WarbandGameState) => WarbandGameState);
    }
    setSelectedMapLoc(null);
  }, [state, applyEngine]);

  // ---- explore mode (real-time 3D) -----------------------------------------
  const handleEnterExplore = useCallback((locId: string) => {
    setState((prev) => prev ? enterExplore(prev, locId) : prev);
    setSelectedMapLoc(null);
  }, []);

  const handleExitExplore = useCallback(() => {
    setState((prev) => prev ? exitExplore(prev) : prev);
  }, []);

  const handleExploreUpdate = useCallback((
    dt: number, jdx: number, jdy: number,
    actions: { attack: boolean; block: boolean; dodge: boolean; mount: boolean; interact: boolean },
  ) => {
    setState((prev) => prev ? updateWorld3D(prev, dt, jdx, jdy, actions) : prev);
  }, []);

  const handleCameraDrag = useCallback((dYaw: number, dPitch: number) => {
    setState((prev) => prev ? updateCamera(prev, dYaw, dPitch) : prev);
  }, []);

  const handleToggleCamera = useCallback(() => {
    setState((prev) => prev ? toggleCamera(prev) : prev);
  }, []);

  const handleExploreEnterLocation = useCallback(() => {
    if (!state || !state.nearbyLocationId) return;
    const loc = state.locations.find((l) => l.id === state.nearbyLocationId);
    if (!loc) return;
    setState((prev) => {
      if (!prev) return prev;
      const exited = exitExplore(prev);
      if (loc.type === 'city' || loc.type === 'castle' || loc.type === 'village') {
        return { ...exited, screen: 'town' };
      }
      return exited;
    });
    setTownTab('tavern');
  }, [state]);

  const handleRest = useCallback(() => {
    applyEngine(rest as (s: WarbandGameState) => WarbandGameState);
  }, [applyEngine]);

  // ---- battle actions ------------------------------------------------------
  const handleCombat = useCallback(
    (action: CombatAction) => {
      applyEngine(performCombatAction as (s: WarbandGameState, a: CombatAction) => WarbandGameState, action);
    },
    [applyEngine],
  );

  const handleUsePotionInBattle = useCallback(
    (itemId: string) => {
      applyEngine(usePotion as (s: WarbandGameState, id: string) => WarbandGameState, itemId);
    },
    [applyEngine],
  );

  // ---- town actions --------------------------------------------------------
  const handleBuy = useCallback(
    (itemId: string) => {
      applyEngine(buyItem as (s: WarbandGameState, id: string) => WarbandGameState, itemId);
    },
    [applyEngine],
  );

  const handleEquip = useCallback(
    (itemId: string) => {
      applyEngine(equipItem as (s: WarbandGameState, id: string) => WarbandGameState, itemId);
    },
    [applyEngine],
  );

  const handleUsePotion = useCallback(
    (itemId: string) => {
      applyEngine(usePotion as (s: WarbandGameState, id: string) => WarbandGameState, itemId);
    },
    [applyEngine],
  );

  const handleRecruit = useCallback(
    (companionId: string) => {
      applyEngine(recruitCompanion as (s: WarbandGameState, id: string) => WarbandGameState, companionId);
    },
    [applyEngine],
  );

  const handleMarry = useCallback(
    (candidateId: string) => {
      applyEngine(marryCandidate as (s: WarbandGameState, id: string) => WarbandGameState, candidateId);
    },
    [applyEngine],
  );

  const handleConquer = useCallback(() => {
    applyEngine(conquerLocation as (s: WarbandGameState) => WarbandGameState);
  }, [applyEngine]);

  const handleClaimQuest = useCallback(
    (questId: string) => {
      applyEngine(claimQuestReward as (s: WarbandGameState, id: string) => WarbandGameState, questId);
    },
    [applyEngine],
  );

  // ---- navigation ----------------------------------------------------------
  const goToWorldMap = useCallback(() => {
    setState((prev) => (prev ? { ...prev, screen: 'world-map' } : prev));
    setSelectedMapLoc(null);
  }, []);

  const goToCharacter = useCallback(() => {
    setState((prev) => (prev ? { ...prev, screen: 'character' } : prev));
  }, []);

  const goToInventory = useCallback(() => {
    setState((prev) => (prev ? { ...prev, screen: 'inventory' } : prev));
  }, []);

  const goToTown = useCallback(() => {
    setState((prev) => (prev ? { ...prev, screen: 'town' } : prev));
    setTownTab('tavern');
  }, []);

  // ============================================================
  // RENDER GUARDS
  // ============================================================

  if (!state || !selectedChar) {
    return <CharacterSelectScreen characters={CHARACTERS} onSelect={handleSelectCharacter} onClose={onClose} />;
  }

  return (
    <div className="fixed inset-0 z-[100] bg-[#0a0a12] text-amber-50 flex flex-col overflow-hidden select-none">
      {/* Top bar (hidden on character select / battle) */}
      {state.screen !== 'battle' && (
        <TopBar state={state} onClose={onClose} onRestart={handleRestart}
          onCharacter={goToCharacter} onInventory={goToInventory} />
      )}

      {/* Main content */}
      <div className="flex-1 min-h-0 overflow-y-auto">
        {state.screen === 'world-map' && (
          <WorldMapScreen
            state={state}
            selectedMapLoc={selectedMapLoc}
            onMapLocTap={handleMapLocTap}
            onTravel={handleTravel}
            onEnter={handleEnterLocation}
            onRest={handleRest}
            onQuests={() => setShowQuests(true)}
            onExplore={handleEnterExplore}
          />
        )}

        {state.screen === 'town' && (
          <TownScreen
            state={state}
            townTab={townTab}
            setTownTab={setTownTab}
            onBack={goToWorldMap}
            onBuy={handleBuy}
            onRecruit={handleRecruit}
            onConquer={handleConquer}
            onMarry={handleMarry}
          />
        )}

        {state.screen === 'explore' && (
          <WarbandExplore
            state={state}
            onExit={handleExitExplore}
            onUpdate={handleExploreUpdate}
            onCameraDrag={handleCameraDrag}
            onToggleCamera={handleToggleCamera}
            onEnterLocation={handleExploreEnterLocation}
          />
        )}

        {state.screen === 'battle' && (
          <BattleScreen
            state={state}
            onAction={handleCombat}
            onUsePotion={handleUsePotionInBattle}
            logRef={battleLogRef}
          />
        )}

        {state.screen === 'character' && (
          <CharacterScreen state={state} onBack={goToWorldMap} />
        )}

        {state.screen === 'inventory' && (
          <InventoryScreen state={state} onBack={goToWorldMap}
            onEquip={handleEquip} onUsePotion={handleUsePotion} />
        )}
      </div>

      {/* Quest modal */}
      {showQuests && (
        <QuestModal
          state={state}
          onClose={() => setShowQuests(false)}
          onClaim={handleClaimQuest}
        />
      )}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[120] px-4 py-2.5 rounded-lg bg-black/85 border border-amber-500/40 text-amber-100 text-xs sm:text-sm shadow-2xl backdrop-blur-sm max-w-[90vw] text-center animate-[fadeIn_0.2s_ease-out]">
          {toast}
        </div>
      )}

      {/* keyframes */}
      <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translate(-50%, 8px); } to { opacity: 1; transform: translate(-50%, 0); } }
        @keyframes floatY { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        @keyframes pulseGlow { 0%,100% { opacity: 0.5; } 50% { opacity: 1; } }
        @keyframes shake { 0%,100% { transform: translateX(0); } 25% { transform: translateX(-3px); } 75% { transform: translateX(3px); } }
      `}</style>
    </div>
  );
}

// ============================================================
// 3D Portrait (shared)
// ============================================================

interface PortraitProps {
  color: string;
  accent?: string;
  initial: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  floating?: boolean;
}

function Portrait({ color, accent = '#fff', initial, size = 'md', floating = false }: PortraitProps) {
  const sizeClass = {
    sm: 'w-10 h-10 text-base',
    md: 'w-14 h-14 text-xl',
    lg: 'w-20 h-20 text-3xl',
    xl: 'w-28 h-28 text-5xl',
  }[size];

  return (
    <div
      className={`${sizeClass} rounded-full flex items-center justify-center font-black shrink-0 relative ${floating ? 'animate-[floatY_3s_ease-in-out_infinite]' : ''}`}
      style={{
        background: `radial-gradient(circle at 32% 28%, ${color}ee, ${color} 55%, #000 130%)`,
        boxShadow: `inset -4px -6px 14px rgba(0,0,0,0.65), inset 4px 4px 10px ${accent}33, 0 6px 18px rgba(0,0,0,0.6), 0 0 0 2px ${accent}55`,
        textShadow: `0 2px 4px rgba(0,0,0,0.8), 0 0 12px ${accent}88`,
        color: accent,
        border: `1.5px solid ${accent}66`,
      }}
    >
      {/* glossy highlight */}
      <span
        className="absolute top-1 left-2 rounded-full bg-white/25 blur-[3px]"
        style={{ width: '30%', height: '22%' }}
      />
      <span className="relative drop-shadow-lg">{initial}</span>
    </div>
  );
}

// ============================================================
// Stat Bar
// ============================================================

interface StatBarProps {
  label: string;
  value: number;
  max: number;
  colorClass?: string;
  showNumbers?: boolean;
  icon?: React.ReactNode;
}

function StatBar({ label, value, max, colorClass = 'bg-emerald-500', showNumbers = true, icon }: StatBarProps) {
  const pct = max > 0 ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
  return (
    <div className="w-full">
      <div className="flex items-center justify-between text-[10px] sm:text-xs mb-0.5">
        <span className="flex items-center gap-1 text-amber-200/80">
          {icon}{label}
        </span>
        {showNumbers && <span className="text-amber-100/70 font-mono">{Math.round(value)}/{max}</span>}
      </div>
      <div className="h-2 rounded-full bg-black/50 overflow-hidden border border-white/5">
        <div className={`h-full ${colorClass} rounded-full transition-all duration-500`}
          style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

// ============================================================
// Top Bar
// ============================================================

interface TopBarProps {
  state: WarbandGameState;
  onClose: () => void;
  onRestart: () => void;
  onCharacter: () => void;
  onInventory: () => void;
}

function TopBar({ state, onClose, onRestart, onCharacter, onInventory }: TopBarProps) {
  const hpPct = (state.hp / state.maxHp) * 100;
  const xpBase = xpForLevel(state.level);
  const xpInLevel = state.xp - xpBase;
  const xpPct = (xpInLevel / MAX_XP_PER_LEVEL) * 100;

  return (
    <div className="shrink-0 bg-gradient-to-b from-[#1a1525] to-[#0f0c18] border-b border-amber-900/40 px-2 sm:px-3 py-2">
      <div className="flex items-center gap-2 max-w-lg mx-auto">
        <Portrait color={state.selectedCharacter.portraitColor} accent={state.selectedCharacter.accentColor}
          initial={state.selectedCharacter.name[0]} size="sm" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 text-[10px] sm:text-xs">
            <span className="font-bold text-amber-200 truncate">{state.selectedCharacter.name}</span>
            <span className="flex items-center gap-1 text-amber-100/70 shrink-0">
              <span className="flex items-center gap-0.5"><Coins className="w-3 h-3 text-yellow-400" />{state.gold}</span>
              <span className="flex items-center gap-0.5"><Star className="w-3 h-3 text-sky-400" />Lv{state.level}</span>
              <span className="flex items-center gap-0.5 text-amber-300/60">Day {state.day}</span>
            </span>
          </div>
          <div className="flex items-center gap-1.5 mt-1">
            <div className="flex-1"><StatBar label="" value={state.hp} max={state.maxHp} colorClass={hpColor(hpPct)} showNumbers={false} icon={<Heart className="w-2.5 h-2.5" />} /></div>
            <div className="flex-1"><StatBar label="" value={xpInLevel} max={MAX_XP_PER_LEVEL} colorClass="bg-sky-500" showNumbers={false} icon={<Sparkles className="w-2.5 h-2.5" />} /></div>
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button onClick={onCharacter} className="p-1.5 rounded-md bg-white/5 hover:bg-amber-900/40 active:scale-95 transition" aria-label="Character">
            <Crown className="w-4 h-4 text-amber-300" />
          </button>
          <button onClick={onInventory} className="p-1.5 rounded-md bg-white/5 hover:bg-amber-900/40 active:scale-95 transition" aria-label="Inventory">
            <Backpack className="w-4 h-4 text-amber-300" />
          </button>
          <button onClick={onRestart} className="p-1.5 rounded-md bg-white/5 hover:bg-rose-900/40 active:scale-95 transition" aria-label="Restart">
            <RotateCcwIcon />
          </button>
          <button onClick={onClose} className="p-1.5 rounded-md bg-white/5 hover:bg-rose-900/60 active:scale-95 transition" aria-label="Close">
            <X className="w-4 h-4 text-rose-300" />
          </button>
        </div>
      </div>
    </div>
  );
}

function RotateCcwIcon() {
  return (
    <svg className="w-4 h-4 text-rose-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 1 0 3-6.7L3 8" /><path d="M3 3v5h5" />
    </svg>
  );
}

// ============================================================
// Screen 1: Character Select
// ============================================================

interface CharacterSelectProps {
  characters: GameCharacter[];
  onSelect: (char: GameCharacter) => void;
  onClose: () => void;
}

function CharacterSelectScreen({ characters, onSelect, onClose }: CharacterSelectProps) {
  return (
    <div className="fixed inset-0 z-[100] bg-gradient-to-b from-[#1a0f1f] via-[#0f0a18] to-[#050308] text-amber-50 flex flex-col overflow-y-auto select-none">
      {/* decorative top */}
      <div className="shrink-0 px-4 pt-5 pb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sword className="w-5 h-5 text-amber-400" />
          <h1 className="text-lg sm:text-2xl font-black tracking-wider bg-gradient-to-r from-amber-200 to-amber-500 bg-clip-text text-transparent">
            WARBAND
          </h1>
        </div>
        <button onClick={onClose} className="p-2 rounded-md bg-white/5 hover:bg-rose-900/50 active:scale-95 transition" aria-label="Close">
          <X className="w-5 h-5 text-rose-300" />
        </button>
      </div>
      <p className="text-center text-amber-200/60 text-xs sm:text-sm px-4 mb-3">Choose your champion</p>

      <div className="flex-1 px-3 sm:px-4 pb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-w-lg mx-auto">
          {characters.map((char) => (
            <CharacterCard key={char.id} char={char} onSelect={onSelect} />
          ))}
        </div>
      </div>
    </div>
  );
}

interface CharacterCardProps {
  char: GameCharacter;
  onSelect: (char: GameCharacter) => void;
}

function CharacterCard({ char, onSelect }: CharacterCardProps) {
  return (
    <button
      onClick={() => onSelect(char)}
      className="group relative text-left rounded-xl p-3 bg-gradient-to-br from-[#1c1626] to-[#0e0a16] border border-amber-900/40 hover:border-amber-500/60 active:scale-[0.98] transition-all duration-200 shadow-lg hover:shadow-amber-900/30 overflow-hidden"
    >
      {/* faction glow strip */}
      <div className="absolute top-0 left-0 right-0 h-0.5" style={{ background: char.portraitColor }} />
      <div className="flex items-start gap-3">
        <Portrait color={char.portraitColor} accent={char.accentColor} initial={char.name[0]} size="md" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <h3 className="font-black text-sm sm:text-base text-amber-100 truncate">{char.name}</h3>
          </div>
          <p className="text-[10px] sm:text-xs text-amber-400/80 font-semibold truncate">{char.title}</p>
          <p className="text-[10px] sm:text-xs text-amber-100/50 mt-1 line-clamp-2">{char.description}</p>
        </div>
      </div>
      <div className="grid grid-cols-4 gap-1 mt-2.5">
        <MiniStat icon={<Sword className="w-3 h-3" />} value={char.attack} label="ATK" />
        <MiniStat icon={<Shield className="w-3 h-3" />} value={char.defense} label="DEF" />
        <MiniStat icon={<Footprints className="w-3 h-3" />} value={char.speed} label="SPD" />
        <MiniStat icon={<Crown className="w-3 h-3" />} value={char.leadership} label="LED" />
      </div>
    </button>
  );
}

interface MiniStatProps {
  icon: React.ReactNode;
  value: number;
  label: string;
}

function MiniStat({ icon, value, label }: MiniStatProps) {
  return (
    <div className="flex flex-col items-center rounded-md bg-black/30 border border-white/5 py-1">
      <span className="text-amber-300">{icon}</span>
      <span className="text-xs font-bold text-amber-100 leading-none mt-0.5">{value}</span>
      <span className="text-[8px] text-amber-200/40 leading-none mt-0.5">{label}</span>
    </div>
  );
}

// ============================================================
// Screen 2: World Map
// ============================================================

interface WorldMapProps {
  state: WarbandGameState;
  selectedMapLoc: string | null;
  onMapLocTap: (locId: string) => void;
  onTravel: (locId: string) => void;
  onEnter: () => void;
  onRest: () => void;
  onQuests: () => void;
  onExplore: (locId: string) => void;
}

function WorldMapScreen({ state, selectedMapLoc, onMapLocTap, onTravel, onEnter, onRest, onQuests, onExplore }: WorldMapProps) {
  const selected = selectedMapLoc ? state.locations.find((l) => l.id === selectedMapLoc) ?? null : null;
  const current = state.locations.find((l) => l.id === state.currentLocationId) ?? null;
  const isCurrentSelected = selected?.id === state.currentLocationId;

  return (
    <div className="w-full max-w-lg mx-auto px-2 sm:px-3 py-2 flex flex-col gap-2">
      {/* faction territory summary */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 max-w-full">
        {state.factions.map((f) => (
          <div key={f.id} className="flex items-center gap-1 shrink-0 rounded-full px-2 py-0.5 bg-black/40 border border-white/5 text-[9px] sm:text-[10px]">
            <span className="w-2 h-2 rounded-full" style={{ background: f.color }} />
            <span className="text-amber-100/70 truncate max-w-[60px]">{f.name.split(' ')[0]}</span>
            <span className="font-bold text-amber-200">{f.territories}</span>
          </div>
        ))}
      </div>

      {/* map */}
      <div className="relative w-full aspect-[3/4] rounded-xl overflow-hidden border border-amber-900/40 shadow-2xl"
        style={{
          background: 'radial-gradient(ellipse at 50% 40%, #1e2a1a 0%, #12160e 45%, #080a06 100%)',
        }}>
        {/* terrain texture */}
        <div className="absolute inset-0 opacity-30"
          style={{ backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 18px, rgba(255,255,255,0.02) 18px, rgba(255,255,255,0.02) 20px)' }} />
        {/* faction territory blobs */}
        {state.factions.map((f) => {
          const facLocs = state.locations.filter((l) => l.faction === f.id);
          if (facLocs.length === 0) return null;
          const cx = facLocs.reduce((s, l) => s + l.x, 0) / facLocs.length;
          const cy = facLocs.reduce((s, l) => s + l.y, 0) / facLocs.length;
          return (
            <div key={f.id} className="absolute rounded-full blur-2xl opacity-20 pointer-events-none"
              style={{ left: `${cx}%`, top: `${cy}%`, width: '34%', height: '24%', transform: 'translate(-50%, -50%)', background: f.color }} />
          );
        })}

        {/* location dots */}
        {state.locations.map((loc) => {
          const isCurrent = loc.id === state.currentLocationId;
          const isSelected = loc.id === selectedMapLoc;
          const col = factionColor(state.factions, loc.faction);
          return (
            <button key={loc.id}
              onClick={() => onMapLocTap(loc.id)}
              className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group"
              style={{ left: `${loc.x}%`, top: `${loc.y}%` }}
              aria-label={loc.name}>
              {/* pulse ring for current */}
              {isCurrent && (
                <span className="absolute -top-1 w-5 h-5 rounded-full border-2 border-amber-300 animate-[pulseGlow_1.5s_ease-in-out_infinite]" />
              )}
              <span className="text-sm sm:text-base leading-none drop-shadow-lg"
                style={{ filter: isSelected ? 'drop-shadow(0 0 6px #fbbf24)' : 'none' }}>
                {locationIcon(loc.type)}
              </span>
              <span className="w-2.5 h-2.5 rounded-full border border-white/40 mt-0.5"
                style={{ background: col, boxShadow: isCurrent ? '0 0 6px #fbbf24' : '0 1px 3px rgba(0,0,0,0.6)' }} />
              {loc.isCapital && <span className="text-[8px]">👑</span>}
              {isSelected && (
                <span className="absolute top-full mt-1 text-[8px] sm:text-[9px] whitespace-nowrap bg-black/80 rounded px-1 py-0.5 text-amber-200 border border-amber-700/40">
                  {loc.name}
                </span>
              )}
            </button>
          );
        })}

        {/* player marker */}
        {current && (
          <div className="absolute -translate-x-1/2 -translate-y-1/2 z-10 pointer-events-none"
            style={{ left: `${current.x}%`, top: `${current.y}%` }}>
            <div className="relative -translate-y-5">
              <Portrait color={state.selectedCharacter.portraitColor} accent={state.selectedCharacter.accentColor}
                initial={state.selectedCharacter.name[0]} size="sm" />
            </div>
          </div>
        )}

        {/* quest button */}
        <button onClick={onQuests}
          className="absolute top-2 right-2 flex items-center gap-1 px-2 py-1 rounded-md bg-black/70 border border-amber-700/50 text-amber-200 text-[10px] sm:text-xs active:scale-95 transition">
          <ScrollText className="w-3.5 h-3.5" />
          Quests
        </button>
      </div>

      {/* bottom info panel */}
      <div className="rounded-xl bg-gradient-to-b from-[#181225] to-[#0d0a14] border border-amber-900/40 p-2.5 sm:p-3 min-h-[96px]">
        {selected ? (
          <div className="flex flex-col gap-2">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h3 className="font-bold text-sm sm:text-base text-amber-100 flex items-center gap-1.5">
                  <span>{locationIcon(selected.type)}</span>{selected.name}
                  {selected.isCapital && <Crown className="w-3.5 h-3.5 text-yellow-400" />}
                </h3>
                <p className="text-[10px] sm:text-xs text-amber-100/50 line-clamp-2 mt-0.5">{selected.description}</p>
              </div>
              <span className="shrink-0 flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full"
                style={{ background: `${factionColor(state.factions, selected.faction)}33`, color: factionColor(state.factions, selected.faction) }}>
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: factionColor(state.factions, selected.faction) }} />
                {factionName(state.factions, selected.faction).split(' ')[0]}
              </span>
            </div>
            <div className="flex items-center gap-2 sm:gap-3 text-[10px] text-amber-200/60 flex-wrap">
              <span>⚔️ Garrison: {selected.garrison}</span>
              <span>💰 Wealth: {selected.wealth}</span>
              {state.ownedTerritories.includes(selected.id) && <span className="text-emerald-400">Owned</span>}
            </div>
            <div className="flex gap-2 flex-wrap">
              {!isCurrentSelected && (
                <button onClick={() => onTravel(selected.id)}
                  className="flex-1 min-w-0 min-h-[44px] rounded-lg bg-gradient-to-b from-amber-600 to-amber-800 hover:from-amber-500 hover:to-amber-700 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 active:scale-95 transition shadow-lg">
                  <MapPin className="w-4 h-4" /> Travel
                </button>
              )}
              {isCurrentSelected && (
                <>
                  <button onClick={onEnter}
                    className="flex-1 min-w-0 min-h-[44px] rounded-lg bg-gradient-to-b from-emerald-600 to-emerald-800 hover:from-emerald-500 hover:to-emerald-700 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 active:scale-95 transition shadow-lg">
                    <Sword className="w-4 h-4" /> Enter
                  </button>
                  <button onClick={() => onExplore(selected.id)}
                    className="min-h-[44px] px-2.5 sm:px-3 rounded-lg bg-gradient-to-b from-violet-700 to-violet-900 hover:from-violet-600 hover:to-violet-800 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 active:scale-95 transition shadow-lg">
                    <Crosshair className="w-4 h-4" /> <span className="hidden sm:inline">Explore</span> 3D
                  </button>
                  <button onClick={onRest}
                    className="min-h-[44px] px-2.5 sm:px-3 rounded-lg bg-gradient-to-b from-sky-700 to-sky-900 hover:from-sky-600 hover:to-sky-800 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 active:scale-95 transition shadow-lg">
                    <Utensils className="w-4 h-4" /> Rest
                  </button>
                </>
              )}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center py-3">
            <MapPin className="w-5 h-5 text-amber-500/50 mb-1" />
            <p className="text-xs text-amber-200/50">Tap a location on the map</p>
            {current && (
              <p className="text-[10px] text-amber-200/40 mt-1">
                You are at <span className="text-amber-300">{current.name}</span>
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// Screen 3: Town
// ============================================================

interface TownProps {
  state: WarbandGameState;
  townTab: TownTab;
  setTownTab: (t: TownTab) => void;
  onBack: () => void;
  onBuy: (itemId: string) => void;
  onRecruit: (companionId: string) => void;
  onConquer: () => void;
  onMarry: (candidateId: string) => void;
}

function TownScreen({ state, townTab, setTownTab, onBack, onBuy, onRecruit, onConquer, onMarry }: TownProps) {
  const loc = state.locations.find((l) => l.id === state.currentLocationId);
  if (!loc) {
    return (
      <div className="p-4 text-center text-amber-200/60 text-sm">
        <p>No town data.</p>
        <button onClick={onBack} className="mt-3 px-4 py-2 rounded-lg bg-amber-800 text-white text-sm">Back</button>
      </div>
    );
  }

  const tabs: { id: TownTab; label: string; icon: React.ReactNode }[] = [
    { id: 'tavern', label: 'Tavern', icon: <Utensils className="w-4 h-4" /> },
    { id: 'shop', label: 'Shop', icon: <ShoppingBag className="w-4 h-4" /> },
    { id: 'castle', label: 'Castle', icon: <Crown className="w-4 h-4" /> },
    { id: 'residence', label: 'Residence', icon: <Home className="w-4 h-4" /> },
  ];

  const isOwned = state.ownedTerritories.includes(loc.id);
  const isEnemy = isEnemyFaction(state, loc);

  return (
    <div className="w-full max-w-lg mx-auto px-2 sm:px-3 py-2 flex flex-col gap-2">
      {/* town header */}
      <div className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#1a1525] to-[#0f0c18] border border-amber-900/40 p-2.5">
        <button onClick={onBack} className="p-1.5 rounded-md bg-white/5 hover:bg-amber-900/40 active:scale-95 transition shrink-0">
          <ChevronLeft className="w-5 h-5 text-amber-200" />
        </button>
        <div className="flex-1 min-w-0">
          <h2 className="font-bold text-sm sm:text-base text-amber-100 flex items-center gap-1.5">
            <span>{locationIcon(loc.type)}</span>{loc.name}
            {loc.isCapital && <Crown className="w-3.5 h-3.5 text-yellow-400" />}
          </h2>
          <p className="text-[10px] text-amber-200/50">{factionName(state.factions, loc.faction)}</p>
        </div>
        <span className="shrink-0 flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full"
          style={{ background: `${factionColor(state.factions, loc.faction)}33`, color: factionColor(state.factions, loc.faction) }}>
          <span className="w-1.5 h-1.5 rounded-full" style={{ background: factionColor(state.factions, loc.faction) }} />
          {factionBanner(state.factions, loc.faction)}
        </span>
      </div>

      {/* tabs */}
      <div className="flex gap-1 rounded-xl bg-black/40 border border-white/5 p-1">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => setTownTab(t.id)}
            className={`flex-1 min-h-[40px] flex flex-col items-center justify-center gap-0.5 rounded-lg text-[10px] sm:text-xs font-semibold transition active:scale-95 ${
              townTab === t.id ? 'bg-gradient-to-b from-amber-600 to-amber-800 text-white shadow-lg' : 'text-amber-200/60 hover:bg-white/5'
            }`}>
            {t.icon}{t.label}
          </button>
        ))}
      </div>

      {/* tab content */}
      <div className="rounded-xl bg-gradient-to-b from-[#14101e] to-[#0a0810] border border-amber-900/30 p-2.5 sm:p-3">
        {townTab === 'tavern' && <TavernTab state={state} onRecruit={onRecruit} />}
        {townTab === 'shop' && <ShopTab state={state} onBuy={onBuy} />}
        {townTab === 'castle' && (
          <CastleTab state={state} isOwned={isOwned} isEnemy={isEnemy} onConquer={onConquer} onBack={onBack} />
        )}
        {townTab === 'residence' && <ResidenceTab state={state} onMarry={onMarry} />}
      </div>
    </div>
  );
}

// ---- Tavern ----
interface TavernTabProps {
  state: WarbandGameState;
  onRecruit: (id: string) => void;
}

function TavernTab({ state, onRecruit }: TavernTabProps) {
  const available = state.companions.filter((c) => !c.recruited);
  const recruited = state.companions.filter((c) => c.recruited);

  return (
    <div className="flex flex-col gap-2">
      <p className="text-[10px] sm:text-xs text-amber-200/60 flex items-center gap-1">
        <Utensils className="w-3.5 h-3.5" /> Hire companions for your party
      </p>
      {available.length === 0 && (
        <p className="text-xs text-amber-200/40 text-center py-4">All companions have been hired.</p>
      )}
      {available.map((comp) => {
        const canAfford = state.gold >= comp.cost;
        return (
          <div key={comp.id} className="flex items-center gap-2.5 rounded-lg bg-black/30 border border-white/5 p-2">
            <Portrait color={comp.portraitColor} initial={comp.name[0]} size="sm" />
            <div className="flex-1 min-w-0">
              <h4 className="text-xs sm:text-sm font-bold text-amber-100 truncate">{comp.name}</h4>
              <p className="text-[10px] text-amber-200/50 truncate">{comp.description}</p>
              <div className="flex items-center gap-2 mt-0.5 text-[9px] text-amber-300/70 flex-wrap">
                <span className="flex items-center gap-0.5"><Sword className="w-2.5 h-2.5" />{comp.attack}</span>
                <span className="flex items-center gap-0.5"><Shield className="w-2.5 h-2.5" />{comp.defense}</span>
                <span className="flex items-center gap-0.5"><Heart className="w-2.5 h-2.5" />{comp.hp}/{comp.maxHp}</span>
                <span className="capitalize text-amber-200/40">Lv{comp.level} {comp.role}</span>
              </div>
            </div>
            <button onClick={() => onRecruit(comp.id)} disabled={!canAfford}
              className={`shrink-0 min-h-[40px] px-3 rounded-lg text-xs font-bold flex items-center gap-1 transition active:scale-95 ${
                canAfford ? 'bg-gradient-to-b from-amber-500 to-amber-700 text-white hover:from-amber-400' : 'bg-white/5 text-amber-200/30 cursor-not-allowed'
              }`}>
              <Coins className="w-3.5 h-3.5" />{comp.cost}
            </button>
          </div>
        );
      })}
      {recruited.length > 0 && (
        <>
          <p className="text-[10px] text-emerald-400/70 mt-1">Your party:</p>
          {recruited.map((comp) => (
            <div key={comp.id} className="flex items-center gap-2 rounded-lg bg-emerald-900/15 border border-emerald-700/20 p-1.5">
              <Portrait color={comp.portraitColor} initial={comp.name[0]} size="sm" />
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-bold text-emerald-200 truncate">{comp.name}</h4>
                <p className="text-[9px] text-emerald-300/50">Lv{comp.level} {comp.role} · {comp.hp}/{comp.maxHp} HP</p>
              </div>
              <span className="text-[9px] text-emerald-400 pr-1">✓ Joined</span>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

// ---- Shop ----
interface ShopTabProps {
  state: WarbandGameState;
  onBuy: (id: string) => void;
}

function ShopTab({ state, onBuy }: ShopTabProps) {
  return (
    <div className="flex flex-col gap-2">
      <p className="text-[10px] sm:text-xs text-amber-200/60 flex items-center gap-1">
        <ShoppingBag className="w-3.5 h-3.5" /> Buy weapons, armor & potions · You have <Coins className="w-3 h-3 text-yellow-400" />{state.gold}
      </p>
      {SHOP_ITEMS.map((item) => {
        const canAfford = state.gold >= item.price;
        return (
          <div key={item.id} className="flex items-center gap-2.5 rounded-lg bg-black/30 border border-white/5 p-2">
            <span className="text-xl shrink-0 w-8 text-center">{item.icon}</span>
            <div className="flex-1 min-w-0">
              <h4 className="text-xs sm:text-sm font-bold text-amber-100 truncate">{item.name}</h4>
              <p className="text-[10px] text-amber-200/50 truncate">{item.description}</p>
              <div className="flex flex-wrap gap-1.5 mt-0.5 text-[9px]">
                {item.attackBonus ? <span className="text-rose-400">+{item.attackBonus} ATK</span> : null}
                {item.defenseBonus ? <span className="text-sky-400">+{item.defenseBonus} DEF</span> : null}
                {item.hpBonus ? <span className="text-emerald-400">+{item.hpBonus} HP</span> : null}
                {item.speedBonus ? <span className="text-violet-400">+{item.speedBonus} SPD</span> : null}
              </div>
            </div>
            <button onClick={() => onBuy(item.id)} disabled={!canAfford}
              className={`shrink-0 min-h-[40px] px-3 rounded-lg text-xs font-bold flex items-center gap-1 transition active:scale-95 ${
                canAfford ? 'bg-gradient-to-b from-amber-500 to-amber-700 text-white hover:from-amber-400' : 'bg-white/5 text-amber-200/30 cursor-not-allowed'
              }`}>
              <Coins className="w-3.5 h-3.5" />{item.price}
            </button>
          </div>
        );
      })}
    </div>
  );
}

// ---- Castle ----
interface CastleTabProps {
  state: WarbandGameState;
  isOwned: boolean;
  isEnemy: boolean;
  onConquer: () => void;
  onBack: () => void;
}

function CastleTab({ state, isOwned, isEnemy, onConquer, onBack }: CastleTabProps) {
  const loc = state.locations.find((l) => l.id === state.currentLocationId);
  if (!loc) return null;

  if (isOwned) {
    return (
      <div className="flex flex-col items-center text-center gap-3 py-4">
        <Crown className="w-8 h-8 text-yellow-400" />
        <h3 className="font-bold text-sm text-emerald-300">You rule {loc.name}</h3>
        <p className="text-[10px] text-amber-200/50 max-w-[80%]">This territory is under your banner. Garrison: {loc.garrison} · Wealth: {loc.wealth}</p>
        <div className="grid grid-cols-2 gap-2 w-full max-w-[240px] text-[10px]">
          <div className="rounded-lg bg-black/30 border border-white/5 p-2">
            <p className="text-amber-200/40">Garrison</p>
            <p className="font-bold text-amber-100 text-sm">{loc.garrison}</p>
          </div>
          <div className="rounded-lg bg-black/30 border border-white/5 p-2">
            <p className="text-amber-200/40">Wealth</p>
            <p className="font-bold text-yellow-400 text-sm">{loc.wealth}</p>
          </div>
        </div>
        <button onClick={onBack} className="min-h-[44px] px-5 rounded-lg bg-white/5 text-amber-200 text-xs font-bold active:scale-95 transition">
          Leave Castle
        </button>
      </div>
    );
  }

  if (isEnemy) {
    return (
      <div className="flex flex-col items-center text-center gap-3 py-4">
        <Flag className="w-8 h-8 text-rose-400" />
        <h3 className="font-bold text-sm text-rose-300">Enemy Territory</h3>
        <p className="text-[10px] text-amber-200/50 max-w-[80%]">
          {loc.name} is held by {factionName(state.factions, loc.faction)}, who is at war with you. Garrison: {loc.garrison}
        </p>
        <button onClick={onConquer}
          className="min-h-[48px] px-6 rounded-lg bg-gradient-to-b from-rose-600 to-rose-800 hover:from-rose-500 text-white text-sm font-bold flex items-center gap-2 active:scale-95 transition shadow-lg">
          <Sword className="w-4 h-4" /> Conquer {loc.name}
        </button>
        <p className="text-[9px] text-amber-200/30">Defeat the garrison to claim this territory</p>
      </div>
    );
  }

  // friendly / neutral non-owned
  return (
    <div className="flex flex-col items-center text-center gap-3 py-4">
      <Crown className="w-8 h-8 text-amber-400/70" />
      <h3 className="font-bold text-sm text-amber-200">{loc.name}</h3>
      <p className="text-[10px] text-amber-200/50 max-w-[80%]">
        This {loc.type} belongs to {factionName(state.factions, loc.faction)}, a neutral faction. You may not conquer it.
      </p>
      <button onClick={onBack} className="min-h-[44px] px-5 rounded-lg bg-white/5 text-amber-200 text-xs font-bold active:scale-95 transition">
        Leave Castle
      </button>
    </div>
  );
}

// ---- Residence ----
interface ResidenceTabProps {
  state: WarbandGameState;
  onMarry: (id: string) => void;
}

function ResidenceTab({ state, onMarry }: ResidenceTabProps) {
  return (
    <div className="flex flex-col gap-2">
      <p className="text-[10px] sm:text-xs text-amber-200/60 flex items-center gap-1">
        <HeartIcon className="w-3.5 h-3.5" /> Arrange a political marriage · Your Charisma: {state.charisma}
      </p>
      {state.marriedTo && (
        <div className="rounded-lg bg-pink-900/20 border border-pink-700/30 p-2.5 text-center">
          <p className="text-xs text-pink-200">💍 Married to <span className="font-bold">{state.marriedTo}</span></p>
        </div>
      )}
      {state.marriageCandidates.map((cand) => {
        const canMarry = !cand.married && state.charisma >= cand.charmRequired && state.gold >= cand.dowry;
        return (
          <div key={cand.id} className="flex items-center gap-2.5 rounded-lg bg-black/30 border border-white/5 p-2"
            style={{ opacity: cand.married ? 0.5 : 1 }}>
            <Portrait color={cand.portraitColor} initial={cand.name[0]} size="sm" />
            <div className="flex-1 min-w-0">
              <h4 className="text-xs sm:text-sm font-bold text-amber-100 truncate">{cand.name}</h4>
              <p className="text-[10px] text-amber-200/50 truncate">{cand.description}</p>
              <p className="text-[9px] text-pink-300/70 mt-0.5">{cand.benefit}</p>
              <div className="flex items-center gap-2 mt-0.5 text-[9px] flex-wrap">
                <span className="text-amber-300/70">Charm ≥ {cand.charmRequired}</span>
                <span className="text-yellow-400">Dowry {cand.dowry}</span>
              </div>
            </div>
            {cand.married ? (
              <span className="shrink-0 text-[9px] text-pink-400 px-2">💍 Married</span>
            ) : (
              <button onClick={() => onMarry(cand.id)} disabled={!canMarry}
                className={`shrink-0 min-h-[40px] px-3 rounded-lg text-xs font-bold flex items-center gap-1 transition active:scale-95 ${
                  canMarry ? 'bg-gradient-to-b from-pink-500 to-pink-700 text-white hover:from-pink-400' : 'bg-white/5 text-amber-200/30 cursor-not-allowed'
                }`}>
                <HeartIcon className="w-3.5 h-3.5" />Marry
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ============================================================
// Screen 4: Battle
// ============================================================

interface BattleProps {
  state: WarbandGameState;
  onAction: (action: CombatAction) => void;
  onUsePotion: (itemId: string) => void;
  logRef: React.RefObject<HTMLDivElement>;
}

function BattleScreen({ state, onAction, onUsePotion, logRef }: BattleProps) {
  const enemy = state.battleEnemy;
  const potions = state.inventory.filter((i) => i.type === 'potion');
  const hpPct = (state.hp / state.maxHp) * 100;
  const enemyPct = enemy ? (enemy.hp / enemy.maxHp) * 100 : 0;

  if (!enemy) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-3 py-10">
        <Sword className="w-10 h-10 text-amber-500/50" />
        <p className="text-sm text-amber-200/60">No enemy to fight.</p>
        <button onClick={() => setStateBackToWorld()} className="px-4 py-2 rounded-lg bg-amber-800 text-white text-sm">Return</button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[100] bg-[#050308] text-amber-50 flex flex-col overflow-hidden select-none">
      {/* pseudo-3D arena */}
      <div className="flex-1 min-h-0 relative overflow-hidden"
        style={{ background: 'linear-gradient(180deg, #1a0a18 0%, #0d0610 45%, #050308 100%)' }}>

        {/* arena floor — trapezoidal perspective */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2"
          style={{
            width: '180%',
            height: '38%',
            background: 'linear-gradient(180deg, rgba(80,60,40,0.5) 0%, rgba(40,28,20,0.7) 100%)',
            transform: 'perspective(420px) rotateX(62deg)',
            transformOrigin: 'bottom center',
            borderRadius: '50% 50% 0 0 / 80% 80% 0 0',
            boxShadow: 'inset 0 8px 30px rgba(0,0,0,0.7)',
          }} />
        {/* floor grid lines */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 opacity-30"
          style={{
            width: '180%', height: '38%',
            backgroundImage: 'repeating-linear-gradient(90deg, transparent, transparent 38px, rgba(255,200,100,0.15) 38px, rgba(255,200,100,0.15) 40px)',
            transform: 'perspective(420px) rotateX(62deg)',
            transformOrigin: 'bottom center',
            borderRadius: '50% 50% 0 0 / 80% 80% 0 0',
          }} />

        {/* enemy info bar (top) */}
        <div className="absolute top-0 left-0 right-0 p-2 sm:p-3 z-20">
          <div className="max-w-lg mx-auto rounded-xl bg-black/60 border border-rose-900/50 p-2 backdrop-blur-sm">
            <div className="flex items-center gap-2">
              <Portrait color={enemy.portraitColor} accent={enemy.accentColor} initial={enemy.name[0]} size="sm" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-xs sm:text-sm font-bold text-rose-200 truncate">{enemy.name}</span>
                  <span className="text-[10px] text-amber-200/50">Lv{enemy.level} {enemy.role}</span>
                </div>
                <StatBar label="" value={enemy.hp} max={enemy.maxHp} colorClass={hpColor(enemyPct)} showNumbers={true} icon={<Heart className="w-2.5 h-2.5" />} />
                <div className="flex items-center gap-2 mt-0.5 text-[9px] text-amber-300/60 flex-wrap">
                  <span className="flex items-center gap-0.5"><Sword className="w-2.5 h-2.5" />{enemy.attack}</span>
                  <span className="flex items-center gap-0.5"><Shield className="w-2.5 h-2.5" />{enemy.defense}</span>
                  <span className="capitalize">⚔ {enemy.weapon}</span>
                </div>
              </div>
            </div>
            {/* remaining enemies */}
            {state.battleEnemies.length > 1 && (
              <div className="flex items-center gap-1 mt-1.5">
                <span className="text-[9px] text-amber-200/40">Enemies:</span>
                {state.battleEnemies.map((e, i) => (
                  <span key={e.id} className={`w-2 h-2 rounded-full ${i === state.battleIndex ? 'bg-rose-500' : e.hp > 0 ? 'bg-amber-600' : 'bg-white/10'}`} />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* enemy figure (floating) */}
        <div className="absolute left-1/2 -translate-x-1/2 z-10" style={{ top: '26%' }}>
          <div className="relative flex flex-col items-center">
            {/* shadow */}
            <div className="absolute -bottom-3 w-20 h-4 rounded-full bg-black/50 blur-md" />
            <Portrait color={enemy.portraitColor} accent={enemy.accentColor} initial={enemy.name[0]} size="xl" floating />
            <span className="text-2xl mt-1">{enemy.weapon === 'bow' ? '🏹' : enemy.weapon === 'axe' ? '🪓' : enemy.weapon === 'spear' ? '🔱' : enemy.weapon === 'mace' ? '🔨' : '⚔️'}</span>
          </div>
        </div>

        {/* player info (bottom) */}
        <div className="absolute bottom-0 left-0 right-0 p-2 sm:p-3 z-20">
          <div className="max-w-lg mx-auto rounded-xl bg-black/60 border border-amber-900/50 p-2 backdrop-blur-sm">
            {/* companions */}
            {state.companionsInBattle.length > 0 && (
              <div className="flex items-center gap-1.5 mb-1.5 overflow-x-auto no-scrollbar max-w-full">
                <span className="text-[9px] text-amber-200/40 shrink-0">Party:</span>
                {state.companionsInBattle.map((c) => (
                  <div key={c.id} className="shrink-0 flex flex-col items-center">
                    <Portrait color={c.portraitColor} initial={c.name[0]} size="sm" />
                    <div className="w-10 h-1 rounded-full bg-black/50 mt-0.5 overflow-hidden">
                      <div className="h-full bg-emerald-500" style={{ width: `${(c.hp / c.maxHp) * 100}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div className="flex items-center gap-2">
              <Portrait color={state.selectedCharacter.portraitColor} accent={state.selectedCharacter.accentColor}
                initial={state.selectedCharacter.name[0]} size="sm" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-xs sm:text-sm font-bold text-amber-100 truncate">{state.selectedCharacter.name}</span>
                  <span className="text-[10px] text-amber-200/50">Lv{state.level}</span>
                </div>
                <StatBar label="" value={state.hp} max={state.maxHp} colorClass={hpColor(hpPct)} showNumbers={true} icon={<Heart className="w-2.5 h-2.5" />} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* battle log */}
      <div ref={logRef} className="shrink-0 max-h-20 overflow-y-auto bg-black/70 border-t border-amber-900/40 px-2.5 py-1.5 text-[10px] sm:text-xs space-y-0.5 no-scrollbar">
        {state.battleLog.map((entry) => (
          <p key={entry.id} className={
            entry.type === 'player' ? 'text-sky-300' :
            entry.type === 'enemy' ? 'text-rose-300' :
            entry.type === 'victory' ? 'text-emerald-300 font-bold' :
            entry.type === 'defeat' ? 'text-rose-500 font-bold' :
            entry.type === 'companion' ? 'text-violet-300' :
            'text-amber-200/70'
          }>{entry.text}</p>
        ))}
      </div>

      {/* action buttons */}
      <div className="shrink-0 bg-gradient-to-t from-[#0a0810] to-[#14101e] border-t border-amber-900/40 p-2 sm:p-3">
        <div className="max-w-lg mx-auto grid grid-cols-4 gap-1.5 sm:gap-2">
          <BattleButton onClick={() => onAction('attack')} icon={<Sword className="w-5 h-5" />} label="Attack" color="rose" />
          <BattleButton onClick={() => onAction('block')} icon={<Shield className="w-5 h-5" />} label="Block" color="sky" />
          <BattleButton onClick={() => onAction('dodge')} icon={<Footprints className="w-5 h-5" />} label="Dodge" color="violet" />
          <BattleButton onClick={() => onAction('special')} icon={<Zap className="w-5 h-5" />} label="Special" color="amber" />
        </div>
        {potions.length > 0 && (
          <div className="max-w-lg mx-auto w-full flex items-center gap-1.5 mt-1.5 overflow-x-auto no-scrollbar">
            <span className="text-[9px] text-amber-200/40 shrink-0">Potions:</span>
            {potions.map((p) => (
              <button key={p.id} onClick={() => onUsePotion(p.id)}
                className="shrink-0 min-h-[36px] px-2.5 rounded-lg bg-emerald-900/40 border border-emerald-700/40 text-emerald-200 text-[10px] font-bold flex items-center gap-1 active:scale-95 transition">
                {p.icon} +{p.hpBonus} ({p.qty})
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// helper for the no-enemy fallback (avoid referencing setState outside component scope)
function setStateBackToWorld(): void {
  // no-op: the battle screen is only shown when screen === 'battle';
  // the engine transitions to world-map automatically on victory/defeat.
}

interface BattleButtonProps {
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  color: 'rose' | 'sky' | 'violet' | 'amber';
}

function BattleButton({ onClick, icon, label, color }: BattleButtonProps) {
  const colors: Record<typeof color, string> = {
    rose: 'from-rose-600 to-rose-800 hover:from-rose-500',
    sky: 'from-sky-600 to-sky-800 hover:from-sky-500',
    violet: 'from-violet-600 to-violet-800 hover:from-violet-500',
    amber: 'from-amber-500 to-amber-700 hover:from-amber-400',
  };
  return (
    <button onClick={onClick}
      className={`min-h-[56px] flex flex-col items-center justify-center gap-1 rounded-xl bg-gradient-to-b ${colors[color]} text-white text-[10px] sm:text-xs font-bold active:scale-95 transition shadow-lg`}>
      {icon}{label}
    </button>
  );
}

// ============================================================
// Screen 5: Character Sheet
// ============================================================

interface CharacterScreenProps {
  state: WarbandGameState;
  onBack: () => void;
}

function CharacterScreen({ state, onBack }: CharacterScreenProps) {
  const char = state.selectedCharacter;
  const totalAtk = state.attack + (state.equippedWeapon?.attackBonus || 0);
  const totalDef = state.defense + (state.equippedArmor?.defenseBonus || 0) + (state.equippedShield?.defenseBonus || 0);

  return (
    <div className="w-full max-w-lg mx-auto px-2 sm:px-3 py-2 flex flex-col gap-2">
      <ScreenHeader title="Character" onBack={onBack} />

      {/* hero card */}
      <div className="rounded-xl bg-gradient-to-br from-[#1c1626] to-[#0e0a16] border border-amber-900/40 p-3">
        <div className="flex items-center gap-3">
          <Portrait color={char.portraitColor} accent={char.accentColor} initial={char.name[0]} size="lg" />
          <div className="flex-1 min-w-0">
            <h2 className="font-black text-base sm:text-lg text-amber-100">{char.name}</h2>
            <p className="text-xs text-amber-400/80">{char.title}</p>
            <p className="text-[10px] text-amber-100/50 mt-1 line-clamp-3">{char.personality}</p>
          </div>
        </div>
      </div>

      {/* stats */}
      <div className="rounded-xl bg-gradient-to-b from-[#14101e] to-[#0a0810] border border-amber-900/30 p-3">
        <h3 className="text-xs font-bold text-amber-300 mb-2 flex items-center gap-1"><Crown className="w-3.5 h-3.5" /> Attributes</h3>
        <div className="grid grid-cols-2 gap-2.5">
          <StatRow label="Attack" value={totalAtk} base={state.attack} max={60} icon={<Sword className="w-3 h-3" />} color="bg-rose-500" />
          <StatRow label="Defense" value={totalDef} base={state.defense} max={60} icon={<Shield className="w-3 h-3" />} color="bg-sky-500" />
          <StatRow label="Speed" value={state.speed + (state.mount?.speedBonus || 0)} base={state.speed} max={50} icon={<Footprints className="w-3 h-3" />} color="bg-violet-500" />
          <StatRow label="Leadership" value={state.leadership} base={state.leadership} max={50} icon={<Crown className="w-3 h-3" />} color="bg-amber-500" />
          <StatRow label="Charisma" value={state.charisma} base={state.charisma} max={50} icon={<Sparkles className="w-3 h-3" />} color="bg-pink-500" />
          <StatRow label="Max HP" value={state.maxHp} base={state.maxHp} max={300} icon={<Heart className="w-3 h-3" />} color="bg-emerald-500" />
        </div>
      </div>

      {/* equipment */}
      <div className="rounded-xl bg-gradient-to-b from-[#14101e] to-[#0a0810] border border-amber-900/30 p-3">
        <h3 className="text-xs font-bold text-amber-300 mb-2 flex items-center gap-1"><Backpack className="w-3.5 h-3.5" /> Equipment</h3>
        <div className="flex flex-col gap-1.5">
          <EquipSlot label="Weapon" item={state.equippedWeapon} />
          <EquipSlot label="Armor" item={state.equippedArmor} />
          <EquipSlot label="Shield" item={state.equippedShield} />
          <EquipSlot label="Mount" item={state.mount} />
        </div>
      </div>

      {/* abilities */}
      <div className="rounded-xl bg-gradient-to-b from-[#14101e] to-[#0a0810] border border-amber-900/30 p-3">
        <h3 className="text-xs font-bold text-amber-300 mb-2 flex items-center gap-1"><Zap className="w-3.5 h-3.5" /> Abilities</h3>
        <div className="flex flex-wrap gap-1.5">
          {char.abilities.map((ab, i) => (
            <span key={ab} className={`text-[10px] sm:text-xs px-2.5 py-1 rounded-full border ${
              i === 0 ? 'bg-amber-900/30 border-amber-600/40 text-amber-200' : 'bg-black/30 border-white/10 text-amber-100/70'
            }`}>{ab}</span>
          ))}
        </div>
      </div>

      {/* army summary */}
      <div className="rounded-xl bg-gradient-to-b from-[#14101e] to-[#0a0810] border border-amber-900/30 p-3">
        <h3 className="text-xs font-bold text-amber-300 mb-2 flex items-center gap-1"><Users className="w-3.5 h-3.5" /> Army</h3>
        <div className="grid grid-cols-3 gap-2 text-center">
          {state.army.map((unit, i) => (
            <div key={i} className="rounded-lg bg-black/30 border border-white/5 p-1.5">
              <p className="text-base">{unit.type === 'infantry' ? '🛡️' : unit.type === 'archer' ? '🏹' : '🐎'}</p>
              <p className="text-[9px] text-amber-200/50 capitalize">{unit.type}</p>
              <p className="text-sm font-bold text-amber-100">{unit.count}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

interface StatRowProps {
  label: string;
  value: number;
  base: number;
  max: number;
  icon: React.ReactNode;
  color: string;
}

function StatRow({ label, value, base, max, icon, color }: StatRowProps) {
  const pct = Math.min(100, (value / max) * 100);
  const bonus = value - base;
  return (
    <div>
      <div className="flex items-center justify-between text-[10px] sm:text-xs mb-0.5">
        <span className="flex items-center gap-1 text-amber-200/70">{icon}{label}</span>
        <span className="font-bold text-amber-100">{value}{bonus > 0 && <span className="text-emerald-400 text-[9px]"> +{bonus}</span>}</span>
      </div>
      <div className="h-1.5 rounded-full bg-black/40 overflow-hidden">
        <div className={`h-full ${color} rounded-full transition-all duration-500`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

interface EquipSlotProps {
  label: string;
  item: Item | null;
}

function EquipSlot({ label, item }: EquipSlotProps) {
  return (
    <div className="flex items-center gap-2 min-w-0 rounded-lg bg-black/30 border border-white/5 p-1.5">
      <span className="text-[10px] text-amber-200/50 w-12 sm:w-14 shrink-0">{label}</span>
      {item ? (
        <>
          <span className="text-base shrink-0">{item.icon}</span>
          <span className="text-xs text-amber-100 flex-1 min-w-0 truncate">{item.name}</span>
          <div className="flex gap-1 text-[9px] shrink-0 flex-wrap justify-end">
            {item.attackBonus ? <span className="text-rose-400">+{item.attackBonus}ATK</span> : null}
            {item.defenseBonus ? <span className="text-sky-400">+{item.defenseBonus}DEF</span> : null}
            {item.hpBonus ? <span className="text-emerald-400">+{item.hpBonus}HP</span> : null}
            {item.speedBonus ? <span className="text-violet-400">+{item.speedBonus}SPD</span> : null}
          </div>
        </>
      ) : (
        <span className="text-xs text-amber-200/30 italic">— empty —</span>
      )}
    </div>
  );
}

// ============================================================
// Screen 6: Inventory
// ============================================================

interface InventoryScreenProps {
  state: WarbandGameState;
  onBack: () => void;
  onEquip: (itemId: string) => void;
  onUsePotion: (itemId: string) => void;
}

function InventoryScreen({ state, onBack, onEquip, onUsePotion }: InventoryScreenProps) {
  return (
    <div className="w-full max-w-lg mx-auto px-2 sm:px-3 py-2 flex flex-col gap-2">
      <ScreenHeader title="Inventory" onBack={onBack} />

      {state.inventory.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <Backpack className="w-10 h-10 text-amber-500/40 mb-2" />
          <p className="text-sm text-amber-200/50">Your pack is empty.</p>
          <p className="text-xs text-amber-200/30 mt-1">Visit a town shop to buy gear.</p>
        </div>
      ) : (
        <div className="flex flex-col gap-1.5">
          {state.inventory.map((item) => (
            <InventoryRow key={item.id} item={item} onEquip={onEquip} onUsePotion={onUsePotion} />
          ))}
        </div>
      )}
    </div>
  );
}

interface InventoryRowProps {
  item: Item;
  onEquip: (itemId: string) => void;
  onUsePotion: (itemId: string) => void;
}

function InventoryRow({ item, onEquip, onUsePotion }: InventoryRowProps) {
  const isEquippable = item.type === 'weapon' || item.type === 'armor' || item.type === 'shield' || item.type === 'mount';
  return (
    <div className="flex items-center gap-2.5 rounded-lg bg-gradient-to-r from-[#181225] to-[#0e0a16] border border-amber-900/30 p-2">
      <span className="text-xl shrink-0 w-8 text-center">{item.icon}</span>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <h4 className="text-xs sm:text-sm font-bold text-amber-100 truncate">{item.name}</h4>
          {item.qty && item.qty > 1 && <span className="text-[9px] text-amber-300/60">×{item.qty}</span>}
        </div>
        <p className="text-[10px] text-amber-200/50 truncate">{item.description}</p>
        <div className="flex flex-wrap gap-1.5 mt-0.5 text-[9px]">
          {item.attackBonus ? <span className="text-rose-400">+{item.attackBonus} ATK</span> : null}
          {item.defenseBonus ? <span className="text-sky-400">+{item.defenseBonus} DEF</span> : null}
          {item.hpBonus ? <span className="text-emerald-400">+{item.hpBonus} HP</span> : null}
          {item.speedBonus ? <span className="text-violet-400">+{item.speedBonus} SPD</span> : null}
        </div>
      </div>
      <div className="shrink-0 flex flex-col gap-1">
        {item.type === 'potion' ? (
          <button onClick={() => onUsePotion(item.id)}
            className="min-h-[36px] px-3 rounded-lg bg-gradient-to-b from-emerald-600 to-emerald-800 text-white text-[10px] font-bold flex items-center gap-1 active:scale-95 transition">
            <Heart className="w-3 h-3" />Use
          </button>
        ) : isEquippable ? (
          <button onClick={() => onEquip(item.id)}
            className="min-h-[36px] px-3 rounded-lg bg-gradient-to-b from-amber-500 to-amber-700 text-white text-[10px] font-bold flex items-center gap-1 active:scale-95 transition">
            <Sword className="w-3 h-3" />Equip
          </button>
        ) : null}
      </div>
    </div>
  );
}

// ============================================================
// Quest Modal
// ============================================================

interface QuestModalProps {
  state: WarbandGameState;
  onClose: () => void;
  onClaim: (questId: string) => void;
}

function QuestModal({ state, onClose, onClaim }: QuestModalProps) {
  const completed = state.quests.filter((q) => q.completed).length;
  return (
    <div className="fixed inset-0 z-[110] bg-black/70 backdrop-blur-sm flex items-center justify-center p-3" onClick={onClose}>
      <div className="w-full max-w-md max-h-[85vh] overflow-y-auto rounded-2xl bg-gradient-to-b from-[#1a1525] to-[#0d0a14] border border-amber-700/40 shadow-2xl"
        onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 bg-gradient-to-b from-[#1a1525] to-[#1a1525] border-b border-amber-900/40 p-3 flex items-center justify-between">
          <h2 className="font-bold text-sm sm:text-base text-amber-200 flex items-center gap-2">
            <ScrollText className="w-4 h-4" /> Quests
            <span className="text-[10px] text-amber-200/50">({completed}/{state.quests.length})</span>
          </h2>
          <button onClick={onClose} className="p-1.5 rounded-md bg-white/5 hover:bg-rose-900/40 active:scale-95 transition">
            <X className="w-4 h-4 text-rose-300" />
          </button>
        </div>
        <div className="p-3 flex flex-col gap-2">
          {state.quests.map((quest) => (
            <QuestRow key={quest.id} quest={quest} onClaim={onClaim} />
          ))}
        </div>
      </div>
    </div>
  );
}

interface QuestRowProps {
  quest: Quest;
  onClaim: (questId: string) => void;
}

function QuestRow({ quest, onClaim }: QuestRowProps) {
  return (
    <div className={`rounded-lg p-2.5 border ${quest.completed ? 'bg-emerald-900/15 border-emerald-700/30' : 'bg-black/30 border-white/5'}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <h4 className={`text-xs sm:text-sm font-bold ${quest.completed ? 'text-emerald-200' : 'text-amber-100'}`}>{quest.title}</h4>
            {quest.completed && <Star className="w-3 h-3 text-emerald-400 fill-emerald-400" />}
          </div>
          <p className="text-[10px] text-amber-200/50 mt-0.5">{quest.description}</p>
          <div className="flex items-center gap-2 mt-1 text-[9px]">
            <span className="text-yellow-400 flex items-center gap-0.5"><Coins className="w-2.5 h-2.5" />{quest.reward}</span>
            <span className="text-sky-400 flex items-center gap-0.5"><Sparkles className="w-2.5 h-2.5" />{quest.rewardXp} XP</span>
          </div>
        </div>
        {quest.completed && (
          <button onClick={() => onClaim(quest.id)}
            className="shrink-0 min-h-[36px] px-3 rounded-lg bg-gradient-to-b from-emerald-500 to-emerald-700 text-white text-[10px] font-bold active:scale-95 transition">
            Claim
          </button>
        )}
      </div>
    </div>
  );
}

// ============================================================
// Shared screen header
// ============================================================

interface ScreenHeaderProps {
  title: string;
  onBack: () => void;
}

function ScreenHeader({ title, onBack }: ScreenHeaderProps) {
  return (
    <div className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#1a1525] to-[#0f0c18] border border-amber-900/40 p-2.5">
      <button onClick={onBack} className="p-1.5 rounded-md bg-white/5 hover:bg-amber-900/40 active:scale-95 transition shrink-0">
        <ChevronLeft className="w-5 h-5 text-amber-200" />
      </button>
      <h2 className="font-bold text-sm sm:text-base text-amber-100">{title}</h2>
    </div>
  );
}
