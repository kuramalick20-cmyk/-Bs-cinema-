import { useState, useRef, useEffect } from 'react';
import { X, Send, Loader2, Bot, User, Plus, MessageSquare, Menu } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useI18n } from '@/lib/i18n';

interface AiChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
}

interface AiChatConversation {
  id: string;
  title: string | null;
  created_at: string;
}

interface AIChatProps {
  onClose: () => void;
}

export default function AIChat({ onClose }: AIChatProps) {
  const { user } = useAuth();
  const { t } = useI18n();
  const [conversations, setConversations] = useState<AiChatConversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<string | null>(null);
  const [messages, setMessages] = useState<AiChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showConvList, setShowConvList] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadConversations();
  }, []);

  useEffect(() => {
    if (activeConvId) loadMessages(activeConvId);
  }, [activeConvId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const loadConversations = async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    const { data } = await supabase
      .from('ai_chat_conversations')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    const convs = (data as AiChatConversation[]) || [];
    setConversations(convs);
    if (convs.length > 0 && !activeConvId) {
      setActiveConvId(convs[0].id);
    }
    setLoading(false);
  };

  const loadMessages = async (convId: string) => {
    const { data } = await supabase
      .from('ai_chat_messages')
      .select('*')
      .eq('conversation_id', convId)
      .order('created_at', { ascending: true });
    setMessages((data as AiChatMessage[]) || []);
  };

  const startNewChat = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('ai_chat_conversations')
      .insert({ user_id: user.id, title: 'گفتوگۆی نوێ' })
      .select('*')
      .maybeSingle();
    if (data) {
      const newConv = data as AiChatConversation;
      setConversations([newConv, ...conversations]);
      setActiveConvId(newConv.id);
      setMessages([]);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || sending) return;
    if (!user) return;

    let convId = activeConvId;

    // Create conversation if none active
    if (!convId) {
      const { data } = await supabase
        .from('ai_chat_conversations')
        .insert({ user_id: user.id, title: input.slice(0, 40) })
        .select('*')
        .maybeSingle();
      if (!data) return;
      convId = (data as AiChatConversation).id;
      setConversations([data as AiChatConversation, ...conversations]);
      setActiveConvId(convId);
    }

    const userMsg = input.trim();
    setInput('');
    setSending(true);

    // Optimistic message
    const tempUserMsg: AiChatMessage = {
      id: 'temp-' + Date.now(),
      role: 'user',
      content: userMsg,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, tempUserMsg]);

    // Save user message to DB
    await supabase.from('ai_chat_messages').insert({
      conversation_id: convId,
      role: 'user',
      content: userMsg,
    });

    // Call AI edge function
    const allMessages = [...messages, { role: 'user', content: userMsg }];
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-chat`;
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({ messages: allMessages }),
      });

      if (!response.ok) throw new Error('Request failed');
      const data = await response.json();
      const reply = data.reply || data.error || 'ببورە، ناتوانم وەڵام بدەمەوە لە ئێستادا.';

      // Save assistant message
      await supabase.from('ai_chat_messages').insert({
        conversation_id: convId,
        role: 'assistant',
        content: reply,
      });

      setMessages((prev) => [
        ...prev.filter((m) => m.id !== tempUserMsg.id),
        { id: 'temp-' + Date.now() + '-a', role: 'user', content: userMsg, created_at: new Date().toISOString() } as AiChatMessage,
        { id: 'temp-' + Date.now() + '-b', role: 'assistant', content: reply, created_at: new Date().toISOString() },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev.filter((m) => m.id !== tempUserMsg.id),
        { id: 'temp-' + Date.now() + '-a', role: 'user', content: userMsg, created_at: new Date().toISOString() } as AiChatMessage,
        { id: 'err-' + Date.now(), role: 'assistant', content: 'ببورە، هەڵەیەک ڕوویدا لە پەیوەندیکردن. تکایە دواتر هەوڵ بدەرەوە.', created_at: new Date().toISOString() },
      ]);
    }
    setSending(false);
  };

  if (!user) {
    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-primary animate-fade-in">
        <div className="text-center max-w-sm px-6">
          <Bot className="w-16 h-16 text-accent mx-auto mb-4" />
          <h2 className="text-xl font-bold text-primary mb-2">{t('aiChatTitle')}</h2>
          <p className="text-secondary text-sm mb-4">{t('login')}</p>
          <button onClick={onClose} className="px-6 py-2.5 rounded-xl bg-accent text-white font-medium text-sm">
            OK
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-primary animate-fade-in">
      {/* Header */}
      <div className="sticky top-0 glass border-b border-default px-4 py-3 flex items-center justify-between z-10" style={{ paddingTop: 'calc(0.75rem + var(--safe-top))' }}>
        <div className="flex items-center gap-2">
          {conversations.length > 0 && (
            <button onClick={() => setShowConvList(true)} className="sm:hidden p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all">
              <Menu className="w-5 h-5" />
            </button>
          )}
          <Bot className="w-5 h-5 text-accent" />
          <h2 className="text-base sm:text-lg font-bold text-primary">{t('aiChatTitle')}</h2>
        </div>
        <div className="flex items-center gap-1">
          {conversations.length > 0 && (
            <button onClick={startNewChat} className="p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all" title={t('newChat')}>
              <Plus className="w-5 h-5" />
            </button>
          )}
          <button onClick={onClose} className="p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar with conversations */}
        {conversations.length > 0 && (
          <div className="hidden sm:flex flex-col w-64 border-r border-default bg-secondary overflow-y-auto">
            <button
              onClick={startNewChat}
              className="flex items-center gap-2 m-3 px-3 py-2.5 rounded-lg bg-accent text-white text-sm font-medium hover:bg-[var(--accent-hover)] transition-colors"
            >
              <Plus className="w-4 h-4" /> {t('newChat')}
            </button>
            <div className="px-2 pb-4 space-y-1">
              {conversations.map((conv) => (
                <button
                  key={conv.id}
                  onClick={() => setActiveConvId(conv.id)}
                  className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm transition-colors text-right ${
                    activeConvId === conv.id ? 'bg-accent/15 text-accent' : 'text-secondary hover:text-primary hover:bg-hover'
                  }`}
                >
                  <MessageSquare className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{conv.title || 'Chat'}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Chat area */}
        <div className="flex-1 flex flex-col">
          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto px-3 py-4 sm:px-4 sm:py-6 space-y-3 sm:space-y-4">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-accent animate-spin" />
              </div>
            ) : messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center mb-4">
                  <Bot className="w-8 h-8 text-accent" />
                </div>
                <p className="text-secondary text-sm max-w-xs">{t('welcomeAi')}</p>
              </div>
            ) : (
              messages.map((msg) => (
                <div key={msg.id} className={`flex gap-2 sm:gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                  <div className={`flex-shrink-0 w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center ${msg.role === 'user' ? 'bg-accent' : 'bg-card border border-default'}`}>
                    {msg.role === 'user' ? <User className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" /> : <Bot className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-accent" />}
                  </div>
                  <div className={`max-w-[80%] sm:max-w-[75%] rounded-2xl px-3 py-2 sm:px-4 sm:py-2.5 text-xs sm:text-sm leading-relaxed break-words ${msg.role === 'user' ? 'bg-accent text-white' : 'bg-card border border-default text-primary'}`} dir="auto">
                    {msg.content}
                  </div>
                </div>
              ))
            )}
            {sending && (
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-card border border-default flex items-center justify-center">
                  <Bot className="w-4 h-4 text-accent" />
                </div>
                <div className="bg-card border border-default rounded-2xl px-4 py-3">
                  <Loader2 className="w-4 h-4 text-accent animate-spin" />
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="border-t border-default p-2 sm:p-3 bg-secondary safe-bottom">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder={t('typeMessage')}
                className="flex-1 min-w-0 px-3 py-2.5 sm:px-4 sm:py-3 rounded-xl bg-card border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent transition-colors"
                disabled={sending}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || sending}
                className="p-3 rounded-xl bg-accent text-white hover:bg-[var(--accent-hover)] transition-colors disabled:opacity-30 flex-shrink-0"
              >
                {sending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile conversation drawer */}
      {showConvList && (
        <div className="sm:hidden fixed inset-0 z-20" onClick={() => setShowConvList(false)}>
          <div className="absolute inset-0 bg-black/50" />
          <div className="absolute right-0 top-0 bottom-0 w-72 max-w-[80vw] bg-secondary border-l border-default flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-3 border-b border-default">
              <span className="text-sm font-bold text-primary"> گفتوگۆکان</span>
              <button onClick={() => setShowConvList(false)} className="p-1.5 rounded-full text-secondary hover:text-primary hover:bg-hover">
                <X className="w-4 h-4" />
              </button>
            </div>
            <button
              onClick={() => { startNewChat(); setShowConvList(false); }}
              className="flex items-center gap-2 m-3 px-3 py-2.5 rounded-lg bg-accent text-white text-sm font-medium"
            >
              <Plus className="w-4 h-4" /> {t('newChat')}
            </button>
            <div className="flex-1 overflow-y-auto px-2 pb-4 space-y-1">
              {conversations.map((conv) => (
                <button
                  key={conv.id}
                  onClick={() => { setActiveConvId(conv.id); setShowConvList(false); }}
                  className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm transition-colors text-right ${
                    activeConvId === conv.id ? 'bg-accent/15 text-accent' : 'text-secondary hover:text-primary hover:bg-hover'
                  }`}
                >
                  <MessageSquare className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{conv.title || 'Chat'}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
