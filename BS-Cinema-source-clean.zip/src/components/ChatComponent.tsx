import { useState, useEffect, useRef, useCallback } from 'react';
import {
  X, Send, Search, ArrowLeft, MessageCircle, Loader2, Mic, Square,
  Play, Pause, Phone, PhoneOff, MicOff, Camera, Video, Image as ImageIcon,
  Trash2, Edit2, Check, Smile, MoreVertical, Download, AlertTriangle, Volume2,
} from 'lucide-react';
import { supabase, type ChatConversation, type ChatMessage, type Profile } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { uploadFile } from '@/lib/storage';
import { useVoiceCall, type CallState } from '@/lib/useVoiceCall';

function Avatar({ profile, size = 28 }: { profile: { avatar_url?: string | null; username?: string | null } | null; size?: number }) {
  if (profile?.avatar_url) {
    return <img src={profile.avatar_url} alt="" className="rounded-full object-cover" style={{ width: size, height: size }} />;
  }
  return (
    <div className="rounded-full bg-accent/20 flex items-center justify-center" style={{ width: size, height: size }}>
      <span className="text-accent font-bold" style={{ fontSize: size * 0.4 }}>{(profile?.username || '?')[0]}</span>
    </div>
  );
}

interface ChatComponentProps {
  onClose: () => void;
}

interface ConversationWithProfile extends ChatConversation {
  otherUser: Profile | null;
  lastMessage?: string;
  unreadCount?: number;
}

const REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '👏'];
const MAX_VIDEO_DURATION = 60;

export default function ChatComponent({ onClose }: ChatComponentProps) {
  const { user, profile: myProfile } = useAuth();
  const [conversations, setConversations] = useState<ConversationWithProfile[]>([]);
  const [activeConv, setActiveConv] = useState<ConversationWithProfile | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const subscriptionRef = useRef<any>(null);

  // Voice message recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [uploadingVoice, setUploadingVoice] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<number | null>(null);

  // Media upload state
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const fileImageRef = useRef<HTMLInputElement>(null);
  const fileVideoRef = useRef<HTMLInputElement>(null);

  // Video recording state
  const [isRecordingVideo, setIsRecordingVideo] = useState(false);
  const [videoRecordSeconds, setVideoRecordSeconds] = useState(0);
  const videoRecorderRef = useRef<MediaRecorder | null>(null);
  const videoChunksRef = useRef<Blob[]>([]);
  const videoTimerRef = useRef<number | null>(null);
  const videoStreamRef = useRef<MediaStream | null>(null);

  // Message actions state
  const [actionMenuMsgId, setActionMenuMsgId] = useState<string | null>(null);
  const [editingMsgId, setEditingMsgId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');
  const [showReactionsFor, setShowReactionsFor] = useState<string | null>(null);

  // Moderation state
  const [moderationWarning, setModerationWarning] = useState<string | null>(null);
  const [isBanned, setIsBanned] = useState(false);

  // Voice call state
  const voiceCall = useVoiceCall({
    userId: user?.id || '',
    otherUserId: activeConv?.otherUser?.id || '',
    conversationId: activeConv?.id || '',
  });

  const loadConversations = useCallback(async () => {
    if (!user) return;
    const { data: convs } = await supabase
      .from('chat_conversations')
      .select('*')
      .or(`user1_id.eq.${user.id},user2_id.eq.${user.id}`)
      .order('created_at', { ascending: false });

    if (!convs) {
      setLoading(false);
      return;
    }

    const convsWithProfiles = await Promise.all(
      (convs as ChatConversation[]).map(async (conv) => {
        const otherUserId = conv.user1_id === user.id ? conv.user2_id : conv.user1_id;
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', otherUserId)
          .maybeSingle();

        const { data: lastMsg } = await supabase
          .from('chat_messages')
          .select('text, message_type, created_at, deleted_at')
          .eq('conversation_id', conv.id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        const { count } = await supabase
          .from('chat_messages')
          .select('*', { count: 'exact', head: true })
          .eq('conversation_id', conv.id)
          .eq('sender_id', otherUserId)
          .is('read_at', null);

        let lastText = '...';
        if (lastMsg?.deleted_at) {
          lastText = '🗑️ پەیام سڕایەوە';
        } else if (lastMsg?.message_type === 'voice') {
          lastText = '🔊 پەیامی دەنگی';
        } else if (lastMsg?.message_type === 'image') {
          lastText = '🖼️ وێنە';
        } else if (lastMsg?.message_type === 'video') {
          lastText = '🎬 ڤیدیۆ';
        } else {
          lastText = lastMsg?.text || '';
        }

        return {
          ...conv,
          otherUser: profile as Profile | null,
          lastMessage: lastText,
          unreadCount: count || 0,
        };
      })
    );

    setConversations(convsWithProfiles);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  // Search for users
  useEffect(() => {
    if (!searchQuery.trim() || !user) {
      setSearchResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .or(`username.ilike.%${searchQuery.trim()}%,username.ilike.${searchQuery.trim()}%`)
        .neq('id', user.id)
        .limit(10);
      setSearchResults((data as Profile[]) || []);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery, user]);

  const loadMessages = useCallback(async (convId: string) => {
    const { data } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('conversation_id', convId)
      .order('created_at', { ascending: true });
    setMessages((data as ChatMessage[]) || []);

    if (user) {
      await supabase
        .from('chat_messages')
        .update({ read_at: new Date().toISOString() })
        .eq('conversation_id', convId)
        .neq('sender_id', user.id)
        .is('read_at', null);
    }
  }, [user]);

  // Real-time subscription for messages
  useEffect(() => {
    if (!activeConv) return;

    loadMessages(activeConv.id);

    subscriptionRef.current = supabase
      .channel(`chat:${activeConv.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `conversation_id=eq.${activeConv.id}` },
        (payload) => {
          const newMsg = payload.new as ChatMessage;
          setMessages((prev) => {
            if (prev.some((m) => m.id === newMsg.id)) return prev;
            return [...prev, newMsg];
          });
          if (user && newMsg.sender_id !== user.id) {
            supabase
              .from('chat_messages')
              .update({ read_at: newMsg.created_at })
              .eq('id', newMsg.id)
              .is('read_at', null);
          }
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'chat_messages', filter: `conversation_id=eq.${activeConv.id}` },
        (payload) => {
          const updated = payload.new as ChatMessage;
          setMessages((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
        }
      )
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'chat_messages', filter: `conversation_id=eq.${activeConv.id}` },
        (payload) => {
          const deleted = payload.old as ChatMessage;
          setMessages((prev) => prev.filter((m) => m.id !== deleted.id));
        }
      )
      .subscribe();

    return () => {
      if (subscriptionRef.current) {
        supabase.removeChannel(subscriptionRef.current);
      }
    };
  }, [activeConv, user, loadMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const startConversation = async (otherUser: Profile) => {
    if (!user) return;
    const { data: existing } = await supabase
      .from('chat_conversations')
      .select('*')
      .or(`and(user1_id.eq.${user.id},user2_id.eq.${otherUser.id}),and(user1_id.eq.${otherUser.id},user2_id.eq.${user.id})`)
      .maybeSingle();

    if (existing) {
      const conv: ConversationWithProfile = {
        ...(existing as ChatConversation),
        otherUser,
        unreadCount: 0,
      };
      setActiveConv(conv);
    } else {
      const { data: newConv } = await supabase
        .from('chat_conversations')
        .insert({ user1_id: user.id, user2_id: otherUser.id })
        .select('*')
        .single();
      if (newConv) {
        const conv: ConversationWithProfile = {
          ...(newConv as ChatConversation),
          otherUser,
          unreadCount: 0,
        };
        setActiveConv(conv);
        loadConversations();
      }
    }
    setSearchQuery('');
    setSearchResults([]);
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !activeConv || !user) return;
    if (isBanned) {
      setModerationWarning('هەژمارەکەت قەدەغە کراوە. ناتوانیت پەیام بنێریت.');
      return;
    }
    setSending(true);
    const msgText = newMessage.trim();
    setNewMessage('');

    const { data, error } = await supabase
      .from('chat_messages')
      .insert({
        conversation_id: activeConv.id,
        sender_id: user.id,
        text: msgText,
        message_type: 'text',
      })
      .select('*')
      .single();

    if (error) {
      setIsBanned(true);
      setModerationWarning('ناتوانیت پەیام بنێریت. هەژمارەکەت قەدەغە کراوە.');
      setNewMessage(msgText);
    } else if (data) {
      const msg = data as ChatMessage;
      if (msg.moderation_status === 'flagged') {
        const violationCount = await checkViolationCount();
        if (violationCount >= 3) {
          setIsBanned(true);
          setModerationWarning('پەیامەکەت سڕایەوە چونکە زانیاری پەیوەندی تێدا بوو. هەژمارەکەت بە هۆی ٣ سەرپێچی قەدەغە کرا.');
        } else {
          setModerationWarning(`پەیامەکەت سڕایەوە چونکە زانیاری پەیوەندی کۆمەڵایەتی تێدا بوو. ئاگاداری ${3 - violationCount} سەرپێچی تر بکەر، نەگەر هەژمارەکەت قەدەغە دەکرێت.`);
        }
      }
      setMessages((prev) => [...prev, msg]);
      if (msg.moderation_status !== 'flagged' && activeConv.otherUser) {
        await supabase.from('notifications').insert({
          user_id: activeConv.otherUser.id,
          type: 'chat_message',
          title: myProfile?.username || 'پەیامی نوێ',
          body: msgText,
          link_id: activeConv.id,
          is_read: false,
        });
      }
    }
    setSending(false);
  };

  // Check violation count for current user
  const checkViolationCount = async (): Promise<number> => {
    if (!user) return 0;
    const { count } = await supabase
      .from('chat_violations')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id);
    return count || 0;
  };

  // Check if user is banned on mount
  useEffect(() => {
    if (myProfile?.banned_at) {
      setIsBanned(true);
    } else {
      setIsBanned(false);
    }
  }, [myProfile?.banned_at]);

  // Auto-dismiss moderation warning after 6 seconds
  useEffect(() => {
    if (moderationWarning) {
      const timer = setTimeout(() => setModerationWarning(null), 6000);
      return () => clearTimeout(timer);
    }
  }, [moderationWarning]);

  // === Message actions: edit, delete, react ===

  const handleEditMessage = async (msgId: string) => {
    if (!editingText.trim()) return;
    await supabase
      .from('chat_messages')
      .update({ text: editingText.trim(), edited_at: new Date().toISOString() })
      .eq('id', msgId);
    setMessages((prev) => prev.map((m) =>
      m.id === msgId ? { ...m, text: editingText.trim(), edited_at: new Date().toISOString() } : m
    ));
    setEditingMsgId(null);
    setEditingText('');
    setActionMenuMsgId(null);
  };

  const handleDeleteMessage = async (msgId: string) => {
    await supabase
      .from('chat_messages')
      .update({
        deleted_at: new Date().toISOString(),
        text: null,
        image_url: null,
        video_url: null,
        audio_url: null,
      })
      .eq('id', msgId);
    setMessages((prev) => prev.map((m) =>
      m.id === msgId
        ? { ...m, deleted_at: new Date().toISOString(), text: null, image_url: null, video_url: null, audio_url: null }
        : m
    ));
    setActionMenuMsgId(null);
  };

  const handleReact = async (msgId: string, emoji: string) => {
    if (!user) return;
    const msg = messages.find((m) => m.id === msgId);
    if (!msg) return;
    const reactions = msg.reactions || {};
    const myReaction = reactions[user.id];
    if (myReaction === emoji) {
      delete reactions[user.id];
    } else {
      reactions[user.id] = emoji;
    }
    await supabase
      .from('chat_messages')
      .update({ reactions: Object.keys(reactions).length > 0 ? reactions : null })
      .eq('id', msgId);
    setMessages((prev) => prev.map((m) =>
      m.id === msgId ? { ...m, reactions: Object.keys(reactions).length > 0 ? reactions : null } : m
    ));
    setShowReactionsFor(null);
  };

  // === Voice message recording ===
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioFile = new File([audioBlob], `voice-${Date.now()}.webm`, { type: 'audio/webm' });
        stream.getTracks().forEach((t) => t.stop());
        await sendVoiceMessage(audioFile);
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
      setRecordSeconds(0);
      recordTimerRef.current = window.setInterval(() => {
        setRecordSeconds((s) => s + 1);
      }, 1000);
    } catch (err) {
      console.error('Failed to start recording:', err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    if (recordTimerRef.current) {
      clearInterval(recordTimerRef.current);
      recordTimerRef.current = null;
    }
    setIsRecording(false);
  };

  const cancelRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.onstop = null;
      mediaRecorderRef.current.stop();
    }
    if (recordTimerRef.current) {
      clearInterval(recordTimerRef.current);
      recordTimerRef.current = null;
    }
    setIsRecording(false);
    audioChunksRef.current = [];
  };

  const sendVoiceMessage = async (audioFile: File) => {
    if (!activeConv || !user) return;
    if (isBanned) { setModerationWarning('هەژمارەکەت قەدەغە کراوە.'); return; }
    setUploadingVoice(true);
    const url = await uploadFile('chat-audio', audioFile);
    if (url) {
      const { data } = await supabase
        .from('chat_messages')
        .insert({
          conversation_id: activeConv.id,
          sender_id: user.id,
          text: null,
          audio_url: url,
          message_type: 'voice',
        })
        .select('*')
        .single();
      if (data) {
        const msg = data as ChatMessage;
        if (msg.moderation_status === 'flagged') {
          setModerationWarning('پەیامەکەت سڕایەوە چونکە زانیاری پەیوەندی تێدا بوو.');
        }
        setMessages((prev) => [...prev, msg]);
        if (msg.moderation_status !== 'flagged' && activeConv.otherUser) {
          await supabase.from('notifications').insert({
            user_id: activeConv.otherUser.id,
            type: 'chat_message',
            title: myProfile?.username || 'پەیامی دەنگی',
            body: '🔊 پەیامی دەنگی',
            link_id: activeConv.id,
            is_read: false,
          });
        }
      }
    }
    setUploadingVoice(false);
  };

  // === Image message ===
  const handleImageSelect = async (file: File) => {
    if (!activeConv || !user) return;
    if (isBanned) { setModerationWarning('هەژمارەکەت قەدەغە کراوە.'); return; }
    setUploadingMedia(true);
    const url = await uploadFile('chat-media', file);
    if (url) {
      const { data } = await supabase
        .from('chat_messages')
        .insert({
          conversation_id: activeConv.id,
          sender_id: user.id,
          text: null,
          image_url: url,
          message_type: 'image',
        })
        .select('*')
        .single();
      if (data) {
        const msg = data as ChatMessage;
        if (msg.moderation_status === 'flagged') {
          setModerationWarning('وێنەکە سڕایەوە چونکە زانیاری پەیوەندی کۆمەڵایەتی لەخۆ گرتبوو.');
        }
        setMessages((prev) => [...prev, msg]);
      }
    }
    setUploadingMedia(false);
  };

  // === Video message (select from file) ===
  const handleVideoSelect = async (file: File) => {
    if (!activeConv || !user) return;
    if (isBanned) { setModerationWarning('هەژمارەکەت قەدەغە کراوە.'); return; }
    // Check duration via a temporary video element
    const videoEl = document.createElement('video');
    videoEl.preload = 'metadata';
    const url = URL.createObjectURL(file);
    videoEl.src = url;
    videoEl.onloadedmetadata = async () => {
      URL.revokeObjectURL(url);
      if (videoEl.duration > MAX_VIDEO_DURATION) {
        alert(`ماوەی ڤیدیۆ زۆرە. زۆرترین ماوە ${MAX_VIDEO_DURATION} چرکەیە.`);
        return;
      }
      setUploadingMedia(true);
      const uploadedUrl = await uploadFile('chat-media', file);
      if (uploadedUrl) {
        const { data } = await supabase
          .from('chat_messages')
          .insert({
            conversation_id: activeConv.id,
            sender_id: user.id,
            text: null,
            video_url: uploadedUrl,
            message_type: 'video',
          })
          .select('*')
          .single();
        if (data) {
          const msg = data as ChatMessage;
          if (msg.moderation_status === 'flagged') {
            setModerationWarning('ڤیدیۆکە سڕایەوە چونکە زانیاری پەیوەندی کۆمەڵایەتی لەخۆ گرتبوو.');
          }
          setMessages((prev) => [...prev, msg]);
        }
      }
      setUploadingMedia(false);
    };
    videoEl.onerror = async () => {
      URL.revokeObjectURL(url);
      // If we can't read metadata, upload anyway (trusted to be short)
      setUploadingMedia(true);
      const uploadedUrl = await uploadFile('chat-media', file);
      if (uploadedUrl) {
        const { data } = await supabase
          .from('chat_messages')
          .insert({
            conversation_id: activeConv.id,
            sender_id: user.id,
            text: null,
            video_url: uploadedUrl,
            message_type: 'video',
          })
          .select('*')
          .single();
        if (data) {
          const msg = data as ChatMessage;
          if (msg.moderation_status === 'flagged') {
            setModerationWarning('ڤیدیۆکە سڕایەوە چونکە زانیاری پەیوەندی کۆمەڵایەتی لەخۆ گرتبوو.');
          }
          setMessages((prev) => [...prev, msg]);
        }
      }
      setUploadingMedia(false);
    };
  };

  // === Video recording ===
  const startVideoRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: true });
      videoStreamRef.current = stream;
      const recorder = new MediaRecorder(stream);
      videoChunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) videoChunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        const videoBlob = new Blob(videoChunksRef.current, { type: 'video/webm' });
        const videoFile = new File([videoBlob], `video-${Date.now()}.webm`, { type: 'video/webm' });
        stream.getTracks().forEach((t) => t.stop());
        videoStreamRef.current = null;
        await handleVideoSelect(videoFile);
      };
      recorder.start();
      videoRecorderRef.current = recorder;
      setIsRecordingVideo(true);
      setVideoRecordSeconds(0);
      videoTimerRef.current = window.setInterval(() => {
        setVideoRecordSeconds((s) => {
          if (s + 1 >= MAX_VIDEO_DURATION) {
            stopVideoRecording();
          }
          return s + 1;
        });
      }, 1000);
    } catch (err) {
      console.error('Failed to start video recording:', err);
    }
  };

  const stopVideoRecording = () => {
    if (videoRecorderRef.current && videoRecorderRef.current.state !== 'inactive') {
      videoRecorderRef.current.stop();
    }
    if (videoTimerRef.current) {
      clearInterval(videoTimerRef.current);
      videoTimerRef.current = null;
    }
    setIsRecordingVideo(false);
  };

  const cancelVideoRecording = () => {
    if (videoRecorderRef.current && videoRecorderRef.current.state !== 'inactive') {
      videoRecorderRef.current.onstop = null;
      videoRecorderRef.current.stop();
    }
    if (videoTimerRef.current) {
      clearInterval(videoTimerRef.current);
      videoTimerRef.current = null;
    }
    if (videoStreamRef.current) {
      videoStreamRef.current.getTracks().forEach((t) => t.stop());
      videoStreamRef.current = null;
    }
    setIsRecordingVideo(false);
    videoChunksRef.current = [];
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (recordTimerRef.current) clearInterval(recordTimerRef.current);
      if (videoTimerRef.current) clearInterval(videoTimerRef.current);
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      if (videoRecorderRef.current && videoRecorderRef.current.state !== 'inactive') {
        videoRecorderRef.current.stop();
      }
      if (videoStreamRef.current) {
        videoStreamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!user) {
    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-primary">
        <div className="text-center space-y-4">
          <MessageCircle className="w-12 h-12 text-muted mx-auto" />
          <p className="text-secondary">تکایە پێشتر بچۆ ژوورەوە بۆ بەکارهێنانی چات</p>
          <button onClick={onClose} className="px-4 py-2 rounded-lg bg-accent text-white text-sm">داخستن</button>
        </div>
      </div>
    );
  }

  const formatDuration = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-[60] bg-primary flex flex-col animate-fade-in">
      {/* Voice Call Overlay */}
      {voiceCall.callState !== 'idle' && activeConv && (
        <CallOverlay
          callState={voiceCall.callState}
          username={activeConv.otherUser?.username || 'بەکارهێنەر'}
          avatarUrl={activeConv.otherUser?.avatar_url || null}
          micEnabled={voiceCall.micEnabled}
          speakerEnabled={voiceCall.speakerEnabled}
          callDuration={voiceCall.callDuration}
          onAccept={voiceCall.acceptCall}
          onDecline={voiceCall.declineCall}
          onEnd={voiceCall.endCall}
          onToggleMic={voiceCall.toggleMic}
          onToggleSpeaker={voiceCall.toggleSpeaker}
        />
      )}

      {/* Header */}
      <div className="glass border-b border-default px-3 sm:px-4 py-2.5 sm:py-3 flex items-center justify-between flex-shrink-0" style={{ paddingTop: 'calc(0.625rem + var(--safe-top, env(safe-area-inset-top)))' }}>
        <h2 className="text-base sm:text-lg font-bold text-primary flex items-center gap-2">
          <MessageCircle className="w-5 h-5 text-accent" /> چات
        </h2>
        <button onClick={onClose} className="p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {!activeConv ? (
          <div className="w-full max-w-md mx-auto flex flex-col">
            {/* Search bar */}
            <div className="p-3 sm:p-4 border-b border-default">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="گەڕان بۆ بەکارهێنەر..."
                  className="w-full pr-10 pl-3 sm:pl-4 py-2 sm:py-2.5 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent"
                />
              </div>
            </div>

            {/* Search results */}
            {searchResults.length > 0 && (
              <div className="border-b border-default">
                <p className="px-3 sm:px-4 py-2 text-xs text-muted">ئەنجامی گەڕان</p>
                {searchResults.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => startConversation(p)}
                    className="w-full flex items-center gap-2.5 sm:gap-3 px-3 sm:px-4 py-2.5 sm:py-3 hover:bg-hover transition-colors text-right"
                  >
                    <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                      {p.avatar_url ? (
                        <img src={p.avatar_url} alt="" className="w-9 h-9 sm:w-10 sm:h-10 rounded-full object-cover" />
                      ) : (
                        <span className="text-accent font-bold text-sm">{(p.username || '?')[0]}</span>
                      )}
                    </div>
                    <span className="text-sm text-primary font-medium truncate">{p.username || 'بەکارهێنەر'}</span>
                  </button>
                ))}
              </div>
            )}

            {/* Conversation list */}
            <div className="flex-1 overflow-y-auto">
              <p className="px-3 sm:px-4 py-2 text-xs text-muted">گفتوگۆکان</p>
              {loading ? (
                <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-accent animate-spin" /></div>
              ) : conversations.length === 0 && !searchQuery ? (
                <div className="text-center py-8 text-secondary text-sm">
                  <p>هیچ گفتوگۆیەک نییە</p>
                  <p className="text-xs text-muted mt-1">گەڕان بکە بۆ دەستپێکردنی گفتوگۆی نوێ</p>
                </div>
              ) : (
                conversations.map((conv) => (
                  <button
                    key={conv.id}
                    onClick={() => setActiveConv(conv)}
                    className="w-full flex items-center gap-2.5 sm:gap-3 px-3 sm:px-4 py-2.5 sm:py-3 hover:bg-hover transition-colors text-right border-b border-default/50"
                  >
                    <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 relative">
                      {conv.otherUser?.avatar_url ? (
                        <img src={conv.otherUser.avatar_url} alt="" className="w-9 h-9 sm:w-10 sm:h-10 rounded-full object-cover" />
                      ) : (
                        <span className="text-accent font-bold text-sm">{(conv.otherUser?.username || '?')[0]}</span>
                      )}
                      {conv.unreadCount && conv.unreadCount > 0 ? (
                        <span className="absolute -top-1 -right-1 w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-accent text-white text-[10px] sm:text-xs flex items-center justify-center font-bold">
                          {conv.unreadCount}
                        </span>
                      ) : null}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-primary font-medium truncate">{conv.otherUser?.username || 'بەکارهێنەر'}</p>
                      <p className="text-xs text-muted truncate">{conv.lastMessage || '...'}</p>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        ) : (
          <>
            <div className="w-full flex flex-col">
              {/* Chat header */}
              <div className="glass border-b border-default px-3 sm:px-4 py-2.5 sm:py-3 flex items-center gap-2 sm:gap-3 flex-shrink-0" style={{ paddingTop: 'calc(0.625rem + var(--safe-top, env(safe-area-inset-top)))' }}>
                <button onClick={() => setActiveConv(null)} className="p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                  {activeConv.otherUser?.avatar_url ? (
                    <img src={activeConv.otherUser.avatar_url} alt="" className="w-8 h-8 sm:w-9 sm:h-9 rounded-full object-cover" />
                  ) : (
                    <span className="text-accent font-bold text-sm">{(activeConv.otherUser?.username || '?')[0]}</span>
                  )}
                </div>
                <span className="text-sm text-primary font-medium truncate flex-1">{activeConv.otherUser?.username || 'بەکارهێنەر'}</span>
                {/* Call button */}
                <button
                  onClick={async () => {
                    await voiceCall.startCall();
                    if (activeConv.otherUser && user) {
                      await supabase.from('notifications').insert({
                        user_id: activeConv.otherUser.id,
                        type: 'voice_call',
                        title: `${myProfile?.username || 'بەکارهێنەر'} پەیوەندی دەنگیت لێکرد`,
                        body: null,
                        link_id: activeConv.id,
                        is_read: false,
                      });
                    }
                  }}
                  disabled={voiceCall.callState !== 'idle'}
                  className="p-2 rounded-full text-green-500 hover:bg-green-500/10 transition-colors disabled:opacity-50 flex-shrink-0"
                  title="پەیوەندی دەنگی"
                >
                  <Phone className="w-5 h-5" />
                </button>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto px-3 sm:px-4 py-3 space-y-2 sm:space-y-3 max-w-3xl mx-auto w-full">
                {messages.map((msg) => {
                  const isMine = msg.sender_id === user.id;
                  const isVoice = msg.message_type === 'voice' && msg.audio_url && !msg.deleted_at;
                  const isImage = msg.message_type === 'image' && msg.image_url && !msg.deleted_at;
                  const isVideo = msg.message_type === 'video' && msg.video_url && !msg.deleted_at;
                  const isDeleted = !!msg.deleted_at;
                  const msgReactions = msg.reactions || {};
                  const senderProfile = isMine ? myProfile : activeConv.otherUser;
                  const senderName = isMine ? (myProfile?.username || 'من') : (activeConv.otherUser?.username || 'بەکارهێنەر');

                  return (
                    <div key={msg.id} className={`flex items-end gap-2 ${isMine ? 'justify-start' : 'justify-end'} group`}>
                      {/* Avatar for other user's messages */}
                      {!isMine && <Avatar profile={senderProfile} size={28} />}

                      <div className="relative max-w-[75%] sm:max-w-[68%]">
                        {/* Sender name for other user's messages */}
                        {!isMine && !isDeleted && (
                          <p className="text-[10px] text-muted mb-0.5 px-1 truncate">{senderName}</p>
                        )}
                        {/* Action menu trigger */}
                        {!isDeleted && (
                          <button
                            onClick={() => setActionMenuMsgId(actionMenuMsgId === msg.id ? null : msg.id)}
                            className={`absolute top-1 ${isMine ? 'right-1' : 'left-1'} opacity-0 group-hover:opacity-100 sm:opacity-0 sm:group-hover:opacity-100 p-1 rounded-full bg-black/40 text-white transition-opacity z-10`}
                          >
                            <MoreVertical className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* Action menu dropdown */}
                        {actionMenuMsgId === msg.id && !isDeleted && (
                          <div className={`absolute top-8 ${isMine ? 'left-0' : 'right-0'} z-20 bg-card border border-default rounded-lg shadow-xl py-1 min-w-[140px]`}>
                            <button
                              onClick={() => { setShowReactionsFor(msg.id); setActionMenuMsgId(null); }}
                              className="w-full flex items-center gap-2 px-3 py-2 text-xs text-primary hover:bg-hover text-left"
                            >
                              <Smile className="w-3.5 h-3.5" /> ڕیئەکشن
                            </button>
                            {isMine && msg.message_type === 'text' && (
                              <button
                                onClick={() => { setEditingMsgId(msg.id); setEditingText(msg.text || ''); setActionMenuMsgId(null); }}
                                className="w-full flex items-center gap-2 px-3 py-2 text-xs text-primary hover:bg-hover text-left"
                              >
                                <Edit2 className="w-3.5 h-3.5" /> دەستکاری
                              </button>
                            )}
                            {isMine && (
                              <button
                                onClick={() => handleDeleteMessage(msg.id)}
                                className="w-full flex items-center gap-2 px-3 py-2 text-xs text-red-400 hover:bg-hover text-left"
                              >
                                <Trash2 className="w-3.5 h-3.5" /> سڕینەوە
                              </button>
                            )}
                          </div>
                        )}

                        {/* Reaction picker */}
                        {showReactionsFor === msg.id && (
                          <div className={`absolute -top-10 ${isMine ? 'left-0' : 'right-0'} z-20 bg-card border border-default rounded-full shadow-xl px-2 py-1.5 flex items-center gap-1`}>
                            {REACTIONS.map((emoji) => (
                              <button
                                key={emoji}
                                onClick={() => handleReact(msg.id, emoji)}
                                className="text-lg hover:scale-125 transition-transform"
                              >
                                {emoji}
                              </button>
                            ))}
                          </div>
                        )}

                        {/* Message bubble */}
                        <div
                          className={`rounded-2xl px-3 sm:px-4 py-2 sm:py-2.5 text-sm ${
                            isMine
                              ? 'bg-accent text-white rounded-bl-md'
                              : 'bg-card text-primary border border-default rounded-br-md'
                          } ${isDeleted ? 'opacity-50 italic' : ''}`}
                          dir="auto"
                          onDoubleClick={() => !isDeleted && setShowReactionsFor(msg.id)}
                        >
                          {isDeleted ? (
                            <p className="text-xs">🗑️ ئەم پەیامە سڕایەوە</p>
                          ) : editingMsgId === msg.id ? (
                            <div className="flex flex-col gap-2">
                              <input
                                type="text"
                                value={editingText}
                                onChange={(e) => setEditingText(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') handleEditMessage(msg.id);
                                  if (e.key === 'Escape') { setEditingMsgId(null); setEditingText(''); }
                                }}
                                autoFocus
                                className="px-2 py-1 rounded text-sm bg-white/20 text-white outline-none border border-white/30"
                                dir="auto"
                              />
                              <div className="flex gap-1.5">
                                <button onClick={() => handleEditMessage(msg.id)} className="p-1 rounded bg-white/20 hover:bg-white/30">
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                                <button onClick={() => { setEditingMsgId(null); setEditingText(''); }} className="p-1 rounded bg-white/20 hover:bg-white/30">
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ) : isVoice ? (
                            <VoiceMessagePlayer audioUrl={msg.audio_url!} isMine={isMine} />
                          ) : isImage ? (
                            <ImageMessage imageUrl={msg.image_url!} isMine={isMine} />
                          ) : isVideo ? (
                            <VideoMessage videoUrl={msg.video_url!} isMine={isMine} />
                          ) : (
                            <p className="leading-relaxed break-words whitespace-pre-wrap">{msg.text}</p>
                          )}

                          {!isDeleted && (
                            <p className={`text-[10px] mt-1 flex items-center gap-1 ${isMine ? 'text-white/60' : 'text-muted'}`}>
                              {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              {msg.edited_at && <span className="italic">· دەستکاریکراو</span>}
                            </p>
                          )}
                        </div>

                        {/* Reactions display */}
                        {Object.keys(msgReactions).length > 0 && (
                          <div className={`flex flex-wrap gap-0.5 mt-0.5 ${isMine ? 'justify-start' : 'justify-end'}`}>
                            {Object.entries(
                              Object.values(msgReactions).reduce((acc, emoji) => {
                                acc[emoji] = (acc[emoji] || 0) + 1;
                                return acc;
                              }, {} as Record<string, number>)
                            ).map(([emoji, count]) => (
                              <span
                                key={emoji}
                                className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-card border border-default text-xs"
                              >
                                {emoji} {count > 1 && <span className="text-[9px] text-muted">{count}</span>}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Video recording overlay */}
              {isRecordingVideo && (
                <div className="absolute inset-0 z-30 bg-black/90 flex flex-col items-center justify-center gap-4">
                  <div className="w-40 h-40 rounded-full border-4 border-red-500 flex items-center justify-center">
                    <span className="text-red-400 text-2xl font-bold">{formatDuration(videoRecordSeconds)}</span>
                  </div>
                  <p className="text-white/70 text-sm">تۆمارکردنی ڤیدیۆ... ({MAX_VIDEO_DURATION} چرکە)</p>
                  <div className="flex gap-3">
                    <button onClick={cancelVideoRecording} className="px-4 py-2.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30 text-sm flex items-center gap-1.5">
                      <X className="w-4 h-4" /> هەڵوەشاندن
                    </button>
                    <button onClick={stopVideoRecording} className="px-4 py-2.5 rounded-full bg-accent text-white text-sm font-medium flex items-center gap-1.5">
                      <Send className="w-4 h-4" /> ناردن
                    </button>
                  </div>
                </div>
              )}

              {/* Moderation warning banner */}
              {moderationWarning && (
                <div className="px-3 sm:px-4 py-2 max-w-3xl mx-auto w-full flex-shrink-0">
                  <div className={`rounded-lg px-3 py-2 text-xs sm:text-sm flex items-start gap-2 ${isBanned ? 'bg-red-500/15 border border-red-500/30 text-red-400' : 'bg-amber-500/15 border border-amber-500/30 text-amber-400'}`} dir="auto">
                    <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
                    <span>{moderationWarning}</span>
                    <button onClick={() => setModerationWarning(null)} className="mr-auto shrink-0 p-0.5">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Banned overlay — blocks input */}
              {isBanned && !moderationWarning && (
                <div className="px-3 sm:px-4 py-2 max-w-3xl mx-auto w-full flex-shrink-0">
                  <div className="rounded-lg px-3 py-2 text-xs sm:text-sm bg-red-500/15 border border-red-500/30 text-red-400 text-center" dir="auto">
                    هەژمارەکەت قەدەغە کراوە. ناتوانیت پەیام بنێریت.
                  </div>
                </div>
              )}

              {/* Input */}
              <div className="border-t border-default p-2 sm:p-3 max-w-3xl mx-auto w-full flex-shrink-0">
                {isRecording ? (
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-2 flex-1 px-3 py-2 rounded-full bg-red-500/10 border border-red-500/30">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
                      <span className="text-sm text-red-400 font-medium">{formatDuration(recordSeconds)}</span>
                    </div>
                    <button onClick={cancelRecording} className="p-2 sm:p-2.5 rounded-full bg-secondary text-secondary hover:text-red-400 transition-colors flex-shrink-0" title="هەڵوەشاندنەوە">
                      <X className="w-5 h-5" />
                    </button>
                    <button onClick={stopRecording} className="p-2 sm:p-2.5 rounded-full bg-accent text-white hover:bg-[var(--accent-hover)] transition-colors flex-shrink-0" title="ناردن">
                      <Send className="w-5 h-5" />
                    </button>
                  </div>
                ) : uploadingMedia ? (
                  <div className="flex items-center justify-center py-2.5">
                    <Loader2 className="w-5 h-5 text-accent animate-spin" />
                    <span className="text-sm text-secondary ml-2">بەرزکردنەوەی میدیا...</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    {/* Image picker */}
                    <input
                      ref={fileImageRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => { if (e.target.files?.[0]) handleImageSelect(e.target.files[0]); e.target.value = ''; }}
                    />
                    <button
                      onClick={() => fileImageRef.current?.click()}
                      className="p-2 sm:p-2.5 rounded-full bg-secondary text-accent hover:bg-hover transition-colors flex-shrink-0"
                      title="وێنە"
                    >
                      <ImageIcon className="w-5 h-5" />
                    </button>

                    {/* Video picker */}
                    <input
                      ref={fileVideoRef}
                      type="file"
                      accept="video/*"
                      className="hidden"
                      onChange={(e) => { if (e.target.files?.[0]) handleVideoSelect(e.target.files[0]); e.target.value = ''; }}
                    />
                    <button
                      onClick={() => fileVideoRef.current?.click()}
                      className="p-2 sm:p-2.5 rounded-full bg-secondary text-accent hover:bg-hover transition-colors flex-shrink-0"
                      title="ڤیدیۆ"
                    >
                      <Video className="w-5 h-5" />
                    </button>

                    {/* Video record button */}
                    <button
                      onClick={startVideoRecording}
                      className="p-2 sm:p-2.5 rounded-full bg-secondary text-red-400 hover:bg-hover transition-colors flex-shrink-0"
                      title="تۆمارکردنی ڤیدیۆ"
                    >
                      <Video className="w-5 h-5" />
                    </button>

                    {/* Text input */}
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                      placeholder="نووسینی پەیام..."
                      className="flex-1 min-w-0 px-3 sm:px-4 py-2 sm:py-2.5 rounded-full bg-secondary border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent"
                      dir="auto"
                    />

                    {/* Voice record button */}
                    <button
                      onClick={startRecording}
                      disabled={uploadingVoice}
                      className="p-2 sm:p-2.5 rounded-full bg-secondary text-accent disabled:opacity-50 hover:bg-hover transition-colors flex-shrink-0"
                      title="پەیامی دەنگی"
                    >
                      {uploadingVoice ? <Loader2 className="w-5 h-5 animate-spin" /> : <Mic className="w-5 h-5" />}
                    </button>

                    {/* Send button */}
                    <button
                      onClick={sendMessage}
                      disabled={!newMessage.trim() || sending}
                      className="p-2 sm:p-2.5 rounded-full bg-accent text-white disabled:opacity-50 hover:bg-[var(--accent-hover)] transition-colors flex-shrink-0"
                    >
                      {sending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>

      {/* Hidden file inputs for mobile */}
      <input
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => { if (e.target.files?.[0]) handleImageSelect(e.target.files[0]); }}
        id="mobile-image-capture"
      />
    </div>
  );
}

// ============================================================
// Voice Call Overlay
// ============================================================

function CallOverlay({
  callState, username, avatarUrl, micEnabled, speakerEnabled, callDuration,
  onAccept, onDecline, onEnd, onToggleMic, onToggleSpeaker,
}: {
  callState: CallState;
  username: string;
  avatarUrl: string | null;
  micEnabled: boolean;
  speakerEnabled: boolean;
  callDuration: number;
  onAccept: () => void;
  onDecline: () => void;
  onEnd: () => void;
  onToggleMic: () => void;
  onToggleSpeaker: () => void;
}) {
  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-[80] bg-gradient-to-b from-gray-900 to-black flex flex-col items-center justify-between py-16 px-4 animate-fade-in">
      {/* Top: status */}
      <div className="text-center">
        <p className="text-white/50 text-sm">
          {callState === 'calling' && 'پەیوەندی کردن...'
            || callState === 'incoming' && 'پەیوەندی هاتوو...'
            || callState === 'connected' && formatTime(callDuration)
            || callState === 'ended' && 'پەیوەندی کۆتایی هات'}
        </p>
      </div>

      {/* Middle: avatar + name */}
      <div className="flex flex-col items-center gap-4">
        <div className={`w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-accent/20 flex items-center justify-center ${callState === 'calling' || callState === 'incoming' ? 'animate-pulse' : ''}`}>
          {avatarUrl ? (
            <img src={avatarUrl} alt="" className="w-28 h-28 sm:w-32 sm:h-32 rounded-full object-cover" />
          ) : (
            <span className="text-accent font-bold text-4xl">{(username || '?')[0]}</span>
          )}
        </div>
        <p className="text-white text-xl font-bold">{username}</p>
        {callState === 'connected' && (
          <div className="flex items-center gap-1.5 text-white/40 text-sm">
            <span className={`w-2 h-2 rounded-full ${micEnabled ? 'bg-green-400' : 'bg-red-400'}`} />
            {micEnabled ? 'مایکرۆفۆن کارا' : 'مایکرۆفۆن داخراوە'}
          </div>
        )}
      </div>

      {/* Bottom: call controls */}
      <div className="flex items-center gap-4 sm:gap-6">
        {callState === 'incoming' ? (
          <>
            <button
              onClick={onDecline}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center transition-colors"
            >
              <PhoneOff className="w-6 h-6 text-white" />
            </button>
            <button
              onClick={onAccept}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-green-500 hover:bg-green-600 flex items-center justify-center transition-colors animate-bounce"
            >
              <Phone className="w-6 h-6 text-white" />
            </button>
          </>
        ) : callState === 'connected' ? (
          <>
            <button
              onClick={onToggleMic}
              className={`w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center transition-colors ${
                micEnabled ? 'bg-white/10 hover:bg-white/20' : 'bg-red-500 hover:bg-red-600'
              }`}
            >
              {micEnabled ? <Mic className="w-6 h-6 text-white" /> : <MicOff className="w-6 h-6 text-white" />}
            </button>
            <button
              onClick={onToggleSpeaker}
              className={`w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center transition-colors ${
                speakerEnabled ? 'bg-white/10 hover:bg-white/20' : 'bg-white/5 hover:bg-white/10'
              }`}
            >
              <Volume2 className="w-6 h-6 text-white" />
            </button>
            <button
              onClick={onEnd}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center transition-colors"
            >
              <PhoneOff className="w-6 h-6 text-white" />
            </button>
          </>
        ) : callState === 'calling' ? (
          <button
            onClick={onEnd}
            className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center transition-colors"
          >
            <PhoneOff className="w-6 h-6 text-white" />
          </button>
        ) : callState === 'ended' ? (
          <div className="text-white/50 text-sm">داخستن...</div>
        ) : null}
      </div>
    </div>
  );
}

// ============================================================
// Image Message
// ============================================================

function ImageMessage({ imageUrl, isMine }: { imageUrl: string; isMine: boolean }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <>
      <button onClick={() => setExpanded(true)} className="block">
        <img
          src={imageUrl}
          alt="image"
          className="max-w-full max-h-60 rounded-lg cursor-pointer"
          loading="lazy"
        />
      </button>
      {expanded && (
        <div
          className="fixed inset-0 z-[90] bg-black/90 flex items-center justify-center p-4"
          onClick={() => setExpanded(false)}
        >
          <img src={imageUrl} alt="image" className="max-w-full max-h-full rounded-lg" />
          <a
            href={imageUrl}
            download
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="absolute bottom-4 right-4 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white"
          >
            <Download className="w-5 h-5" />
          </a>
        </div>
      )}
    </>
  );
}

// ============================================================
// Video Message
// ============================================================

function VideoMessage({ videoUrl, isMine }: { videoUrl: string; isMine: boolean }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (playing) {
      videoRef.current.pause();
    } else {
      videoRef.current.play().catch(() => {});
    }
  };

  return (
    <div className="relative rounded-lg overflow-hidden" style={{ maxWidth: '260px' }}>
      <video
        ref={videoRef}
        src={videoUrl}
        className="w-full max-h-60 rounded-lg"
        playsInline
        controls
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => setPlaying(false)}
      />
    </div>
  );
}

// ============================================================
// Voice message player
// ============================================================

function VoiceMessagePlayer({ audioUrl, isMine }: { audioUrl: string; isMine: boolean }) {
  const [playing, setPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const togglePlay = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio(audioUrl);
      audioRef.current.onloadedmetadata = () => setDuration(audioRef.current?.duration || 0);
      audioRef.current.ontimeupdate = () => setCurrentTime(audioRef.current?.currentTime || 0);
      audioRef.current.onended = () => { setPlaying(false); setCurrentTime(0); };
    }
    if (playing) {
      audioRef.current.pause();
      setPlaying(false);
    } else {
      audioRef.current.play().then(() => setPlaying(true)).catch(() => {});
    }
  };

  const formatTime = (s: number) => {
    if (!s || isNaN(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const pct = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="flex items-center gap-2 min-w-[140px]">
      <button onClick={togglePlay} className={`p-1.5 rounded-full flex-shrink-0 ${isMine ? 'bg-white/20' : 'bg-accent/20'}`}>
        {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" fill="currentColor" />}
      </button>
      <div className="flex-1">
        <div className={`h-1.5 rounded-full overflow-hidden ${isMine ? 'bg-white/20' : 'bg-muted/30'}`}>
          <div className={`h-full rounded-full transition-all ${isMine ? 'bg-white' : 'bg-accent'}`} style={{ width: `${pct}%` }} />
        </div>
        <span className={`text-[10px] mt-0.5 block ${isMine ? 'text-white/70' : 'text-muted'}`}>
          {formatTime(playing || currentTime > 0 ? currentTime : duration)}
        </span>
      </div>
    </div>
  );
}
