import { useState, useRef, useEffect, useCallback } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { ComicPanel } from '@/lib/supabase';

interface BookAnimationViewProps {
  panels: ComicPanel[];
  onClose: () => void;
}

export default function BookAnimationView({ panels, onClose }: BookAnimationViewProps) {
  const [currentSpread, setCurrentSpread] = useState(0);
  const [flipping, setFlipping] = useState<'next' | 'prev' | null>(null);
  const [dragX, setDragX] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // A spread shows 2 panels (left + right) on wide screens, 1 on narrow
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  const panelsPerSpread = isMobile ? 1 : 2;
  const totalSpreads = Math.ceil(panels.length / panelsPerSpread);

  const getSpreadPanels = (spreadIdx: number): ComicPanel[] => {
    const start = spreadIdx * panelsPerSpread;
    return panels.slice(start, start + panelsPerSpread);
  };

  const goNext = useCallback(() => {
    if (currentSpread >= totalSpreads - 1 || flipping) return;
    setFlipping('next');
    setTimeout(() => {
      setCurrentSpread((s) => Math.min(s + 1, totalSpreads - 1));
      setFlipping(null);
    }, 500);
  }, [currentSpread, totalSpreads, flipping]);

  const goPrev = useCallback(() => {
    if (currentSpread <= 0 || flipping) return;
    setFlipping('prev');
    setTimeout(() => {
      setCurrentSpread((s) => Math.max(s - 1, 0));
      setFlipping(null);
    }, 500);
  }, [currentSpread, flipping]);

  // Touch/drag handling
  const handleDragStart = (clientX: number) => {
    if (flipping) return;
    dragStartRef.current = clientX;
    setIsDragging(true);
  };

  const handleDragMove = (clientX: number) => {
    if (!isDragging || dragStartRef.current === null) return;
    const delta = clientX - dragStartRef.current;
    setDragX(delta);
  };

  const handleDragEnd = () => {
    if (!isDragging || dragStartRef.current === null) return;
    const delta = dragX;
    setIsDragging(false);
    setDragX(0);
    dragStartRef.current = null;

    // In RTL, dragging left (negative) = next page, dragging right (positive) = prev page
    // But for book turning left, we want: swipe left = next, swipe right = prev
    const threshold = 80;
    if (delta < -threshold) {
      goNext();
    } else if (delta > threshold) {
      goPrev();
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') goNext();
      else if (e.key === 'ArrowRight') goPrev();
      else if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [goNext, goPrev, onClose]);

  const currentPanels = getSpreadPanels(currentSpread);
  const nextPanels = getSpreadPanels(currentSpread + 1);
  const prevPanels = getSpreadPanels(currentSpread - 1);

  const flipTransform = flipping === 'next'
    ? 'perspective(2000px) rotateY(-180deg)'
    : flipping === 'prev'
    ? 'perspective(2000px) rotateY(180deg)'
    : isDragging
    ? `perspective(2000px) rotateY(${dragX * 0.15}deg)`
    : 'perspective(2000px) rotateY(0deg)';

  return (
    <div className="absolute inset-0 z-40 bg-black/95 flex flex-col animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
        <span className="text-white text-sm font-medium">
          {currentSpread + 1} / {totalSpreads}
        </span>
        <button onClick={onClose} className="p-2 rounded-lg text-white hover:text-accent transition-colors text-sm">
          ✕
        </button>
      </div>

      {/* Book area */}
      <div
        ref={containerRef}
        className="flex-1 flex items-center justify-center overflow-hidden select-none"
        style={{ touchAction: 'pan-y' }}
        onMouseDown={(e) => handleDragStart(e.clientX)}
        onMouseMove={(e) => isDragging && handleDragMove(e.clientX)}
        onMouseUp={handleDragEnd}
        onMouseLeave={handleDragEnd}
        onTouchStart={(e) => handleDragStart(e.touches[0].clientX)}
        onTouchMove={(e) => isDragging && handleDragMove(e.touches[0].clientX)}
        onTouchEnd={handleDragEnd}
      >
        <div className="relative w-full max-w-4xl h-full flex items-center justify-center px-4">
          {/* Book spread */}
          <div
            className="relative flex gap-0 shadow-2xl transition-transform duration-500"
            style={{
              transform: flipTransform,
              transformOrigin: 'center',
              transitionDuration: isDragging ? '0ms' : '500ms',
            }}
          >
            {currentPanels.map((panel, i) => (
              <div
                key={panel.id}
                className="relative bg-black overflow-hidden"
                style={{
                  width: isMobile ? '85vw' : '42vw',
                  maxWidth: isMobile ? '360px' : '480px',
                  aspectRatio: panel.aspect_ratio || 'auto',
                  borderRight: i === 0 && !isMobile ? '1px solid rgba(255,255,255,0.08)' : 'none',
                  borderRadius: isMobile ? '8px' : i === 0 ? '8px 0 0 8px' : '0 8px 8px 0',
                }}
              >
                {panel.video_url ? (
                  <video src={panel.video_url} controls playsInline className="w-full h-full object-contain" />
                ) : (
                  <img src={panel.image_url} alt={`Page ${currentSpread * panelsPerSpread + i + 1}`} className="w-full h-full object-contain" draggable={false} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Navigation arrows */}
        {currentSpread > 0 && (
          <button
            onClick={(e) => { e.stopPropagation(); goPrev(); }}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full glass text-white hover:text-accent transition-colors z-10"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}
        {currentSpread < totalSpreads - 1 && (
          <button
            onClick={(e) => { e.stopPropagation(); goNext(); }}
            className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full glass text-white hover:text-accent transition-colors z-10"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Page indicator dots */}
      <div className="flex items-center justify-center gap-1.5 py-3 border-t border-white/10">
        {Array.from({ length: totalSpreads }).map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentSpread(i)}
            className={`h-2 rounded-full transition-all ${i === currentSpread ? 'w-6 bg-accent' : 'w-2 bg-white/20 hover:bg-white/40'}`}
          />
        ))}
      </div>
    </div>
  );
}
