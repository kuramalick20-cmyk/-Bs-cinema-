import { useState, useMemo } from 'react';
import {
  type GameState, type Move, type PieceColor,
  getLegalMovesForSquare, isInCheck, findKing, squareToCoords, coordsToSquare,
} from '@/lib/chessEngine';

interface ChessBoardProps {
  state: GameState;
  playerColor: PieceColor; // 'w' or 'b' — which side the viewer plays
  onMove: (move: Move) => void;
  disabled?: boolean;
  lastMove?: { from: string; to: string } | null;
}

const PIECE_UNICODE: Record<string, string> = {
  'wK': '♔', 'wQ': '♕', 'wR': '♖', 'wB': '♗', 'wN': '♘', 'wP': '♙',
  'bK': '♚', 'bQ': '♛', 'bR': '♜', 'bB': '♝', 'bN': '♞', 'bP': '♟',
};

export default function ChessBoard({ state, playerColor, onMove, disabled, lastMove }: ChessBoardProps) {
  const [selectedSquare, setSelectedSquare] = useState<string | null>(null);
  const [legalMoves, setLegalMoves] = useState<Move[]>([]);
  const [promotionMove, setPromotionMove] = useState<Move | null>(null);

  const isMyTurn = state.turn === playerColor && !disabled;

  // Render board from the player's perspective
  const displayRows = playerColor === 'w' ? [0, 1, 2, 3, 4, 5, 6, 7] : [7, 6, 5, 4, 3, 2, 1, 0];
  const displayCols = playerColor === 'w' ? [0, 1, 2, 3, 4, 5, 6, 7] : [7, 6, 5, 4, 3, 2, 1, 0];

  const kingPos = useMemo(() => findKing(state, state.turn), [state]);
  const inCheck = useMemo(() => isInCheck(state, state.turn), [state]);

  const handleSquareClick = (square: string) => {
    if (!isMyTurn) return;
    const [row, col] = squareToCoords(square);
    const piece = state.board[row][col];

    if (selectedSquare) {
      // Try to make a move
      const moves = legalMoves.filter((m) => m.to === square);
      if (moves.length > 0) {
        if (moves.length > 1 && moves[0].promotion) {
          // Promotion — show dialog
          setPromotionMove(moves[0]);
          setSelectedSquare(null);
          setLegalMoves([]);
          return;
        }
        onMove(moves[0]);
        setSelectedSquare(null);
        setLegalMoves([]);
        return;
      }
      // Select a different piece
      if (piece && piece.color === state.turn) {
        setSelectedSquare(square);
        setLegalMoves(getLegalMovesForSquare(state, square));
      } else {
        setSelectedSquare(null);
        setLegalMoves([]);
      }
    } else {
      // Select a piece
      if (piece && piece.color === state.turn) {
        setSelectedSquare(square);
        setLegalMoves(getLegalMovesForSquare(state, square));
      }
    }
  };

  const handlePromotion = (type: 'q' | 'r' | 'b' | 'n') => {
    if (promotionMove) {
      onMove({ ...promotionMove, promotion: type });
      setPromotionMove(null);
    }
  };

  const legalTargets = new Set(legalMoves.map((m) => m.to));

  return (
    <div className="relative w-full max-w-[min(92vw,560px)] mx-auto">
      <div className="grid grid-cols-8 rounded-xl overflow-hidden shadow-card border border-bright" style={{ aspectRatio: '1' }}>
        {displayRows.map((row) =>
          displayCols.map((col) => {
            const square = coordsToSquare(row, col);
            const piece = state.board[row][col];
            const isLight = (row + col) % 2 === 0;
            const isSelected = selectedSquare === square;
            const isLegal = legalTargets.has(square);
            const isCapture = isLegal && (piece || legalMoves.find((m) => m.to === square && m.isEnPassant));
            const isLastMove = lastMove && (lastMove.from === square || lastMove.to === square);
            const isKingInCheck = inCheck && kingPos && kingPos[0] === row && kingPos[1] === col;

            const pieceKey = piece ? `${piece.color}${piece.type.toUpperCase()}` : '';
            const pieceSymbol = piece ? PIECE_UNICODE[pieceKey] : '';

            return (
              <button
                key={square}
                onClick={() => handleSquareClick(square)}
                className="relative flex items-center justify-center transition-colors"
                style={{
                  background: isKingInCheck
                    ? 'radial-gradient(circle, rgba(239,51,64,0.5) 0%, rgba(239,51,64,0.2) 70%, transparent 100%)'
                    : isLight ? '#3a3a4e' : '#1a1a26',
                }}
              >
                {/* Last move highlight */}
                {isLastMove && (
                  <div className="absolute inset-0 bg-accent/15" />
                )}
                {/* Selected highlight */}
                {isSelected && (
                  <div className="absolute inset-0 bg-accent/25" />
                )}
                {/* Legal move indicator */}
                {isLegal && !isCapture && (
                  <div className="absolute w-3 h-3 rounded-full bg-accent/40" />
                )}
                {isLegal && isCapture && (
                  <div className="absolute inset-1 rounded-full border-2 border-accent/50" />
                )}
                {/* Piece */}
                {piece && (
                  <span
                    className="relative text-[clamp(28px,8vw,52px)] leading-none select-none"
                    style={{
                      color: piece.color === 'w' ? '#f5f5f7' : '#1a1a26',
                      textShadow: piece.color === 'w' ? '0 1px 3px rgba(0,0,0,0.8)' : '0 1px 3px rgba(0,0,0,0.3)',
                      filter: piece.color === 'b' ? 'drop-shadow(0 0 1px rgba(255,255,255,0.4))' : 'none',
                    }}
                  >
                    {pieceSymbol}
                  </span>
                )}
              </button>
            );
          })
        )}
      </div>

      {/* Promotion dialog */}
      {promotionMove && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/80 rounded-xl animate-fade-in">
          <div className="bg-card border border-bright rounded-xl p-4 space-y-3">
            <p className="text-sm text-primary text-center font-medium">پرومۆت بکە بۆ:</p>
            <div className="flex gap-2">
              {(['q', 'r', 'b', 'n'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => handlePromotion(type)}
                  className="w-14 h-14 rounded-lg bg-hover hover:bg-accent/20 flex items-center justify-center text-3xl text-primary hover:text-accent transition-all"
                >
                  {PIECE_UNICODE[`${promotionMove.piece.color}${type.toUpperCase()}`]}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
