import { useState, useRef, useEffect, useCallback } from 'react';
import {
  X, Volume2, VolumeX, Maximize2, Minimize2,
  ArrowUp, ArrowDown, Trash2, RefreshCw, Plus, Loader2,
  Eye, EyeOff, ChevronUp, Play, Pause, Music as MusicIcon, Video as VideoIcon, Languages, MessageSquareText, Film
} from 'lucide-react';
import type { ComicPanel, ComicMusicTrack, ComicSpeechBubble, ComicCharacter, ComicChapterVideo } from '@/lib/supabase';
import { supabase } from '@/lib/supabase';
import { uploadFile } from '@/lib/storage';
import { useAdmin } from '@/context/AdminContext';
import ComicTranslationOverlay from './ComicTranslationOverlay';
import BubbleEditor from './BubbleEditor';
import ComicAnimationStudio from './ComicAnimationStudio';
import { fetchChapterBubbles } from '@/lib/comicVoice';
import { reOCRPanel } from '@/lib/comicOCR';

interface ComicReaderProps {
  panels: ComicPanel[];
  musicUrl: string | null;
  onClose: () => void;
  chapterId?: string | null;
  format?: string;
  contentId?: string;
}

export default function ComicReader({ panels, musicUrl, onClose, chapterId, format = 'default', contentId }: ComicReaderProps) {
  const { isAdmin } = useAdmin();
  const [musicPlaying, setMusicPlaying] = useState(false);
  const [localPanels, setLocalPanels] = useState<ComicPanel[]>(panels);
  const [uploading, setUploading] = useState(false);
  const [uiVisible, setUiVisible] = useState(true);
  const [autoScroll, setAutoScroll] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [atTop, setAtTop] = useState(true);
  const [atBottom, setAtBottom] = useState(false);
  const [musicTracks, setMusicTracks] = useState<ComicMusicTrack[]>([]);
  const [activeTrackIdx, setActiveTrackIdx] = useState(0);
  const [showTrackList, setShowTrackList] = useState(false);
  const [translatingPanel, setTranslatingPanel] = useState<number | null>(null);
  const [editingBubblePanel, setEditingBubblePanel] = useState<number | null>(null);
  const [translationError, setTranslationError] = useState<string | null>(null);

  const [chapterBubbles, setChapterBubbles] = useState<ComicSpeechBubble[]>([]);
  const [panelBubblesMap, setPanelBubblesMap] = useState<Record<string, ComicSpeechBubble[]>>({});

  // Chapter videos state
  const [chapterVideos, setChapterVideos] = useState<ComicChapterVideo[]>([]);
  const [showVideoSection, setShowVideoSection] = useState(false);
  const [activeVideo, setActiveVideo] = useState<ComicChapterVideo | null>(null);
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [videoForm, setVideoForm] = useState<{ title: string; type: 'upload' | 'link' | 'gdrive'; url: string }>({ title: '', type: 'upload', url: '' });
  const [showVideoForm, setShowVideoForm] = useState(false);

  // Animation studio state
  const [showAnimationStudio, setShowAnimationStudio] = useState(false);

  // OCR state — manual only, no auto-OCR
  const [ocrScanning, setOcrScanning] = useState(false);
  const [ocrPanelIdx, setOcrPanelIdx] = useState(-1);

  // Per-panel sound state
  const [playingPanelSoundId, setPlayingPanelSoundId] = useState<string | null>(null);
  const panelSoundRef = useRef<HTMLAudioElement | null>(null);

  const audioRef = useRef<HTMLAudioElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const autoScrollRef = useRef<number | null>(null);
  const uiTimeoutRef = useRef<number | null>(null);

  useEffect(() => { setLocalPanels(panels); }, [panels]);

  // Load multiple music tracks for this chapter
  useEffect(() => {
    if (!chapterId) return;
    supabase
      .from('comic_music_tracks')
      .select('*')
      .eq('chapter_id', chapterId)
      .order('track_order', { ascending: true })
      .then(({ data }) => {
        setMusicTracks((data as ComicMusicTrack[]) || []);
      });
  }, [chapterId]);

  // Load chapter videos
  const reloadChapterVideos = useCallback(async () => {
    if (!chapterId) return;
    const { data } = await supabase
      .from('comic_chapter_videos')
      .select('*')
      .eq('chapter_id', chapterId)
      .order('video_order', { ascending: true });
    setChapterVideos((data as ComicChapterVideo[]) || []);
  }, [chapterId]);

  useEffect(() => {
    reloadChapterVideos();
  }, [reloadChapterVideos]);

  // Load speech bubbles for this chapter
  const reloadBubbles = useCallback(() => {
    if (!chapterId) return;
    fetchChapterBubbles(chapterId).then((bubbles) => {
      setChapterBubbles(bubbles);
      const map: Record<string, ComicSpeechBubble[]> = {};
      for (const b of bubbles) {
        if (!map[b.panel_id]) map[b.panel_id] = [];
        map[b.panel_id].push(b);
      }
      setPanelBubblesMap(map);
    });
  }, [chapterId]);

  useEffect(() => {
    reloadBubbles();
  }, [reloadBubbles]);



  const togglePanelSound = (panel: ComicPanel, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!panel.sound_url) return;
    if (playingPanelSoundId === panel.id) {
      panelSoundRef.current?.pause();
      setPlayingPanelSoundId(null);
      return;
    }
    if (panelSoundRef.current) {
      panelSoundRef.current.pause();
    }
    const audio = new Audio(panel.sound_url);
    audio.onended = () => setPlayingPanelSoundId(null);
    panelSoundRef.current = audio;
    audio.play().then(() => setPlayingPanelSoundId(panel.id)).catch(() => {});
  };

  const handleReScanPanel = async (panel: ComicPanel, e: React.MouseEvent) => {
    e.stopPropagation();
    setOcrScanning(true);
    setOcrPanelIdx(localPanels.findIndex((p) => p.id === panel.id));
    await reOCRPanel(panel.image_url, panel.id);
    setOcrScanning(false);
    setOcrPanelIdx(-1);
    reloadBubbles();
  };

  useEffect(() => {
    return () => {
      panelSoundRef.current?.pause();
    };
  }, []);

  // === Admin: chapter video operations ===
  const handleAddChapterVideo = async () => {
    if (!chapterId || !videoForm.url.trim()) return;
    const currentMax = chapterVideos.length > 0 ? Math.max(...chapterVideos.map((v) => v.video_order)) : -1;
    await supabase.from('comic_chapter_videos').insert({
      chapter_id: chapterId,
      title: videoForm.title || null,
      video_type: videoForm.type,
      video_url: videoForm.url,
      video_order: currentMax + 1,
    });
    setVideoForm({ title: '', type: 'upload', url: '' });
    setShowVideoForm(false);
    await reloadChapterVideos();
  };

  const handleChapterVideoUpload = async (file: File) => {
    setUploadingVideo(true);
    const url = await uploadFile('videos', file);
    if (url) setVideoForm((prev) => ({ ...prev, url }));
    setUploadingVideo(false);
  };

  const handleDeleteChapterVideo = async (id: string) => {
    await supabase.from('comic_chapter_videos').delete().eq('id', id);
    if (activeVideo?.id === id) setActiveVideo(null);
    await reloadChapterVideos();
  };

  const moveChapterVideo = async (video: ComicChapterVideo, direction: 'up' | 'down') => {
    const sorted = [...chapterVideos];
    const idx = sorted.findIndex((v) => v.id === video.id);
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sorted.length) return;
    const swap = sorted[swapIdx];
    await supabase.from('comic_chapter_videos').update({ video_order: swap.video_order }).eq('id', video.id);
    await supabase.from('comic_chapter_videos').update({ video_order: video.video_order }).eq('id', swap.id);
    await reloadChapterVideos();
  };

  // Determine which music track should be playing based on scroll position
  const currentPanelIdx = Math.round((scrollProgress / 100) * (localPanels.length - 1));

  useEffect(() => {
    if (musicTracks.length === 0 || !musicPlaying) return;
    const matchingTrack = musicTracks.findIndex(
      (t) =>
        (t.start_panel == null || currentPanelIdx >= t.start_panel) &&
        (t.end_panel == null || currentPanelIdx <= t.end_panel)
    );
    if (matchingTrack >= 0 && matchingTrack !== activeTrackIdx) {
      setActiveTrackIdx(matchingTrack);
    }
  }, [currentPanelIdx, musicTracks, musicPlaying, activeTrackIdx]);

  const activeTrack = musicTracks[activeTrackIdx];
  const effectiveMusicUrl = activeTrack?.track_url || musicUrl;

  useEffect(() => {
    if (musicPlaying && audioRef.current && effectiveMusicUrl) {
      audioRef.current.play().catch(() => setMusicPlaying(false));
    } else if (audioRef.current) {
      audioRef.current.pause();
    }
  }, [musicPlaying, effectiveMusicUrl, activeTrackIdx]);

  useEffect(() => {
    if (audioRef.current && effectiveMusicUrl) {
      audioRef.current.src = effectiveMusicUrl;
      if (musicPlaying) {
        audioRef.current.play().catch(() => setMusicPlaying(false));
      }
    }
  }, [effectiveMusicUrl]);

  const scrollRafRef = useRef<number | null>(null);

  const handleScroll = useCallback(() => {
    if (scrollRafRef.current) return;
    scrollRafRef.current = requestAnimationFrame(() => {
      scrollRafRef.current = null;
      const el = scrollRef.current;
      if (!el) return;
      const scrollTop = el.scrollTop;
      const scrollHeight = el.scrollHeight - el.clientHeight;
      setScrollProgress(scrollHeight > 0 ? (scrollTop / scrollHeight) * 100 : 0);
      setAtTop(scrollTop < 10);
      setAtBottom(scrollTop >= scrollHeight - 10);
    });
  }, []);

  useEffect(() => {
    if (autoScroll) {
      autoScrollRef.current = window.setInterval(() => {
        const el = scrollRef.current;
        if (!el) return;
        const scrollHeight = el.scrollHeight - el.clientHeight;
        if (el.scrollTop >= scrollHeight - 5) {
          setAutoScroll(false);
          return;
        }
        el.scrollTo({ top: el.scrollTop + 1.5, behavior: 'auto' });
      }, 16);
    } else if (autoScrollRef.current) {
      window.clearInterval(autoScrollRef.current);
      autoScrollRef.current = null;
    }
    return () => {
      if (autoScrollRef.current) window.clearInterval(autoScrollRef.current);
    };
  }, [autoScroll]);

  const toggleFullscreen = () => {
    const el = scrollRef.current?.closest('[data-comic-fullscreen]');
    if (document.fullscreenElement) document.exitFullscreen();
    else el?.requestFullscreen?.();
  };

  const scrollToTop = () => {
    scrollRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTap = () => {
    setUiVisible((prev) => !prev);
  };

  const showUiTemporarily = useCallback(() => {
    setUiVisible(true);
    if (uiTimeoutRef.current) window.clearTimeout(uiTimeoutRef.current);
    uiTimeoutRef.current = window.setTimeout(() => {
      if (autoScroll) setUiVisible(false);
    }, 3000);
  }, [autoScroll]);

  // === Admin panel operations ===
  const reloadPanels = async () => {
    if (!chapterId) return;
    const { data: p } = await supabase.from('comic_panels').select('*').eq('chapter_id', chapterId).order('panel_order', { ascending: true });
    const panelsData = (p as ComicPanel[]) || [];
    setLocalPanels(panelsData);
    // Update cache so next openChapter is fresh
    // (panelsCache is in contentCache but we keep localPanels in sync directly)
  };

  const movePanel = async (panel: ComicPanel, direction: 'up' | 'down') => {
    const sorted = [...localPanels];
    const idx = sorted.findIndex((p) => p.id === panel.id);
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sorted.length) return;
    const swapPanel = sorted[swapIdx];
    await supabase.from('comic_panels').update({ panel_order: swapPanel.panel_order }).eq('id', panel.id);
    await supabase.from('comic_panels').update({ panel_order: panel.panel_order }).eq('id', swapPanel.id);
    await reloadPanels();
  };

  const deletePanel = async (panel: ComicPanel) => {
    await supabase.from('comic_panels').delete().eq('id', panel.id);
    await reloadPanels();
  };

  const replacePanel = async (panel: ComicPanel, file: File) => {
    const url = await uploadFile('panels', file);
    if (url) {
      await supabase.from('comic_panels').update({ image_url: url, video_url: null }).eq('id', panel.id);
      await reloadPanels();
    }
  };

  const replacePanelWithVideo = async (panel: ComicPanel, file: File) => {
    setUploading(true);
    const url = await uploadFile('panels', file);
    if (url) {
      await supabase.from('comic_panels').update({ video_url: url }).eq('id', panel.id);
      await reloadPanels();
    }
    setUploading(false);
  };

  const removePanelVideo = async (panel: ComicPanel) => {
    await supabase.from('comic_panels').update({ video_url: null }).eq('id', panel.id);
    await reloadPanels();
  };

  const addPanel = async (files: FileList) => {
    if (!chapterId) return;
    setUploading(true);
    const currentMax = localPanels.length > 0 ? Math.max(...localPanels.map((p) => p.panel_order)) : -1;
    for (const file of Array.from(files)) {
      const url = await uploadFile('panels', file);
      if (url) {
        await supabase.from('comic_panels').insert({ chapter_id: chapterId, image_url: url, panel_order: currentMax + 1 });
      }
    }
    setUploading(false);
    await reloadPanels();
  };

  if (localPanels.length === 0 && chapterVideos.length === 0) {
    return <div className="text-center py-12 text-secondary"><p>هیچ ناوەڕۆکێک بەردەست نییە</p></div>;
  }

  return (
    <div data-comic-fullscreen className="relative w-full bg-black rounded-xl overflow-hidden flex flex-col" style={{ height: '80vh' }}>
      {effectiveMusicUrl && <audio ref={audioRef} src={effectiveMusicUrl} loop preload="none" />}

      {/* Top progress bar */}
      <div className={`absolute top-0 left-0 right-0 z-30 transition-all duration-300 ${uiVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <div className="h-1 bg-white/10">
          <div className="h-full bg-accent transition-all duration-75" style={{ width: `${scrollProgress}%` }} />
        </div>
      </div>

      {/* Top bar */}
      <div className={`absolute top-1 left-0 right-0 z-20 flex flex-wrap items-center justify-between gap-y-1 px-2 sm:px-3 py-2 bg-gradient-to-b from-black/70 to-transparent transition-all duration-300 ${uiVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <div className="flex items-center gap-1 sm:gap-2 flex-wrap">
          {effectiveMusicUrl && (
            <>
              <button onClick={() => setMusicPlaying(!musicPlaying)} className="p-2 rounded-full glass text-white hover:text-accent transition-colors" title={musicPlaying ? 'وەستان' : 'لێدان'}>
                {musicPlaying ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>
              {musicTracks.length > 1 && (
                <button
                  onClick={() => setShowTrackList(!showTrackList)}
                  className="p-2 rounded-full glass text-white hover:text-accent transition-colors relative"
                  title="لیستی مۆسیقا"
                >
                  <MusicIcon className="w-4 h-4" />
                  {showTrackList && (
                    <div className="absolute top-full right-0 mt-2 bg-black/90 rounded-lg p-2 min-w-[150px] z-30">
                      {musicTracks.map((t, i) => (
                        <button
                          key={t.id}
                          onClick={(e) => { e.stopPropagation(); setActiveTrackIdx(i); setShowTrackList(false); }}
                          className={`block w-full text-right px-3 py-1.5 rounded text-xs transition-colors ${i === activeTrackIdx ? 'bg-accent text-white' : 'text-white hover:bg-white/10'}`}
                        >
                          {t.track_name || `تراک ${i + 1}`}
                        </button>
                      ))}
                    </div>
                  )}
                </button>
              )}
            </>
          )}
          {/* Translation button */}
          <button
            onClick={() => setTranslatingPanel(translatingPanel === null ? currentPanelIdx : null)}
            className={`p-2 rounded-full glass transition-colors ${translatingPanel !== null ? 'text-accent' : 'text-white hover:text-accent'}`}
            title="وەرگێڕانی دەق"
          >
            <Languages className="w-4 h-4" />
          </button>

          <span className="text-white/80 text-xs">{Math.round(scrollProgress)}%</span>
        </div>
        <div className="flex items-center gap-1 flex-wrap justify-end">
          {isAdmin && chapterId && localPanels.length > 0 && (
            <button
              onClick={() => setShowAnimationStudio(true)}
              className="p-2 rounded-full glass text-white hover:text-accent transition-colors"
              title="ستودیۆی ئەنیمەیشن"
            >
              <Film className="w-4 h-4" />
            </button>
          )}
          {chapterVideos.length > 0 && (
            <button
              onClick={() => setShowVideoSection(!showVideoSection)}
              className={`p-2 rounded-full glass transition-colors ${showVideoSection ? 'text-accent' : 'text-white hover:text-accent'}`}
              title="ڤیدیۆکان"
            >
              <VideoIcon className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setAutoScroll(!autoScroll)}
            className={`p-2 rounded-full glass transition-colors ${autoScroll ? 'text-accent' : 'text-white hover:text-accent'}`}
            title="خۆکار خڕۆردن"
          >
            {autoScroll ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
          <button onClick={() => setUiVisible(false)} className="p-2 rounded-full glass text-white hover:text-accent transition-colors" title="شاردنەوەی UI">
            <EyeOff className="w-4 h-4" />
          </button>
          <button onClick={toggleFullscreen} className="p-2 rounded-full glass text-white hover:text-accent transition-colors" title="تەواوی شاشە">
            <Maximize2 className="w-4 h-4" />
          </button>
          <button onClick={onClose} className="p-2 rounded-full glass text-white hover:text-accent transition-colors" title="داخستن">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* === Animation Studio === */}
      {showAnimationStudio && isAdmin && chapterId && contentId && (
        <ComicAnimationStudio
          panels={localPanels}
          chapterId={chapterId}
          contentId={contentId}
          onClose={() => setShowAnimationStudio(false)}
        />
      )}

      {/* === Chapter Videos Section === */}
      {showVideoSection && (
        <div className="absolute inset-0 z-40 bg-black/95 flex flex-col animate-fade-in">
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <VideoIcon className="w-5 h-5 text-accent" />
              <span className="text-white text-sm font-medium">ڤیدیۆکانی ئەم بەشە</span>
            </div>
            <div className="flex items-center gap-2">
              {isAdmin && (
                <button onClick={() => setShowVideoForm(!showVideoForm)} className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-accent text-white text-xs font-medium">
                  <Plus className="w-3.5 h-3.5" /> زیادکردنی ڤیدیۆ
                </button>
              )}
              <button onClick={() => setShowVideoSection(false)} className="p-2 rounded-lg text-white hover:text-accent">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Admin video form */}
          {isAdmin && showVideoForm && (
            <div className="p-4 border-b border-white/10 space-y-3 bg-white/5">
              <input
                type="text"
                value={videoForm.title}
                onChange={(e) => setVideoForm((prev) => ({ ...prev, title: e.target.value }))}
                placeholder="ناونیشانی ڤیدیۆ (ئیختیاری)"
                className="w-full px-3 py-2 rounded-lg bg-white/10 text-white text-sm outline-none placeholder:text-white/30"
              />
              <div className="flex flex-wrap gap-2">
                <button onClick={() => setVideoForm((prev) => ({ ...prev, type: 'upload' }))} className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-xs font-medium ${videoForm.type === 'upload' ? 'bg-accent text-white' : 'bg-white/10 text-white'}`}>بارکردن</button>
                <button onClick={() => setVideoForm((prev) => ({ ...prev, type: 'link' }))} className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-xs font-medium ${videoForm.type === 'link' ? 'bg-accent text-white' : 'bg-white/10 text-white'}`}>YouTube</button>
                <button onClick={() => setVideoForm((prev) => ({ ...prev, type: 'gdrive' }))} className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-xs font-medium ${videoForm.type === 'gdrive' ? 'bg-accent text-white' : 'bg-white/10 text-white'}`}>Google Drive</button>
              </div>
              {videoForm.type === 'upload' ? (
                <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/10 text-white cursor-pointer text-sm">
                  {uploadingVideo ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                  {videoForm.url ? 'ڤیدیۆ هەڵبژێردرا ✓' : 'هەڵبژاردنی ڤیدیۆ'}
                  <input
                    type="file"
                    accept="video/*"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && handleChapterVideoUpload(e.target.files[0])}
                  />
                </label>
              ) : (
                <input
                  type="text"
                  value={videoForm.url}
                  onChange={(e) => setVideoForm((prev) => ({ ...prev, url: e.target.value }))}
                  placeholder={videoForm.type === 'gdrive' ? 'لینکی Google Drive' : 'لینکی YouTube/Vimeo'}
                  className="w-full px-3 py-2 rounded-lg bg-white/10 text-white text-sm outline-none placeholder:text-white/30"
                />
              )}
              <button
                onClick={handleAddChapterVideo}
                disabled={!videoForm.url.trim() || uploadingVideo}
                className="w-full py-2 rounded-lg bg-green-600 text-white text-sm font-medium disabled:opacity-50"
              >
                زیادکردنی ڤیدیۆ
              </button>
            </div>
          )}

          {/* Active video player */}
          {activeVideo && (
            <div className="p-4 border-b border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white text-sm font-medium">{activeVideo.title || 'ڤیدیۆ'}</span>
                <button onClick={() => setActiveVideo(null)} className="p-2 text-white/60 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="w-full aspect-video bg-black rounded-lg overflow-hidden">
                <video
                  src={activeVideo.video_url}
                  controls
                  playsInline
                  className="w-full h-full object-contain"
                />
              </div>
            </div>
          )}

          {/* Video list */}
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {chapterVideos.length === 0 ? (
              <p className="text-center text-white/40 text-sm py-8">هیچ ڤیدیۆیەک نییە</p>
            ) : (
              chapterVideos.map((v, i) => (
                <div key={v.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                  <button
                    onClick={() => setActiveVideo(v)}
                    className="flex items-center gap-3 flex-1 text-right group"
                  >
                    <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center text-accent">
                      <Play className="w-5 h-5" fill="currentColor" />
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">{v.title || `ڤیدیۆ ${i + 1}`}</p>
                      <p className="text-xs text-white/40">{v.video_type === 'upload' ? 'بارکراو' : v.video_type === 'gdrive' ? 'Google Drive' : 'لینک'}</p>
                    </div>
                  </button>
                  {isAdmin && (
                    <div className="flex items-center gap-0.5">
                      <button onClick={() => moveChapterVideo(v, 'up')} disabled={i === 0} className="p-2 rounded text-white/60 hover:text-accent disabled:opacity-30">
                        <ArrowUp className="w-4 h-4" />
                      </button>
                      <button onClick={() => moveChapterVideo(v, 'down')} disabled={i === chapterVideos.length - 1} className="p-2 rounded text-white/60 hover:text-accent disabled:opacity-30">
                        <ArrowDown className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDeleteChapterVideo(v.id)} className="p-2 rounded text-white/60 hover:text-red-400">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Scroll container — continuous vertical panels */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        onClick={handleTap}
        className="flex-1 overflow-y-auto overflow-x-hidden scrollbar-hide"
        style={{
          scrollBehavior: autoScroll ? 'auto' : 'smooth',
          WebkitOverflowScrolling: 'touch',
          touchAction: 'pan-y',
          overscrollBehavior: 'contain',
        }}
      >
        <div className="w-full">
          {localPanels.map((panel, i) => (
            <div key={panel.id} className="relative w-full group">
              {panel.video_url ? (
                <div
                  className="w-full flex justify-center"
                  style={{
                    aspectRatio: panel.aspect_ratio || (format === '9:16' ? '9 / 16' : format === '16:9' ? '16 / 9' : 'auto'),
                    maxHeight: format === '9:16' ? '100vh' : 'none',
                  }}
                >
                  <video
                    src={panel.video_url}
                    controls
                    playsInline
                    preload="none"
                    className="w-full h-full object-contain"
                    style={{ aspectRatio: panel.aspect_ratio || (format === '9:16' ? '9 / 16' : format === '16:9' ? '16 / 9' : 'auto') }}
                  />
                </div>
              ) : (
                <img
                  src={panel.image_url}
                  alt={`پەنال ${i + 1}`}
                  loading="lazy"
                  decoding="async"
                  className="w-full h-auto block"
                  style={{
                    display: 'block',
                    aspectRatio: format === '9:16' ? '9 / 16' : format === '16:9' ? '16 / 9' : 'auto',
                    objectFit: format === '9:16' || format === '16:9' ? 'contain' : 'unset',
                  }}
                />
              )}

              {/* Speech bubble overlays */}
              {(panelBubblesMap[panel.id] || []).map((bubble) => {
                const displayText = bubble.translated_text || bubble.text;
                const char = bubble.character;
                const isRtl = bubble.target_language === 'ku' || bubble.target_language === 'ar' || bubble.target_language === 'fa';
                return (
                  <div
                    key={bubble.id}
                    className="absolute transition-all duration-200"
                    style={{
                      left: `${bubble.region_x * 100}%`,
                      top: `${bubble.region_y * 100}%`,
                      width: `${bubble.region_width * 100}%`,
                      minHeight: `${bubble.region_height * 100}%`,
                    }}
                  >
                    <div
                      className="bg-black/75 rounded-lg px-3 py-1.5"
                      dir={isRtl ? 'rtl' : 'ltr'}
                    >
                      {char && (
                        <div className="flex items-center gap-1 mb-0.5">
                          {char.voice_type === 'female' ? (
                            <span className="text-[8px] text-pink-400">♀</span>
                          ) : (
                            <span className="text-[8px] text-blue-400">♂</span>
                          )}
                          <span className="text-[8px] text-white/50">{char.name}</span>
                        </div>
                      )}
                      <p className="text-white text-xs leading-tight text-center" style={{ wordBreak: 'break-word' }}>
                        {displayText}
                      </p>
                    </div>
                  </div>
                );
              })}

              {/* Translation overlay */}
              {translatingPanel === i && !panel.video_url && (
                <ComicTranslationOverlay
                  panel={panel}
                  panelIndex={i}
                  onClose={() => setTranslatingPanel(null)}
                />
              )}

              {/* Admin edit overlay per panel */}
              {isAdmin && uiVisible && editingBubblePanel !== i && (
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-start justify-center pt-2">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 flex-wrap justify-center">
                    <button
                      onClick={(e) => { e.stopPropagation(); movePanel(panel, 'up'); }}
                      disabled={i === 0}
                      className="p-2 rounded-lg glass text-white hover:bg-accent disabled:opacity-30 transition-colors"
                      title="بەرەو سەر"
                    >
                      <ArrowUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); movePanel(panel, 'down'); }}
                      disabled={i === localPanels.length - 1}
                      className="p-2 rounded-lg glass text-white hover:bg-accent disabled:opacity-30 transition-colors"
                      title="بەرەو خوار"
                    >
                      <ArrowDown className="w-4 h-4" />
                    </button>
                    <label
                      onClick={(e) => e.stopPropagation()}
                      className="p-2 rounded-lg glass text-white hover:bg-accent transition-colors cursor-pointer"
                      title="گۆڕینی وێنە"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => e.target.files?.[0] && replacePanel(panel, e.target.files[0])}
                      />
                    </label>
                    <label
                      onClick={(e) => e.stopPropagation()}
                      className="p-2 rounded-lg glass text-white hover:bg-accent transition-colors cursor-pointer"
                      title={panel.video_url ? 'گۆڕینی ڤیدیۆ' : 'زیادکردنی ڤیدیۆ'}
                    >
                      {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <VideoIcon className="w-4 h-4" />}
                      <input
                        type="file"
                        accept="video/*"
                        className="hidden"
                        onChange={(e) => e.target.files?.[0] && replacePanelWithVideo(panel, e.target.files[0])}
                      />
                    </label>
                    {panel.video_url && (
                      <button
                        onClick={(e) => { e.stopPropagation(); removePanelVideo(panel); }}
                        className="p-2 rounded-lg glass text-white hover:bg-accent transition-colors"
                        title="لابردنی ڤیدیۆ"
                      >
                        <VideoIcon className="w-4 h-4 opacity-40" />
                      </button>
                    )}
                    <button
                      onClick={(e) => { e.stopPropagation(); setEditingBubblePanel(i); }}
                      className="p-2 rounded-lg glass text-white hover:bg-accent transition-colors"
                      title="دەستکاری دەق"
                    >
                      <MessageSquareText className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => handleReScanPanel(panel, e)}
                      disabled={ocrScanning}
                      className="p-2 rounded-lg glass text-white hover:bg-accent transition-colors disabled:opacity-50"
                      title="دووبارە سکانکردن (OCR)"
                    >
                      {ocrScanning && ocrPanelIdx === i ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); deletePanel(panel); }}
                      className="p-2 rounded-lg glass text-white hover:bg-red-500 transition-colors"
                      title="سڕینەوە"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* Bubble editor for this panel */}
              {isAdmin && editingBubblePanel === i && contentId && (
                <BubbleEditor
                  panel={panel}
                  panelIndex={i}
                  contentId={contentId}
                  onClose={() => setEditingBubblePanel(null)}
                  onBubblesChanged={reloadBubbles}
                />
              )}

              {/* Panel sound button */}
              {panel.sound_url && (
                <button
                  onClick={(e) => togglePanelSound(panel, e)}
                  className={`absolute bottom-2 left-2 z-10 p-2 rounded-full glass transition-all duration-300 ${uiVisible ? 'opacity-100' : 'opacity-0'} ${playingPanelSoundId === panel.id ? 'text-accent animate-pulse' : 'text-white/80 hover:text-accent'}`}
                  title="دەنگی پەنال"
                >
                  {playingPanelSoundId === panel.id ? <Pause className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              )}

              {/* Panel number badge */}
              <div className={`absolute bottom-2 right-2 px-2 py-1 rounded-md glass text-white/80 text-xs transition-opacity duration-300 ${uiVisible ? 'opacity-100' : 'opacity-0'}`}>
                {i + 1}
              </div>
            </div>
          ))}

          {/* Chapter videos quick access */}
          {chapterVideos.length > 0 && !showVideoSection && (
            <div className="px-4 py-4">
              <button
                onClick={(e) => { e.stopPropagation(); setShowVideoSection(true); }}
                className="w-full flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <VideoIcon className="w-6 h-6 text-accent" />
                  <div className="text-right">
                    <p className="text-white text-sm font-medium">ڤیدیۆکانی ئەم بەشە</p>
                    <p className="text-xs text-white/40">{chapterVideos.length} ڤیدیۆ</p>
                  </div>
                </div>
                <Play className="w-5 h-5 text-white/60" fill="currentColor" />
              </button>
            </div>
          )}

          {/* End spacer */}
          <div className="h-20 flex items-center justify-center">
            <span className="text-white/30 text-xs">کۆتایی بەش</span>
          </div>
        </div>
      </div>

      {/* Bottom bar — admin add + scroll-to-top */}
      <div className={`absolute bottom-0 left-0 right-0 z-20 flex flex-wrap items-center justify-center gap-2 px-3 py-3 bg-gradient-to-t from-black/70 to-transparent transition-all duration-300 ${uiVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        {isAdmin && chapterId && (
          <label className="flex items-center gap-1.5 px-4 py-2.5 rounded-full bg-accent text-white text-xs font-medium cursor-pointer hover:bg-[var(--accent-hover)] transition-colors">
            {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            زیادکردنی پەنال
            <input
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => e.target.files && addPanel(e.target.files)}
            />
          </label>
        )}
        {!atTop && (
          <button
            onClick={(e) => { e.stopPropagation(); scrollToTop(); }}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-full glass text-white text-xs font-medium hover:text-accent transition-colors"
          >
            <ChevronUp className="w-4 h-4" /> بەرەو سەرەوە
          </button>
        )}
      </div>

      {/* Show UI button when hidden */}
      {!uiVisible && (
        <button
          onClick={(e) => { e.stopPropagation(); setUiVisible(true); }}
          className="absolute bottom-3 left-1/2 -translate-x-1/2 z-30 p-2.5 rounded-full glass text-white hover:text-accent transition-colors animate-pulse-glow"
          title="پیشاندانی UI"
        >
          <Eye className="w-5 h-5" />
        </button>
      )}

      {/* Auto-scroll indicator */}
      {autoScroll && (
        <div className="absolute top-12 left-1/2 -translate-x-1/2 z-30 px-3 py-1.5 rounded-full glass text-accent text-xs font-medium flex items-center gap-1.5 animate-fade-in">
          <Play className="w-3 h-3" /> خۆکار خڕۆردن
        </div>
      )}

      {/* Translation/voice error message */}
      {translationError && (
        <div className="absolute top-12 left-1/2 -translate-x-1/2 z-30 px-4 py-2 rounded-full bg-red-500/80 text-white text-xs font-medium animate-fade-in max-w-[80%]">
          {translationError}
        </div>
      )}

      {/* OCR scanning indicator */}
      {ocrScanning && (
        <div className="absolute top-12 left-1/2 -translate-x-1/2 z-30 px-4 py-2 rounded-full glass text-accent text-xs font-medium flex items-center gap-2 animate-fade-in max-w-[80%]">
          <Loader2 className="w-3 h-3 animate-spin" />
          <span>OCR سکانکردنی دەق — پەنال {ocrPanelIdx >= 0 ? ocrPanelIdx + 1 : ''}...</span>
        </div>
      )}

    </div>
  );
}
