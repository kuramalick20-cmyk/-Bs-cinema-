import { useState, useEffect, useCallback } from 'react';
import { MessageCircle, Send, Trash2, Loader2, AlertCircle } from 'lucide-react';
import type { ItemType, Comment } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { fetchComments, postComment, deleteComment } from '@/lib/engagement';

interface CommentSectionProps {
  itemType: ItemType;
  itemId: string;
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'ئێستا';
  if (mins < 60) return `${mins} خولەک`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} کاتژمێر`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} ڕۆژ`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months} مانگ`;
  const years = Math.floor(months / 12);
  return `${years} ساڵ`;
}

export default function CommentSection({ itemType, itemId }: CommentSectionProps) {
  const { user, profile, signInWithGoogle } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const data = await fetchComments(itemType, itemId);
    setComments(data);
    setLoading(false);
  }, [itemType, itemId]);

  useEffect(() => { load(); }, [load]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || submitting) return;
    setSubmitting(true);
    setError(null);
    const comment = await postComment(itemType, itemId, text.trim());
    if (comment) {
      setComments((prev) => [comment, ...prev]);
      setText('');
    } else {
      setError('نەتوانرا لێدوانەکە پاشەکەوت بکرێت');
    }
    setSubmitting(false);
  };

  const handleDelete = async (commentId: string) => {
    const ok = await deleteComment(commentId);
    if (ok) {
      setComments((prev) => prev.filter((c) => c.id !== commentId));
    }
  };

  const handleGoogleSignIn = async () => {
    await signInWithGoogle();
  };

  return (
    <div className="mt-6">
      <h3 className="text-base font-semibold text-primary mb-4 flex items-center gap-2">
        <MessageCircle className="w-5 h-5" />
        لێدوانەکان
        {comments.length > 0 && (
          <span className="text-sm font-normal text-muted">({comments.length})</span>
        )}
      </h3>

      {/* Comment form */}
      {user ? (
        <form onSubmit={handleSubmit} className="mb-4">
          <div className="flex gap-2">
            <div className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-white text-xs font-bold overflow-hidden flex-shrink-0">
              {profile?.avatar_url ? (
                <img src={profile.avatar_url} alt="avatar" className="w-full h-full object-cover" />
              ) : (
                (profile?.username || user.email || 'U').charAt(0).toUpperCase()
              )}
            </div>
            <div className="flex-1 flex gap-2 min-w-0">
              <input
                type="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="لێدوانەکەت بنووسە..."
                maxLength={2000}
                className="flex-1 min-w-0 px-3 sm:px-4 py-2.5 rounded-xl bg-card border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent transition-colors"
              />
              <button
                type="submit"
                disabled={submitting || !text.trim()}
                className="px-4 py-2.5 rounded-xl bg-accent text-white text-sm font-medium hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50 flex items-center gap-1.5"
              >
                {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </button>
            </div>
          </div>
          {error && (
            <div className="flex items-center gap-2 text-red-400 text-sm mt-2 mr-11">
              <AlertCircle className="w-4 h-4" /> {error}
            </div>
          )}
        </form>
      ) : (
        <div className="mb-4 p-4 rounded-xl bg-card border border-default text-center">
          <p className="text-sm text-secondary mb-3">تکایە بە Google چوە ژوورەوە بۆ نووسینی لێدوان</p>
          <button
            onClick={handleGoogleSignIn}
            className="inline-flex items-center gap-3 px-5 py-2.5 rounded-xl bg-white text-gray-800 font-medium text-sm hover:bg-gray-100 transition-all"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            چوونەژوورەوە بە Google
          </button>
        </div>
      )}

      {/* Comment list */}
      {loading ? (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="w-5 h-5 text-accent animate-spin" />
        </div>
      ) : comments.length === 0 ? (
        <p className="text-sm text-muted text-center py-6">هیچ لێدوانێک نییە. یەکەم کەس بە لێدوان دەست پێ بکە!</p>
      ) : (
        <div className="space-y-3">
          {comments.map((c) => (
            <div key={c.id} className="flex gap-2.5 p-3 rounded-xl bg-card border border-default">
              <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-white text-xs font-bold overflow-hidden flex-shrink-0">
                {c.profiles?.avatar_url ? (
                  <img src={c.profiles.avatar_url} alt="avatar" className="w-full h-full object-cover" />
                ) : (
                  (c.profiles?.username || 'U').charAt(0).toUpperCase()
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2 mb-0.5">
                  <span className="text-sm font-medium text-primary truncate">
                    {c.profiles?.username || 'بەکارهێنەر'}
                  </span>
                  <span className="text-xs text-muted flex-shrink-0">{timeAgo(c.created_at)}</span>
                </div>
                <p className="text-sm text-secondary break-words leading-relaxed">{c.text}</p>
              </div>
              {user?.id === c.user_id && (
                <button
                  onClick={() => handleDelete(c.id)}
                  className="p-1.5 rounded-lg text-muted hover:text-red-400 transition-colors flex-shrink-0"
                  title="سڕینەوە"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
