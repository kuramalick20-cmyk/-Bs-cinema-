import { useState, useEffect } from 'react';
import { Eye, Star } from 'lucide-react';
import type { ItemType } from '@/lib/supabase';
import {
  recordView,
  getViewCount,
  getStarCount,
  hasStarred,
  toggleStar,
  formatCount,
} from '@/lib/engagement';

interface EngagementBarProps {
  itemType: ItemType;
  itemId: string;
  variant?: 'default' | 'overlay';
}

export default function EngagementBar({ itemType, itemId, variant = 'default' }: EngagementBarProps) {
  const [viewCount, setViewCount] = useState(0);
  const [starCount, setStarCount] = useState(0);
  const [starred, setStarred] = useState(false);
  const [toggling, setToggling] = useState(false);
  const [viewRecorded, setViewRecorded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const [v, s, h] = await Promise.all([
        getViewCount(itemType, itemId),
        getStarCount(itemType, itemId),
        hasStarred(itemType, itemId),
      ]);
      if (cancelled) return;
      setViewCount(v);
      setStarCount(s);
      setStarred(h);
    })();
    return () => { cancelled = true; };
  }, [itemType, itemId]);

  // Record a view once when the component mounts
  useEffect(() => {
    if (viewRecorded) return;
    setViewRecorded(true);
    (async () => {
      const count = await recordView(itemType, itemId);
      if (count > 0) setViewCount(count);
    })();
  }, [itemType, itemId, viewRecorded]);

  const handleStar = async () => {
    if (toggling) return;
    setToggling(true);
    const result = await toggleStar(itemType, itemId);
    if (result) {
      setStarred(result.starred);
      setStarCount(result.star_count);
    }
    setToggling(false);
  };

  const isOverlay = variant === 'overlay';
  const containerClass = isOverlay
    ? 'flex items-center gap-4'
    : 'flex items-center gap-4 py-2';

  return (
    <div className={containerClass}>
      {/* View counter */}
      <div className={`flex items-center gap-1.5 ${isOverlay ? 'text-white/90' : 'text-secondary'}`}>
        <Eye className="w-4 h-4" />
        <span className="text-sm font-medium">{formatCount(viewCount)}</span>
      </div>

      {/* Star button */}
      <button
        onClick={handleStar}
        disabled={toggling}
        className={`flex items-center gap-1.5 px-2 py-1.5 -mx-2 rounded-lg transition-all disabled:opacity-50 ${
          isOverlay ? 'text-white/90 hover:text-accent' : 'text-secondary hover:text-accent'
        }`}
        title={starred ? 'لابردنی ستار' : 'زیادکردنی ستار'}
      >
        <Star
          className={`w-5 h-5 transition-all ${starred ? 'fill-[var(--accent)] text-accent' : ''} ${toggling ? 'animate-pulse' : ''}`}
        />
        <span className="text-sm font-medium">{formatCount(starCount)}</span>
      </button>
    </div>
  );
}
