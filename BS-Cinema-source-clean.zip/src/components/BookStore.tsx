import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { uploadFile } from '@/lib/storage';
import { useAuth } from '@/context/AuthContext';
import { useAdmin } from '@/context/AdminContext';
import { useI18n } from '@/lib/i18n';
import {
  X, BookOpen, Loader2, Upload, Trash2, Plus, Edit2, Save,
  ShoppingCart, DollarSign, CheckCircle, MapPin, Phone, MessageCircle,
  Navigation, ArrowLeft, ArrowRight, AlertCircle,
} from 'lucide-react';

interface Book {
  id: string;
  title: string;
  description: string | null;
  price: number;
  cover_image_url: string | null;
  images: string[];
  author: string | null;
  is_active: boolean;
}

interface BookStoreProps {
  onClose: () => void;
}

const WHATSAPP_NUMBER = '9647511590023';

export default function BookStore({ onClose }: BookStoreProps) {
  const { user } = useAuth();
  const { isAdmin } = useAdmin();
  const { t, dir } = useI18n();
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [showOrderModal, setShowOrderModal] = useState(false);

  // Admin states
  const [showAdminForm, setShowAdminForm] = useState(false);
  const [editBook, setEditBook] = useState<Book | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formPrice, setFormPrice] = useState('');
  const [formAuthor, setFormAuthor] = useState('');
  const [formCover, setFormCover] = useState('');
  const [formImages, setFormImages] = useState<string[]>([]);
  const [uploadingCover, setUploadingCover] = useState(false);
  const [uploadingImages, setUploadingImages] = useState(false);
  const [saving, setSaving] = useState(false);

  // User requests
  const [userRequests, setUserRequests] = useState<any[]>([]);

  useEffect(() => {
    loadBooks();
    if (user) loadUserRequests();
  }, [user]);

  const loadBooks = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('books')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: false });
    setBooks((data as Book[]) || []);
    setLoading(false);
  };

  const loadUserRequests = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('book_purchase_requests')
      .select('*, books(title, cover_image_url)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setUserRequests(data || []);
  };

  // Admin: save book
  const handleSaveBook = async () => {
    setSaving(true);
    const bookData = {
      title: formTitle,
      description: formDesc || null,
      price: parseFloat(formPrice) || 0,
      author: formAuthor || null,
      cover_image_url: formCover || null,
      images: formImages,
      is_active: true,
    };
    if (editBook) {
      await supabase.from('books').update(bookData).eq('id', editBook.id);
    } else {
      await supabase.from('books').insert(bookData);
    }
    setSaving(false);
    resetForm();
    loadBooks();
  };

  const resetForm = () => {
    setShowAdminForm(false);
    setEditBook(null);
    setFormTitle('');
    setFormDesc('');
    setFormPrice('');
    setFormAuthor('');
    setFormCover('');
    setFormImages([]);
  };

  const startEdit = (book: Book) => {
    setEditBook(book);
    setFormTitle(book.title);
    setFormDesc(book.description || '');
    setFormPrice(String(book.price));
    setFormAuthor(book.author || '');
    setFormCover(book.cover_image_url || '');
    setFormImages(book.images || []);
    setShowAdminForm(true);
  };

  const handleDeleteBook = async (id: string) => {
    await supabase.from('books').delete().eq('id', id);
    loadBooks();
  };

  const handleCoverUpload = async (file: File) => {
    setUploadingCover(true);
    const url = await uploadFile('books', file);
    if (url) setFormCover(url);
    setUploadingCover(false);
  };

  const handleImagesUpload = async (files: FileList) => {
    setUploadingImages(true);
    const urls: string[] = [];
    for (const file of Array.from(files)) {
      const url = await uploadFile('books', file);
      if (url) urls.push(url);
    }
    setFormImages([...formImages, ...urls]);
    setUploadingImages(false);
  };

  const openOrderModal = (book: Book) => {
    setSelectedBook(book);
    setShowOrderModal(true);
  };

  const closeOrderModal = () => {
    setShowOrderModal(false);
    setSelectedBook(null);
  };

  // WhatsApp order
  const orderViaWhatsapp = (book: Book) => {
    const msg = `*BS Cinema - Book Order*\n\n` +
      `Book: ${book.title}\n` +
      `Price: ${book.price} IQD\n\n` +
      `I would like to order this book for delivery in Sulaymaniyah.\n` +
      `Payment: FastPay or Cash on Delivery`;
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-[60] overflow-y-auto bg-primary animate-fade-in">
      {/* Header */}
      <div className="sticky top-0 glass border-b border-default px-4 py-3 flex items-center justify-between z-10" style={{ paddingTop: 'calc(0.75rem + var(--safe-top))' }}>
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-accent" />
          <h2 className="text-lg font-bold text-primary">{t('bookStoreTitle')}</h2>
        </div>
        <div className="flex items-center gap-2">
          {isAdmin && (
            <button
              onClick={() => { resetForm(); setShowAdminForm(true); }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-accent text-white text-xs font-medium"
            >
              <Plus className="w-4 h-4" /> {t('bookStoreTitle')}
            </button>
          )}
          <button onClick={onClose} className="p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 md:p-6">
        {/* Sulaymaniyah delivery notice */}
        <div className="bg-accent/10 border border-accent/30 rounded-xl p-3 mb-4 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-accent shrink-0" />
          <p className="text-xs sm:text-sm text-accent font-medium">{t('deliveryOnlySuly')}</p>
        </div>

        {/* Admin form */}
        {isAdmin && showAdminForm && (
          <div className="bg-card border border-default rounded-xl p-4 mb-6 space-y-3 animate-scale-in">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-primary">{editBook ? t('bookStoreTitle') : t('bookStoreTitle')}</h3>
              <button onClick={resetForm} className="text-secondary hover:text-primary"><X className="w-4 h-4" /></button>
            </div>
            <input type="text" value={formTitle} onChange={(e) => setFormTitle(e.target.value)} placeholder={t('bookStoreTitle')} className="w-full px-3 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
            <textarea value={formDesc} onChange={(e) => setFormDesc(e.target.value)} placeholder={t('bookStoreTitle')} rows={3} className="w-full px-3 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent resize-none" />
            <div className="grid grid-cols-2 gap-3">
              <input type="number" value={formPrice} onChange={(e) => setFormPrice(e.target.value)} placeholder={t('bookPrice')} className="px-3 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
              <input type="text" value={formAuthor} onChange={(e) => setFormAuthor(e.target.value)} placeholder={t('bookAuthor')} className="px-3 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
            </div>
            {/* Cover upload */}
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-secondary border border-default text-secondary cursor-pointer text-sm">
                {uploadingCover ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                {t('bookStoreTitle')}
                <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleCoverUpload(e.target.files[0])} />
              </label>
              {formCover && <img src={formCover} alt="cover" className="w-12 h-16 object-cover rounded" />}
            </div>
            {/* Images upload */}
            <div className="flex items-center gap-3 flex-wrap">
              <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-secondary border border-default text-secondary cursor-pointer text-sm">
                {uploadingImages ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                {t('bookStoreTitle')}
                <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => e.target.files && handleImagesUpload(e.target.files)} />
              </label>
              {formImages.map((url, i) => (
                <div key={i} className="relative">
                  <img src={url} alt={`img ${i}`} className="w-12 h-16 object-cover rounded" />
                  <button onClick={() => setFormImages(formImages.filter((_, idx) => idx !== i))} className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-xs">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
            <button onClick={handleSaveBook} disabled={saving || !formTitle.trim()} className="w-full py-2.5 rounded-lg bg-green-600 text-white text-sm font-medium disabled:opacity-50 flex items-center justify-center gap-2">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {t('submitRequest')}
            </button>
          </div>
        )}

        {/* User's purchase requests */}
        {user && userRequests.length > 0 && !showAdminForm && (
          <div className="bg-card border border-default rounded-xl p-4 mb-6">
            <h3 className="text-sm font-semibold text-primary mb-3">{t('yourRequests')}</h3>
            <div className="space-y-2">
              {userRequests.map((req) => (
                <div key={req.id} className="flex items-center gap-3 p-2.5 rounded-lg bg-secondary border border-default text-sm">
                  {req.books?.cover_image_url && <img src={req.books.cover_image_url} alt="" className="w-8 h-10 object-cover rounded" />}
                  <div className="flex-1 min-w-0">
                    <p className="text-primary truncate">{req.books?.title || t('bookStoreTitle')}</p>
                    <p className="text-xs text-muted">{req.payment_method === 'fastpay' ? 'FastPay' : t('cashMethod')}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                    req.status === 'pending' ? 'bg-accent/20 text-accent' :
                    req.status === 'approved' ? 'bg-green-500/20 text-green-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {req.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Books grid */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-accent animate-spin" />
          </div>
        ) : books.length === 0 ? (
          <div className="text-center py-20 text-secondary">
            <BookOpen className="w-12 h-12 mx-auto mb-4 text-muted" />
            <p className="text-lg">{t('noContent')}</p>
            <p className="text-sm text-muted mt-2">{t('noContentSoon')}</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 md:gap-4">
            {books.map((book, i) => (
              <div key={book.id} className="animate-slide-up" style={{ animationDelay: `${Math.min(i * 0.03, 0.45)}s`, opacity: 0 }}>
                <div className="group cursor-pointer" onClick={() => openOrderModal(book)}>
                  <div className="relative aspect-[2/3] rounded-xl overflow-hidden bg-card border border-default group-hover:border-accent/50 transition-all">
                    {book.cover_image_url ? (
                      <img src={book.cover_image_url} alt={book.title} className="w-full h-full object-cover" loading="lazy" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <BookOpen className="w-8 h-8 text-muted" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-2">
                      <p className="text-white text-xs font-medium truncate" dir="auto">{book.title}</p>
                      <p className="text-accent text-xs font-bold mt-0.5" dir="ltr">{book.price} {t('bookPrice')}</p>
                    </div>
                  </div>
                </div>
                {/* Admin controls */}
                {isAdmin && (
                  <div className="flex items-center gap-1 mt-1">
                    <button onClick={() => startEdit(book)} className="p-1.5 rounded text-secondary hover:text-accent"><Edit2 className="w-3.5 h-3.5" /></button>
                    <button onClick={() => handleDeleteBook(book.id)} className="p-1.5 rounded text-secondary hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Order modal */}
      {showOrderModal && selectedBook && (
        <OrderModal
          book={selectedBook}
          onClose={closeOrderModal}
          onSuccess={() => { loadUserRequests(); }}
          onWhatsappOrder={() => orderViaWhatsapp(selectedBook)}
          t={t}
          dir={dir}
          user={user}
        />
      )}
    </div>
  );
}

// ============================================================
// Order Modal — multi-step book order with delivery info
// ============================================================

interface OrderModalProps {
  book: Book;
  onClose: () => void;
  onSuccess: () => void;
  onWhatsappOrder: () => void;
  t: (key: any) => string;
  dir: 'rtl' | 'ltr';
  user: any;
}

type OrderStep = 'channel' | 'location' | 'details' | 'payment' | 'success';

function OrderModal({ book, onClose, onSuccess, onWhatsappOrder, t, dir, user }: OrderModalProps) {
  const [step, setStep] = useState<OrderStep>('channel');
  const [orderChannel, setOrderChannel] = useState<'website' | 'whatsapp'>('website');
  const [deliveryLat, setDeliveryLat] = useState<number | null>(null);
  const [deliveryLng, setDeliveryLng] = useState<number | null>(null);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [deliveryNote, setDeliveryNote] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'fastpay' | 'cash'>('cash');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [locating, setLocating] = useState(false);
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markerRef = useRef<any>(null);
  const geocoderRef = useRef<any>(null);
  const googleMapsLoaded = useRef(false);

  // SULAYMANIYAH center
  const SUL_LAT = 35.5582;
  const SUL_LNG = 45.4354;

  // Load Google Maps script
  useEffect(() => {
    if (step !== 'location') return;
    if (googleMapsLoaded.current && window.google?.maps) {
      initMap();
      return;
    }
    // Use Google Maps without API key (embed style won't work for interactive picker)
    // Use a simple approach: Geolocation API + OpenStreetMap for location picking
    googleMapsLoaded.current = true;
    initMap();
  }, [step]);

  const initMap = () => {
    if (!mapRef.current) return;

    // Use OpenStreetMap with Leaflet-style approach but without external deps
    // We'll use a simple visual map with the browser's Geolocation API
    setLocating(true);

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          setDeliveryLat(lat);
          setDeliveryLng(lng);
          renderMap(lat, lng);
          setLocating(false);
          // Try reverse geocode using free service
          reverseGeocode(lat, lng);
        },
        () => {
          // Fall back to Sulaymaniyah center
          setDeliveryLat(SUL_LAT);
          setDeliveryLng(SUL_LNG);
          renderMap(SUL_LAT, SUL_LNG);
          setLocating(false);
        },
        { enableHighAccuracy: true, timeout: 10000 },
      );
    } else {
      setDeliveryLat(SUL_LAT);
      setDeliveryLng(SUL_LNG);
      renderMap(SUL_LAT, SUL_LNG);
      setLocating(false);
    }
  };

  const renderMap = (lat: number, lng: number) => {
    if (!mapRef.current) return;

    // Render a static map preview using OpenStreetMap tile
    const delta = 0.008;
    const bbox = `${lng - delta},${lat - delta},${lng + delta},${lat + delta}`;
    const mapUrl = `https://staticmap.openstreetmap.de/staticmap.php?center=${lat},${lng}&zoom=15&size=400x300&markers=${lat},${lng},red-pushpin`;

    mapRef.current.innerHTML = `
      <div class="relative w-full h-full">
        <img src="${mapUrl}" alt="map" class="w-full h-full object-cover rounded-lg" />
        <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div class="w-8 h-8 rounded-full bg-red-500 border-2 border-white shadow-lg flex items-center justify-center">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
          </div>
        </div>
        <div class="absolute bottom-2 left-2 right-2 bg-black/70 rounded-lg px-2 py-1.5 text-center">
          <p class="text-white text-xs font-medium">${lat.toFixed(5)}, ${lng.toFixed(5)}</p>
        </div>
      </div>
    `;
  };

  const reverseGeocode = async (lat: number, lng: number) => {
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&zoom=16`);
      const data = await res.json();
      if (data.display_name) {
        setDeliveryAddress(data.display_name);
      }
    } catch {
      // ignore — address is optional
    }
  };

  const handleRelocate = () => {
    setLocating(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          setDeliveryLat(lat);
          setDeliveryLng(lng);
          renderMap(lat, lng);
          setLocating(false);
          reverseGeocode(lat, lng);
        },
        () => {
          setDeliveryLat(SUL_LAT);
          setDeliveryLng(SUL_LNG);
          renderMap(SUL_LAT, SUL_LNG);
          setLocating(false);
        },
        { enableHighAccuracy: true, timeout: 10000 },
      );
    }
  };

  const handleConfirmLocation = () => {
    if (deliveryLat === null || deliveryLng === null) return;
    setStep('details');
  };

  const handleConfirmDetails = () => {
    if (!deliveryNote.trim() || !phoneNumber.trim()) {
      setError(t('fillAllFields'));
      return;
    }
    setError('');
    setStep('payment');
  };

  const handleSubmitOrder = async () => {
    setSubmitting(true);
    setError('');

    const orderData: any = {
      book_id: book.id,
      payment_method: paymentMethod,
      payment_note: null,
      delivery_lat: deliveryLat,
      delivery_lng: deliveryLng,
      delivery_address: deliveryAddress || null,
      delivery_note: deliveryNote.trim(),
      phone_number: phoneNumber.trim(),
      order_channel: 'website',
      status: 'pending',
    };
    if (user) {
      orderData.user_id = user.id;
    }

    const { error: insertError } = await supabase
      .from('book_purchase_requests')
      .insert(orderData);

    if (insertError) {
      setError(insertError.message);
      setSubmitting(false);
      return;
    }

    setSubmitting(false);
    setStep('success');
    onSuccess();
    setTimeout(() => {
      onClose();
    }, 2500);
  };

  const handleWebsiteChannel = () => {
    setOrderChannel('website');
    setStep('location');
  };

  const handleWhatsappChannel = () => {
    onWhatsappOrder();
    // Also save a record
    supabase.from('book_purchase_requests').insert({
      book_id: book.id,
      payment_method: 'cash',
      delivery_lat: null,
      delivery_lng: null,
      delivery_address: null,
      delivery_note: null,
      phone_number: null,
      order_channel: 'whatsapp',
      status: 'pending',
      ...(user ? { user_id: user.id } : {}),
    }).then(() => { onSuccess(); });
    onClose();
  };

  const nextIcon = dir === 'rtl' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />;
  const prevIcon = dir === 'rtl' ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 animate-fade-in">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md bg-secondary rounded-2xl border border-default shadow-2xl animate-scale-in max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-secondary border-b border-default px-5 py-3 flex items-center justify-between rounded-t-2xl">
          <h3 className="text-base font-bold text-primary">{t('orderBook')}</h3>
          <button onClick={onClose} className="p-1 text-secondary hover:text-primary">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Book info */}
        <div className="px-5 pt-4 pb-3 flex gap-3">
          {book.cover_image_url && (
            <img src={book.cover_image_url} alt={book.title} className="w-16 h-22 object-cover rounded-lg flex-shrink-0" />
          )}
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-bold text-primary" dir="auto">{book.title}</h4>
            {book.author && <p className="text-xs text-secondary mt-0.5" dir="auto">{book.author}</p>}
            <p className="text-accent font-bold text-sm mt-1" dir="ltr">{book.price} {t('bookPrice')}</p>
          </div>
        </div>

        {/* Sulaymaniyah notice */}
        {step !== 'success' && (
          <div className="mx-5 mb-3 bg-accent/10 border border-accent/30 rounded-lg px-3 py-2 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-accent shrink-0" />
            <p className="text-[11px] text-accent font-medium">{t('deliveryOnlySuly')}</p>
          </div>
        )}

        <div className="px-5 pb-5">
          {/* Step: Channel selection */}
          {step === 'channel' && (
            <div className="space-y-3">
              <p className="text-sm text-secondary text-center mb-2">{t('orderBook')}</p>
              <button
                onClick={handleWebsiteChannel}
                className="w-full flex items-center gap-3 p-4 rounded-xl bg-card border-2 border-accent text-primary hover:border-accent/60 transition-all active:scale-[0.98]"
              >
                <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                  <ShoppingCart className="w-5 h-5 text-accent" />
                </div>
                <div className="text-left flex-1">
                  <p className="text-sm font-bold text-primary">{t('orderViaWebsite')}</p>
                  <p className="text-xs text-secondary mt-0.5">FastPay · {t('cashMethod')}</p>
                </div>
                {nextIcon}
              </button>
              <button
                onClick={handleWhatsappChannel}
                className="w-full flex items-center gap-3 p-4 rounded-xl bg-card border-2 border-green-600/40 text-primary hover:border-green-600 transition-all active:scale-[0.98]"
              >
                <div className="w-10 h-10 rounded-full bg-green-600/20 flex items-center justify-center shrink-0">
                  <MessageCircle className="w-5 h-5 text-green-500" />
                </div>
                <div className="text-left flex-1">
                  <p className="text-sm font-bold text-primary">{t('orderViaWhatsapp')}</p>
                  <p className="text-xs text-secondary mt-0.5" dir="ltr">{t('whatsappNumber')}</p>
                </div>
                {nextIcon}
              </button>
            </div>
          )}

          {/* Step: Location */}
          {step === 'location' && (
            <div className="space-y-3">
              {/* Step indicator */}
              <StepIndicator current={1} t={t} />

              <p className="text-sm text-secondary">{t('selectLocation')}</p>

              {/* Map */}
              <div ref={mapRef} className="w-full h-56 rounded-xl overflow-hidden bg-card border border-default relative">
                {locating && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Loader2 className="w-8 h-8 text-accent animate-spin" />
                  </div>
                )}
              </div>

              {/* Relocate button */}
              <button
                onClick={handleRelocate}
                disabled={locating}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-card border border-default text-primary text-sm font-medium hover:bg-hover transition-all disabled:opacity-50"
              >
                {locating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Navigation className="w-4 h-4 text-accent" />}
                {t('selectLocation')}
              </button>

              {/* Address display */}
              {deliveryAddress && (
                <div className="flex items-start gap-2 p-2.5 rounded-lg bg-card border border-default">
                  <MapPin className="w-4 h-4 text-accent shrink-0 mt-0.5" />
                  <p className="text-xs text-secondary" dir="auto">{deliveryAddress}</p>
                </div>
              )}

              {deliveryLat !== null && (
                <div className="flex items-center gap-1.5 text-xs text-green-400">
                  <CheckCircle className="w-4 h-4" />
                  {t('locationSelected')}
                </div>
              )}

              <button
                onClick={handleConfirmLocation}
                disabled={deliveryLat === null || locating}
                className="w-full py-3 rounded-xl bg-accent text-white font-semibold text-sm hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {t('confirmOrder')} {nextIcon}
              </button>
            </div>
          )}

          {/* Step: Details (delivery note + phone) */}
          {step === 'details' && (
            <div className="space-y-3">
              <StepIndicator current={2} t={t} />

              {/* Delivery note */}
              <div>
                <label className="text-sm text-secondary mb-1.5 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-accent" />
                  {t('deliveryNote')}
                </label>
                <textarea
                  value={deliveryNote}
                  onChange={(e) => { setDeliveryNote(e.target.value); setError(''); }}
                  placeholder={t('deliveryNotePlaceholder')}
                  rows={3}
                  dir="auto"
                  className="w-full px-3 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent resize-none"
                />
              </div>

              {/* Phone number */}
              <div>
                <label className="text-sm text-secondary mb-1.5 flex items-center gap-1.5">
                  <Phone className="w-4 h-4 text-accent" />
                  {t('phoneNumber')}
                </label>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => { setPhoneNumber(e.target.value); setError(''); }}
                  placeholder={t('phoneNumberPlaceholder')}
                  dir="ltr"
                  className="w-full px-3 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent"
                />
              </div>

              {error && (
                <div className="flex items-center gap-2 p-2.5 rounded-lg bg-red-500/10 border border-red-500/30">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <p className="text-xs text-red-400">{error}</p>
                </div>
              )}

              <div className="flex gap-2">
                <button
                  onClick={() => setStep('location')}
                  className="px-4 py-3 rounded-xl bg-card border border-default text-secondary text-sm font-medium hover:bg-hover transition-all flex items-center gap-1.5"
                >
                  {prevIcon}
                </button>
                <button
                  onClick={handleConfirmDetails}
                  className="flex-1 py-3 rounded-xl bg-accent text-white font-semibold text-sm hover:bg-[var(--accent-hover)] transition-all flex items-center justify-center gap-2"
                >
                  {t('confirmOrder')} {nextIcon}
                </button>
              </div>
            </div>
          )}

          {/* Step: Payment method */}
          {step === 'payment' && (
            <div className="space-y-3">
              <StepIndicator current={3} t={t} />

              <div>
                <p className="text-sm text-secondary mb-2">{t('paymentMethod')}</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setPaymentMethod('fastpay')}
                    className={`flex-1 flex flex-col items-center gap-1.5 py-4 rounded-xl text-sm font-medium transition-all ${paymentMethod === 'fastpay' ? 'bg-green-600 text-white border-2 border-green-500' : 'bg-card border border-default text-secondary'}`}
                  >
                    <DollarSign className="w-5 h-5" />
                    {t('fastpayMethod')}
                  </button>
                  <button
                    onClick={() => setPaymentMethod('cash')}
                    className={`flex-1 flex flex-col items-center gap-1.5 py-4 rounded-xl text-sm font-medium transition-all ${paymentMethod === 'cash' ? 'bg-accent text-white border-2 border-accent' : 'bg-card border border-default text-secondary'}`}
                  >
                    <ShoppingCart className="w-5 h-5" />
                    {t('cashMethod')}
                  </button>
                </div>
              </div>

              {/* Order summary */}
              <div className="rounded-xl bg-card border border-default p-3 space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-secondary">{t('bookPrice')}</span>
                  <span className="text-primary font-bold" dir="ltr">{book.price} IQD</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-secondary">{t('paymentMethod')}</span>
                  <span className="text-primary">{paymentMethod === 'fastpay' ? t('fastpayMethod') : t('cashMethod')}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-secondary">{t('phoneNumber')}</span>
                  <span className="text-primary" dir="ltr">{phoneNumber}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setStep('details')}
                  className="px-4 py-3 rounded-xl bg-card border border-default text-secondary text-sm font-medium hover:bg-hover transition-all flex items-center gap-1.5"
                >
                  {prevIcon}
                </button>
                <button
                  onClick={handleSubmitOrder}
                  disabled={submitting}
                  className="flex-1 py-3 rounded-xl bg-accent text-white font-semibold text-sm hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                  {t('submitRequest')}
                </button>
              </div>
            </div>
          )}

          {/* Step: Success */}
          {step === 'success' && (
            <div className="text-center py-8">
              <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-10 h-10 text-green-400" />
              </div>
              <p className="text-primary font-bold text-lg">{t('orderPlaced')}</p>
              <p className="text-secondary text-sm mt-2">{t('requestSent')}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Step Indicator
// ============================================================

function StepIndicator({ current, t }: { current: number; t: (key: any) => string }) {
  const steps = [
    { num: 1, label: t('deliveryLocation') },
    { num: 2, label: t('deliveryNote') },
    { num: 3, label: t('paymentMethod') },
  ];
  return (
    <div className="flex items-center gap-1.5 mb-2">
      {steps.map((s, i) => (
        <div key={s.num} className="flex items-center gap-1.5 flex-1">
          <div className={`flex items-center justify-center w-6 h-6 rounded-full text-[10px] font-bold transition-all ${
            current >= s.num ? 'bg-accent text-white' : 'bg-card border border-default text-muted'
          }`}>
            {s.num}
          </div>
          {i < steps.length - 1 && (
            <div className={`h-0.5 flex-1 rounded ${current > s.num ? 'bg-accent' : 'bg-card'}`} />
          )}
        </div>
      ))}
    </div>
  );
}
