import { ChevronDown } from 'lucide-react';

const HERO_IMAGE_BASE = 'https://images.pexels.com/photos/7991486/pexels-photo-7991486.jpeg';
const HERO_IMAGE_SOURCES = [
  `${HERO_IMAGE_BASE}?auto=compress&cs=tinysrgb&w=768 768w`,
  `${HERO_IMAGE_BASE}?auto=compress&cs=tinysrgb&w=1280 1280w`,
  `${HERO_IMAGE_BASE}?auto=compress&cs=tinysrgb&w=1920 1920w`,
];

interface HeroProps {
  onExplore: () => void;
}

export default function Hero({ onExplore }: HeroProps) {
  return (
    <section
      className="relative h-[42vh] min-h-[280px] sm:h-[80vh] sm:min-h-[520px] w-full overflow-hidden flex items-center justify-center"
      style={{ paddingTop: 'var(--safe-top)' }}
    >
      {/* Background image with slow zoom */}
      <div className="absolute inset-0 overflow-hidden">
        <img
          src={`${HERO_IMAGE_BASE}?auto=compress&cs=tinysrgb&w=1280`}
          srcSet={HERO_IMAGE_SOURCES.join(', ')}
          sizes="100vw"
          alt="BS Cinema Hero"
          fetchPriority="high"
          decoding="async"
          className="w-full h-full object-cover hero-zoom"
          style={{ filter: 'brightness(0.28) contrast(1.35) saturate(1.15)', objectPosition: 'center 30%' }}
        />

        {/* Warm amber glow (upper) */}
        <div className="absolute inset-0" style={{ background: 'var(--hero-glow)' }} />
        {/* Kurdistan green glow (lower) */}
        <div className="absolute inset-0" style={{ background: 'var(--hero-glow-2)' }} />
        {/* Golden sun glow (center) */}
        <div className="absolute inset-0 animate-sun-pulse" style={{ background: 'var(--hero-sun)' }} />

        {/* Rotating golden sun rays — subtle */}
        <div className="absolute top-[25%] left-1/2 -translate-x-1/2 w-[280px] h-[280px] sm:w-[400px] sm:h-[400px] md:w-[600px] md:h-[600px] opacity-[0.07] pointer-events-none">
          <svg viewBox="0 0 200 200" className="w-full h-full animate-sun-rotate" aria-hidden="true">
            {Array.from({ length: 21 }).map((_, i) => {
              const angle = (i * 360) / 21;
              const rad = (angle * Math.PI) / 180;
              const cx = 100, cy = 100;
              const inner = 60, outer = 95;
              const spread = 0.04;
              const x1 = cx + Math.cos(rad - spread) * inner;
              const y1 = cy + Math.sin(rad - spread) * inner;
              const x2 = cx + Math.cos(rad) * outer;
              const y2 = cy + Math.sin(rad) * outer;
              const x3 = cx + Math.cos(rad + spread) * inner;
              const y3 = cy + Math.sin(rad + spread) * inner;
              return <polygon key={i} points={`${x1},${y1} ${x2},${y2} ${x3},${y3}`} fill="var(--accent)" />;
            })}
          </svg>
        </div>

        {/* Cinematic gradient overlays — deeper at bottom for content fade */}
        <div className="absolute inset-0 bg-gradient-to-t from-[var(--bg-primary)] via-[var(--bg-primary)]/20 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-b from-[var(--bg-primary)]/70 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[var(--bg-primary)]/40 via-transparent to-[var(--bg-primary)]/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl">
        {/* BS Logo */}
        <div className="flex justify-center mb-2 sm:mb-5 animate-hero-fade">
          <div className="w-14 h-14 sm:w-24 sm:h-24 md:w-28 md:h-28">
            <div className="flex items-center justify-center w-full h-full">
              <svg viewBox="0 0 100 100" className="w-full h-full" aria-hidden="true">
                <defs>
                  <linearGradient id="hero-bs-bg" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#ef3340" />
                    <stop offset="45%" stopColor="#0c0c12" />
                    <stop offset="100%" stopColor="#2bb24c" />
                  </linearGradient>
                  <radialGradient id="hero-bs-sun" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#f9e300" />
                    <stop offset="100%" stopColor="#c5a016" />
                  </radialGradient>
                </defs>
                <rect x="4" y="4" width="92" height="92" rx="22" fill="url(#hero-bs-bg)" />
                <rect x="4" y="40" width="92" height="20" fill="rgba(255,255,255,0.85)" />
                <rect x="4" y="4" width="92" height="92" rx="22" fill="none" stroke="rgba(107,159,255,0.2)" strokeWidth="1" />
                {Array.from({ length: 21 }).map((_, i) => {
                  const angle = (i * 360) / 21;
                  const rad = (angle * Math.PI) / 180;
                  const cx = 50, cy = 50;
                  const inner = 30, outer = 40;
                  const spread = 0.045;
                  const x1 = cx + Math.cos(rad - spread) * inner;
                  const y1 = cy + Math.sin(rad - spread) * inner;
                  const x2 = cx + Math.cos(rad) * outer;
                  const y2 = cy + Math.sin(rad) * outer;
                  const x3 = cx + Math.cos(rad + spread) * inner;
                  const y3 = cy + Math.sin(rad + spread) * inner;
                  return <polygon key={i} points={`${x1},${y1} ${x2},${y2} ${x3},${y3}`} fill="url(#hero-bs-sun)" opacity="0.6" />;
                })}
                <circle cx="50" cy="50" r="22" fill="url(#hero-bs-sun)" opacity="0.2" />
                <text x="50" y="57" textAnchor="middle" fontFamily="'Cairo', system-ui, sans-serif" fontWeight="900" fontSize="40" fill="white" letterSpacing="-2" style={{ filter: 'drop-shadow(0 1px 3px rgba(0,0,0,0.6))' }}>
                  BS
                </text>
              </svg>
            </div>
          </div>
        </div>

        {/* Flag stripe accent — preserved exactly */}
        <div className="hidden sm:flex justify-center mb-5 animate-hero-fade">
          <div className="flex h-1.5 w-32 sm:w-40 rounded-full overflow-hidden" style={{ boxShadow: '0 0 12px var(--shadow-glow)' }}>
            <div className="flex-1" style={{ background: 'var(--flag-red)' }} />
            <div className="flex-1" style={{ background: 'var(--flag-white)', opacity: 0.8 }} />
            <div className="flex-1" style={{ background: 'var(--flag-green)' }} />
            <div className="flex-1" style={{ background: 'var(--flag-yellow)' }} />
          </div>
        </div>

        <h1 className="text-2xl sm:text-5xl md:text-7xl lg:text-8xl font-black mb-2 sm:mb-4 animate-slide-up-lg tracking-tight leading-none">
          <span style={{ color: 'var(--accent)' }}>B</span>
          <span style={{ color: 'var(--flag-red)' }}>S</span>
          <span className="text-primary ml-2 sm:ml-3 text-gradient-gold">Cinema</span>
        </h1>

        <p className="text-sm sm:text-lg md:text-2xl text-primary mb-1 sm:mb-2 animate-slide-up font-semibold" style={{ animationDelay: '0.15s', opacity: 0 }}>
          ماڵپەڕی سینەمای کوردی
        </p>
        <p className="text-xs sm:text-sm md:text-base text-secondary mb-3 sm:mb-8 animate-slide-up" style={{ animationDelay: '0.3s', opacity: 0 }}>
          فیلم، زنجیرە، ئەنیمی و کۆمیک — هەمووی لە یەک شوێن
        </p>

        <button
          onClick={onExplore}
          className="px-6 sm:px-10 py-2.5 sm:py-3.5 rounded-full btn-cinema text-white font-bold text-xs sm:text-base hover:scale-105 transition-all animate-pulse-glow animate-slide-up"
          style={{ animationDelay: '0.45s', opacity: 0 }}
        >
          دەستپێبکە
        </button>
      </div>

      {/* Scroll indicator */}
      <div className="hidden sm:block absolute bottom-8 left-1/2 -translate-x-1/2 animate-float opacity-40">
        <ChevronDown className="w-6 h-6 text-white" />
      </div>
    </section>
  );
}
