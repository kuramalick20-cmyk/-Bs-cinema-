import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import { Loader2, BookOpen } from 'lucide-react';

interface YadiItem {
  id: string;
  title: string;
  description: string | null;
  category: string;
  cover_image_url: string | null;
  is_vip: boolean;
  video_url?: string | null;
  tags: string[] | null;
}

interface YadiJaranProps {
  onOpenAuth: () => void;
}

export default function YadiJaran({ onOpenAuth }: YadiJaranProps) {
  const { t } = useI18n();
  const [items, setItems] = useState<YadiItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'old_songs' | 'old_movies'>('all');

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      let query = supabase
        .from('content')
        .select('id, title, description, category, cover_image_url, is_vip, tags')
        .eq('category', 'yadi_jaran')
        .order('created_at', { ascending: false });

      if (filter !== 'all') {
        query = query.contains('tags', [filter]);
      }

      const { data, error } = await query;
      if (!error && data) {
        setItems(data as YadiItem[]);
      }
      setLoading(false);
    };
    loadData();
  }, [filter]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      <div className="mb-8">
        <h2 className="text-2xl md:text-4xl font-black text-primary tracking-tight mb-2">
          {t('yadiJaran')}
        </h2>
        <p className="text-secondary text-sm">{t('yadiJaranDesc')}</p>
      </div>

      {/* Filter tabs */}
      <div className="flex items-center gap-2 mb-6">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${filter === 'all' ? 'bg-accent text-white' : 'bg-card border border-default text-secondary hover:text-primary'}`}
        >
          {t('all')}
        </button>
        <button
          onClick={() => setFilter('old_songs')}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${filter === 'old_songs' ? 'bg-accent text-white' : 'bg-card border border-default text-secondary hover:text-primary'}`}
        >
          {t('oldSongs')}
        </button>
        <button
          onClick={() => setFilter('old_movies')}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${filter === 'old_movies' ? 'bg-accent text-white' : 'bg-card border border-default text-secondary hover:text-primary'}`}
        >
          {t('oldMovies')}
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-accent animate-spin" />
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-20 text-secondary">
          <BookOpen className="w-12 h-12 mx-auto mb-4 text-muted" />
          <p className="text-lg">{t('noContent')}</p>
          <p className="text-sm text-muted mt-2">{t('noContentSoon')}</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4">
          {items.map((item, i) => (
            <div
              key={item.id}
              className="animate-slide-up cursor-pointer group"
              style={{ animationDelay: `${Math.min(i * 0.03, 0.45)}s`, opacity: 0 }}
              onClick={() => {
                // Navigate to content detail - use existing flow
                window.dispatchEvent(new CustomEvent('open-content', { detail: { id: item.id } }));
              }}
            >
              <div className="relative aspect-[2/3] rounded-xl overflow-hidden bg-card border border-default group-hover:border-accent/50 transition-all group-hover:scale-[1.03] transition-transform">
                {item.cover_image_url ? (
                  <img src={item.cover_image_url} alt={item.title} className="w-full h-full object-cover" loading="lazy" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <BookOpen className="w-8 h-8 text-muted" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-2">
                  <p className="text-white text-xs font-medium truncate" dir="auto">{item.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
