import { Play, BookOpen } from 'lucide-react';
import type { ContentItem } from '@/lib/supabase';
import { CATEGORY_LABELS } from '@/lib/categories';

interface ContentCardProps {
  item: ContentItem;
  onClick: () => void;
}

export default function ContentCard({ item, onClick }: ContentCardProps) {
  return (
    <button
      onClick={onClick}
      className="card-hover premium-card group relative rounded-2xl overflow-hidden bg-card border border-default text-right w-full shadow-card"
    >
      {/* Cover */}
      <div className="aspect-[2/3] relative overflow-hidden">
        {item.cover_image_url ? (
          <img
            src={item.cover_image_url}
            alt={item.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            loading="lazy"
            decoding="async"
            style={{ color: 'transparent' }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-hover">
            {item.category === 'comic' ? (
              <BookOpen className="w-12 h-12 text-muted" />
            ) : (
              <Play className="w-12 h-12 text-muted" />
            )}
          </div>
        )}
        {/* Bottom gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-transparent" />
        {/* Play icon on hover */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-14 h-14 rounded-full bg-accent flex items-center justify-center shadow-glow scale-75 group-hover:scale-100 transition-transform duration-300">
            {item.category === 'comic' ? (
              <BookOpen className="w-6 h-6 text-white" />
            ) : (
              <Play className="w-6 h-6 text-white ml-0.5" fill="white" />
            )}
          </div>
        </div>
        {/* Amber top border on hover */}
        <div className="absolute top-0 left-0 right-0 h-0.5 bg-accent scale-x-0 group-hover:scale-x-100 transition-transform duration-400 origin-right" />
        {/* Category badge */}
        <div className="absolute top-2.5 right-2.5 px-2.5 py-1 rounded-lg glass-dark text-[10px] font-medium text-white/90 tracking-wide">
          {CATEGORY_LABELS[item.category]}
        </div>
        {/* VIP badge */}
        {item.is_vip && (
          <div className="absolute top-2.5 left-2.5 px-2 py-1 rounded-lg bg-accent/90 text-white text-[10px] font-bold tracking-wide">
            VIP
          </div>
        )}
        {/* Title overlay at bottom */}
        <div className="absolute bottom-0 left-0 right-0 p-3">
          <h3 className="text-sm font-bold text-white line-clamp-2 drop-shadow-lg">{item.title}</h3>
          {item.dubbing_group && (
            <p className="text-[11px] text-white/60 mt-0.5">{item.dubbing_group}</p>
          )}
        </div>
      </div>
    </button>
  );
}
