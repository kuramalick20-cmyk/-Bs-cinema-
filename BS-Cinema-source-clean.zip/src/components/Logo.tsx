interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
}

export default function Logo({ size = 'md' }: LogoProps) {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-16 h-16',
  };
  const textSizes = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-4xl md:text-5xl',
  };
  const subSizes = {
    sm: 'text-[8px]',
    md: 'text-[9px]',
    lg: 'text-sm',
  };
  const uid = `bs-${size}`;

  return (
    <div className="flex items-center gap-2 select-none">
      {/* Kurdistan-themed BS monogram */}
      <div className={`relative ${iconSizes[size]} flex-shrink-0`}>
        <svg viewBox="0 0 100 100" className="w-full h-full" aria-hidden="true">
          <defs>
            <linearGradient id={`${uid}-bg`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ef3340" />
              <stop offset="45%" stopColor="#0c0c12" />
              <stop offset="100%" stopColor="#2bb24c" />
            </linearGradient>
            <radialGradient id={`${uid}-sun`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f9e300" />
              <stop offset="100%" stopColor="#c5a016" />
            </radialGradient>
          </defs>

          {/* Rounded square with Kurdistan flag gradient */}
          <rect x="4" y="4" width="92" height="92" rx="22" fill={`url(#${uid}-bg)`} />
          {/* White horizontal stripe */}
          <rect x="4" y="40" width="92" height="20" fill="rgba(255,255,255,0.85)" />
          <rect x="4" y="4" width="92" height="92" rx="22" fill="none" stroke="rgba(107,159,255,0.15)" strokeWidth="1" />

          {/* 21 sun rays */}
          {Array.from({ length: 21 }).map((_, i) => {
            const angle = (i * 360) / 21;
            const rad = (angle * Math.PI) / 180;
            const cx = 50, cy = 50;
            const inner = 30, outer = 40;
            const spread = 0.045;
            const x1 = cx + Math.cos(rad - spread) * inner;
            const y1 = cy + Math.sin(rad - spread) * inner;
            const x2 = cx + Math.cos(rad) * outer;
            const y2 = cy + Math.sin(rad) * outer;
            const x3 = cx + Math.cos(rad + spread) * inner;
            const y3 = cy + Math.sin(rad + spread) * inner;
            return (
              <polygon
                key={i}
                points={`${x1},${y1} ${x2},${y2} ${x3},${y3}`}
                fill={`url(#${uid}-sun)`}
                opacity="0.6"
              />
            );
          })}

          {/* Sun circle */}
          <circle cx="50" cy="50" r="22" fill={`url(#${uid}-sun)`} opacity="0.2" />

          {/* BS text */}
          <text
            x="50" y="57"
            textAnchor="middle"
            fontFamily="'Cairo', system-ui, sans-serif"
            fontWeight="900"
            fontSize="40"
            fill="white"
            letterSpacing="-2"
            style={{ filter: 'drop-shadow(0 1px 3px rgba(0,0,0,0.6))' }}
          >
            BS
          </text>
        </svg>
      </div>

      {/* Wordmark */}
      <div className="flex flex-col leading-none">
        <span className={`${textSizes[size]} font-black tracking-tight text-primary`}>
          BS <span style={{ color: 'var(--accent)' }}>Cinema</span>
        </span>
        <span className={`${subSizes[size]} font-medium text-muted tracking-[0.25em] uppercase mt-0.5`}>
          Kurdistan
        </span>
      </div>
    </div>
  );
}
