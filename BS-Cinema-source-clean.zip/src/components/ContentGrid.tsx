import { useEffect, useState, useRef, useCallback } from 'react';
import { Loader2, Film, ChevronLeft, ChevronRight } from 'lucide-react';
import ContentCard from './ContentCard';
import AdSlot from './AdSlot';
import type { ContentItem, ContentCategory } from '@/lib/supabase';
import { fetchContentList, invalidateContentCache } from '@/lib/contentCache';
import { CATEGORIES, CATEGORY_LABELS } from '@/lib/categories';

interface ContentGridProps {
  category: ContentCategory | 'all';
  searchQuery: string;
  onItemClick: (item: ContentItem) => void;
}

export default function ContentGrid({ category, searchQuery, onItemClick }: ContentGridProps) {
  const [items, setItems] = useState<ContentItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await fetchContentList(category, searchQuery);
        setItems(data);
      } catch (err: any) {
        setError(err.message || 'هەڵە لە بارکردن');
      }
      setLoading(false);
    }, searchQuery.trim() ? 300 : 0);

    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [category, searchQuery]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-accent animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-20 text-red-400">
        <p>هەڵە: {error}</p>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="text-center py-20 text-secondary">
        <Film className="w-12 h-12 mx-auto mb-4 text-muted" />
        <p className="text-lg">هیچ ناوەڕۆکێک نەدۆزرایەوە</p>
        <p className="text-sm text-muted mt-2">بەم زووانە ناوەڕۆک زیاد دەکرێت</p>
      </div>
    );
  }

  // Search or specific category — flat grid
  if (searchQuery.trim() || category !== 'all') {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2 sm:gap-3 md:gap-4">
        {items.map((item, i) => (
          <div key={item.id}>
            <div className="animate-slide-up" style={{ animationDelay: `${Math.min(i * 0.02, 0.4)}s`, opacity: 0 }}>
              <ContentCard item={item} onClick={() => onItemClick(item)} />
            </div>
            {i > 0 && i % 8 === 7 && (
              <div className="col-span-2 sm:col-span-3 md:col-span-4 lg:col-span-5 xl:col-span-6 my-2">
                <AdSlot placement="between-content" />
              </div>
            )}
          </div>
        ))}
      </div>
    );
  }

  // "All" view — horizontal carousels by category
  const itemsByCategory: Record<string, ContentItem[]> = {};
  for (const item of items) {
    if (!itemsByCategory[item.category]) itemsByCategory[item.category] = [];
    itemsByCategory[item.category].push(item);
  }

  const rows = CATEGORIES.filter((cat) => itemsByCategory[cat.key]?.length > 0);

  return (
    <div className="space-y-6 sm:space-y-8 md:space-y-12">
      {rows.map((cat, rowIdx) => (
        <div key={cat.key}>
          <CarouselRow
            title={CATEGORY_LABELS[cat.key]}
            items={itemsByCategory[cat.key]}
            onItemClick={onItemClick}
          />
          {rowIdx === Math.floor(rows.length / 2) && (
            <div className="mt-6 sm:mt-8 md:mt-12">
              <AdSlot placement="between-content" />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function CarouselRow({ title, items, onItemClick }: { title: string; items: ContentItem[]; onItemClick: (item: ContentItem) => void }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  const rafRef = useRef<number | null>(null);

  const updateScrollButtons = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(() => {
      const el = scrollRef.current;
      if (!el) return;
      const maxScroll = el.scrollWidth - el.clientWidth;
      const current = Math.abs(el.scrollLeft);
      setCanScrollRight(current < maxScroll - 2);
      setCanScrollLeft(current > 2);
    });
  }, []);

  useEffect(() => {
    updateScrollButtons();
    const el = scrollRef.current;
    if (!el) return;
    el.addEventListener('scroll', updateScrollButtons, { passive: true });
    return () => {
      el.removeEventListener('scroll', updateScrollButtons);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [updateScrollButtons]);

  const scroll = (direction: 'left' | 'right') => {
    const el = scrollRef.current;
    if (!el) return;
    const amount = el.clientWidth * 0.8;
    el.scrollBy({ left: direction === 'left' ? -amount : amount, behavior: 'smooth' });
  };

  return (
    <div className="group/row">
      <div className="flex items-center justify-between mb-3 sm:mb-4 px-1">
        <h3 className="text-base sm:text-lg md:text-2xl font-bold text-primary tracking-tight flex items-center gap-2.5">
          <span className="w-1 h-5 md:h-7 rounded-full bg-accent" style={{ boxShadow: '0 0 8px var(--shadow-glow)' }} />
          {title}
          <span className="text-accent text-xs sm:text-sm font-normal">({items.length})</span>
        </h3>
        <div className="flex items-center gap-1.5 opacity-0 group-hover/row:opacity-100 transition-opacity">
          <button
            onClick={() => scroll('right')}
            disabled={!canScrollLeft}
            className="p-1.5 rounded-full glass-dark text-white hover:text-accent transition-colors disabled:opacity-20"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
          <button
            onClick={() => scroll('left')}
            disabled={!canScrollRight}
            className="p-1.5 rounded-full glass-dark text-white hover:text-accent transition-colors disabled:opacity-20"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>
      </div>
      <div
        ref={scrollRef}
        className="flex gap-2.5 sm:gap-3 md:gap-4 overflow-x-auto carousel-hide-scroll pb-2 -mx-1 px-1"
        style={{ scrollBehavior: 'smooth' }}
      >
        {items.map((item, i) => (
          <div
            key={item.id}
            className="flex-shrink-0 w-[142px] sm:w-[170px] md:w-[195px] animate-slide-up"
            style={{ animationDelay: `${Math.min(i * 0.03, 0.45)}s`, opacity: 0 }}
          >
            <ContentCard item={item} onClick={() => onItemClick(item)} />
          </div>
        ))}
      </div>
    </div>
  );
}

export { invalidateContentCache };
