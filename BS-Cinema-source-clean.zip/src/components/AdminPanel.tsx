import { useState, useEffect } from 'react';
import {
  X, Lock, Plus, Edit2, Trash2, Upload, Link2, Film, BookOpen,
  List, Music, Image as ImageIcon, Save, Loader2, ChevronDown, ChevronUp, Eye, EyeOff,
  ArrowUp, ArrowDown, RefreshCw, MessageSquare, BarChart3, Settings as SettingsIcon, Star, Cloud,
  Crown, Check, XCircle, Bell, Megaphone, Languages, Video as VideoIcon, Smartphone, Sparkles, Volume2
} from 'lucide-react';
import type { ContentItem, ContentCategory, Episode, ComicChapter, ComicPanel, VipPayment, Ad, ComicImageTranslation, Subtitle as SubtitleType } from '@/lib/supabase';
import { supabase } from '@/lib/supabase';
import { uploadFile, uploadVideoChunked, validateVideoFile, type ChunkedUploadState } from '@/lib/storage';
import { CATEGORIES, CATEGORY_LABELS } from '@/lib/categories';
import { useAdmin } from '@/context/AdminContext';
import { getSiteSettings, updateSiteSettings, type SiteSettings, type SocialLinks as SocialLinksData } from '@/lib/settings';
import { DEFAULT_SOCIAL_LINKS } from '@/lib/settings';
import { formatCount } from '@/lib/engagement';
import { fetchSubtitles, saveAISubtitles, deleteSubtitles, generateSubtitlesFromTranscript } from '@/lib/subtitles';
import AdminAISettings from './AdminAISettings';

interface AdminPanelProps {
  onClose: () => void;
}

type Tab = 'content' | 'episodes' | 'chapters' | 'comments' | 'engagement' | 'settings' | 'vip' | 'ads' | 'notifications' | 'translations' | 'subtitles' | 'ai';

export default function AdminPanel({ onClose }: AdminPanelProps) {
  const { isAdmin, adminUnlock, adminLoading } = useAdmin();
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [passwordError, setPasswordError] = useState(false);

  const [tab, setTab] = useState<Tab>('content');
  const [items, setItems] = useState<ContentItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingItem, setEditingItem] = useState<ContentItem | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [expandedItem, setExpandedItem] = useState<string | null>(null);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [chapters, setChapters] = useState<ComicChapter[]>([]);
  const [panels, setPanels] = useState<ComicPanel[]>([]);
  const [expandedChapter, setExpandedChapter] = useState<string | null>(null);

  // Comments management
  const [allComments, setAllComments] = useState<any[]>([]);
  const [commentsLoading, setCommentsLoading] = useState(false);

  // Settings
  const [siteSettings, setSiteSettings] = useState<SiteSettings | null>(null);
  const [socialLinks, setSocialLinks] = useState<SocialLinksData>(DEFAULT_SOCIAL_LINKS);
  const [adsEnabled, setAdsEnabled] = useState(true);
  const [adClientId, setAdClientId] = useState('');
  const [settingsSaving, setSettingsSaving] = useState(false);

  // Engagement stats
  const [engagementStats, setEngagementStats] = useState<Record<string, { views: number; stars: number }>>({});

  // VIP payments
  const [vipPayments, setVipPayments] = useState<VipPayment[]>([]);
  const [vipLoading, setVipLoading] = useState(false);

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ContentCategory>('movie');
  const [coverUrl, setCoverUrl] = useState('');
  const [tags, setTags] = useState('');
  const [dubbingGroup, setDubbingGroup] = useState('');
  const [authorName, setAuthorName] = useState('');
  const [chapterNotice, setChapterNotice] = useState('');
  const [isVipContent, setIsVipContent] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);

  // Episode form + edit
  const [epNumber, setEpNumber] = useState('1');
  const [epTitle, setEpTitle] = useState('');
  const [epVideoType, setEpVideoType] = useState<'upload' | 'link' | 'gdrive'>('upload');
  const [epVideoUrl, setEpVideoUrl] = useState('');
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [videoUploadProgress, setVideoUploadProgress] = useState(0);
  const [videoUploadError, setVideoUploadError] = useState<string | null>(null);
  const [selectedContentId, setSelectedContentId] = useState<string | null>(null);
  const [editingEpisode, setEditingEpisode] = useState<Episode | null>(null);
  const [showEpForm, setShowEpForm] = useState(false);

  // Chapter form + edit
  const [chNumber, setChNumber] = useState('1');
  const [chTitle, setChTitle] = useState('');
  const [chMusicUrl, setChMusicUrl] = useState('');
  const [uploadingMusic, setUploadingMusic] = useState(false);
  const [chPanels, setChPanels] = useState<string[]>([]);
  const [uploadingPanel, setUploadingPanel] = useState(false);
  const [editingChapter, setEditingChapter] = useState<ComicChapter | null>(null);
  const [showChForm, setShowChForm] = useState(false);
  const [chFormat, setChFormat] = useState('default');

  // Music tracks for chapter
  const [chapterTracks, setChapterTracks] = useState<Array<{ track_url: string; track_name: string; start_panel: number | null; end_panel: number | null; track_order: number }>>([]);
  const [uploadingTrack, setUploadingTrack] = useState(false);

  // Ads management
  const [ads, setAds] = useState<Ad[]>([]);
  const [adsLoading, setAdsLoading] = useState(false);
  const [showAdForm, setShowAdForm] = useState(false);
  const [adTitle, setAdTitle] = useState('');
  const [adImageUrl, setAdImageUrl] = useState('');
  const [adLinkUrl, setAdLinkUrl] = useState('');
  const [adPosition, setAdPosition] = useState('homepage-top');
  const [uploadingAd, setUploadingAd] = useState(false);

  // Notifications
  const [notifTitle, setNotifTitle] = useState('');
  const [notifBody, setNotifBody] = useState('');
  const [notifType, setNotifType] = useState('new_content');
  const [sendingNotif, setSendingNotif] = useState(false);

  // Translation review
  const [pendingTranslations, setPendingTranslations] = useState<ComicImageTranslation[]>([]);
  const [translationsLoading, setTranslationsLoading] = useState(false);

  // AI Subtitles
  const [subtitleItems, setSubtitleItems] = useState<ContentItem[]>([]);
  const [subtitlesForEp, setSubtitlesForEp] = useState<SubtitleType[]>([]);
  const [selectedEpForSubs, setSelectedEpForSubs] = useState<string | null>(null);
  const [subtitleEntries, setSubtitleEntries] = useState<Array<{ content: string; start_time: string; end_time: string }>>([{ content: '', start_time: '', end_time: '' }]);
  const [subtitleLang, setSubtitleLang] = useState<'ku' | 'en'>('ku');
  const [savingSubtitles, setSavingSubtitles] = useState(false);
  const [transcriptText, setTranscriptText] = useState('');
  const [transcriptSourceLang, setTranscriptSourceLang] = useState<'ku' | 'en'>('ku');
  const [generatingSubs, setGeneratingSubs] = useState(false);

  const [authError, setAuthError] = useState<string | null>(null);
  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setPasswordError(false);
    const result = await adminUnlock(passwordInput);
    if (result.error) {
      setPasswordError(true);
      setAuthError(result.error);
    }
    setPasswordInput('');
  };

  const loadItems = async () => {
    setLoading(true);
    const { data } = await supabase.from('content').select('*').order('created_at', { ascending: false });
    setItems(data as ContentItem[]);
    setLoading(false);
  };

  const loadAllComments = async () => {
    setCommentsLoading(true);
    const { data } = await supabase
      .from('comments')
      .select('*, profiles:profiles(username, avatar_url)')
      .order('created_at', { ascending: false })
      .limit(100);
    setAllComments(data || []);
    setCommentsLoading(false);
  };

  const loadSettings = async () => {
    const s = await getSiteSettings();
    if (s) {
      setSiteSettings(s);
      setSocialLinks(s.social_links);
      setAdsEnabled(s.ads_enabled);
      setAdClientId(s.ad_client_id || '');
    }
  };

  const handleSaveSettings = async () => {
    setSettingsSaving(true);
    await updateSiteSettings({
      social_links: socialLinks,
      ads_enabled: adsEnabled,
      ad_client_id: adClientId || null,
    });
    setSettingsSaving(false);
  };

  const handleDeleteComment = async (id: string) => {
    await supabase.from('comments').delete().eq('id', id);
    await loadAllComments();
  };

  const loadEngagementStats = async (contentItems: ContentItem[]) => {
    const stats: Record<string, { views: number; stars: number }> = {};
    for (const item of contentItems) {
      const { data: vData } = await supabase.rpc('get_view_count', { p_item_type: 'content', p_item_id: item.id });
      const { data: sData } = await supabase.rpc('get_star_count', { p_item_type: 'content', p_item_id: item.id });
      stats[item.id] = { views: (vData as number) || 0, stars: (sData as number) || 0 };
    }
    setEngagementStats(stats);
  };

  const loadVipPayments = async () => {
    setVipLoading(true);
    const { data } = await supabase
      .from('vip_payments')
      .select('*, profiles:profiles(username, avatar_url, phone, vip_status, trial_end_date, vip_end_date)')
      .order('created_at', { ascending: false });
    setVipPayments(data as VipPayment[] || []);
    setVipLoading(false);
  };

  const loadAds = async () => {
    setAdsLoading(true);
    const { data } = await supabase.from('ads').select('*').order('created_at', { ascending: false });
    setAds((data as Ad[]) || []);
    setAdsLoading(false);
  };

  const loadPendingTranslations = async () => {
    setTranslationsLoading(true);
    const { data } = await supabase
      .from('comic_image_translations')
      .select('*, comic_panels!inner(image_url, panel_order)')
      .eq('is_approved', false)
      .order('created_at', { ascending: false });
    setPendingTranslations((data as any[]) || []);
    setTranslationsLoading(false);
  };

  const handleApproveVip = async (payment: VipPayment) => {
    const now = new Date();
    const vipEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    await supabase.from('vip_payments').update({
      status: 'approved',
      reviewed_at: now.toISOString(),
    }).eq('id', payment.id);
    await supabase.from('profiles').update({
      vip_status: 'vip',
      vip_start_date: now.toISOString(),
      vip_end_date: vipEnd.toISOString(),
    }).eq('id', payment.user_id);
    await loadVipPayments();
  };

  const handleRejectVip = async (payment: VipPayment) => {
    await supabase.from('vip_payments').update({
      status: 'rejected',
      reviewed_at: new Date().toISOString(),
    }).eq('id', payment.id);
    await loadVipPayments();
  };

  // === Ad handlers ===
  const handleAdImageUpload = async (file: File) => {
    setUploadingAd(true);
    const url = await uploadFile('covers', file);
    if (url) setAdImageUrl(url);
    setUploadingAd(false);
  };

  const handleSaveAd = async () => {
    await supabase.from('ads').insert({
      title: adTitle || null,
      image_url: adImageUrl || null,
      link_url: adLinkUrl || null,
      position: adPosition,
      is_active: true,
    });
    setAdTitle(''); setAdImageUrl(''); setAdLinkUrl(''); setAdPosition('homepage-top');
    setShowAdForm(false);
    await loadAds();
  };

  const handleToggleAd = async (ad: Ad) => {
    await supabase.from('ads').update({ is_active: !ad.is_active }).eq('id', ad.id);
    await loadAds();
  };

  const handleDeleteAd = async (id: string) => {
    await supabase.from('ads').delete().eq('id', id);
    await loadAds();
  };

  // === Notification handler ===
  const handleSendNotification = async () => {
    if (!notifTitle.trim()) return;
    setSendingNotif(true);
    // Get all users
    const { data: profiles } = await supabase.from('profiles').select('id');
    if (profiles && profiles.length > 0) {
      const notifs = profiles.map((p) => ({
        user_id: (p as any).id,
        type: notifType,
        title: notifTitle,
        body: notifBody || null,
        is_read: false,
      }));
      // Insert in batches
      for (let i = 0; i < notifs.length; i += 100) {
        await supabase.from('notifications').insert(notifs.slice(i, i + 100));
      }
    }
    setNotifTitle(''); setNotifBody('');
    setSendingNotif(false);
    alert('ئاگادارکردنەوە نێردرا!');
  };

  // === Translation review handlers ===
  const handleApproveTranslation = async (tr: ComicImageTranslation) => {
    await supabase.from('comic_image_translations').update({ is_approved: true }).eq('id', tr.id);
    await loadPendingTranslations();
  };

  const handleDeleteTranslation = async (id: string) => {
    await supabase.from('comic_image_translations').delete().eq('id', id);
    await loadPendingTranslations();
  };

  const handleUpdateTranslationText = async (id: string, newText: string) => {
    await supabase.from('comic_image_translations').update({ translated_text: newText }).eq('id', id);
  };

  // === AI Subtitle handlers ===
  const loadVideoContentItems = async () => {
    const { data } = await supabase.from('content').select('*').neq('category', 'comic').order('created_at', { ascending: false });
    setSubtitleItems((data as ContentItem[]) || []);
  };

  const loadSubtitlesForEpisode = async (episodeId: string, lang: 'ku' | 'en') => {
    const subs = await fetchSubtitles('episode', episodeId);
    const filtered = subs.filter((s) => s.language === lang);
    setSubtitlesForEp(filtered);
    if (filtered.length > 0) {
      setSubtitleEntries(filtered.map((s) => ({
        content: s.content || '',
        start_time: s.start_time != null ? formatTime(s.start_time) : '',
        end_time: s.end_time != null ? formatTime(s.end_time) : '',
      })));
    } else {
      setSubtitleEntries([{ content: '', start_time: '', end_time: '' }]);
    }
  };

  const formatTime = (seconds: number): string => {
    const mm = Math.floor(seconds / 60);
    const ss = Math.floor(seconds % 60);
    return `${mm}:${ss.toString().padStart(2, '0')}`;
  };

  const parseTime = (str: string): number => {
    const parts = str.split(':');
    if (parts.length === 2) {
      return parseInt(parts[0]) * 60 + parseFloat(parts[1]);
    }
    return parseFloat(str) || 0;
  };

  const handleSaveSubtitles = async () => {
    if (!selectedEpForSubs) return;
    setSavingSubtitles(true);
    const validEntries = subtitleEntries.filter((e) => e.content.trim() && e.start_time && e.end_time);
    if (validEntries.length === 0) {
      setSavingSubtitles(false);
      return;
    }
    const subs = validEntries.map((e) => ({
      content: e.content.trim(),
      start_time: parseTime(e.start_time),
      end_time: parseTime(e.end_time),
      source_text: e.content.trim(),
    }));
    const result = await saveAISubtitles(selectedEpForSubs, subtitleLang, subs);
    if (result.success) {
      await loadSubtitlesForEpisode(selectedEpForSubs, subtitleLang);
      alert('ژێرنووسەکان پاشەکەوتکران');
    } else {
      alert('هەڵە: ' + result.error);
    }
    setSavingSubtitles(false);
  };

  const handleDeleteSubtitles = async () => {
    if (!selectedEpForSubs) return;
    if (!confirm('دڵنیایت لە سڕینەوەی هەموو ژێرنووسەکان بۆ ئەم ئەلقەیە؟')) return;
    await deleteSubtitles(selectedEpForSubs, subtitleLang);
    await loadSubtitlesForEpisode(selectedEpForSubs, subtitleLang);
    alert('ژێرنووسەکان سڕانەوە');
  };

  const handleGenerateFromTranscript = async () => {
    if (!selectedEpForSubs || !transcriptText.trim()) return;
    setGeneratingSubs(true);
    const result = await generateSubtitlesFromTranscript(selectedEpForSubs, subtitleLang, transcriptText.trim(), transcriptSourceLang);
    if (result.success) {
      await loadSubtitlesForEpisode(selectedEpForSubs, subtitleLang);
      setTranscriptText('');
      alert('ژێرنووسەکان لە دەقەوە دروستکران');
    } else {
      alert('هەڵە: ' + result.error);
    }
    setGeneratingSubs(false);
  };

  useEffect(() => {
    if (isAdmin) {
      loadItems();
      loadAllComments();
      loadSettings();
      loadVipPayments();
      loadAds();
      loadPendingTranslations();
    }
  }, [isAdmin]);

  const loadEpisodesAndChapters = async (contentId: string) => {
    const { data: eps } = await supabase.from('episodes').select('*').eq('content_id', contentId).order('episode_number', { ascending: true });
    setEpisodes(eps as Episode[]);
    const { data: chs } = await supabase.from('comic_chapters').select('*').eq('content_id', contentId).order('chapter_number', { ascending: true });
    setChapters(chs as ComicChapter[]);
  };

  const loadPanels = async (chapterId: string) => {
    const { data: p } = await supabase.from('comic_panels').select('*').eq('chapter_id', chapterId).order('panel_order', { ascending: true });
    setPanels(p as ComicPanel[]);
  };

  const handleExpand = (item: ContentItem) => {
    if (expandedItem === item.id) {
      setExpandedItem(null);
    } else {
      setExpandedItem(item.id);
      setSelectedContentId(item.id);
      loadEpisodesAndChapters(item.id);
    }
  };

  const handleExpandChapter = (ch: ComicChapter) => {
    if (expandedChapter === ch.id) {
      setExpandedChapter(null);
    } else {
      setExpandedChapter(ch.id);
      loadPanels(ch.id);
    }
  };

  // === Content CRUD ===
  const resetForm = () => {
    setTitle(''); setDescription(''); setCategory('movie');
    setCoverUrl(''); setTags(''); setDubbingGroup('');
    setAuthorName(''); setChapterNotice(''); setIsVipContent(false);
    setEditingItem(null); setShowForm(false);
  };

  const startEdit = (item: ContentItem) => {
    setEditingItem(item);
    setTitle(item.title);
    setDescription(item.description || '');
    setCategory(item.category);
    setCoverUrl(item.cover_image_url || '');
    setTags((item.tags || []).join(', '));
    setDubbingGroup(item.dubbing_group || '');
    setAuthorName(item.author_name || '');
    setChapterNotice(item.chapter_notice || '');
    setIsVipContent(item.is_vip || false);
    setShowForm(true);
  };

  const handleSaveContent = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const payload = {
      title, description: description || null, category,
      cover_image_url: coverUrl || null,
      tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
      dubbing_group: dubbingGroup || null,
      author_name: category === 'comic' ? (authorName || null) : null,
      chapter_notice: category === 'comic' ? (chapterNotice || null) : null,
      is_vip: isVipContent,
    };
    if (editingItem) {
      const { error: updError } = await supabase.from('content').update(payload).eq('id', editingItem.id);
      if (updError) {
        alert('هەڵە لە نوێژکردنەوە: ' + updError.message);
        setLoading(false);
        return;
      }
    } else {
      const { data: newItem, error: insError } = await supabase.from('content').insert(payload).select().maybeSingle();
      if (insError) {
        alert('هەڵە لە زیادکردن: ' + insError.message);
        setLoading(false);
        return;
      }
      if (newItem) {
        const catLabel = CATEGORY_LABELS[category as ContentCategory] || 'ناوەڕۆک';
        const notifTitle = `ئەمڕۆ ${catLabel}ێکی نوێ زیاد کرا`;
        const notifBody = `${title}`;
        const { data: profiles } = await supabase.from('profiles').select('id');
        if (profiles && profiles.length > 0) {
          const notifs = profiles.map((p) => ({
            user_id: (p as any).id,
            type: isVipContent ? 'new_vip_content' : 'new_content',
            title: notifTitle,
            body: notifBody,
            link_id: (newItem as any).id,
            is_read: false,
          }));
          for (let i = 0; i < notifs.length; i += 100) {
            await supabase.from('notifications').insert(notifs.slice(i, i + 100));
          }
        }
      }
    }
    resetForm();
    await loadItems();
    setLoading(false);
  };

  const handleDeleteContent = async (id: string) => {
    if (!confirm('دڵنیایت لە سڕینەوەی ئەم ناوەڕۆکە؟')) return;
    await supabase.from('content').delete().eq('id', id);
    await loadItems();
  };

  const handleCoverUpload = async (file: File) => {
    setUploadingCover(true);
    const url = await uploadFile('covers', file);
    if (url) setCoverUrl(url);
    setUploadingCover(false);
  };

  // === Move content up/down ===
  const moveContent = async (item: ContentItem, direction: 'up' | 'down') => {
    const sorted = [...items];
    const idx = sorted.findIndex((i) => i.id === item.id);
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sorted.length) return;
    const swapItem = sorted[swapIdx];
    // Swap created_at to reorder
    const tempDate = item.created_at;
    await supabase.from('content').update({ created_at: swapItem.created_at }).eq('id', item.id);
    await supabase.from('content').update({ created_at: tempDate }).eq('id', swapItem.id);
    await loadItems();
  };

  // === Episode CRUD ===
  const resetEpForm = () => {
    setEpNumber('1'); setEpTitle(''); setEpVideoType('upload');
    setEpVideoUrl(''); setEditingEpisode(null); setShowEpForm(false);
  };

  const startEditEpisode = (ep: Episode) => {
    setEditingEpisode(ep);
    setEpNumber(String(ep.episode_number));
    setEpTitle(ep.title || '');
    setEpVideoType(ep.video_type);
    setEpVideoUrl(ep.video_url);
    setShowEpForm(true);
  };

  const handleVideoUpload = async (file: File) => {
    const validationError = validateVideoFile(file);
    if (validationError) {
      setVideoUploadError(validationError);
      return;
    }
    setVideoUploadError(null);
    setUploadingVideo(true);
    setVideoUploadProgress(0);
    const url = await uploadVideoChunked('videos', file, 'episodes/', (state: ChunkedUploadState) => {
      setVideoUploadProgress(state.progress);
      if (state.error) setVideoUploadError(state.error);
    });
    if (url) setEpVideoUrl(url);
    setUploadingVideo(false);
  };

  const handleSaveEpisode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedContentId) return;
    setLoading(true);
    if (editingEpisode) {
      await supabase.from('episodes').update({
        episode_number: parseInt(epNumber),
        title: epTitle || null,
        video_type: epVideoType,
        video_url: epVideoUrl,
      }).eq('id', editingEpisode.id);
    } else {
      await supabase.from('episodes').insert({
        content_id: selectedContentId,
        episode_number: parseInt(epNumber),
        title: epTitle || null,
        video_type: epVideoType,
        video_url: epVideoUrl,
      });
    }
    resetEpForm();
    await loadEpisodesAndChapters(selectedContentId);
    setLoading(false);
  };

  const handleDeleteEpisode = async (id: string) => {
    await supabase.from('episodes').delete().eq('id', id);
    if (selectedContentId) await loadEpisodesAndChapters(selectedContentId);
  };

  const moveEpisode = async (ep: Episode, direction: 'up' | 'down') => {
    const sorted = [...episodes];
    const idx = sorted.findIndex((e) => e.id === ep.id);
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sorted.length) return;
    const swapEp = sorted[swapIdx];
    await supabase.from('episodes').update({ episode_number: swapEp.episode_number }).eq('id', ep.id);
    await supabase.from('episodes').update({ episode_number: ep.episode_number }).eq('id', swapEp.id);
    if (selectedContentId) await loadEpisodesAndChapters(selectedContentId);
  };

  // === Chapter CRUD ===
  const resetChForm = () => {
    setChNumber('1'); setChTitle(''); setChMusicUrl('');
    setChPanels([]); setEditingChapter(null); setShowChForm(false);
    setChFormat('default'); setChapterTracks([]);
  };

  const startEditChapter = (ch: ComicChapter) => {
    setEditingChapter(ch);
    setChNumber(String(ch.chapter_number));
    setChTitle(ch.title || '');
    setChMusicUrl(ch.background_music_url || '');
    setChFormat(ch.format || 'default');
    setShowChForm(true);
    // Load existing tracks for this chapter
    supabase.from('comic_music_tracks').select('*').eq('chapter_id', ch.id).order('track_order', { ascending: true }).then(({ data }) => {
      setChapterTracks((data as any[]) || []);
    });
  };

  const handleMusicUpload = async (file: File) => {
    setUploadingMusic(true);
    const url = await uploadFile('music', file);
    if (url) setChMusicUrl(url);
    setUploadingMusic(false);
  };

  const handlePanelUpload = async (files: FileList) => {
    setUploadingPanel(true);
    const urls: string[] = [];
    for (const file of Array.from(files)) {
      const url = await uploadFile('panels', file);
      if (url) urls.push(url);
    }
    setChPanels((prev) => [...prev, ...urls]);
    setUploadingPanel(false);
  };

  const handleSaveChapter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedContentId) return;
    setLoading(true);
    if (editingChapter) {
      await supabase.from('comic_chapters').update({
        chapter_number: parseInt(chNumber),
        title: chTitle || null,
        background_music_url: chMusicUrl || null,
        format: chFormat,
      }).eq('id', editingChapter.id);
      if (chPanels.length > 0) {
        const panelInserts = chPanels.map((url, i) => ({
          chapter_id: editingChapter.id,
          image_url: url,
          panel_order: panels.length + i,
        }));
        await supabase.from('comic_panels').insert(panelInserts);
      }
      // Save music tracks
      for (const track of chapterTracks) {
        if (track.track_url) {
          await supabase.from('comic_music_tracks').insert({
            chapter_id: editingChapter.id,
            track_url: track.track_url,
            track_name: track.track_name || null,
            start_panel: track.start_panel,
            end_panel: track.end_panel,
            track_order: track.track_order,
          });
        }
      }
    } else {
      const { data: ch } = await supabase.from('comic_chapters').insert({
        content_id: selectedContentId,
        chapter_number: parseInt(chNumber),
        title: chTitle || null,
        background_music_url: chMusicUrl || null,
        format: chFormat,
      }).select().maybeSingle();
      if (ch && chPanels.length > 0) {
        const panelInserts = chPanels.map((url, i) => ({
          chapter_id: (ch as ComicChapter).id,
          image_url: url,
          panel_order: i,
        }));
        await supabase.from('comic_panels').insert(panelInserts);
      }
      if (ch) {
        for (const track of chapterTracks) {
          if (track.track_url) {
            await supabase.from('comic_music_tracks').insert({
              chapter_id: (ch as ComicChapter).id,
              track_url: track.track_url,
              track_name: track.track_name || null,
              start_panel: track.start_panel,
              end_panel: track.end_panel,
              track_order: track.track_order,
            });
          }
        }
      }
    }
    resetChForm();
    await loadEpisodesAndChapters(selectedContentId);
    setLoading(false);
  };

  const handleDeleteChapter = async (id: string) => {
    await supabase.from('comic_chapters').delete().eq('id', id);
    if (selectedContentId) await loadEpisodesAndChapters(selectedContentId);
  };

  const moveChapter = async (ch: ComicChapter, direction: 'up' | 'down') => {
    const sorted = [...chapters];
    const idx = sorted.findIndex((c) => c.id === ch.id);
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sorted.length) return;
    const swapCh = sorted[swapIdx];
    await supabase.from('comic_chapters').update({ chapter_number: swapCh.chapter_number }).eq('id', ch.id);
    await supabase.from('comic_chapters').update({ chapter_number: ch.chapter_number }).eq('id', swapCh.id);
    if (selectedContentId) await loadEpisodesAndChapters(selectedContentId);
  };

  // === Panel CRUD ===
  const handleDeletePanel = async (panel: ComicPanel) => {
    await supabase.from('comic_panels').delete().eq('id', panel.id);
    if (expandedChapter) await loadPanels(expandedChapter);
  };

  const movePanel = async (panel: ComicPanel, direction: 'up' | 'down') => {
    const sorted = [...panels];
    const idx = sorted.findIndex((p) => p.id === panel.id);
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sorted.length) return;
    const swapPanel = sorted[swapIdx];
    await supabase.from('comic_panels').update({ panel_order: swapPanel.panel_order }).eq('id', panel.id);
    await supabase.from('comic_panels').update({ panel_order: panel.panel_order }).eq('id', swapPanel.id);
    if (expandedChapter) await loadPanels(expandedChapter);
  };

  const handleReplacePanel = async (panel: ComicPanel, file: File) => {
    const url = await uploadFile('panels', file);
    if (url) {
      await supabase.from('comic_panels').update({ image_url: url, video_url: null }).eq('id', panel.id);
      if (expandedChapter) await loadPanels(expandedChapter);
    }
  };

  const handleSetPanelVideo = async (panel: ComicPanel, file: File) => {
    setUploadingPanel(true);
    const url = await uploadFile('panels', file);
    if (url) {
      await supabase.from('comic_panels').update({ video_url: url }).eq('id', panel.id);
      if (expandedChapter) await loadPanels(expandedChapter);
    }
    setUploadingPanel(false);
  };

  const handleRemovePanelVideo = async (panel: ComicPanel) => {
    await supabase.from('comic_panels').update({ video_url: null }).eq('id', panel.id);
    if (expandedChapter) await loadPanels(expandedChapter);
  };

  const handleAddPanelToExisting = async (chapterId: string, files: FileList) => {
    setUploadingPanel(true);
    const currentMaxOrder = panels.length > 0 ? Math.max(...panels.map((p) => p.panel_order)) : -1;
    let order = currentMaxOrder + 1;
    for (const file of Array.from(files)) {
      const url = await uploadFile('panels', file);
      if (url) {
        await supabase.from('comic_panels').insert({
          chapter_id: chapterId,
          image_url: url,
          panel_order: order,
        });
        order++;
      }
    }
    setUploadingPanel(false);
    await loadPanels(chapterId);
  };

  // Add video-only panel (no image, just video) to a chapter
  const handleAddVideoPanelToExisting = async (chapterId: string, file: File) => {
    setUploadingPanel(true);
    const currentMaxOrder = panels.length > 0 ? Math.max(...panels.map((p) => p.panel_order)) : -1;
    const url = await uploadFile('panels', file);
    if (url) {
      await supabase.from('comic_panels').insert({
        chapter_id: chapterId,
        image_url: url,
        video_url: url,
        panel_order: currentMaxOrder + 1,
      });
    }
    setUploadingPanel(false);
    await loadPanels(chapterId);
  };

  // Set sound for an individual panel
  const handleSetPanelSound = async (panel: ComicPanel, file: File) => {
    setUploadingPanel(true);
    const url = await uploadFile('music', file);
    if (url) {
      await supabase.from('comic_panels').update({ sound_url: url }).eq('id', panel.id);
      if (expandedChapter) await loadPanels(expandedChapter);
    }
    setUploadingPanel(false);
  };

  const handleRemovePanelSound = async (panel: ComicPanel) => {
    await supabase.from('comic_panels').update({ sound_url: null }).eq('id', panel.id);
    if (expandedChapter) await loadPanels(expandedChapter);
  };

  if (!isAdmin) {
    return (
      <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 animate-fade-in">
        <div className="absolute inset-0 bg-black/85 backdrop-blur-sm" onClick={onClose} />
        <div className="relative w-full max-w-sm bg-secondary rounded-2xl border border-default shadow-2xl p-8 animate-scale-in">
          <button onClick={onClose} className="absolute top-4 left-4 text-secondary hover:text-primary transition-colors">
            <X className="w-5 h-5" />
          </button>
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-accent" />
            </div>
            <h2 className="text-xl font-bold text-primary">بەڕێوبەری ماڵپەڕ</h2>
            <p className="text-sm text-secondary mt-1">تکایە وشەی نهێنی بنووسە</p>
          </div>
          <form onSubmit={handleAuth} className="space-y-3">
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="وشەی نهێنی"
                  className="w-full pr-10 pl-10 py-3 rounded-xl bg-card border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent transition-colors"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted hover:text-primary"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {passwordError && <p className="text-red-400 text-sm text-center">{authError || 'وشەی نهێنی هەڵەیە'}</p>}
              <button type="submit" disabled={adminLoading} className="w-full py-3 rounded-xl bg-accent text-white font-semibold text-sm hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50">
                {adminLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : null}
                چوونەژوورەوە
              </button>
            </form>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[80] bg-primary overflow-y-auto animate-fade-in">
      <div className="sticky top-0 z-10 glass border-b border-default px-4 py-3 flex items-center justify-between" style={{ paddingTop: 'calc(0.75rem + var(--safe-top))' }}>
        <h2 className="text-lg font-bold text-primary flex items-center gap-2">
          <Lock className="w-5 h-5 text-accent" /> بەڕێوبەری ماڵپەڕ
        </h2>
        <button onClick={onClose} className="p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-5xl mx-auto p-4 md:p-6">
        {/* Tabs */}
        <div className="flex gap-1 mb-6 p-1 bg-card rounded-xl overflow-x-auto scrollbar-hide">
          <button onClick={() => setTab('content')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'content' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <Film className="w-4 h-4" /> ناوەڕۆک
          </button>
          <button onClick={() => setTab('episodes')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'episodes' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <List className="w-4 h-4" /> ئەلقەکان
          </button>
          <button onClick={() => setTab('chapters')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'chapters' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <BookOpen className="w-4 h-4" /> بەشە کۆمیک
          </button>
          <button onClick={() => setTab('comments')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'comments' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <MessageSquare className="w-4 h-4" /> لێدوانەکان
          </button>
          <button onClick={() => setTab('engagement')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'engagement' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <BarChart3 className="w-4 h-4" /> ئامار
          </button>
          <button onClick={() => setTab('settings')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'settings' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <SettingsIcon className="w-4 h-4" /> ڕێکخستن
          </button>
          <button onClick={() => setTab('vip')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'vip' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <Crown className="w-4 h-4" /> VIP
          </button>
          <button onClick={() => setTab('ads')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'ads' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <Megaphone className="w-4 h-4" /> ڕیکلام
          </button>
          <button onClick={() => setTab('notifications')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'notifications' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <Bell className="w-4 h-4" /> ئاگادارکردنەوە
          </button>
          <button onClick={() => setTab('translations')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'translations' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <Languages className="w-4 h-4" /> وەرگێڕان
          </button>
          <button onClick={() => setTab('subtitles')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'subtitles' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <VideoIcon className="w-4 h-4" /> ژێرنووس
          </button>
          <button onClick={() => setTab('ai')} className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex-shrink-0 ${tab === 'ai' ? 'bg-accent text-white' : 'text-secondary hover:text-primary'}`}>
            <Sparkles className="w-4 h-4" /> AI
          </button>
        </div>

        {tab === 'content' && (
          <div>
            {!showForm ? (
              <button onClick={() => { resetForm(); setShowForm(true); }} className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-accent text-white font-medium text-sm hover:bg-[var(--accent-hover)] transition-all mb-4">
                <Plus className="w-4 h-4" /> زیادکردنی ناوەڕۆک
              </button>
            ) : (
              <form onSubmit={handleSaveContent} className="bg-card border border-default rounded-xl p-4 mb-4 space-y-3 animate-scale-in">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-primary">{editingItem ? 'دەستکاریکردن' : 'ناوەڕۆکی نوێ'}</h3>
                  <button type="button" onClick={resetForm} className="text-secondary hover:text-primary"><X className="w-5 h-5" /></button>
                </div>
                <input type="text" placeholder="ناونیشان" value={title} onChange={(e) => setTitle(e.target.value)} required className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent" />
                <textarea placeholder="وەسف / کورتەی چیرۆک" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent resize-none" />
                <select value={category} onChange={(e) => setCategory(e.target.value as ContentCategory)} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent">
                  {CATEGORIES.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}
                </select>
                <input type="text" placeholder="ناوی گرووپی دۆبلاژ (ئیختیاری)" value={dubbingGroup} onChange={(e) => setDubbingGroup(e.target.value)} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent" />
                {category === 'comic' && (
                  <>
                    <input type="text" placeholder="ناوی نووسەر (ئیختیاری)" value={authorName} onChange={(e) => setAuthorName(e.target.value)} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent" />
                    <input type="text" placeholder="تێبینی بەش (ئیختیاری)" value={chapterNotice} onChange={(e) => setChapterNotice(e.target.value)} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent" />
                  </>
                )}
                <input type="text" placeholder="تاگەکان (بە کۆما جیاکردنەوە)" value={tags} onChange={(e) => setTags(e.target.value)} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent" />
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={isVipContent} onChange={(e) => setIsVipContent(e.target.checked)} className="w-4 h-4 accent-[var(--accent)]" />
                  <span className="text-sm text-primary flex items-center gap-1.5"><Crown className="w-4 h-4 text-accent" /> ناوەڕۆکی VIP تەنها</span>
                </label>
                <div className="space-y-2">
                  <label className="text-sm text-secondary">وێنەی بەرگ</label>
                  <div className="flex items-center gap-2">
                    <label className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-hover text-secondary cursor-pointer hover:text-primary transition-colors text-sm">
                      <Upload className="w-4 h-4" />
                      {uploadingCover ? <Loader2 className="w-4 h-4 animate-spin" /> : 'بارکردن لە ئامێرەکەوە'}
                      <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleCoverUpload(e.target.files[0])} />
                    </label>
                    <input type="text" placeholder="یان لینکی وێنە" value={coverUrl} onChange={(e) => setCoverUrl(e.target.value)} className="flex-1 px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent" />
                  </div>
                  {coverUrl && <img src={coverUrl} alt="cover" className="w-24 h-36 object-cover rounded-lg" />}
                </div>
                <button type="submit" disabled={loading} className="w-full flex items-center justify-center gap-2 py-3 rounded-lg bg-accent text-white font-medium text-sm hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} پاشەکەوتکردن
                </button>
              </form>
            )}

            <div className="space-y-2">
              {items.map((item, i) => (
                <div key={item.id} className="bg-card border border-default rounded-xl overflow-hidden">
                  <div className="flex items-center gap-1 sm:gap-2 p-2 sm:p-3">
                    <div className="w-10 h-14 sm:w-12 sm:h-16 rounded-lg overflow-hidden bg-hover flex-shrink-0">
                      {item.cover_image_url ? <img src={item.cover_image_url} alt={item.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center">{item.category === 'comic' ? <BookOpen className="w-4 h-4 sm:w-5 sm:h-5 text-muted" /> : <Film className="w-4 h-4 sm:w-5 sm:h-5 text-muted" />}</div>}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-primary truncate">{item.title}</p>
                      <p className="text-xs text-muted">{CATEGORY_LABELS[item.category]}{item.is_vip && ' • VIP'}</p>
                    </div>
                    <div className="flex items-center gap-0.5 sm:gap-1 flex-shrink-0">
                      <button onClick={() => moveContent(item, 'up')} disabled={i === 0} className="p-1.5 sm:p-2 rounded-lg text-secondary hover:text-accent hover:bg-hover transition-all disabled:opacity-30"><ArrowUp className="w-4 h-4" /></button>
                      <button onClick={() => moveContent(item, 'down')} disabled={i === items.length - 1} className="p-1.5 sm:p-2 rounded-lg text-secondary hover:text-accent hover:bg-hover transition-all disabled:opacity-30"><ArrowDown className="w-4 h-4" /></button>
                      <button onClick={() => handleExpand(item)} className="p-1.5 sm:p-2 rounded-lg text-secondary hover:text-primary hover:bg-hover transition-all">{expandedItem === item.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}</button>
                      <button onClick={() => startEdit(item)} className="p-1.5 sm:p-2 rounded-lg text-secondary hover:text-accent hover:bg-hover transition-all"><Edit2 className="w-4 h-4" /></button>
                      <button onClick={() => handleDeleteContent(item.id)} className="p-1.5 sm:p-2 rounded-lg text-secondary hover:text-red-400 hover:bg-hover transition-all"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </div>

                  {expandedItem === item.id && (
                    <div className="border-t border-default p-3 space-y-4 animate-slide-up">
                      {item.category !== 'comic' ? (
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="text-sm font-semibold text-primary flex items-center gap-2"><List className="w-4 h-4" /> ئەلقەکان ({episodes.length})</h4>
                            {!showEpForm && <button onClick={() => { resetEpForm(); setShowEpForm(true); }} className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-accent text-white text-xs font-medium"><Plus className="w-3.5 h-3.5" /> زیادکردن</button>}
                          </div>

                          {showEpForm && (
                            <form onSubmit={handleSaveEpisode} className="bg-secondary rounded-lg p-3 space-y-2 mb-3 animate-scale-in">
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-xs font-medium text-secondary">{editingEpisode ? 'دەستکاری ئەلقە' : 'ئەلقەی نوێ'}</span>
                                <button type="button" onClick={resetEpForm} className="text-secondary hover:text-primary"><X className="w-4 h-4" /></button>
                              </div>
                              <div className="grid grid-cols-2 gap-2">
                                <input type="number" placeholder="ژمارەی ئەلقە" value={epNumber} onChange={(e) => setEpNumber(e.target.value)} required className="px-3 py-2 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                                <input type="text" placeholder="ناونیشانی ئەلقە" value={epTitle} onChange={(e) => setEpTitle(e.target.value)} className="px-3 py-2 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                              </div>
                              <div className="flex flex-wrap gap-2">
                                <button type="button" onClick={() => setEpVideoType('upload')} className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${epVideoType === 'upload' ? 'bg-accent text-white' : 'bg-card text-secondary border border-default'}`}><Upload className="w-3.5 h-3.5" /> بارکردن</button>
                                <button type="button" onClick={() => setEpVideoType('link')} className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${epVideoType === 'link' ? 'bg-accent text-white' : 'bg-card text-secondary border border-default'}`}><Link2 className="w-3.5 h-3.5" /> YouTube</button>
                                <button type="button" onClick={() => setEpVideoType('gdrive')} className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${epVideoType === 'gdrive' ? 'bg-accent text-white' : 'bg-card text-secondary border border-default'}`}><Cloud className="w-3.5 h-3.5" /> Google Drive</button>
                              </div>
                              {epVideoType === 'upload' ? (
                                <div className="space-y-2">
                                  <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-hover text-secondary cursor-pointer text-sm">
                                    {uploadingVideo ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />} ڤیدیۆ باربکە
                                    <input type="file" accept="video/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleVideoUpload(e.target.files[0])} />
                                  </label>
                                  {uploadingVideo && (
                                    <div className="w-full bg-secondary rounded-full h-2 overflow-hidden">
                                      <div className="h-full bg-accent transition-all duration-300" style={{ width: `${videoUploadProgress}%` }} />
                                    </div>
                                  )}
                                  {uploadingVideo && <p className="text-xs text-accent">{videoUploadProgress}% بارکراوە</p>}
                                  {videoUploadError && <p className="text-xs text-red-400">{videoUploadError}</p>}
                                </div>
                              ) : epVideoType === 'gdrive' ? (
                                <input type="text" placeholder="لینکی Google Drive" value={epVideoUrl} onChange={(e) => setEpVideoUrl(e.target.value)} required className="w-full px-3 py-2 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                              ) : (
                                <input type="text" placeholder="لینکی YouTube/Vimeo" value={epVideoUrl} onChange={(e) => setEpVideoUrl(e.target.value)} required className="w-full px-3 py-2 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                              )}
                              {epVideoUrl && <p className="text-xs text-green-400">ڤیدیۆ ئامادەیە</p>}
                              <button type="submit" disabled={loading || !epVideoUrl} className="w-full py-2 rounded-lg bg-accent text-white text-sm font-medium hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50">{editingEpisode ? 'پاشەکەوتکردن' : 'زیادکردنی ئەلقە'}</button>
                            </form>
                          )}

                          <div className="space-y-1">
                            {episodes.map((ep, i) => (
                              <div key={ep.id} className="flex items-center gap-1 p-2 sm:p-2.5 rounded-lg bg-secondary text-sm">
                                <span className="text-primary flex-1 min-w-0 truncate">ئەلقە {ep.episode_number} {ep.title ? `- ${ep.title}` : ''}</span>
                                <button onClick={() => moveEpisode(ep, 'up')} disabled={i === 0} className="p-2 rounded text-secondary hover:text-accent transition-colors disabled:opacity-30"><ArrowUp className="w-4 h-4" /></button>
                                <button onClick={() => moveEpisode(ep, 'down')} disabled={i === episodes.length - 1} className="p-2 rounded text-secondary hover:text-accent transition-colors disabled:opacity-30"><ArrowDown className="w-4 h-4" /></button>
                                <button onClick={() => startEditEpisode(ep)} className="p-2 rounded text-secondary hover:text-accent transition-colors"><Edit2 className="w-4 h-4" /></button>
                                <button onClick={() => handleDeleteEpisode(ep.id)} className="p-2 rounded text-secondary hover:text-red-400 transition-colors"><Trash2 className="w-4 h-4" /></button>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="text-sm font-semibold text-primary flex items-center gap-2"><BookOpen className="w-4 h-4" /> بەشەکان ({chapters.length})</h4>
                            {!showChForm && <button onClick={() => { resetChForm(); setShowChForm(true); }} className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-accent text-white text-xs font-medium"><Plus className="w-3.5 h-3.5" /> زیادکردن</button>}
                          </div>

                          {showChForm && (
                            <form onSubmit={handleSaveChapter} className="bg-secondary rounded-lg p-3 space-y-2 mb-3 animate-scale-in">
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-xs font-medium text-secondary">{editingChapter ? 'دەستکاری بەش' : 'بەشی نوێ'}</span>
                                <button type="button" onClick={resetChForm} className="text-secondary hover:text-primary"><X className="w-4 h-4" /></button>
                              </div>
                              <div className="grid grid-cols-2 gap-2">
                                <input type="number" placeholder="ژمارەی بەش" value={chNumber} onChange={(e) => setChNumber(e.target.value)} required className="px-3 py-2 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                                <input type="text" placeholder="ناونیشانی بەش" value={chTitle} onChange={(e) => setChTitle(e.target.value)} className="px-3 py-2 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                              </div>
                              <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-hover text-secondary cursor-pointer text-sm">
                                {uploadingMusic ? <Loader2 className="w-4 h-4 animate-spin" /> : <Music className="w-4 h-4" />} مۆسیقای پاشبنەما (ئیختیاری)
                                <input type="file" accept="audio/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleMusicUpload(e.target.files[0])} />
                              </label>
                              {chMusicUrl && <p className="text-xs text-green-400">مۆسیقا ئامادەیە</p>}

                              {/* Format selector */}
                              <div>
                                <label className="text-xs text-secondary mb-1 block">فۆرماتی کۆمیک</label>
                                <select value={chFormat} onChange={(e) => setChFormat(e.target.value)} className="w-full px-3 py-2 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent">
                                  <option value="default">فۆرماتی ئاسایی</option>
                                  <option value="9:16">9:16 (TikTok/Shorts)</option>
                                  <option value="16:9">16:9 (YouTube)</option>
                                </select>
                              </div>

                              {/* Multiple music tracks */}
                              <div className="space-y-2">
                                <label className="text-xs text-secondary">تراکی مۆسیقای زیادە (بۆ گۆڕینی مۆسیقا بەپێی دەیمەکان)</label>
                                {chapterTracks.map((track, ti) => (
                                  <div key={ti} className="flex flex-wrap items-center gap-2 p-2 rounded-lg bg-card border border-default">
                                    <span className="text-xs text-muted flex-shrink-0">تراک {ti + 1}</span>
                                    <input type="text" placeholder="ناوی تراک" value={track.track_name} onChange={(e) => {
                                      const next = [...chapterTracks]; next[ti] = { ...track, track_name: e.target.value }; setChapterTracks(next);
                                    }} className="flex-1 min-w-[100px] px-2 py-1.5 rounded bg-secondary border border-default text-primary text-xs outline-none focus:border-accent" />
                                    <input type="number" placeholder="دەستپێک" value={track.start_panel ?? ''} onChange={(e) => {
                                      const next = [...chapterTracks]; next[ti] = { ...track, start_panel: e.target.value ? parseInt(e.target.value) : null }; setChapterTracks(next);
                                    }} className="w-16 px-2 py-1.5 rounded bg-secondary border border-default text-primary text-xs outline-none focus:border-accent" />
                                    <input type="number" placeholder="کۆتایی" value={track.end_panel ?? ''} onChange={(e) => {
                                      const next = [...chapterTracks]; next[ti] = { ...track, end_panel: e.target.value ? parseInt(e.target.value) : null }; setChapterTracks(next);
                                    }} className="w-16 px-2 py-1.5 rounded bg-secondary border border-default text-primary text-xs outline-none focus:border-accent" />
                                    <button type="button" onClick={() => setChapterTracks(chapterTracks.filter((_, idx) => idx !== ti))} className="p-1.5 text-muted hover:text-red-400"><X className="w-3.5 h-3.5" /></button>
                                  </div>
                                ))}
                                <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-hover text-secondary cursor-pointer text-xs">
                                  {uploadingTrack ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />} زیادکردنی تراک
                                  <input type="file" accept="audio/*" className="hidden" onChange={async (e) => {
                                    if (!e.target.files?.[0]) return;
                                    setUploadingTrack(true);
                                    const url = await uploadFile('music', e.target.files[0]);
                                    if (url) {
                                      setChapterTracks(prev => [...prev, { track_url: url, track_name: '', start_panel: null, end_panel: null, track_order: prev.length }]);
                                    }
                                    setUploadingTrack(false);
                                  }} />
                                </label>
                              </div>
                              {!editingChapter && (
                                <div>
                                  <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-hover text-secondary cursor-pointer text-sm">
                                    {uploadingPanel ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />} وێنەی پەنال زیاد بکە
                                    <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => e.target.files && handlePanelUpload(e.target.files)} />
                                  </label>
                                  {chPanels.length > 0 && (
                                    <div className="flex flex-wrap gap-2 mt-2">
                                      {chPanels.map((url, i) => (
                                        <div key={i} className="relative">
                                          <img src={url} alt={`panel ${i}`} className="w-14 h-18 sm:w-16 sm:h-20 object-cover rounded-lg" />
                                          <button type="button" onClick={() => setChPanels(chPanels.filter((_, idx) => idx !== i))} className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center"><X className="w-3 h-3" /></button>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              )}
                              <button type="submit" disabled={loading} className="w-full py-2 rounded-lg bg-accent text-white text-sm font-medium hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50">{editingChapter ? 'پاشەکەوتکردن' : 'زیادکردنی بەش'}</button>
                            </form>
                          )}

                          <div className="space-y-1">
                            {chapters.map((ch, i) => (
                              <div key={ch.id} className="rounded-lg bg-secondary overflow-hidden">
                                <div className="flex items-center gap-1 p-2 sm:p-2.5 text-sm">
                                  <span className="text-primary flex-1 min-w-0 truncate">بەش {ch.chapter_number} {ch.title ? `- ${ch.title}` : ''}</span>
                                  <button onClick={() => moveChapter(ch, 'up')} disabled={i === 0} className="p-2 rounded text-secondary hover:text-accent transition-colors disabled:opacity-30"><ArrowUp className="w-4 h-4" /></button>
                                  <button onClick={() => moveChapter(ch, 'down')} disabled={i === chapters.length - 1} className="p-2 rounded text-secondary hover:text-accent transition-colors disabled:opacity-30"><ArrowDown className="w-4 h-4" /></button>
                                  <button onClick={() => handleExpandChapter(ch)} className="p-2 rounded text-secondary hover:text-primary transition-colors">{expandedChapter === ch.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}</button>
                                  <button onClick={() => startEditChapter(ch)} className="p-2 rounded text-secondary hover:text-accent transition-colors"><Edit2 className="w-4 h-4" /></button>
                                  <button onClick={() => handleDeleteChapter(ch.id)} className="p-2 rounded text-secondary hover:text-red-400 transition-colors"><Trash2 className="w-4 h-4" /></button>
                                </div>

                                {expandedChapter === ch.id && (
                                  <div className="border-t border-default p-2 animate-slide-up">
                                    <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                                      <span className="text-xs text-secondary">پەنالەکان ({panels.length})</span>
                                      <div className="flex items-center gap-1">
                                        <label className="flex items-center gap-1 px-2 py-1 rounded-lg bg-accent text-white text-xs cursor-pointer">
                                          {uploadingPanel ? <Loader2 className="w-3 h-3 animate-spin" /> : <ImageIcon className="w-3 h-3" />} وێنە
                                          <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => e.target.files && handleAddPanelToExisting(ch.id, e.target.files)} />
                                        </label>
                                        <label className="flex items-center gap-1 px-2 py-1 rounded-lg bg-secondary text-secondary border border-default text-xs cursor-pointer hover:text-accent">
                                          <VideoIcon className="w-3 h-3" /> ڤیدیۆ
                                          <input type="file" accept="video/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleAddVideoPanelToExisting(ch.id, e.target.files[0])} />
                                        </label>
                                      </div>
                                    </div>
                                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                                      {panels.map((panel, pi) => (
                                        <div key={panel.id} className="relative group rounded-lg overflow-hidden">
                                          {panel.video_url ? (
                                            <video src={panel.video_url} className="w-full h-20 object-cover" muted />
                                          ) : (
                                            <img src={panel.image_url} alt={`panel ${pi}`} className="w-full h-20 object-cover" />
                                          )}
                                          {panel.video_url && (
                                            <div className="absolute top-1 right-1 px-1 py-0.5 rounded bg-accent/80 text-white text-[8px] font-medium flex items-center gap-0.5">
                                              <VideoIcon className="w-2.5 h-2.5" /> ڤیدیۆ
                                            </div>
                                          )}
                                          {panel.sound_url && (
                                            <div className="absolute top-1 left-1 px-1 py-0.5 rounded bg-green-600/80 text-white text-[8px] font-medium flex items-center gap-0.5">
                                              <Volume2 className="w-2.5 h-2.5" /> دەنگ
                                            </div>
                                          )}
                                          <div className="absolute inset-0 bg-black/60 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity flex flex-wrap items-center justify-center gap-1 p-1">
                                            <button onClick={() => movePanel(panel, 'up')} disabled={pi === 0} className="p-1.5 rounded bg-white/20 text-white hover:bg-accent transition-colors disabled:opacity-30"><ArrowUp className="w-3.5 h-3.5" /></button>
                                            <button onClick={() => movePanel(panel, 'down')} disabled={pi === panels.length - 1} className="p-1.5 rounded bg-white/20 text-white hover:bg-accent transition-colors disabled:opacity-30"><ArrowDown className="w-3.5 h-3.5" /></button>
                                            <label className="p-1.5 rounded bg-white/20 text-white hover:bg-accent transition-colors cursor-pointer">
                                              <RefreshCw className="w-3.5 h-3.5" />
                                              <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleReplacePanel(panel, e.target.files[0])} />
                                            </label>
                                            <label className="p-1.5 rounded bg-white/20 text-white hover:bg-accent transition-colors cursor-pointer">
                                              <VideoIcon className="w-3.5 h-3.5" />
                                              <input type="file" accept="video/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleSetPanelVideo(panel, e.target.files[0])} />
                                            </label>
                                            {panel.video_url && (
                                              <button onClick={() => handleRemovePanelVideo(panel)} className="p-1.5 rounded bg-white/20 text-white hover:bg-accent transition-colors" title="لابردنی ڤیدیۆ">
                                                <VideoIcon className="w-3.5 h-3.5 opacity-40" />
                                              </button>
                                            )}
                                            <label className="p-1.5 rounded bg-white/20 text-white hover:bg-accent transition-colors cursor-pointer" title="دەنگی پەنال">
                                              <Volume2 className="w-3.5 h-3.5" />
                                              <input type="file" accept="audio/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleSetPanelSound(panel, e.target.files[0])} />
                                            </label>
                                            {panel.sound_url && (
                                              <button onClick={() => handleRemovePanelSound(panel)} className="p-1.5 rounded bg-white/20 text-white hover:bg-accent transition-colors" title="لابردنی دەنگ">
                                                <Volume2 className="w-3.5 h-3.5 opacity-40" />
                                              </button>
                                            )}
                                            <button onClick={() => handleDeletePanel(panel)} className="p-1.5 rounded bg-white/20 text-white hover:bg-red-500 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
              {items.length === 0 && !loading && <div className="text-center py-12 text-secondary"><p>هیچ ناوەڕۆکێک نییە. یەکەم ناوەڕۆک زیاد بکە!</p></div>}
            </div>
          </div>
        )}

        {tab === 'episodes' && (
          <div className="text-center py-12 text-secondary">
            <List className="w-12 h-12 mx-auto mb-4 text-muted" />
            <p>ئەلقەکان لە تابی ناوەڕۆکەوە بەڕێوە دەبرێن</p>
            <p className="text-sm text-muted mt-2">لە لیستی ناوەڕۆک، سەرەکی هەر بابەتێک بکە بۆ بەڕێوەبردنی ئەلقەکان</p>
            <button onClick={() => setTab('content')} className="mt-4 px-4 py-2 rounded-lg bg-accent text-white text-sm">چوونە ناوەڕۆک</button>
          </div>
        )}

        {tab === 'chapters' && (
          <div className="text-center py-12 text-secondary">
            <BookOpen className="w-12 h-12 mx-auto mb-4 text-muted" />
            <p>بەشە کۆمیک لە تابی ناوەڕۆکەوە بەڕێوە دەبرێن</p>
            <p className="text-sm text-muted mt-2">لە لیستی ناوەڕۆک، سەرەکی کۆمیکێک بکە بۆ بەڕێوەبردنی بەشەکان</p>
            <button onClick={() => setTab('content')} className="mt-4 px-4 py-2 rounded-lg bg-accent text-white text-sm">چوونە ناوەڕۆک</button>
          </div>
        )}

        {tab === 'comments' && (
          <div>
            <h3 className="text-lg font-semibold text-primary mb-4">بەڕێوەبردنی لێدوانەکان</h3>
            {commentsLoading ? (
              <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-accent animate-spin" /></div>
            ) : allComments.length === 0 ? (
              <p className="text-center py-8 text-secondary">هیچ لێدوانێک نییە</p>
            ) : (
              <div className="space-y-2">
                {allComments.map((c) => (
                  <div key={c.id} className="flex items-start gap-3 p-3 rounded-xl bg-card border border-default">
                    <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-white text-xs font-bold overflow-hidden flex-shrink-0">
                      {c.profiles?.avatar_url ? <img src={c.profiles.avatar_url} alt="avatar" className="w-full h-full object-cover" /> : (c.profiles?.username || 'U').charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium text-primary">{c.profiles?.username || 'بەکارهێنەر'}</span>
                        <span className="text-xs text-muted">{new Date(c.created_at).toLocaleDateString()}</span>
                        <span className="text-xs px-2 py-0.5 rounded-full bg-hover text-muted">{c.item_type}</span>
                      </div>
                      <p className="text-sm text-secondary break-words">{c.text}</p>
                    </div>
                    <button onClick={() => handleDeleteComment(c.id)} className="p-2 rounded-lg text-muted hover:text-red-400 transition-colors flex-shrink-0">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'engagement' && (
          <div>
            <h3 className="text-lg font-semibold text-primary mb-4">ئاماری بینین و ستار</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="p-4 rounded-xl bg-card border border-default">
                <div className="flex items-center gap-2 mb-2">
                  <Eye className="w-5 h-5 text-accent" />
                  <span className="text-sm font-medium text-primary">کۆی بینینەکان</span>
                </div>
                {(() => {
                  const total = items.reduce((sum, item) => sum + (item.view_count || 0), 0);
                  return <p className="text-2xl font-bold text-primary">{formatCount(total)}</p>;
                })()}
              </div>
              <div className="p-4 rounded-xl bg-card border border-default">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-5 h-5 text-accent" />
                  <span className="text-sm font-medium text-primary">کۆی ستارەکان</span>
                </div>
                {(() => {
                  const total = items.reduce((sum, item) => sum + (item.star_count || 0), 0);
                  return <p className="text-2xl font-bold text-primary">{formatCount(total)}</p>;
                })()}
              </div>
            </div>
            <div className="space-y-2">
              {items.map((item) => (
                <div key={item.id} className="flex items-center gap-3 p-3 rounded-xl bg-card border border-default">
                  <div className="w-10 h-14 rounded-lg overflow-hidden bg-hover flex-shrink-0">
                    {item.cover_image_url ? <img src={item.cover_image_url} alt={item.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Film className="w-4 h-4 text-muted" /></div>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-primary truncate">{item.title}</p>
                    <p className="text-xs text-muted">{CATEGORY_LABELS[item.category]}</p>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="flex items-center gap-1 text-secondary"><Eye className="w-4 h-4" /> {formatCount(item.view_count || 0)}</span>
                    <span className="flex items-center gap-1 text-secondary"><Star className="w-4 h-4" /> {formatCount(item.star_count || 0)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 'settings' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-primary mb-4">بەستەرەکانی سۆشیاڵ میدیا</h3>
              <div className="space-y-3">
                <div>
                  <label className="text-sm text-secondary mb-1 block">Telegram</label>
                  <input type="text" value={socialLinks.telegram} onChange={(e) => setSocialLinks({ ...socialLinks, telegram: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                </div>
                <div>
                  <label className="text-sm text-secondary mb-1 block">Snapchat</label>
                  <input type="text" value={socialLinks.snapchat} onChange={(e) => setSocialLinks({ ...socialLinks, snapchat: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                </div>
                <div>
                  <label className="text-sm text-secondary mb-1 block">TikTok</label>
                  <input type="text" value={socialLinks.tiktok} onChange={(e) => setSocialLinks({ ...socialLinks, tiktok: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                </div>
                <div>
                  <label className="text-sm text-secondary mb-1 block">WhatsApp</label>
                  <input type="text" value={socialLinks.whatsapp} onChange={(e) => setSocialLinks({ ...socialLinks, whatsapp: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                </div>
                <div>
                  <label className="text-sm text-secondary mb-1 block">FastPay ژمارە</label>
                  <input type="text" value={socialLinks.fastpay_number} onChange={(e) => setSocialLinks({ ...socialLinks, fastpay_number: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-primary mb-4">ڕیکلام و دراوکردن</h3>
              <div className="space-y-3">
                <label className="flex items-center gap-3 p-3 rounded-lg bg-card border border-default cursor-pointer">
                  <input type="checkbox" checked={adsEnabled} onChange={(e) => setAdsEnabled(e.target.checked)} className="w-5 h-5 accent-[var(--accent)]" />
                  <span className="text-sm text-primary">چالاککردنی ڕیکلام</span>
                </label>
                <div>
                  <label className="text-sm text-secondary mb-1 block">Google AdSense Client ID (ca-pub-XXXX)</label>
                  <input type="text" value={adClientId} onChange={(e) => setAdClientId(e.target.value)} placeholder="ca-pub-XXXXXXXXXXXXXXXX" className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                </div>
              </div>
            </div>

            <button onClick={handleSaveSettings} disabled={settingsSaving} className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-accent text-white font-medium text-sm hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50">
              {settingsSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} پاشەکەوتکردنی ڕێکخستنەکان
            </button>
          </div>
        )}

        {tab === 'vip' && (
          <div>
            <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
              <Crown className="w-5 h-5 text-accent" /> بەڕێوەبردنی VIP
            </h3>
            {vipLoading ? (
              <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-accent animate-spin" /></div>
            ) : vipPayments.length === 0 ? (
              <p className="text-center py-8 text-secondary">هیچ داواکاریەکی VIP نییە</p>
            ) : (
              <div className="space-y-3">
                {vipPayments.map((p) => {
                  const profileData = p.profiles as any;
                  const status = p.status;
                  const methodLabel = p.payment_method === 'fastpay' ? 'FastPay' : 'مۆبایل کرێدت';
                  const vipBadge = profileData?.vip_status === 'vip' ? 'VIP' : profileData?.vip_status === 'trial' ? 'بەرایی' : 'بەخۆڕایی';
                  return (
                    <div key={p.id} className="bg-card border border-default rounded-xl p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center text-white text-sm font-bold overflow-hidden flex-shrink-0">
                            {profileData?.avatar_url ? <img src={profileData.avatar_url} alt="avatar" className="w-full h-full object-cover" /> : (profileData?.username || 'U').charAt(0).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-primary truncate">{profileData?.username || 'بەکارهێنەر'}</p>
                            <p className="text-xs text-muted">{profileData?.phone || ''}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-xs px-2 py-0.5 rounded-full bg-hover text-muted">{vipBadge}</span>
                              <span className="text-xs text-muted">{methodLabel}</span>
                            </div>
                          </div>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium flex-shrink-0 ${
                          status === 'approved' ? 'bg-green-500/20 text-green-400' :
                          status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                          'bg-accent/20 text-accent'
                        }`}>
                          {status === 'approved' ? 'پەسەندکرا' : status === 'rejected' ? 'ڕەتکرایەوە' : 'چاوەڕێ'}
                        </span>
                      </div>

                      {p.payment_note && (
                        <p className="text-xs text-secondary mt-2 bg-secondary rounded-lg p-2">{p.payment_note}</p>
                      )}

                      <p className="text-xs text-muted mt-2">{new Date(p.created_at).toLocaleDateString()}</p>

                      {status === 'pending' && (
                        <div className="flex gap-2 mt-3">
                          <button
                            onClick={() => handleApproveVip(p)}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-green-600 text-white text-xs font-medium hover:bg-green-700 transition-all"
                          >
                            <Check className="w-3.5 h-3.5" /> پەسەندکردن و چالاککردن
                          </button>
                          <button
                            onClick={() => handleRejectVip(p)}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-red-500 text-white text-xs font-medium hover:bg-red-600 transition-all"
                          >
                            <XCircle className="w-3.5 h-3.5" /> ڕەتکردنەوە
                          </button>
                        </div>
                      )}

                      {status === 'approved' && profileData?.vip_end_date && (
                        <p className="text-xs text-green-400 mt-2">
                          VIP چالاککرا تا {new Date(profileData.vip_end_date).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {tab === 'ads' && (
          <div>
            <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-accent" /> بەڕێوەبردنی ڕیکلام
            </h3>
            {!showAdForm ? (
              <button onClick={() => setShowAdForm(true)} className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-accent text-white font-medium text-sm hover:bg-[var(--accent-hover)] transition-all mb-4">
                <Plus className="w-4 h-4" /> زیادکردنی ڕیکلام
              </button>
            ) : (
              <div className="bg-card border border-default rounded-xl p-4 mb-4 space-y-3 animate-scale-in">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-primary text-sm">ڕیکلامی نوێ</h4>
                  <button onClick={() => setShowAdForm(false)} className="text-secondary hover:text-primary"><X className="w-5 h-5" /></button>
                </div>
                <input type="text" placeholder="ناونیشان" value={adTitle} onChange={(e) => setAdTitle(e.target.value)} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
                <div className="flex items-center gap-2">
                  <label className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-hover text-secondary cursor-pointer text-sm">
                    {uploadingAd ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />} وێنەی ڕیکلام
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleAdImageUpload(e.target.files[0])} />
                  </label>
                  <input type="text" placeholder="یان لینکی وێنە" value={adImageUrl} onChange={(e) => setAdImageUrl(e.target.value)} className="flex-1 px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
                </div>
                {adImageUrl && <img src={adImageUrl} alt="ad" className="w-full h-24 object-cover rounded-lg" />}
                <input type="text" placeholder="لینکی ڕیکلام (ئیختیاری)" value={adLinkUrl} onChange={(e) => setAdLinkUrl(e.target.value)} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
                <select value={adPosition} onChange={(e) => setAdPosition(e.target.value)} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent">
                  <option value="homepage-top">سەرەوەی پەڕەی سەرەکی</option>
                  <option value="between-content">نێوان ناوەڕۆک</option>
                  <option value="sidebar">لای چەپ</option>
                  <option value="mobile">مۆبایل</option>
                </select>
                <button onClick={handleSaveAd} className="w-full py-2.5 rounded-lg bg-accent text-white text-sm font-medium">پاشەکەوتکردن</button>
              </div>
            )}
            {adsLoading ? (
              <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-accent animate-spin" /></div>
            ) : ads.length === 0 ? (
              <p className="text-center py-8 text-secondary">هیچ ڕیکلامێک نییە</p>
            ) : (
              <div className="space-y-2">
                {ads.map((ad) => (
                  <div key={ad.id} className="flex items-center gap-3 p-3 rounded-xl bg-card border border-default">
                    {ad.image_url && <img src={ad.image_url} alt="" className="w-16 h-12 object-cover rounded-lg flex-shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-primary truncate">{ad.title || 'بێ ناونیشان'}</p>
                      <p className="text-xs text-muted">{ad.position} — {ad.impressions} بینین</p>
                    </div>
                    <button onClick={() => handleToggleAd(ad)} className={`px-3 py-1.5 rounded-lg text-xs font-medium ${ad.is_active ? 'bg-green-500/20 text-green-400' : 'bg-hover text-muted'}`}>
                      {ad.is_active ? 'چالاک' : 'ناچالاک'}
                    </button>
                    <button onClick={() => handleDeleteAd(ad.id)} className="p-2 rounded-lg text-muted hover:text-red-400"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'notifications' && (
          <div>
            <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
              <Bell className="w-5 h-5 text-accent" /> ناردنی ئاگادارکردنەوە
            </h3>
            <div className="bg-card border border-default rounded-xl p-4 space-y-3">
              <div>
                <label className="text-sm text-secondary mb-1 block">جۆری ئاگادارکردنەوە</label>
                <select value={notifType} onChange={(e) => setNotifType(e.target.value)} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent">
                  <option value="new_content">ناوەڕۆکی نوێ</option>
                  <option value="new_episode">ئەلقەی نوێ</option>
                  <option value="new_chapter">بەشی کۆمیکی نوێ</option>
                  <option value="new_vip_content">ناوەڕۆکی VIP نوێ</option>
                </select>
              </div>
              <input type="text" placeholder="ناونیشانی ئاگادارکردنەوە" value={notifTitle} onChange={(e) => setNotifTitle(e.target.value)} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
              <textarea placeholder="ناوەڕۆکی ئاگادارکردنەوە (ئیختیاری)" value={notifBody} onChange={(e) => setNotifBody(e.target.value)} rows={3} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent resize-none" />
              <button onClick={handleSendNotification} disabled={!notifTitle.trim() || sendingNotif} className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-accent text-white font-medium text-sm disabled:opacity-50">
                {sendingNotif ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bell className="w-4 h-4" />} ناردن بۆ هەموو بەکارهێنەران
              </button>
              <p className="text-xs text-muted text-center">ئاگادارکردنەوە دەنێردرێت بۆ هەموو بەکارهێنەرانی تۆمارکراو</p>
            </div>
          </div>
        )}

        {tab === 'translations' && (
          <div>
            <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
              <Languages className="w-5 h-5 text-accent" /> پێداچوونەوەی وەرگێڕان
            </h3>
            <p className="text-sm text-secondary mb-4">وەرگێڕانە کاتییەکانی دەقی کۆمیک کە چاوەڕێی پەسەندکردن دەکەن</p>
            {translationsLoading ? (
              <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-accent animate-spin" /></div>
            ) : pendingTranslations.length === 0 ? (
              <p className="text-center py-8 text-secondary">هیچ وەرگێڕانێک چاوەڕێی پەسەندکردن نییە</p>
            ) : (
              <div className="space-y-3">
                {pendingTranslations.map((tr: any) => (
                  <div key={tr.id} className="bg-card border border-default rounded-xl p-4">
                    <div className="flex items-start gap-3">
                      {tr.comic_panels?.image_url && (
                        <img src={tr.comic_panels.image_url} alt="" className="w-20 h-28 object-cover rounded-lg flex-shrink-0" />
                      )}
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs px-2 py-0.5 rounded-full bg-accent/20 text-accent">{tr.source_language || '؟'} ← {tr.target_language}</span>
                        </div>
                        <div>
                          <p className="text-xs text-muted">دەقی ڕەسەن:</p>
                          <p className="text-sm text-secondary" dir="auto">{tr.original_text}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted">وەرگێڕان:</p>
                          <textarea
                            defaultValue={tr.translated_text}
                            dir="auto"
                            rows={2}
                            onBlur={(e) => handleUpdateTranslationText(tr.id, e.target.value)}
                            className="w-full px-3 py-2 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent resize-none"
                          />
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => handleApproveTranslation(tr)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-600 text-white text-xs font-medium">
                            <Check className="w-3.5 h-3.5" /> پەسەندکردن
                          </button>
                          <button onClick={() => handleDeleteTranslation(tr.id)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-medium">
                            <XCircle className="w-3.5 h-3.5" /> ڕەتکردنەوە
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'subtitles' && (
          <div>
            <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
              <VideoIcon className="w-5 h-5 text-accent" /> بەڕێوەبردنی ژێرنووسی AI
            </h3>
            <p className="text-sm text-secondary mb-4">ژێرنووسی AI بۆ ڤیدیۆکان - تەنها کوردی سۆرانی و ئینگلیزی (US)</p>

            <div className="bg-card border border-default rounded-xl p-4 space-y-4">
              {/* Step 1: Select content */}
              <div>
                <label className="text-sm text-secondary mb-1 block">١. ناوەڕۆک هەڵبژێرە</label>
                {!subtitleItems.length && (
                  <button onClick={loadVideoContentItems} className="px-4 py-2 rounded-lg bg-accent text-white text-sm font-medium">بارکردنی لیست</button>
                )}
                {subtitleItems.length > 0 && (
                  <select
                    onChange={async (e) => {
                      const contentId = e.target.value;
                      if (!contentId) return;
                      const { data: eps } = await supabase.from('episodes').select('*').eq('content_id', contentId).order('episode_number', { ascending: true });
                      setEpisodes(eps as Episode[]);
                      setSelectedEpForSubs(null);
                      setSubtitlesForEp([]);
                      setSubtitleEntries([{ content: '', start_time: '', end_time: '' }]);
                    }}
                    className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent"
                  >
                    <option value="">-- ناوەڕۆک هەڵبژێرە --</option>
                    {subtitleItems.map((item) => (
                      <option key={item.id} value={item.id}>{item.title} ({CATEGORY_LABELS[item.category]})</option>
                    ))}
                  </select>
                )}
              </div>

              {/* Step 2: Select episode */}
              {episodes.length > 0 && (
                <div>
                  <label className="text-sm text-secondary mb-1 block">٢. ئەلقە هەڵبژێرە</label>
                  <select
                    onChange={async (e) => {
                      const epId = e.target.value;
                      if (!epId) return;
                      setSelectedEpForSubs(epId);
                      await loadSubtitlesForEpisode(epId, subtitleLang);
                    }}
                    className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent"
                  >
                    <option value="">-- ئەلقە هەڵبژێرە --</option>
                    {episodes.map((ep) => (
                      <option key={ep.id} value={ep.id}>ئەلقە {ep.episode_number} {ep.title ? `- ${ep.title}` : ''}</option>
                    ))}
                  </select>
                </div>
              )}

              {/* Step 3: Select language */}
              {selectedEpForSubs && (
                <div>
                  <label className="text-sm text-secondary mb-1 block">٣. زمان هەڵبژێرە</label>
                  <div className="flex gap-2">
                    <button
                      onClick={() => { setSubtitleLang('ku'); loadSubtitlesForEpisode(selectedEpForSubs, 'ku'); }}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${subtitleLang === 'ku' ? 'bg-accent text-white' : 'bg-secondary text-secondary border border-default'}`}
                    >
                      کوردی سۆرانی
                    </button>
                    <button
                      onClick={() => { setSubtitleLang('en'); loadSubtitlesForEpisode(selectedEpForSubs, 'en'); }}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${subtitleLang === 'en' ? 'bg-accent text-white' : 'bg-secondary text-secondary border border-default'}`}
                    >
                      English (US)
                    </button>
                  </div>
                </div>
              )}

              {/* Generate from transcript */}
              {selectedEpForSubs && (
                <div className="space-y-2 p-3 rounded-lg bg-secondary border border-default">
                  <label className="text-sm text-secondary flex items-center gap-1.5">
                    <VideoIcon className="w-4 h-4" /> دروستکردنی ژێرنووس لە دەقەوە
                  </label>
                  <p className="text-xs text-muted">دەقی قسەکردنی ڤیدیۆکە بنووسە، سیستەم خۆکارانە ژێرنووسی دروست دەکات و وەرگێڕان دەکات بۆ زمانی هەڵبژێردراو</p>
                  <div className="flex gap-2">
                    <select value={transcriptSourceLang} onChange={(e) => setTranscriptSourceLang(e.target.value as 'ku' | 'en')} className="px-3 py-2 rounded-lg bg-card border border-default text-primary text-xs outline-none focus:border-accent">
                      <option value="ku">سەرچاوە: کوردی</option>
                      <option value="en">سەرچاوە: ئینگلیزی</option>
                    </select>
                  </div>
                  <textarea
                    value={transcriptText}
                    onChange={(e) => setTranscriptText(e.target.value)}
                    placeholder={transcriptSourceLang === 'ku' ? 'دەقی کوردی بنووسە...' : 'Type English transcript...'}
                    dir={transcriptSourceLang === 'ku' ? 'rtl' : 'ltr'}
                    rows={4}
                    className="w-full px-3 py-2 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent resize-none"
                  />
                  <button
                    onClick={handleGenerateFromTranscript}
                    disabled={!transcriptText.trim() || generatingSubs}
                    className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-green-600 text-white text-sm font-medium disabled:opacity-50"
                  >
                    {generatingSubs ? <Loader2 className="w-4 h-4 animate-spin" /> : <VideoIcon className="w-4 h-4" />}
                    دروستکردنی ژێرنوسی AI
                  </button>
                </div>
              )}

              {/* Step 4: Subtitle entries */}
              {selectedEpForSubs && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-sm text-secondary">٤. ژێرنووسەکان ({subtitlesForEp.filter((s) => s.is_ai_generated).length} ژێرنووسی AI)</label>
                    {subtitlesForEp.filter((s) => s.is_ai_generated).length > 0 && (
                      <button onClick={handleDeleteSubtitles} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-medium">
                        <Trash2 className="w-3.5 h-3.5" /> سڕینەوەی ژێرنووسەکان
                      </button>
                    )}
                  </div>

                  {subtitleEntries.map((entry, i) => (
                    <div key={i} className="flex items-start gap-2 p-3 rounded-lg bg-secondary border border-default">
                      <span className="text-xs text-muted flex-shrink-0 pt-2">{i + 1}</span>
                      <div className="flex-1 space-y-2">
                        <textarea
                          placeholder="دەقی ژێرنووس"
                          dir={subtitleLang === 'ku' ? 'rtl' : 'ltr'}
                          value={entry.content}
                          onChange={(e) => {
                            const next = [...subtitleEntries];
                            next[i] = { ...entry, content: e.target.value };
                            setSubtitleEntries(next);
                          }}
                          rows={2}
                          className="w-full px-3 py-2 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent resize-none"
                        />
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="دەستپێک (م:ث)"
                            value={entry.start_time}
                            onChange={(e) => {
                              const next = [...subtitleEntries];
                              next[i] = { ...entry, start_time: e.target.value };
                              setSubtitleEntries(next);
                            }}
                            className="w-24 px-2 py-1.5 rounded-lg bg-card border border-default text-primary text-xs outline-none focus:border-accent"
                          />
                          <input
                            type="text"
                            placeholder="کۆتایی (م:ث)"
                            value={entry.end_time}
                            onChange={(e) => {
                              const next = [...subtitleEntries];
                              next[i] = { ...entry, end_time: e.target.value };
                              setSubtitleEntries(next);
                            }}
                            className="w-24 px-2 py-1.5 rounded-lg bg-card border border-default text-primary text-xs outline-none focus:border-accent"
                          />
                        </div>
                      </div>
                      <button
                        onClick={() => setSubtitleEntries(subtitleEntries.filter((_, idx) => idx !== i))}
                        className="p-1.5 text-muted hover:text-red-400 flex-shrink-0"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}

                  <button
                    onClick={() => setSubtitleEntries([...subtitleEntries, { content: '', start_time: '', end_time: '' }])}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-hover text-secondary text-sm font-medium hover:text-primary transition-all"
                  >
                    <Plus className="w-4 h-4" /> زیادکردنی ژێرنووس
                  </button>

                  <button
                    onClick={handleSaveSubtitles}
                    disabled={savingSubtitles}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-accent text-white font-medium text-sm hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50"
                  >
                    {savingSubtitles ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} پاشەکەوتکردنی ژێرنووسەکان
                  </button>
                </div>
              )}

              {!selectedEpForSubs && episodes.length === 0 && (
                <p className="text-center py-6 text-muted text-sm">سەرەتا ناوەڕۆکێک هەڵبژێرە بۆ بەڕێوەبردنی ژێرنووسەکان</p>
              )}
            </div>
          </div>
        )}
        {tab === 'ai' && (
          <div>
            <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-accent" /> ڕێکخستنی AI کۆمیک
            </h3>
            <AdminAISettings />
          </div>
        )}
      </div>
    </div>
  );
}
