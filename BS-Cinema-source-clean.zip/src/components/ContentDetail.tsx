import { useEffect, useState, useMemo } from 'react';
import {
  X, Loader2, BookOpen, Music, List, Edit2, Save, Upload, ArrowUp, ArrowDown, Trash2, RefreshCw, Link2, Cloud, User, Info, Crown, Lock
} from 'lucide-react';
import type { ContentItem, ContentCategory, Episode, ComicChapter, ComicPanel } from '@/lib/supabase';
import { supabase } from '@/lib/supabase';
import { uploadFile } from '@/lib/storage';
import { fetchEpisodes, fetchChapters, fetchPanels, invalidateContentCache } from '@/lib/contentCache';
import { CATEGORY_LABELS, CATEGORIES } from '@/lib/categories';
import { useAdmin } from '@/context/AdminContext';
import { useAuth } from '@/context/AuthContext';
import VideoPlayer from './VideoPlayer';
import ComicReader from './ComicReader';
import EngagementBar from './EngagementBar';
import CommentSection from './CommentSection';

interface ContentDetailProps {
  item: ContentItem;
  onClose: () => void;
  onContentUpdated?: () => void;
}

export default function ContentDetail({ item, onClose, onContentUpdated }: ContentDetailProps) {
  const { isAdmin } = useAdmin();
  const { profile } = useAuth();
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [chapters, setChapters] = useState<ComicChapter[]>([]);
  const [panels, setPanels] = useState<ComicPanel[]>([]);
  const [currentEpisode, setCurrentEpisode] = useState(0);
  const [loading, setLoading] = useState(true);
  const [showReader, setShowReader] = useState(false);

  // Admin edit state
  const [editMode, setEditMode] = useState(false);
  const [editTitle, setEditTitle] = useState(item.title);
  const [editDesc, setEditDesc] = useState(item.description || '');
  const [editCategory, setEditCategory] = useState<ContentCategory>(item.category);
  const [editCover, setEditCover] = useState(item.cover_image_url || '');
  const [editTags, setEditTags] = useState((item.tags || []).join(', '));
  const [editDubbing, setEditDubbing] = useState(item.dubbing_group || '');
  const [editAuthorName, setEditAuthorName] = useState(item.author_name || '');
  const [editChapterNotice, setEditChapterNotice] = useState(item.chapter_notice || '');
  const [editIsVip, setEditIsVip] = useState(item.is_vip || false);
  const [saving, setSaving] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);

  // Admin episode edit
  const [editingEp, setEditingEp] = useState<Episode | null>(null);
  const [showEpEdit, setShowEpEdit] = useState(false);
  const [epNum, setEpNum] = useState('1');
  const [epTitle, setEpTitle] = useState('');
  const [epType, setEpType] = useState<'upload' | 'link' | 'gdrive'>('upload');
  const [epUrl, setEpUrl] = useState('');
  const [uploadingVideo, setUploadingVideo] = useState(false);

  const isVipLocked = item.is_vip && profile?.vip_status !== 'vip' && profile?.vip_status !== 'trial' && !isAdmin;

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        if (item.category === 'comic') {
          const ch = await fetchChapters(item.id);
          setChapters(ch);
        } else {
          const eps = await fetchEpisodes(item.id);
          setEpisodes(eps);
        }
      } catch (err: any) {
        // Fall back silently — UI will show empty state
      }
      setLoading(false);
    };
    loadData();
  }, [item.id, item.category]);

  const openChapter = async (chapter: ComicChapter) => {
    const p = await fetchPanels(chapter.id);
    setPanels(p);
    setShowReader(true);
  };

  const reloadEpisodes = async () => {
    invalidateContentCache(item.id);
    const eps = await fetchEpisodes(item.id);
    setEpisodes(eps);
  };

  const reloadChapters = async () => {
    invalidateContentCache(item.id);
    const ch = await fetchChapters(item.id);
    setChapters(ch);
  };

  // === Admin: save content edits ===
  const handleSaveEdits = async () => {
    setSaving(true);
    await supabase.from('content').update({
      title: editTitle,
      description: editDesc || null,
      category: editCategory,
      cover_image_url: editCover || null,
      tags: editTags.split(',').map((t) => t.trim()).filter(Boolean),
      dubbing_group: editDubbing || null,
      author_name: editCategory === 'comic' ? (editAuthorName || null) : null,
      chapter_notice: editCategory === 'comic' ? (editChapterNotice || null) : null,
      is_vip: editIsVip,
    }).eq('id', item.id);
    setSaving(false);
    setEditMode(false);
    invalidateContentCache(item.id);
    onContentUpdated?.();
  };

  const handleCoverUpload = async (file: File) => {
    setUploadingCover(true);
    const url = await uploadFile('covers', file);
    if (url) setEditCover(url);
    setUploadingCover(false);
  };

  // === Admin: episode edit ===
  const startEditEpisode = (ep: Episode) => {
    setEditingEp(ep);
    setEpNum(String(ep.episode_number));
    setEpTitle(ep.title || '');
    setEpType(ep.video_type);
    setEpUrl(ep.video_url);
    setShowEpEdit(true);
  };

  const handleSaveEpisode = async () => {
    if (!editingEp) return;
    setSaving(true);
    await supabase.from('episodes').update({
      episode_number: parseInt(epNum),
      title: epTitle || null,
      video_type: epType,
      video_url: epUrl,
    }).eq('id', editingEp.id);
    setSaving(false);
    setShowEpEdit(false);
    setEditingEp(null);
    await reloadEpisodes();
  };

  const handleVideoUpload = async (file: File) => {
    setUploadingVideo(true);
    const url = await uploadFile('videos', file);
    if (url) setEpUrl(url);
    setUploadingVideo(false);
  };

  const handleDeleteEpisode = async (id: string) => {
    await supabase.from('episodes').delete().eq('id', id);
    await reloadEpisodes();
  };

  const moveEpisode = async (ep: Episode, direction: 'up' | 'down') => {
    const sorted = [...episodes];
    const idx = sorted.findIndex((e) => e.id === ep.id);
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sorted.length) return;
    const swapEp = sorted[swapIdx];
    await supabase.from('episodes').update({ episode_number: swapEp.episode_number }).eq('id', ep.id);
    await supabase.from('episodes').update({ episode_number: ep.episode_number }).eq('id', swapEp.id);
    await reloadEpisodes();
  };

  // === Admin: chapter edit ===
  const handleDeleteChapter = async (id: string) => {
    await supabase.from('comic_chapters').delete().eq('id', id);
    await reloadChapters();
  };

  const moveChapter = async (ch: ComicChapter, direction: 'up' | 'down') => {
    const sorted = [...chapters];
    const idx = sorted.findIndex((c) => c.id === ch.id);
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sorted.length) return;
    const swapCh = sorted[swapIdx];
    await supabase.from('comic_chapters').update({ chapter_number: swapCh.chapter_number }).eq('id', ch.id);
    await supabase.from('comic_chapters').update({ chapter_number: ch.chapter_number }).eq('id', swapCh.id);
    await reloadChapters();
  };

  const isVideo = item.category !== 'comic';
  const currentEp = episodes[currentEpisode];

  // Memoize the active chapter lookup (was called 4+ times per render)
  const activeChapter = useMemo(
    () => chapters.find((c) => c.id === panels[0]?.chapter_id),
    [chapters, panels]
  );

  return (
    <div className="fixed inset-0 z-[60] flex items-start justify-center p-0 md:p-6 overflow-y-auto animate-fade-in">
      <div className="absolute inset-0 bg-black/85 backdrop-blur-md" onClick={onClose} />
      <div className="relative w-full max-w-4xl bg-secondary rounded-none md:rounded-3xl border border-default shadow-2xl my-0 md:my-4 animate-scale-in overflow-hidden">
        <button onClick={onClose} className="absolute z-10 p-2.5 rounded-full glass text-white hover:text-accent transition-colors" style={{ top: 'calc(0.75rem + var(--safe-top))', left: '0.75rem' }}>
          <X className="w-5 h-5" />
        </button>

        {/* Admin edit bar */}
        {isAdmin && (
          <div className="sticky top-0 z-20 flex items-center justify-between px-4 py-2 bg-accent/10 border-b border-default rounded-t-2xl">
            <span className="text-xs font-medium text-accent">دەستکاری بەڕێوبەر</span>
            <div className="flex items-center gap-2">
              {!editMode ? (
                <button onClick={() => setEditMode(true)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-accent text-white text-xs font-medium">
                  <Edit2 className="w-3.5 h-3.5" /> دەستکاریکردن
                </button>
              ) : (
                <button onClick={handleSaveEdits} disabled={saving} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-600 text-white text-xs font-medium disabled:opacity-50">
                  {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />} پاشەکەوتکردن
                </button>
              )}
            </div>
          </div>
        )}

        {/* Cover banner */}
        <div className="relative h-52 md:h-72 overflow-hidden">
          {editMode ? (
            <>
              {editCover ? <img src={editCover} alt={editTitle} className="w-full h-full object-cover" /> : <div className="w-full h-full bg-card flex items-center justify-center"><BookOpen className="w-16 h-16 text-muted" /></div>}
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center gap-2">
                <label className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/20 text-white cursor-pointer text-sm">
                  {uploadingCover ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />} گۆڕینی وێنە
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleCoverUpload(e.target.files[0])} />
                </label>
              </div>
            </>
          ) : item.cover_image_url ? (
            <img src={item.cover_image_url} alt={item.title} className="w-full h-full object-cover" loading="eager" decoding="async" />
          ) : (
            <div className="w-full h-full bg-card flex items-center justify-center"><BookOpen className="w-16 h-16 text-muted" /></div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[var(--bg-secondary)] via-transparent to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-transparent" />
        </div>

        <div className="p-4 sm:p-6 md:p-8">
          {/* Title & info */}
          <div className="mb-6">
            {editMode ? (
              <div className="space-y-3">
                <input type="text" value={editTitle} onChange={(e) => setEditTitle(e.target.value)} placeholder="ناونیشان" className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                <textarea value={editDesc} onChange={(e) => setEditDesc(e.target.value)} placeholder="وەسف" rows={3} className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent resize-none" />
                <select value={editCategory} onChange={(e) => setEditCategory(e.target.value as ContentCategory)} className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent">
                  {CATEGORIES.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}
                </select>
                <input type="text" value={editDubbing} onChange={(e) => setEditDubbing(e.target.value)} placeholder="ناوی گرووپی دۆبلاژ" className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                {editCategory === 'comic' && (
                  <>
                    <input type="text" value={editAuthorName} onChange={(e) => setEditAuthorName(e.target.value)} placeholder="ناوی نووسەر" className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                    <input type="text" value={editChapterNotice} onChange={(e) => setEditChapterNotice(e.target.value)} placeholder="تێبینی بەش" className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                  </>
                )}
                <input type="text" value={editTags} onChange={(e) => setEditTags(e.target.value)} placeholder="تاگەکان (بە کۆما)" className="w-full px-4 py-2.5 rounded-lg bg-card border border-default text-primary text-sm outline-none focus:border-accent" />
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={editIsVip} onChange={(e) => setEditIsVip(e.target.checked)} className="w-4 h-4 rounded accent-[var(--accent)]" />
                  <span className="text-sm text-primary flex items-center gap-1.5"><Crown className="w-4 h-4 text-accent" /> ناوەڕۆکی VIP</span>
                </label>
              </div>
            ) : (
              <>
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <span className="px-3 py-1 rounded-full bg-accent/20 text-accent text-xs font-medium">{CATEGORY_LABELS[item.category]}</span>
                  {item.is_vip && <span className="px-3 py-1 rounded-full bg-accent/20 text-accent text-xs font-medium flex items-center gap-1"><Crown className="w-3 h-3" /> VIP</span>}
                  {item.dubbing_group && <span className="px-3 py-1 rounded-full bg-hover text-secondary text-xs font-medium">{item.dubbing_group}</span>}
                </div>
                <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-primary mb-3">{item.title}</h2>
                <EngagementBar itemType="content" itemId={item.id} />
                {item.description && <p className="text-secondary text-sm md:text-base leading-relaxed mt-3">{item.description}</p>}
                {item.category === 'comic' && (item.author_name || item.chapter_notice) && (
                  <div className="flex flex-col gap-1.5 mt-3">
                    {item.author_name && (
                      <p className="text-sm text-secondary flex items-center gap-1.5"><User className="w-4 h-4 text-muted" /> {item.author_name}</p>
                    )}
                    {item.chapter_notice && (
                      <p className="text-sm text-secondary flex items-center gap-1.5"><Info className="w-4 h-4 text-muted" /> {item.chapter_notice}</p>
                    )}
                  </div>
                )}
                {item.tags && item.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {item.tags.map((tag, i) => <span key={i} className="text-xs px-3 py-1 rounded-full bg-hover text-secondary">{tag}</span>)}
                  </div>
                )}
              </>
            )}
          </div>

          {/* VIP content lock */}
          {isVipLocked && (
            <div className="bg-accent/10 border border-accent/30 rounded-xl p-4 sm:p-8 text-center space-y-3 sm:space-y-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center mx-auto">
                <Lock className="w-8 h-8 text-accent" />
              </div>
              <div>
                <p className="text-lg font-bold text-accent flex items-center justify-center gap-2"><Crown className="w-5 h-5" /> ناوەڕۆکی VIP</p>
                <p className="text-sm text-secondary mt-2">ئەم ناوەڕۆکە تەنها بۆ ئەندامانی VIP ـە</p>
                <p className="text-xs text-muted mt-1">بە 2,000 دینار لە مانگدا ببە ئەندامی VIP</p>
              </div>
            </div>
          )}

          {/* Content area */}
          {loading ? (
            <div className="flex items-center justify-center py-12"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>
          ) : isVideo ? (
            isVipLocked ? (
              <div className="text-center py-8 text-secondary text-sm">تکایە VIP بکڕە بۆ بینینی ئەم ناوەڕۆکە</div>
            ) : episodes.length > 0 ? (
              <div>
                <VideoPlayer videoUrl={currentEp?.video_url || ''} videoType={currentEp?.video_type || 'upload'} title={currentEp?.title || `${item.title} - ئەلقە ${currentEp?.episode_number}`} episodes={episodes} currentEpisode={currentEpisode} onEpisodeChange={setCurrentEpisode} episodeId={currentEp?.id} />

                {/* Admin episode list with edit controls */}
                {isAdmin && !editMode && (
                  <div className="mt-6 space-y-2">
                    <h4 className="text-sm font-semibold text-primary mb-2">بەڕێوەبردنی ئەلقەکان</h4>
                    {showEpEdit && editingEp && (
                      <div className="bg-card border border-default rounded-xl p-3 space-y-2 animate-scale-in">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-medium text-secondary">دەستکاری ئەلقە</span>
                          <button onClick={() => { setShowEpEdit(false); setEditingEp(null); }} className="text-secondary hover:text-primary"><X className="w-4 h-4" /></button>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <input type="number" value={epNum} onChange={(e) => setEpNum(e.target.value)} placeholder="ژمارە" className="px-3 py-2 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
                          <input type="text" value={epTitle} onChange={(e) => setEpTitle(e.target.value)} placeholder="ناونیشان" className="px-3 py-2 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <button onClick={() => setEpType('upload')} className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-xs font-medium ${epType === 'upload' ? 'bg-accent text-white' : 'bg-secondary text-secondary border border-default'}`}><Upload className="w-3.5 h-3.5" /> بارکردن</button>
                          <button onClick={() => setEpType('link')} className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-xs font-medium ${epType === 'link' ? 'bg-accent text-white' : 'bg-secondary text-secondary border border-default'}`}><Link2 className="w-3.5 h-3.5" /> YouTube</button>
                          <button onClick={() => setEpType('gdrive')} className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-xs font-medium ${epType === 'gdrive' ? 'bg-accent text-white' : 'bg-secondary text-secondary border border-default'}`}><Cloud className="w-3.5 h-3.5" /> Google Drive</button>
                        </div>
                        {epType === 'upload' ? (
                          <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-hover text-secondary cursor-pointer text-sm">
                            {uploadingVideo ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />} گۆڕینی ڤیدیۆ
                            <input type="file" accept="video/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleVideoUpload(e.target.files[0])} />
                          </label>
                        ) : epType === 'gdrive' ? (
                          <input type="text" value={epUrl} onChange={(e) => setEpUrl(e.target.value)} placeholder="لینکی Google Drive" className="w-full px-3 py-2 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
                        ) : (
                          <input type="text" value={epUrl} onChange={(e) => setEpUrl(e.target.value)} placeholder="لینکی YouTube/Vimeo" className="w-full px-3 py-2 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent" />
                        )}
                        <button onClick={handleSaveEpisode} disabled={saving} className="w-full py-2 rounded-lg bg-green-600 text-white text-sm font-medium disabled:opacity-50">{saving ? <Loader2 className="w-4 h-4 animate-spin" /> : 'پاشەکەوتکردن'}</button>
                      </div>
                    )}
                    {episodes.map((ep, i) => (
                      <div key={ep.id} className="flex items-center gap-1 p-2 sm:p-2.5 rounded-lg bg-card border border-default text-sm">
                        <span className="text-primary flex-1 min-w-0 truncate">ئەلقە {ep.episode_number} {ep.title ? `- ${ep.title}` : ''}</span>
                        <button onClick={() => moveEpisode(ep, 'up')} disabled={i === 0} className="p-2 rounded text-secondary hover:text-accent disabled:opacity-30"><ArrowUp className="w-4 h-4" /></button>
                        <button onClick={() => moveEpisode(ep, 'down')} disabled={i === episodes.length - 1} className="p-2 rounded text-secondary hover:text-accent disabled:opacity-30"><ArrowDown className="w-4 h-4" /></button>
                        <button onClick={() => startEditEpisode(ep)} className="p-2 rounded text-secondary hover:text-accent"><Edit2 className="w-4 h-4" /></button>
                        <button onClick={() => handleDeleteEpisode(ep.id)} className="p-2 rounded text-secondary hover:text-red-400"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12 text-secondary"><p>هیچ ئەلقەیەک بەردەست نییە</p></div>
            )
          ) : isVipLocked ? (
            <div className="text-center py-8 text-secondary text-sm">تکایە VIP بکڕە بۆ بینینی ئەم ناوەڕۆکە</div>
          ) : chapters.length > 0 ? (
            showReader ? (
              <>
                <ComicReader panels={panels} musicUrl={activeChapter?.background_music_url || null} onClose={() => setShowReader(false)} chapterId={activeChapter?.id || null} format={activeChapter?.format || 'default'} contentId={item.id} />
                {activeChapter?.id && (
                  <>
                    <div className="mt-3">
                      <EngagementBar itemType="comic_chapter" itemId={activeChapter.id} />
                    </div>
                    <CommentSection itemType="comic_chapter" itemId={activeChapter.id} />
                  </>
                )}
              </>
            ) : (
              <div>
                <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2"><List className="w-5 h-5" /> بەشەکان</h3>
                <div className="space-y-2">
                  {chapters.map((ch, i) => (
                    <div key={ch.id} className="rounded-xl bg-card border border-default overflow-hidden">
                      <div className="flex items-center gap-2 p-3">
                        <button onClick={() => openChapter(ch)} className="flex items-center gap-3 flex-1 text-right group">
                          <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center text-accent font-bold text-sm">{ch.chapter_number}</div>
                          <div>
                            <p className="text-primary font-medium">{ch.title || `بەشی ${ch.chapter_number}`}</p>
                            {ch.background_music_url && <p className="text-xs text-muted flex items-center gap-1 mt-0.5"><Music className="w-3 h-3" /> مۆسیقای پاشبنەما</p>}
                          </div>
                        </button>
                        {isAdmin && (
                          <div className="flex items-center gap-0.5 flex-shrink-0">
                            <button onClick={() => moveChapter(ch, 'up')} disabled={i === 0} className="p-2 rounded text-secondary hover:text-accent disabled:opacity-30"><ArrowUp className="w-4 h-4" /></button>
                            <button onClick={() => moveChapter(ch, 'down')} disabled={i === chapters.length - 1} className="p-2 rounded text-secondary hover:text-accent disabled:opacity-30"><ArrowDown className="w-4 h-4" /></button>
                            <button onClick={() => handleDeleteChapter(ch.id)} className="p-2 rounded text-secondary hover:text-red-400"><Trash2 className="w-4 h-4" /></button>
                          </div>
                        )}
                        <BookOpen className="w-5 h-5 text-muted group-hover:text-accent transition-colors" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )
          ) : (
            <div className="text-center py-12 text-secondary"><p>هیچ بەشێک بەردەست نییە</p></div>
          )}

          {/* Content-level comments */}
          {!editMode && !loading && (
            <CommentSection itemType="content" itemId={item.id} />
          )}
        </div>
      </div>
    </div>
  );
}
