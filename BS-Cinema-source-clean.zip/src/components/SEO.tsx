import { useEffect } from 'react';
import type { ContentItem } from '@/lib/supabase';

const SITE_URL = 'https://bscinema.com';
const DEFAULT_OG_IMAGE = '/og-image.png';
const SITE_TITLE = 'BS Cinema — ماڵپەڕی سینەمای کوردی بۆ فیلم، زنجیرە، ئەنیمی و کۆمیک';
const SITE_DESCRIPTION = 'BS Cinema — یەکەم پلاتفۆڕمی سینەمای کوردی بۆ فیلم، زنجیرە، ئەنیمی، ئەنیمەیشن و کۆمیک. ناوەڕۆکی کوردی بە کوالێتی بەرز.';

function getCategorySchemaType(category: string): string {
  switch (category) {
    case 'movie': return 'Movie';
    case 'series': return 'TVSeries';
    case 'anime': return 'TVSeries';
    case 'comic': return 'ComicSeries';
    default: return 'CreativeWork';
  }
}

function setMeta(attr: string, key: string, content: string) {
  let el = document.querySelector(`meta[${attr}="${key}"]`) as HTMLMetaElement | null;
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function setLink(rel: string, href: string, sizes?: string, type?: string) {
  let el = document.querySelector(`link[rel="${rel}"]${sizes ? `[sizes="${sizes}"]` : ''}`) as HTMLLinkElement | null;
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    if (sizes) el.setAttribute('sizes', sizes);
    if (type) el.setAttribute('type', type);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}

interface SEOProps {
  item: ContentItem | null;
}

export default function SEO({ item }: SEOProps) {
  useEffect(() => {
    const title = item ? `${item.title} — BS Cinema` : SITE_TITLE;
    const description = item?.description || SITE_DESCRIPTION;
    const image = item?.cover_image_url || `${SITE_URL}${DEFAULT_OG_IMAGE}`;
    const url = item ? `${SITE_URL}/` : SITE_URL;

    document.title = title;

    // Standard meta
    setMeta('name', 'description', description);
    setMeta('name', 'author', 'BS Studio');
    setMeta('name', 'keywords', 'BS Cinema, سینەمای کوردی, فیلم, زنجیرە, ئەنیمی, کۆمیک, Kurdish cinema, movies, series, anime');

    // Open Graph
    setMeta('property', 'og:title', title);
    setMeta('property', 'og:description', description);
    setMeta('property', 'og:image', image);
    setMeta('property', 'og:image:secure_url', image);
    setMeta('property', 'og:image:type', 'image/png');
    setMeta('property', 'og:image:width', '1200');
    setMeta('property', 'og:image:height', '630');
    setMeta('property', 'og:image:alt', 'BS Cinema — ماڵپەڕی سینەمای کوردی');
    setMeta('property', 'og:url', url);
    setMeta('property', 'og:type', item ? 'video.movie' : 'website');
    setMeta('property', 'og:site_name', 'BS Cinema');
    setMeta('property', 'og:locale', 'ckb_IQ');
    setMeta('property', 'og:locale:alternate', 'en_US');
    setMeta('property', 'og:locale:alternate', 'ar_IQ');

    // Twitter Card
    setMeta('name', 'twitter:card', 'summary_large_image');
    setMeta('name', 'twitter:title', title);
    setMeta('name', 'twitter:description', description);
    setMeta('name', 'twitter:image', image);

    // Favicon / icons — use BS Cinema branding
    setLink('icon', '/favicon.svg', undefined, 'image/svg+xml');
    setLink('apple-touch-icon', '/apple-touch-icon.png', '180x180');

    // Theme color
    setMeta('name', 'theme-color', '#E63946');

    // JSON-LD structured data
    const schemaType = item ? getCategorySchemaType(item.category) : 'WebSite';
    const jsonLd: Record<string, any> = {
      '@context': 'https://schema.org',
      '@type': schemaType,
      name: item ? item.title : 'BS Cinema',
      description: description,
      url: url,
      inLanguage: 'ckb',
    };
    if (item?.cover_image_url) jsonLd.image = item.cover_image_url;
    if (!item) {
      jsonLd.publisher = { '@type': 'Organization', name: 'BS Studio' };
    }

    let script = document.getElementById('dynamic-jsonld') as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement('script');
      script.id = 'dynamic-jsonld';
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }
    script.textContent = JSON.stringify(jsonLd);

    return () => {
      const s = document.getElementById('dynamic-jsonld');
      if (s) s.remove();
    };
  }, [item]);

  return null;
}
