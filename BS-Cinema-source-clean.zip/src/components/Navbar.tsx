import { useState, useEffect } from 'react';
import { Search, Menu, X, Sun, Moon, User, Settings as SettingsIcon, LogOut, Crown, Bell, MessageCircle, Gamepad2, BookOpen, Bot, Sparkles, Tv } from 'lucide-react';
import Logo from './Logo';
import { CATEGORIES } from '@/lib/categories';
import type { ContentCategory } from '@/lib/supabase';
import { useTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';

interface NavbarProps {
  activeCategory: ContentCategory | 'all' | null;
  onCategoryChange: (cat: ContentCategory | 'all') => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onOpenSettings: () => void;
  onOpenAbout: () => void;
  onOpenVip: () => void;
  onOpenChat: () => void;
  onOpenNotifications: () => void;
  onOpenGames: () => void;
  onOpenYadiJaran: () => void;
  onOpenBookStore: () => void;
  onOpenAIChat: () => void;
  onOpenChannels: () => void;
}

export default function Navbar({
  activeCategory,
  onCategoryChange,
  searchQuery,
  onSearchChange,
  onOpenAuth,
  onOpenProfile,
  onOpenSettings,
  onOpenAbout,
  onOpenVip,
  onOpenChat,
  onOpenNotifications,
  onOpenGames,
  onOpenYadiJaran,
  onOpenBookStore,
  onOpenAIChat,
  onOpenChannels,
}: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const { theme, toggleTheme } = useTheme();
  const { user, profile, signOut } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (!user) return;
    const fetchUnread = () => {
      supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('is_read', false)
        .then(({ count }) => setUnreadNotifs(count || 0));
    };
    fetchUnread();
    const sub = supabase
      .channel('nav-notifs')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${user.id}` }, fetchUnread)
      .subscribe();
    return () => { supabase.removeChannel(sub); };
  }, [user]);

  const handleNav = (cat: ContentCategory | 'all') => {
    onCategoryChange(cat);
    setMobileOpen(false);
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled ? 'glass-dark shadow-deep nav-glow' : 'bg-gradient-to-b from-black/70 to-transparent'
        }`}
        style={{ paddingTop: 'var(--safe-top)' }}
      >
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14 md:h-16 gap-1 sm:gap-2">
            {/* Logo */}
            <button onClick={() => handleNav('all')} className="flex-shrink-0">
              <Logo size="md" />
            </button>

            {/* Desktop Nav — Netflix-style category pills */}
            <div className="hidden lg:flex items-center gap-1 overflow-x-auto scrollbar-hide">
              <button
                onClick={() => handleNav('all')}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                  activeCategory === 'all' ? 'text-accent' : 'text-secondary hover:text-primary'
                }`}
              >
                سەرجەم
              </button>
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.key}
                  onClick={() => handleNav(cat.key)}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all whitespace-nowrap relative ${
                    activeCategory === cat.key ? 'text-accent' : 'text-secondary hover:text-primary'
                  }`}
                >
                  {cat.label}
                  {activeCategory === cat.key && (
                    <span className="absolute bottom-0 left-2 right-2 h-0.5 bg-accent rounded-full" />
                  )}
                </button>
              ))}
            </div>

            {/* Right side actions - desktop */}
            <div className="hidden md:flex items-center gap-1">
              <button
                onClick={onOpenYadiJaran}
                className="p-2.5 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all"
                title="یادی جاران"
              >
                <Sparkles className="w-5 h-5" />
              </button>
              <button
                onClick={onOpenBookStore}
                className="p-2.5 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all"
                title="کتێبخانە"
              >
                <BookOpen className="w-5 h-5" />
              </button>
              <button
                onClick={onOpenAIChat}
                className="p-2.5 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all"
                title="AI چات"
              >
                <Bot className="w-5 h-5" />
              </button>
              <button
                onClick={onOpenChannels}
                className="p-2.5 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all"
                title="کەناڵە کوردیەکان"
              >
                <Tv className="w-5 h-5" />
              </button>
              {user && (
                <>
                  <button
                    onClick={onOpenGames}
                    className="p-2.5 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all"
                    title="یاریەکان"
                  >
                    <Gamepad2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={onOpenChat}
                    className="p-2.5 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all"
                    title="چات"
                  >
                    <MessageCircle className="w-5 h-5" />
                  </button>
                  <button
                    onClick={onOpenNotifications}
                    className="p-2.5 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all relative"
                    title="ئاگادارکردنەوەکان"
                  >
                    <Bell className="w-5 h-5" />
                    {unreadNotifs > 0 && (
                      <span className="absolute -top-0.5 -right-0.5 w-5 h-5 rounded-full bg-[var(--accent)] text-white text-[11px] flex items-center justify-center font-bold">
                        {unreadNotifs > 9 ? '9+' : unreadNotifs}
                      </span>
                    )}
                  </button>
                </>
              )}
              {user && (
                <button
                  onClick={onOpenVip}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-semibold transition-all flex-shrink-0 ${
                    profile?.vip_status === 'vip'
                      ? 'bg-accent/20 text-accent border border-accent/30'
                      : 'bg-accent/10 text-accent border border-accent/20'
                  }`}
                  title="VIP"
                >
                  <Crown className="w-4 h-4" />
                  {profile?.vip_status === 'vip' ? 'VIP' : 'ببە VIP'}
                </button>
              )}
              <div className="relative">
                {searchOpen ? (
                  <div className="flex items-center bg-card border border-bright rounded-full px-3 py-1.5 animate-scale-in">
                    <Search className="w-4 h-4 text-muted flex-shrink-0" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => onSearchChange(e.target.value)}
                      placeholder="گەڕان..."
                      className="bg-transparent border-none outline-none text-sm text-primary placeholder:text-muted w-32 md:w-48 ml-2"
                      autoFocus
                      onBlur={() => !searchQuery && setSearchOpen(false)}
                    />
                    <button onClick={() => { setSearchOpen(false); onSearchChange(''); }}>
                      <X className="w-4 h-4 text-muted" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setSearchOpen(true)}
                    className="p-2.5 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all"
                  >
                    <Search className="w-5 h-5" />
                  </button>
                )}
              </div>
              <button
                onClick={toggleTheme}
                className="p-2.5 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all"
                title={theme === 'dark' ? 'ڕۆشنایی' : 'تاریک'}
              >
                {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
              {user ? (
                <div className="relative">
                  <button
                    onClick={() => setUserMenuOpen(!userMenuOpen)}
                    className="flex items-center gap-2 p-1 pr-2 rounded-full bg-card border border-default hover:bg-hover transition-all"
                  >
                    <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-white text-xs font-bold overflow-hidden">
                      {profile?.avatar_url ? (
                        <img src={profile.avatar_url} alt="avatar" className="w-full h-full object-cover" />
                      ) : (
                        (profile?.username || user.email || 'U').charAt(0).toUpperCase()
                      )}
                    </div>
                  </button>
                  {userMenuOpen && (
                    <>
                      <div className="fixed inset-0 z-40" onClick={() => setUserMenuOpen(false)} />
                      <div className="absolute left-0 mt-2 w-48 glass-dark border border-bright rounded-xl shadow-deep py-2 z-50 animate-scale-in">
                        <button onClick={() => { onOpenProfile(); setUserMenuOpen(false); }} className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-primary hover:text-accent transition-colors">
                          <User className="w-4 h-4" /> پرۆفایل
                        </button>
                        <button onClick={() => { onOpenSettings(); setUserMenuOpen(false); }} className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-primary hover:text-accent transition-colors">
                          <SettingsIcon className="w-4 h-4" /> ڕێکخستنەکان
                        </button>
                        <button onClick={() => { signOut(); setUserMenuOpen(false); }} className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:bg-hover transition-colors">
                          <LogOut className="w-4 h-4" /> چوونەدەرەوە
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <button
                  onClick={onOpenAuth}
                  className="px-5 py-1.5 rounded-full bg-accent text-white text-sm font-bold hover:bg-[var(--accent-hover)] transition-all"
                >
                  چوونەژوورەوە
                </button>
              )}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="md:hidden p-2.5 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all"
              >
                {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>

            {/* Mobile right side - minimal icons */}
            <div className="flex md:hidden items-center gap-1">
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="p-2 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all"
              >
                {searchOpen ? <X className="w-5 h-5" /> : <Search className="w-5 h-5" />}
              </button>
              {user && (
                <button
                  onClick={onOpenNotifications}
                  className="p-2 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all relative"
                >
                  <Bell className="w-5 h-5" />
                  {unreadNotifs > 0 && (
                    <span className="absolute top-0 right-0 w-4 h-4 rounded-full bg-[var(--accent)] text-white text-[10px] flex items-center justify-center font-bold">
                      {unreadNotifs > 9 ? '9+' : unreadNotifs}
                    </span>
                  )}
                </button>
              )}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="p-2 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all"
              >
                {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Mobile search bar */}
          {searchOpen && (
            <div className="md:hidden pb-3 animate-slide-up">
              <div className="flex items-center bg-card border border-bright rounded-full px-3 py-2.5">
                <Search className="w-4 h-4 text-muted flex-shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  placeholder="گەڕان..."
                  className="bg-transparent border-none outline-none text-sm text-primary placeholder:text-muted flex-1 mx-2 min-w-0"
                  autoFocus
                />
                {searchQuery && (
                  <button onClick={() => { setSearchOpen(false); onSearchChange(''); }}>
                    <X className="w-4 h-4 text-muted" />
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Mobile Nav — cinematic dark drawer */}
        {mobileOpen && (
          <div className="md:hidden glass-dark border-t border-default animate-slide-up overflow-y-auto" style={{ maxHeight: 'calc(100vh - 3.5rem - var(--safe-top))' }}>
            <div className="px-3 py-3 space-y-0.5">
              <button
                onClick={() => handleNav('all')}
                className={`w-full text-right px-4 py-3 rounded-lg text-sm font-semibold transition-all ${
                  activeCategory === 'all' ? 'text-accent bg-accent/10' : 'text-secondary hover:text-primary hover:bg-hover'
                }`}
              >
                سەرجەم
              </button>
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.key}
                  onClick={() => handleNav(cat.key)}
                  className={`w-full text-right px-4 py-3 rounded-lg text-sm font-semibold transition-all ${
                    activeCategory === cat.key ? 'text-accent bg-accent/10' : 'text-secondary hover:text-primary hover:bg-hover'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
              <div className="my-2 border-t border-default" />
              <button
                onClick={() => { onOpenYadiJaran(); setMobileOpen(false); }}
                className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-secondary hover:text-accent hover:bg-hover transition-all flex items-center gap-2"
              >
                <Sparkles className="w-5 h-5" /> یادی جاران
              </button>
              <button
                onClick={() => { onOpenBookStore(); setMobileOpen(false); }}
                className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-secondary hover:text-accent hover:bg-hover transition-all flex items-center gap-2"
              >
                <BookOpen className="w-5 h-5" /> کتێبخانە
              </button>
              <button
                onClick={() => { onOpenAIChat(); setMobileOpen(false); }}
                className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-secondary hover:text-accent hover:bg-hover transition-all flex items-center gap-2"
              >
                <Bot className="w-5 h-5" /> AI چات
              </button>
              <button
                onClick={() => { onOpenChannels(); setMobileOpen(false); }}
                className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-secondary hover:text-accent hover:bg-hover transition-all flex items-center gap-2"
              >
                <Tv className="w-5 h-5" /> کەناڵە کوردیەکان
              </button>
              <button
                onClick={() => { onOpenAbout(); setMobileOpen(false); }}
                className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-secondary hover:text-accent hover:bg-hover transition-all"
              >
                دەربارە
              </button>
              {user && (
                <>
                  <button
                    onClick={() => { onOpenGames(); setMobileOpen(false); }}
                    className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-secondary hover:text-accent hover:bg-hover transition-all flex items-center gap-2"
                  >
                    <Gamepad2 className="w-5 h-5" /> یاریەکان
                  </button>
                  <button
                    onClick={() => { onOpenChat(); setMobileOpen(false); }}
                    className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-secondary hover:text-accent hover:bg-hover transition-all flex items-center gap-2"
                  >
                    <MessageCircle className="w-5 h-5" /> چات
                  </button>
                  <button
                    onClick={() => { onOpenNotifications(); setMobileOpen(false); }}
                    className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-secondary hover:text-accent hover:bg-hover transition-all flex items-center gap-2"
                  >
                    <Bell className="w-5 h-5" /> ئاگادارکردنەوەکان
                    {unreadNotifs > 0 && <span className="px-1.5 py-0.5 rounded-full bg-[var(--accent)] text-white text-xs font-bold">{unreadNotifs}</span>}
                  </button>
                  <button
                    onClick={() => { onOpenVip(); setMobileOpen(false); }}
                    className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-accent hover:bg-hover transition-all flex items-center gap-2"
                  >
                    <Crown className="w-5 h-5" /> {profile?.vip_status === 'vip' ? 'VIP' : 'ببە VIP'}
                  </button>
                  <button
                    onClick={() => { onOpenProfile(); setMobileOpen(false); }}
                    className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-secondary hover:text-accent hover:bg-hover transition-all flex items-center gap-2"
                  >
                    <User className="w-5 h-5" /> پرۆفایل
                  </button>
                  <button
                    onClick={() => { onOpenSettings(); setMobileOpen(false); }}
                    className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-secondary hover:text-accent hover:bg-hover transition-all flex items-center gap-2"
                  >
                    <SettingsIcon className="w-5 h-5" /> ڕێکخستنەکان
                  </button>
                  <button
                    onClick={toggleTheme}
                    className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-secondary hover:text-accent hover:bg-hover transition-all flex items-center gap-2"
                  >
                    {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                    {theme === 'dark' ? 'ڕۆشنایی' : 'تاریک'}
                  </button>
                  <button
                    onClick={() => { signOut(); setMobileOpen(false); }}
                    className="w-full text-right px-4 py-3 rounded-lg text-sm font-semibold text-red-400 hover:bg-hover transition-all flex items-center gap-2"
                  >
                    <LogOut className="w-5 h-5" /> چوونەدەرەوە
                  </button>
                </>
              )}
              {!user && (
                <button
                  onClick={() => { onOpenAuth(); setMobileOpen(false); }}
                  className="w-full text-center px-4 py-3 rounded-lg bg-accent text-white text-sm font-bold transition-all"
                >
                  چوونەژوورەوە
                </button>
              )}
            </div>
          </div>
        )}
      </nav>
      <div className="h-14 md:h-16" style={{ height: 'calc(3.5rem + var(--safe-top))' }} />
    </>
  );
}
