import { X, Download, Smartphone, Apple, Loader2, Sparkles } from 'lucide-react';
import { useState, useEffect, useMemo } from 'react';
import { isNativeApp } from '@/lib/platform';

interface AboutPageProps {
  onClose: () => void;
}

interface SignatureCard {
  id: string;
  label: string;
  labelEn: string;
  flagGradient: string;
  flagEmoji: string;
  isGold?: boolean;
  isOrg?: boolean;
}

const SIGNATURE_CARDS: SignatureCard[] = [
  {
    id: 'japan',
    label: 'ژاپۆن',
    labelEn: 'Japan',
    flagGradient: 'linear-gradient(135deg, #ffffff 0%, #bcc3d9 100%)',
    flagEmoji: '🇯🇵',
  },
  {
    id: 'china',
    label: 'چین',
    labelEn: 'China',
    flagGradient: 'linear-gradient(135deg, #de2910 0%, #ffde00 100%)',
    flagEmoji: '🇨🇳',
  },
  {
    id: 'korea',
    label: 'کۆریا',
    labelEn: 'Korea',
    flagGradient: 'linear-gradient(135deg, #003478 0%, #c60c30 100%)',
    flagEmoji: '🇰🇷',
  },
  {
    id: 'usa',
    label: 'ئەمریکا',
    labelEn: 'United States',
    flagGradient: 'linear-gradient(135deg, #3c3b6e 0%, #b22234 100%)',
    flagEmoji: '🇺🇸',
  },
  {
    id: 'kurdistan',
    label: 'کوردستان',
    labelEn: 'Kurdistan',
    flagGradient: 'linear-gradient(135deg, #ef3340 0%, #f9e300 50%, #2bb24c 100%)',
    flagEmoji: '☀',
  },
  {
    id: 'armenia',
    label: 'ئەرمەنستان',
    labelEn: 'Armenia',
    flagGradient: 'linear-gradient(135deg, #d90012 0%, #0033a0 50%, #f2a800 100%)',
    flagEmoji: '🇦🇲',
  },
  {
    id: 'india',
    label: 'هیندستان',
    labelEn: 'India',
    flagGradient: 'linear-gradient(135deg, #ff9933 0%, #ffffff 50%, #138808 100%)',
    flagEmoji: '🇮🇳',
  },
  {
    id: 'greece',
    label: 'یۆنان',
    labelEn: 'Greece',
    flagGradient: 'linear-gradient(135deg, #0d5eaf 0%, #ffffff 100%)',
    flagEmoji: '🇬🇷',
  },
  {
    id: 'lord-aries',
    label: 'لۆرد ئاریس',
    labelEn: 'Lord Aries',
    flagGradient: 'linear-gradient(135deg, #c5a016 0%, #f9e300 50%, #b8862a 100%)',
    flagEmoji: '♈',
    isGold: true,
  },
];

function DecorativeSignature({ id, isGold }: { id: string; isGold?: boolean }) {
  const stroke = isGold ? 'rgba(249,227,0,0.45)' : 'rgba(184,198,224,0.4)';
  const stroke2 = isGold ? 'rgba(249,227,0,0.25)' : 'rgba(107,159,255,0.25)';

  const path = useMemo(() => {
    const hash = id.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    const rand = (seed: number) => {
      const x = Math.sin(seed * 99.7 + hash) * 10000;
      return x - Math.floor(x);
    };

    const strokes: { d: string; w: number }[] = [];
    let seed = 1;

    for (let s = 0; s < 3; s++) {
      const points: string[] = [];
      const numPoints = 4 + Math.floor(rand(seed) * 4);
      let x = 5 + rand(seed) * 10;
      let y = 20 + rand(seed + 1) * 20;
      points.push(`M${x.toFixed(1)},${y.toFixed(1)}`);

      for (let p = 1; p < numPoints; p++) {
        const cx = x + 8 + rand(seed + p * 2) * 18;
        const cy = y + (rand(seed + p * 3) - 0.5) * 30;
        const ex = cx + 6 + rand(seed + p * 5) * 14;
        const ey = 20 + rand(seed + p * 7) * 20;
        points.push(`Q${cx.toFixed(1)},${cy.toFixed(1)} ${ex.toFixed(1)},${ey.toFixed(1)}`);
        x = ex;
        y = ey;
        seed += 10;
      }
      strokes.push({ d: points.join(' '), w: 1.2 + rand(seed) * 1.5 });
      seed += 20;
    }

    return strokes;
  }, [id]);

  return (
    <svg
      viewBox="0 0 100 50"
      className="w-full h-16 sm:h-20"
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
    >
      {path.map((s, i) => (
        <path
          key={i}
          d={s.d}
          fill="none"
          stroke={i === 0 ? stroke : stroke2}
          strokeWidth={s.w}
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity={0.7 - i * 0.15}
          style={{ filter: isGold ? 'drop-shadow(0 0 3px rgba(249,227,0,0.15))' : 'drop-shadow(0 0 2px rgba(107,159,255,0.1))' }}
        />
      ))}
      {/* Small decorative dot at end */}
      <circle
        cx={85 + (id.length % 8)}
        cy={25 + (id.length % 10)}
        r="1.5"
        fill={stroke}
        opacity="0.5"
      />
    </svg>
  );
}

export default function AboutPage({ onClose }: AboutPageProps) {
  const [downloadStatus, setDownloadStatus] = useState<'idle' | 'downloading' | 'success' | 'error'>('idle');
  const [isAndroidApp, setIsAndroidApp] = useState(false);

  useEffect(() => {
    const ua = navigator.userAgent || '';
    setIsAndroidApp(/Android/i.test(ua) && /wv/i.test(ua));
  }, []);

  const handleAndroidDownload = (e: React.MouseEvent) => {
    e.preventDefault();
    setDownloadStatus('downloading');

    try {
      const link = document.createElement('a');
      link.href = './BS-Cinema.apk';
      link.download = 'BS-Cinema.apk';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setTimeout(() => {
        setDownloadStatus('success');
        setTimeout(() => setDownloadStatus('idle'), 5000);
      }, 1500);
    } catch {
      try {
        window.open('./BS-Cinema.apk', '_blank');
        setDownloadStatus('success');
        setTimeout(() => setDownloadStatus('idle'), 5000);
      } catch {
        setDownloadStatus('error');
        setTimeout(() => setDownloadStatus('idle'), 5000);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[60] overflow-y-auto bg-primary animate-fade-in">
      {/* Cosmic star field for the About page */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
        <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg, #020410 0%, #040714 50%, #060a1c 100%)' }} />
        <div className="absolute inset-0 animate-nebula-drift" style={{ background: 'radial-gradient(ellipse 60% 40% at 30% 20%, rgba(107,159,255,0.06) 0%, transparent 70%)' }} />
        <div className="absolute inset-0 animate-nebula-drift" style={{ background: 'radial-gradient(ellipse 50% 35% at 70% 60%, rgba(167,139,255,0.05) 0%, transparent 70%)', animationDelay: '5s' }} />
        {Array.from({ length: 120 }).map((_, i) => {
          const x = (i * 37 + 13) % 100;
          const y = (i * 53 + 7) % 100;
          const size = ((i * 7) % 3) + 0.5;
          const delay = ((i * 11) % 5);
          const duration = ((i * 13) % 3) + 2;
          return (
            <div
              key={`about-star-${i}`}
              className="absolute rounded-full animate-twinkle"
              style={{
                left: `${x}%`, top: `${y}%`,
                width: `${size}px`, height: `${size}px`,
                background: 'rgba(220, 230, 255, 0.8)',
                boxShadow: `0 0 ${size * 2}px rgba(184, 198, 224, 0.3)`,
                animationDelay: `${delay}s`,
                animationDuration: `${duration}s`,
                opacity: 0.3 + ((i * 17) % 60) / 100,
              }}
            />
          );
        })}
      </div>

      <div className="relative z-10">
        <div className="sticky top-0 glass-dark border-b border-default px-4 py-3 flex items-center justify-between" style={{ paddingTop: 'calc(0.75rem + var(--safe-top))' }}>
          <h2 className="text-lg font-bold text-primary">دەربارە</h2>
          <button onClick={onClose} className="p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="max-w-4xl mx-auto p-4 sm:p-6 md:p-8">
          {/* Header */}
          <div className="text-center mb-8 sm:mb-12 animate-slide-up">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full cosmic-glass flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-8 h-8 sm:w-10 sm:h-10 text-accent" />
            </div>
            {/* Flag stripe — preserved */}
            <div className="flex justify-center mb-4">
              <div className="flex h-1.5 w-32 rounded-full overflow-hidden">
                <div className="flex-1" style={{ background: 'var(--flag-red)' }} />
                <div className="flex-1" style={{ background: 'var(--flag-white)' }} />
                <div className="flex-1" style={{ background: 'var(--flag-green)' }} />
                <div className="flex-1" style={{ background: 'var(--flag-yellow)' }} />
              </div>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black mb-3">
              <span style={{ color: 'var(--accent)' }}>B</span>
              <span style={{ color: 'var(--flag-red)' }}>S</span>
              <span className="text-primary ml-2">Cinema</span>
            </h1>
            <p className="text-sm sm:text-base text-secondary max-w-md mx-auto leading-relaxed">
              BS Cinema تایبەت دروست کراوە بۆ خزمەتی گەلان، بەڕێوبەری ماڵپەر لۆرد ئاریس
            </p>
          </div>

          {/* Signature Cards Section */}
          <div className="mb-8 sm:mb-12">
            <h2 className="text-xl sm:text-2xl font-bold text-primary text-center mb-2">
              <span className="text-gradient-accent">واژۆی تایبەت</span>
            </h2>
            <p className="text-xs sm:text-sm text-secondary text-center mb-6 sm:mb-8 leading-relaxed max-w-lg mx-auto">
              کۆکراوەی واژۆی تایبەت لە نەتەوە و ڕێکخراوە جیاوازەکانەوە — هێمای ڕێز و هاوکاری
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-5">
              {SIGNATURE_CARDS.map((card, idx) => (
                <div
                  key={card.id}
                  className={`group relative rounded-2xl overflow-hidden animate-slide-up ${card.isGold ? 'cosmic-glass-gold' : 'cosmic-glass'}`}
                  style={{ animationDelay: `${idx * 0.08}s`, opacity: 0 }}
                >
                  <div className="p-4 sm:p-5 flex flex-col items-center text-center min-h-[200px] sm:min-h-[240px]">
                    {/* Flag / identity circle */}
                    <div
                      className="w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center mb-3 flex-shrink-0 overflow-hidden"
                      style={{ background: card.flagGradient, boxShadow: '0 0 16px rgba(107, 159, 255, 0.15)' }}
                    >
                      <span className="text-xl sm:text-2xl" style={{ filter: 'drop-shadow(0 1px 2px rgba(0,0,0,0.3))' }}>
                        {card.flagEmoji}
                      </span>
                    </div>

                    {/* Label */}
                    <h3 className={`text-sm sm:text-base font-bold mb-1 ${card.isGold ? 'text-yellow-200' : 'text-primary'}`}>
                      {card.label}
                    </h3>
                    <p className="text-[10px] sm:text-xs text-muted mb-3">
                      {card.labelEn}
                    </p>

                    {/* Decorative signature area */}
                    <div className="flex-1 w-full flex items-center justify-center">
                      <div
                        className={`w-full rounded-lg flex items-center justify-center px-2 py-1 ${card.isGold ? 'border border-yellow-400/15' : 'border border-white/5'}`}
                        style={{
                          background: card.isGold
                            ? 'linear-gradient(135deg, rgba(249,227,0,0.04) 0%, rgba(232,168,56,0.02) 100%)'
                            : 'linear-gradient(135deg, rgba(107,159,255,0.03) 0%, rgba(167,139,255,0.02) 100%)',
                        }}
                      >
                        <DecorativeSignature id={card.id} isGold={card.isGold} />
                      </div>
                    </div>
                  </div>

                  {/* Subtle glow border on hover */}
                  <div
                    className="absolute inset-0 rounded-2xl pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{
                      boxShadow: card.isGold
                        ? 'inset 0 0 20px rgba(249,227,0,0.08)'
                        : 'inset 0 0 20px rgba(107,159,255,0.06)',
                    }}
                  />
                </div>
              ))}
            </div>

            {/* Disclaimer */}
            <p className="text-[10px] sm:text-xs text-muted text-center mt-6 leading-relaxed max-w-lg mx-auto">
              ئەم واژانە هێمای ڕێز و نزیکییەوە، نەک پشتگیری فەرمی حکومەت
            </p>
          </div>

          {/* Download buttons — hidden inside the APK, only shown on website */}
          {!isNativeApp() && (
          <div className="space-y-4 mb-6">
            {/* Android download */}
            <div className="flex flex-col items-center gap-3">
              <button
                onClick={handleAndroidDownload}
                disabled={downloadStatus === 'downloading'}
                className="group flex items-center gap-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold px-8 py-4 rounded-2xl shadow-lg shadow-blue-900/40 transition-all hover:scale-105 hover:shadow-xl w-full sm:w-auto justify-center disabled:opacity-70 disabled:hover:scale-100"
              >
                {downloadStatus === 'downloading' ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  <Smartphone className="w-6 h-6 group-hover:animate-pulse" />
                )}
                <span className="text-base">
                  {downloadStatus === 'downloading'
                    ? 'داگرتن...'
                    : downloadStatus === 'success'
                    ? 'داگرتن سەرکەوتوو بوو ✓'
                    : downloadStatus === 'error'
                    ? 'هەڵە لە داگرتن — دووبارە هەوڵ بدە'
                    : 'داگرتنی ئەپی ئەندرۆید'}
                </span>
                {downloadStatus === 'idle' && <Download className="w-5 h-5" />}
              </button>
              <p className="text-xs text-muted">BS-Cinema.apk</p>
              {downloadStatus === 'success' && isAndroidApp && (
                <p className="text-xs text-accent">داگرتن تەواو بوو — دامەزراندنی ئەپ بکەرەوە</p>
              )}
              {downloadStatus === 'error' && (
                <p className="text-xs text-red-400">تکایە هێڵی ئینتەرنێت پشکنە و دووبارە هەوڵ بدە</p>
              )}
            </div>

            {/* iPhone install instructions */}
            <div className="cosmic-glass rounded-2xl p-5 md:p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center flex-shrink-0">
                  <Apple className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-base font-bold text-primary">داگرتن بۆ ئایفۆن</h3>
              </div>
              <div className="space-y-2.5 text-sm text-secondary leading-relaxed" dir="rtl">
                <p className="font-medium text-primary">ڕێگەی دامەزراندن لەسەر ئایفۆن:</p>
                <ol className="list-none space-y-2">
                  <li className="flex gap-2">
                    <span className="text-accent font-bold flex-shrink-0">١.</span>
                    <span>سافاری (Safari) بکەرەوە و بڕۆ بۆ <a href="https://bscinema.com" className="text-accent underline">bscinema.com</a></span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent font-bold flex-shrink-0">٢.</span>
                    <span>هێمای هاوبەشکردن (Share) دابگرە لە خوارەوەی شاشە</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent font-bold flex-shrink-0">٣.</span>
                    <span>«Add to Home Screen» هەڵبژێرە</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent font-bold flex-shrink-0">٤.</span>
                    <span>«Add» دابگرە بۆ دامەزراندنی ئەپ</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent font-bold flex-shrink-0">٥.</span>
                    <span>ئەپ لەسەر شاشەی سەرەکی ئایفۆنەکەت دەردەکەوێت و وەک ئەپی ڕەسەن کار دەکات</span>
                  </li>
                </ol>
              </div>
            </div>
          </div>
          )}

          {/* Footer */}
          <div className="mt-6 text-center text-sm text-muted">
            <p>© 2026 BS Cinema — هەموو مافەکان پارێزراون</p>
            <a href="https://bscinema.com" target="_blank" rel="noopener noreferrer" className="text-accent hover:text-primary transition-colors mt-1 inline-block">
              bscinema.com
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
