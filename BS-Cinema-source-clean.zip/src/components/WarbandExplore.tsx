import { useRef, useEffect, useCallback, useState } from 'react';
import {
  Sword, Shield, Footprints, FastForward, Hand, Camera as CameraIcon,
  ChevronLeft, MapPin, Heart,
} from 'lucide-react';
import type { WarbandGameState, WorldEntity } from '@/lib/warbandTypes';
import { mapToWorld } from '@/lib/warband3D';
import { FACTIONS } from '@/lib/warbandEngine';

// === Canvas 3D renderer for the explore screen ===
// Renders a pseudo-3D world using canvas 2D with perspective projection.

interface ExploreScreenProps {
  state: WarbandGameState;
  onExit: () => void;
  onUpdate: (dt: number, jdx: number, jdy: number, actions: ExploreActions) => void;
  onCameraDrag: (dYaw: number, dPitch: number) => void;
  onToggleCamera: () => void;
  onEnterLocation: () => void;
}

interface ExploreActions {
  attack: boolean;
  block: boolean;
  dodge: boolean;
  mount: boolean;
  interact: boolean;
}

export default function ExploreScreen({
  state, onExit, onUpdate, onCameraDrag, onToggleCamera, onEnterLocation,
}: ExploreScreenProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [joystickDX, setJoystickDX] = useState(0);
  const [joystickDY, setJoystickDY] = useState(0);
  const [joystickActive, setJoystickActive] = useState(false);
  const joystickId = useRef<number | null>(null);
  const joystickStart = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const cameraDragId = useRef<number | null>(null);
  const cameraLastPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const lastFrameTime = useRef<number>(0);
  const animFrame = useRef<number>(0);

  // Keep action ref in sync without re-render
  const actionsQueue = useRef<ExploreActions>({ attack: false, block: false, dodge: false, mount: false, interact: false });

  // === Main game loop ===
  useEffect(() => {
    const loop = (time: number) => {
      const dt = lastFrameTime.current ? Math.min(0.05, (time - lastFrameTime.current) / 1000) : 0.016;
      lastFrameTime.current = time;

      // Process queued actions then reset one-shot actions
      onupdate_ref.current(dt, joystickDX, joystickDY, { ...actionsQueue.current });
      actionsQueue.current = { ...actionsQueue.current, attack: false, dodge: false, mount: false, interact: false };

      // Render
      renderCanvas();

      animFrame.current = requestAnimationFrame(loop);
    };
    animFrame.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrame.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [joystickDX, joystickDY]);

  // Use a ref to avoid stale closure in the game loop
  const onupdate_ref = useRef(onUpdate);
  onupdate_ref.current = onUpdate;

  // === Canvas rendering ===
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    const p = state.player3D;
    const cam = state.cameraMode;

    // Clear
    ctx.fillStyle = '#0a0a12';
    ctx.fillRect(0, 0, w, h);

    // Sky gradient
    const skyGrad = ctx.createLinearGradient(0, 0, 0, h * 0.6);
    skyGrad.addColorStop(0, '#1a1525');
    skyGrad.addColorStop(0.5, '#2a1f3a');
    skyGrad.addColorStop(1, '#3a2a1a');
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, w, h * 0.55);

    // Ground gradient
    const groundGrad = ctx.createLinearGradient(0, h * 0.45, 0, h);
    groundGrad.addColorStop(0, '#2a3320');
    groundGrad.addColorStop(1, '#1a2010');
    ctx.fillStyle = groundGrad;
    ctx.fillRect(0, h * 0.45, w, h * 0.55);

    // Camera params
    const fov = h * 0.8;
    const camHeight = cam === 'first-person' ? 1.8 : 4;
    const camDist = cam === 'first-person' ? 0 : p.camDist;
    const camX = p.x - Math.sin(p.camYaw) * camDist;
    const camZ = p.z - Math.cos(p.camYaw) * camDist;

    // Project 3D world point to 2D screen
    const project = (wx: number, wy: number, wz: number): { sx: number; sy: number; scale: number } | null => {
      // Translate relative to camera
      let dx = wx - camX;
      let dz = wz - camZ;
      // Rotate by camera yaw
      const cosY = Math.cos(p.camYaw);
      const sinY = Math.sin(p.camYaw);
      const rx = dx * cosY + dz * sinY;
      const rz = -dx * sinY + dz * cosY;
      // Apply pitch
      const cosP = Math.cos(p.camPitch);
      const sinP = Math.sin(p.camPitch);
      const ry = wy - camHeight;
      const fy = ry * cosP - rz * sinP;
      const fz = ry * sinP + rz * cosP;

      if (fz < 0.5) return null; // Behind camera

      const scale = fov / fz;
      const sx = w / 2 + rx * scale;
      const sy = h / 2 - fy * scale;
      return { sx, sy, scale };
    };

    // Draw ground grid
    ctx.strokeStyle = 'rgba(80, 70, 40, 0.3)';
    ctx.lineWidth = 1;
    const gridSize = 10;
    const range = 60;
    for (let gx = Math.floor((p.x - range) / gridSize) * gridSize; gx <= p.x + range; gx += gridSize) {
      const start = project(gx, 0, p.z - range);
      const end = project(gx, 0, p.z + range);
      if (start && end) {
        ctx.beginPath();
        ctx.moveTo(start.sx, start.sy);
        ctx.lineTo(end.sx, end.sy);
        ctx.stroke();
      }
    }
    for (let gz = Math.floor((p.z - range) / gridSize) * gridSize; gz <= p.z + range; gz += gridSize) {
      const start = project(p.x - range, 0, gz);
      const end = project(p.x + range, 0, gz);
      if (start && end) {
        ctx.beginPath();
        ctx.moveTo(start.sx, start.sy);
        ctx.lineTo(end.sx, end.sy);
        ctx.stroke();
      }
    }

    // Draw current location structure
    const currentLoc = state.locations.find((l) => l.id === state.currentLocationId);
    if (currentLoc) {
      const { x: lx, z: lz } = mapToWorld(currentLoc);
      const factionColor = FACTIONS.find((f) => f.id === currentLoc.faction)?.color || '#888';

      // Draw location as a 3D structure
      const locHeight = currentLoc.type === 'city' ? 15 : currentLoc.type === 'castle' ? 12 : currentLoc.type === 'village' ? 5 : 3;
      const locRadius = currentLoc.type === 'city' ? 8 : currentLoc.type === 'castle' ? 6 : 4;

      // Base/foundation
      const baseProj = project(lx, 0, lz);
      if (baseProj) {
        ctx.fillStyle = factionColor + '44';
        ctx.beginPath();
        ctx.arc(baseProj.sx, baseProj.sy, locRadius * baseProj.scale, 0, Math.PI * 2);
        ctx.fill();
      }

      // Walls (draw as box)
      const corners = [
        { x: lx - locRadius, z: lz - locRadius },
        { x: lx + locRadius, z: lz - locRadius },
        { x: lx + locRadius, z: lz + locRadius },
        { x: lx - locRadius, z: lz + locRadius },
      ];
      const wallBottom = corners.map((c) => project(c.x, 0, c.z));
      const wallTop = corners.map((c) => project(c.x, locHeight, c.z));
      if (wallBottom[0] && wallTop[0] && wallBottom[1] && wallTop[1]) {
        // Front face
        ctx.fillStyle = factionColor + 'cc';
        ctx.beginPath();
        ctx.moveTo(wallBottom[0].sx, wallBottom[0].sy);
        ctx.lineTo(wallBottom[1].sx, wallBottom[1].sy);
        ctx.lineTo(wallTop[1].sx, wallTop[1].sy);
        ctx.lineTo(wallTop[0].sx, wallTop[0].sy);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = factionColor;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Side face
        if (wallBottom[1] && wallTop[1] && wallBottom[2] && wallTop[2]) {
          ctx.fillStyle = factionColor + '88';
          ctx.beginPath();
          ctx.moveTo(wallBottom[1].sx, wallBottom[1].sy);
          ctx.lineTo(wallBottom[2].sx, wallBottom[2].sy);
          ctx.lineTo(wallTop[2].sx, wallTop[2].sy);
          ctx.lineTo(wallTop[1].sx, wallTop[1].sy);
          ctx.closePath();
          ctx.fill();
        }

        // Banner on top
        const bannerProj = project(lx, locHeight + 3, lz);
        if (bannerProj && currentLoc.isCapital) {
          ctx.fillStyle = '#ffd700';
          ctx.font = `bold ${Math.max(10, 20 * bannerProj.scale / 50)}px sans-serif`;
          ctx.textAlign = 'center';
          ctx.fillText('👑', bannerProj.sx, bannerProj.sy);
        }
      }

      // Location name label
      const nameProj = project(lx, locHeight + 5, lz);
      if (nameProj && nameProj.scale > 2) {
        ctx.fillStyle = '#fff';
        ctx.font = `bold ${Math.max(8, Math.min(16, 14 * nameProj.scale / 30))}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText(currentLoc.name, nameProj.sx, nameProj.sy);
      }
    }

    // Collect all visible entities + player for depth sorting
    type RenderItem = { sx: number; sy: number; scale: number; dist: number; kind: string; entity?: WorldEntity };
    const items: RenderItem[] = [];

    // Player shadow
    const playerShadow = project(p.x, 0, p.z);
    if (playerShadow && cam === 'third-person') {
      items.push({ ...playerShadow, dist: 0, kind: 'player-shadow' });
    }

    // Player character (third person)
    if (cam === 'third-person') {
      const playerProj = project(p.x, 0, p.z);
      if (playerProj) {
        const charHeight = p.isMounted ? 3 : 2;
        const headProj = project(p.x, charHeight, p.z);
        if (headProj) {
          items.push({ ...playerProj, dist: 0, kind: 'player', entity: undefined });
          void headProj;
        }
      }
    }

    // Entities
    for (const e of state.worldEntities) {
      if (e.state === 'dead') continue;
      const proj = project(e.x, 0, e.z);
      if (proj) {
        const dx = e.x - camX;
        const dz = e.z - camZ;
        const dist = Math.sqrt(dx * dx + dz * dz);
        items.push({ ...proj, dist, kind: e.type, entity: e });
      }
    }

    // Sort by distance (far first)
    items.sort((a, b) => b.dist - a.dist);

    // Draw all items
    for (const item of items) {
      if (item.kind === 'player-shadow') {
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.beginPath();
        ctx.ellipse(item.sx, item.sy, 12 * item.scale / 50, 4 * item.scale / 50, 0, 0, Math.PI * 2);
        ctx.fill();
        continue;
      }

      if (item.kind === 'player') {
        drawCharacter3D(ctx, item.sx, item.sy, item.scale, state.selectedCharacter.portraitColor, state.selectedCharacter.accentColor, p.angle - p.camYaw, p.attackAnim, p.isBlocking, p.hitFlash, p.isMounted, state.selectedCharacter.weapon);
        continue;
      }

      if (item.entity) {
        const e = item.entity;
        const charHeight = e.type === 'horse' ? 2.5 : 2;
        const headProj = project(e.x, charHeight, e.z);

        // Shadow
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.beginPath();
        ctx.ellipse(item.sx, item.sy, 10 * item.scale / 50, 3 * item.scale / 50, 0, 0, Math.PI * 2);
        ctx.fill();

        if (e.type === 'enemy') {
          drawCharacter3D(ctx, item.sx, item.sy, item.scale, e.portraitColor, e.accentColor, e.angle - p.camYaw, e.attackCooldown > 0.8 ? 1 : 0, false, e.hitFlash, false, e.weapon);
          // HP bar above enemy
          if (headProj && item.scale > 3) {
            const barW = Math.max(20, 40 * item.scale / 50);
            const barH = 4;
            const barY = headProj.sy - 10;
            ctx.fillStyle = 'rgba(0,0,0,0.6)';
            ctx.fillRect(headProj.sx - barW / 2, barY, barW, barH);
            const hpPct = e.hp / e.maxHp;
            ctx.fillStyle = hpPct > 0.5 ? '#22c55e' : hpPct > 0.25 ? '#f59e0b' : '#ef4444';
            ctx.fillRect(headProj.sx - barW / 2, barY, barW * hpPct, barH);
          }
        } else if (e.type === 'horse') {
          drawHorse3D(ctx, item.sx, item.sy, item.scale, e.portraitColor);
        } else if (e.type === 'npc') {
          drawCharacter3D(ctx, item.sx, item.sy, item.scale, e.portraitColor, e.accentColor, e.angle - p.camYaw, 0, false, 0, false, 'sword');
        }
      }
    }

    // First-person weapon overlay
    if (cam === 'first-person') {
      drawFirstPersonWeapon(ctx, w, h, p.attackAnim, p.isBlocking, state.selectedCharacter.weapon);
    }

    // Crosshair in first person
    if (cam === 'first-person') {
      ctx.strokeStyle = 'rgba(255,200,100,0.5)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(w / 2 - 8, h / 2);
      ctx.lineTo(w / 2 + 8, h / 2);
      ctx.moveTo(w / 2, h / 2 - 8);
      ctx.lineTo(w / 2, h / 2 + 8);
      ctx.stroke();
    }
  }, [state]);

  // === Touch handlers for joystick (left side) ===
  const handleJoystickStart = useCallback((e: React.TouchEvent) => {
    const touch = e.changedTouches[0];
    joystickId.current = touch.identifier;
    joystickStart.current = { x: touch.clientX, y: touch.clientY };
    setJoystickActive(true);
  }, []);

  const handleJoystickMove = useCallback((e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === joystickId.current) {
        const dx = touch.clientX - joystickStart.current.x;
        const dy = touch.clientY - joystickStart.current.y;
        const maxR = 50;
        const mag = Math.sqrt(dx * dx + dy * dy);
        const clampedMag = Math.min(maxR, mag);
        const angle = Math.atan2(dy, dx);
        const jdx = Math.cos(angle) * (clampedMag / maxR);
        const jdy = Math.sin(angle) * (clampedMag / maxR);
        setJoystickDX(jdx);
        setJoystickDY(jdy);
      }
    }
  }, []);

  const handleJoystickEnd = useCallback((e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === joystickId.current) {
        joystickId.current = null;
        setJoystickActive(false);
        setJoystickDX(0);
        setJoystickDY(0);
      }
    }
  }, []);

  // === Touch handlers for camera (right side) ===
  const handleCameraStart = useCallback((e: React.TouchEvent) => {
    const touch = e.changedTouches[0];
    cameraDragId.current = touch.identifier;
    cameraLastPos.current = { x: touch.clientX, y: touch.clientY };
  }, []);

  const handleCameraMove = useCallback((e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === cameraDragId.current) {
        const dx = touch.clientX - cameraLastPos.current.x;
        const dy = touch.clientY - cameraLastPos.current.y;
        cameraLastPos.current = { x: touch.clientX, y: touch.clientY };
        onCameraDrag(-dx * 0.005, -dy * 0.005);
      }
    }
  }, [onCameraDrag]);

  const handleCameraEnd = useCallback((e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === cameraDragId.current) {
        cameraDragId.current = null;
      }
    }
  }, []);

  // Action button handlers (one-shot)
  const handleAttack = useCallback(() => { actionsQueue.current.attack = true; }, []);
  const handleDodge = useCallback(() => { actionsQueue.current.dodge = true; }, []);
  const handleMount = useCallback(() => { actionsQueue.current.mount = true; }, []);
  const handleInteract = useCallback(() => { actionsQueue.current.interact = true; }, []);

  // Block is continuous (hold)
  const handleBlockStart = useCallback(() => { actionsQueue.current.block = true; }, []);
  const handleBlockEnd = useCallback(() => { actionsQueue.current.block = false; }, []);

  // Canvas resize
  useEffect(() => {
    const resize = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const parent = canvas.parentElement;
      if (!parent) return;
      canvas.width = parent.clientWidth;
      canvas.height = parent.clientHeight;
    };
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, []);

  const hpPct = (state.player3D.currentHp / state.maxHp) * 100;
  const aliveEnemies = state.worldEntities.filter((e) => e.type === 'enemy' && e.state !== 'dead').length;

  return (
    <div className="fixed inset-0 z-[100] bg-[#050308] select-none touch-none overflow-hidden">
      {/* Canvas — fills entire screen */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />

      {/* Camera drag area (right half, behind buttons) */}
      <div
        className="absolute right-0 top-0 bottom-0 w-1/2 z-10"
        onTouchStart={handleCameraStart}
        onTouchMove={handleCameraMove}
        onTouchEnd={handleCameraEnd}
        onTouchCancel={handleCameraEnd}
      />

      {/* Joystick area (left half) */}
      <div
        className="absolute left-0 top-0 bottom-0 w-1/2 z-10"
        onTouchStart={handleJoystickStart}
        onTouchMove={handleJoystickMove}
        onTouchEnd={handleJoystickEnd}
        onTouchCancel={handleJoystickEnd}
      />

      {/* Visual joystick base */}
      {joystickActive && (
        <div className="absolute z-20 pointer-events-none" style={{ left: joystickStart.current.x - 60, top: joystickStart.current.y - 60 }}>
          <div className="w-[120px] h-[120px] rounded-full border-2 border-amber-500/30 bg-black/20" />
        </div>
      )}
      {joystickActive && (
        <div
          className="absolute z-20 pointer-events-none w-12 h-12 rounded-full bg-amber-500/40 border-2 border-amber-400"
          style={{
            left: joystickStart.current.x - 24 + joystickDX * 50,
            top: joystickStart.current.y - 24 + joystickDY * 50,
          }}
        />
      )}

      {/* HUD: Top bar */}
      <div className="absolute top-0 left-0 right-0 z-30 p-2 flex items-center justify-between gap-2">
        {/* HP bar */}
        <div className="flex items-center gap-2 bg-black/60 rounded-lg px-2 py-1 backdrop-blur-sm">
          <Heart className="w-4 h-4 text-rose-400 shrink-0" />
          <div className="w-20 h-2 rounded-full bg-black/50 overflow-hidden">
            <div className={`h-full ${hpPct > 50 ? 'bg-emerald-500' : hpPct > 25 ? 'bg-amber-500' : 'bg-rose-600'} transition-all`}
              style={{ width: `${hpPct}%` }} />
          </div>
          <span className="text-[10px] text-amber-200 font-mono">{Math.ceil(state.player3D.currentHp)}/{state.maxHp}</span>
        </div>

        {/* Location name */}
        <div className="flex items-center gap-1.5 bg-black/60 rounded-lg px-2.5 py-1 backdrop-blur-sm">
          <MapPin className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-xs text-amber-100 font-bold">{state.locations.find((l) => l.id === state.currentLocationId)?.name || 'Unknown'}</span>
          {aliveEnemies > 0 && <span className="text-[10px] text-rose-400 ml-1">⚔ {aliveEnemies}</span>}
        </div>

        {/* Buttons */}
        <div className="flex items-center gap-1">
          <button onClick={onToggleCamera} className="p-2 rounded-lg bg-black/60 backdrop-blur-sm active:scale-95 transition" aria-label="Camera">
            <CameraIcon className="w-4 h-4 text-amber-300" />
          </button>
          <button onClick={onExit} className="p-2 rounded-lg bg-black/60 backdrop-blur-sm active:scale-95 transition" aria-label="Exit">
            <ChevronLeft className="w-5 h-5 text-amber-200" />
          </button>
        </div>
      </div>

      {/* Camera mode indicator */}
      <div className="absolute top-12 right-2 z-30 text-[9px] text-amber-300/60 bg-black/50 rounded px-1.5 py-0.5">
        {state.cameraMode === 'first-person' ? '1st Person' : '3rd Person'}
      </div>

      {/* Enter location prompt */}
      {state.nearbyLocationId && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-30 pointer-events-none">
          <button onClick={onEnterLocation}
            className="pointer-events-auto min-h-[44px] px-5 rounded-lg bg-gradient-to-b from-amber-500 to-amber-700 text-white text-sm font-bold flex items-center gap-2 active:scale-95 transition shadow-xl animate-pulse">
            <MapPin className="w-4 h-4" /> Enter Location
          </button>
        </div>
      )}

      {/* Combat log (top-right, below HUD) */}
      {state.combatLog.length > 0 && (
        <div className="absolute top-20 left-2 z-20 max-w-[60%] space-y-0.5 pointer-events-none">
          {state.combatLog.slice(-4).map((entry) => (
            <p key={entry.id} className="text-[9px] sm:text-[10px] text-amber-200/70 bg-black/40 rounded px-1.5 py-0.5">
              {entry.text}
            </p>
          ))}
        </div>
      )}

      {/* Action buttons (right side, above camera drag) */}
      <div className="absolute bottom-4 right-3 z-30 flex flex-col items-end gap-2">
        {/* Attack */}
        <button onTouchStart={(e) => { e.preventDefault(); handleAttack(); }}
          className="w-14 h-14 rounded-full bg-gradient-to-b from-rose-600 to-rose-800 border-2 border-rose-400/50 flex items-center justify-center active:scale-90 transition shadow-xl">
          <Sword className="w-6 h-6 text-white" />
        </button>
        <div className="flex gap-2">
          {/* Block (hold) */}
          <button
            onTouchStart={(e) => { e.preventDefault(); handleBlockStart(); }}
            onTouchEnd={(e) => { e.preventDefault(); handleBlockEnd(); }}
            onTouchCancel={handleBlockEnd}
            className="w-12 h-12 rounded-full bg-gradient-to-b from-sky-600 to-sky-800 border-2 border-sky-400/50 flex items-center justify-center active:scale-90 transition shadow-xl">
            <Shield className="w-5 h-5 text-white" />
          </button>
          {/* Dodge */}
          <button onTouchStart={(e) => { e.preventDefault(); handleDodge(); }}
            className="w-12 h-12 rounded-full bg-gradient-to-b from-violet-600 to-violet-800 border-2 border-violet-400/50 flex items-center justify-center active:scale-90 transition shadow-xl">
            <Footprints className="w-5 h-5 text-white" />
          </button>
        </div>
        <div className="flex gap-2">
          {/* Mount */}
          <button onTouchStart={(e) => { e.preventDefault(); handleMount(); }}
            className={`w-12 h-12 rounded-full border-2 flex items-center justify-center active:scale-90 transition shadow-xl ${
              state.player3D.isMounted
                ? 'bg-gradient-to-b from-amber-500 to-amber-700 border-amber-300'
                : 'bg-gradient-to-b from-amber-800 to-amber-950 border-amber-600/50'
            }`}>
            <FastForward className="w-5 h-5 text-white" />
          </button>
          {/* Interact */}
          <button onTouchStart={(e) => { e.preventDefault(); handleInteract(); }}
            className="w-12 h-12 rounded-full bg-gradient-to-b from-emerald-600 to-emerald-800 border-2 border-emerald-400/50 flex items-center justify-center active:scale-90 transition shadow-xl">
            <Hand className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      {/* Controls hint (bottom-left) */}
      <div className="absolute bottom-2 left-2 z-20 text-[8px] text-amber-200/40 pointer-events-none">
        Left: move · Right: camera
      </div>
    </div>
  );
}

// === Drawing helpers ===

function drawCharacter3D(
  ctx: CanvasRenderingContext2D,
  sx: number, sy: number, scale: number,
  bodyColor: string, accentColor: string,
  angle: number, attackAnim: number, isBlocking: boolean, hitFlash: number,
  isMounted: boolean, weapon: string,
) {
  const s = Math.max(0.3, scale / 50);
  const bodyW = 16 * s;
  const bodyH = isMounted ? 20 * s : 28 * s;
  const headR = 7 * s;

  // Shadow
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.beginPath();
  ctx.ellipse(sx, sy, bodyW * 0.8, bodyW * 0.3, 0, 0, Math.PI * 2);
  ctx.fill();

  // Body (from feet up)
  const feetY = sy;
  const hipY = sy - bodyH * 0.4;
  const shoulderY = sy - bodyH * 0.75;
  const headY = sy - bodyH;

  // Legs
  ctx.fillStyle = bodyColor;
  ctx.fillRect(sx - bodyW * 0.3, hipY, bodyW * 0.25, bodyH * 0.4);
  ctx.fillRect(sx + bodyW * 0.05, hipY, bodyW * 0.25, bodyH * 0.4);

  // Torso
  const flashColor = hitFlash > 0 ? '#ff4444' : bodyColor;
  ctx.fillStyle = flashColor;
  ctx.fillRect(sx - bodyW * 0.4, shoulderY, bodyW * 0.8, bodyH * 0.35);

  // Armor highlight
  ctx.fillStyle = accentColor + '44';
  ctx.fillRect(sx - bodyW * 0.4, shoulderY, bodyW * 0.8, bodyH * 0.08);

  // Head
  ctx.fillStyle = flashColor;
  ctx.beginPath();
  ctx.arc(sx, headY, headR, 0, Math.PI * 2);
  ctx.fill();

  // Helmet/crest
  ctx.fillStyle = accentColor;
  ctx.beginPath();
  ctx.arc(sx, headY - headR * 0.3, headR * 0.7, Math.PI, 0);
  ctx.fill();

  // Weapon — drawn based on attack animation and angle
  const weaponLen = bodyH * 0.6;
  const swingAngle = attackAnim > 0 ? (1 - attackAnim) * Math.PI * 1.2 - Math.PI / 4 : -Math.PI / 6;

  if (weapon === 'bow') {
    // Bow on back or side
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 2 * s;
    ctx.beginPath();
    ctx.arc(sx + bodyW * 0.5, shoulderY + bodyH * 0.1, bodyH * 0.2, -Math.PI / 3, Math.PI / 3);
    ctx.stroke();
  } else {
    // Melee weapon
    const wx = sx + bodyW * 0.5;
    const wy = shoulderY + bodyH * 0.15;
    ctx.strokeStyle = attackAnim > 0 ? '#ffdd44' : accentColor;
    ctx.lineWidth = 3 * s;
    ctx.beginPath();
    ctx.moveTo(wx, wy);
    const swx = wx + Math.cos(swingAngle) * weaponLen;
    const swy = wy + Math.sin(swingAngle) * weaponLen;
    ctx.lineTo(swx, swy);
    ctx.stroke();

    // Sword blade
    if (weapon === 'sword' || weapon === 'spear') {
      ctx.strokeStyle = '#ddd';
      ctx.lineWidth = 2 * s;
      ctx.beginPath();
      ctx.moveTo(wx + Math.cos(swingAngle) * weaponLen * 0.4, wy + Math.sin(swingAngle) * weaponLen * 0.4);
      ctx.lineTo(swx, swy);
      ctx.stroke();
    }
  }

  // Block shield
  if (isBlocking) {
    ctx.fillStyle = 'rgba(100, 150, 255, 0.6)';
    ctx.fillRect(sx - bodyW * 0.7, shoulderY, bodyW * 0.3, bodyH * 0.4);
    ctx.strokeStyle = 'rgba(150, 200, 255, 0.8)';
    ctx.lineWidth = 1.5 * s;
    ctx.strokeRect(sx - bodyW * 0.7, shoulderY, bodyW * 0.3, bodyH * 0.4);
  }

  // Mount
  if (isMounted) {
    ctx.fillStyle = '#5a3a1a';
    ctx.beginPath();
    ctx.ellipse(sx, sy - 2, bodyW * 1.2, bodyW * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();
    // Horse head
    ctx.fillStyle = '#4a2a0a';
    ctx.beginPath();
    ctx.arc(sx + bodyW * 0.9, sy - bodyH * 0.15, bodyW * 0.3, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawHorse3D(ctx: CanvasRenderingContext2D, sx: number, sy: number, scale: number, color: string) {
  const s = Math.max(0.3, scale / 50);
  const w = 24 * s;
  const h = 14 * s;

  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  ctx.beginPath();
  ctx.ellipse(sx, sy, w * 0.5, w * 0.15, 0, 0, Math.PI * 2);
  ctx.fill();

  // Body
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.ellipse(sx, sy - h * 0.3, w * 0.45, h * 0.3, 0, 0, Math.PI * 2);
  ctx.fill();

  // Legs
  ctx.fillRect(sx - w * 0.35, sy - h * 0.2, w * 0.08, h * 0.2);
  ctx.fillRect(sx + w * 0.25, sy - h * 0.2, w * 0.08, h * 0.2);

  // Head
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(sx + w * 0.4, sy - h * 0.5, w * 0.15, 0, Math.PI * 2);
  ctx.fill();

  // Mane
  ctx.fillStyle = '#2a1a0a';
  ctx.beginPath();
  ctx.arc(sx - w * 0.1, sy - h * 0.55, w * 0.1, 0, Math.PI * 2);
  ctx.fill();
}

function drawFirstPersonWeapon(
  ctx: CanvasRenderingContext2D,
  w: number, h: number,
  attackAnim: number, isBlocking: boolean, weapon: string,
) {
  // Draw weapon in bottom-right of screen (first person view)
  const cx = w * 0.72;
  const cy = h * 0.85;
  const swing = attackAnim > 0 ? attackAnim : 0;

  ctx.save();
  ctx.translate(cx, cy);
  if (swing > 0) {
    ctx.rotate(-swing * 1.5);
  }

  if (weapon === 'bow') {
    ctx.strokeStyle = '#8b6914';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(0, -40, 50, -Math.PI / 2.5, Math.PI / 2.5);
    ctx.stroke();
    ctx.strokeStyle = '#ddd';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, -40 + 50 * Math.sin(-Math.PI / 2.5));
    ctx.lineTo(0, -40 + 50 * Math.sin(Math.PI / 2.5));
    ctx.stroke();
  } else {
    // Sword/Axe/Spear handle
    ctx.strokeStyle = '#4a3a1a';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(20, -60);
    ctx.stroke();

    // Blade
    ctx.strokeStyle = '#ccc';
    ctx.lineWidth = weapon === 'spear' ? 3 : 5;
    ctx.beginPath();
    ctx.moveTo(20, -60);
    const bladeLen = weapon === 'spear' ? 80 : 50;
    ctx.lineTo(20 + Math.cos(-Math.PI / 4) * bladeLen, -60 + Math.sin(-Math.PI / 4) * bladeLen);
    ctx.stroke();
  }

  ctx.restore();

  // Shield overlay when blocking
  if (isBlocking) {
    ctx.fillStyle = 'rgba(80, 130, 220, 0.3)';
    ctx.beginPath();
    ctx.ellipse(w / 2, h * 0.55, w * 0.35, h * 0.3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(120, 170, 255, 0.6)';
    ctx.lineWidth = 3;
    ctx.stroke();
  }
}
