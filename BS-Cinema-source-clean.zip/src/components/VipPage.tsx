import { useState, useEffect, useCallback } from 'react';
import { X, Crown, Clock, Check, CreditCard, Smartphone, Loader2, Star, Film, Sparkles, Tv } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type PaymentMethod } from '@/lib/supabase';

interface VipPageProps {
  onClose: () => void;
}

const PAYMENT_PHONE = '07511590023';

export default function VipPage({ onClose }: VipPageProps) {
  const { user, profile } = useAuth();
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('fastpay');
  const [paymentNote, setPaymentNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [myRequests, setMyRequests] = useState<any[]>([]);
  const [loadingRequests, setLoadingRequests] = useState(false);
  const [successMsg, setSuccessMsg] = useState(false);

  const loadMyRequests = useCallback(async () => {
    if (!user) return;
    setLoadingRequests(true);
    const { data } = await supabase
      .from('vip_payments')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setMyRequests(data || []);
    setLoadingRequests(false);
  }, [user]);

  useEffect(() => {
    loadMyRequests();
  }, [loadMyRequests]);

  const vipStatus = profile?.vip_status || 'free';
  const vipEndDate = profile?.vip_end_date ? new Date(profile.vip_end_date) : null;
  const trialEndDate = profile?.trial_end_date ? new Date(profile.trial_end_date) : null;
  const now = new Date();

  const vipDaysLeft = vipEndDate ? Math.max(0, Math.ceil((vipEndDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))) : 0;
  const trialDaysLeft = trialEndDate ? Math.max(0, Math.ceil((trialEndDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))) : 0;
  const trialHoursLeft = trialEndDate ? Math.max(0, Math.ceil((trialEndDate.getTime() - now.getTime()) / (1000 * 60 * 60))) : 0;

  const hasPendingRequest = myRequests.some((r) => r.status === 'pending');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    await supabase.from('vip_payments').insert({
      user_id: user.id,
      payment_method: paymentMethod,
      payment_note: paymentNote || null,
    });
    setSubmitting(false);
    setPaymentNote('');
    setSuccessMsg(true);
    setTimeout(() => setSuccessMsg(false), 3000);
    await loadMyRequests();
  };

  const statusLabel = (status: string) => {
    if (status === 'pending') return 'چاوەڕێکردن';
    if (status === 'approved') return 'پەسەندکرا';
    if (status === 'rejected') return 'ڕەتکرایەوە';
    return status;
  };

  const methodLabel = (method: string) => {
    if (method === 'fastpay') return 'FastPay';
    if (method === 'mobile_credit') return 'مۆبایل کرێدت';
    return method;
  };

  return (
    <div className="fixed inset-0 z-[60] overflow-y-auto bg-primary animate-fade-in">
      <div className="sticky top-0 glass border-b border-default px-4 py-3 flex items-center justify-between" style={{ paddingTop: 'calc(0.75rem + var(--safe-top))' }}>
        <h2 className="text-lg font-bold text-primary flex items-center gap-2">
          <Crown className="w-5 h-5 text-accent" /> ئەندامی VIP
        </h2>
        <button onClick={onClose} className="p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-2xl mx-auto p-4 md:p-6 space-y-6" style={{ paddingBottom: 'calc(1rem + var(--safe-bottom))' }}>
        {/* VIP Status Card */}
        <div className="bg-card border border-default rounded-xl p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${vipStatus === 'vip' ? 'bg-accent/20' : vipStatus === 'trial' ? 'bg-accent/20' : 'bg-hover'}`}>
              {vipStatus === 'vip' ? <Crown className="w-6 h-6 text-accent" /> : vipStatus === 'trial' ? <Clock className="w-6 h-6 text-accent" /> : <Star className="w-6 h-6 text-muted" />}
            </div>
            <div>
              <p className="text-sm text-secondary">دۆخی ئەندامیەت</p>
              <p className="text-lg font-bold text-primary">
                {vipStatus === 'vip' ? 'VIP' : vipStatus === 'trial' ? 'بەرایی' : 'بەخۆڕایی'}
              </p>
            </div>
          </div>

          {vipStatus === 'vip' && vipEndDate && (
            <div className="bg-accent/10 border border-accent/30 rounded-lg p-3 text-center">
              <p className="text-sm text-accent font-medium">
                {vipDaysLeft} ڕۆژ ماوە لە VIP
              </p>
              <p className="text-xs text-muted mt-1">
                بەسەرچوون: {vipEndDate.toLocaleDateString()}
              </p>
            </div>
          )}

          {vipStatus === 'trial' && trialEndDate && (
            <div className="bg-accent/10 border border-accent/30 rounded-lg p-3 text-center">
              <p className="text-sm text-accent font-medium">
                {trialHoursLeft > 24 ? `${trialDaysLeft} ڕۆژ` : `${trialHoursLeft} کاتژمێر`} ماوە لە بەرایی
              </p>
              <p className="text-xs text-muted mt-1">
                بەسەرچوون: {trialEndDate.toLocaleDateString()}
              </p>
            </div>
          )}

          {vipStatus === 'free' && (
            <div className="bg-hover rounded-lg p-3 text-center">
              <p className="text-sm text-secondary">ئەندامیەتی VIP نییە</p>
            </div>
          )}
        </div>

        {/* VIP Benefits */}
        <div className="bg-card border border-default rounded-xl p-5">
          <h3 className="text-base font-bold text-primary mb-4"> سوودەکانی VIP</h3>
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                <Film className="w-4 h-4 text-accent" />
              </div>
              <p className="text-sm text-secondary">بینینی سەرجەم فیلم و زنجیرەکان بێ ئیعلان</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                <Tv className="w-4 h-4 text-accent" />
              </div>
              <p className="text-sm text-secondary">بینینی ئەنیمی و ئەنیمەیشن بێ سنووردارکردن</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-4 h-4 text-accent" />
              </div>
              <p className="text-sm text-secondary">ناوەڕۆکی تایبەت تەنها بۆ ئەندامانی VIP</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                <Check className="w-4 h-4 text-accent" />
              </div>
              <p className="text-sm text-secondary">خێرایی زیاتری لۆدکردنی ڤیدیۆکان</p>
            </div>
          </div>
        </div>

        {/* Price & Trial */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-card border border-default rounded-xl p-5 text-center">
            <p className="text-sm text-secondary mb-1">نرخی VIP</p>
            <p className="text-2xl font-bold text-primary">2,000 <span className="text-sm font-normal text-secondary">دینار / مانگ</span></p>
          </div>
          <div className="bg-card border border-default rounded-xl p-5 text-center">
            <p className="text-sm text-secondary mb-1">بەرای ڕۆژانە</p>
            <p className="text-2xl font-bold text-accent">3 <span className="text-sm font-normal text-secondary">ڕۆژ بەخۆڕایی</span></p>
            <p className="text-xs text-muted mt-1">تەنها یەک جار بۆ هەر بەکارهێنەرێک</p>
          </div>
        </div>

        {/* Payment Section - only for non-VIP users */}
        {vipStatus !== 'vip' && (
          <div className="bg-card border border-default rounded-xl p-5 space-y-4">
            <h3 className="text-base font-bold text-primary">پارەدانی VIP</h3>

            {/* Payment instructions */}
            <div className="bg-secondary rounded-lg p-4 space-y-3">
              <p className="text-sm text-secondary font-medium">ڕێنمایی پارەدان:</p>
              <div className="flex items-center gap-2 bg-hover rounded-lg p-3">
                <Smartphone className="w-5 h-5 text-accent flex-shrink-0" />
                <div>
                  <p className="text-xs text-muted">ژمارەی پارەدان</p>
                  <p className="text-sm font-bold text-primary" dir="ltr">{PAYMENT_PHONE}</p>
                </div>
              </div>
              <p className="text-xs text-muted leading-relaxed">
                1. دوو هەزار دینار بنێرە بۆ ژمارەی سەرەوە بە یەکێک لە ڕێگاکانی خوارەوە.
                <br />
                2. پاشان فۆڕمی خوارەوە پڕبکەرەوە و زانیاری ناونیشان بەکارهێنەر بنووسە.
                <br />
                3. دوای پەسەندکردنی بەڕێوبەر، VIP چالاک دەکرێت بۆ 30 ڕۆژ.
              </p>
            </div>

            {/* Payment form */}
            {hasPendingRequest ? (
              <div className="bg-accent/10 border border-accent/30 rounded-lg p-4 text-center">
                <p className="text-sm text-accent font-medium">داواکاریەکی پارەدانت چاوەڕێی پێداچوونەوەیە</p>
                <p className="text-xs text-muted mt-1">تکایە چاوەڕێ بە تا پەسەندکرێت</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3">
                <div>
                  <label className="text-sm text-secondary mb-2 block">ڕێگای پارەدان هەڵبژێرە</label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('fastpay')}
                      className={`flex items-center gap-2 flex-1 px-4 py-3 rounded-lg text-sm font-medium transition-all ${paymentMethod === 'fastpay' ? 'bg-accent text-white' : 'bg-secondary text-secondary border border-default'}`}
                    >
                      <CreditCard className="w-4 h-4" /> FastPay
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('mobile_credit')}
                      className={`flex items-center gap-2 flex-1 px-4 py-3 rounded-lg text-sm font-medium transition-all ${paymentMethod === 'mobile_credit' ? 'bg-accent text-white' : 'bg-secondary text-secondary border border-default'}`}
                    >
                      <Smartphone className="w-4 h-4" /> مۆبایل کرێدت
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-sm text-secondary mb-1.5 block">زانیاری زیادە (ئیختیاری)</label>
                  <textarea
                    value={paymentNote}
                    onChange={(e) => setPaymentNote(e.target.value)}
                    placeholder="ناونیشانی بەکارهێنەری FastPay یان کاتی ناردنی پارە"
                    rows={2}
                    className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-default text-primary placeholder:text-muted text-sm outline-none focus:border-accent resize-none"
                  />
                </div>
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-lg bg-accent text-white font-medium text-sm hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50"
                >
                  {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Crown className="w-4 h-4" />}
                  ناردنی داواکاری VIP
                </button>
                {successMsg && (
                  <p className="text-center text-sm text-green-400">داواکاریەکەت نێردرا! چاوەڕێی پەسەندکردن بە.</p>
                )}
              </form>
            )}
          </div>
        )}

        {/* Payment History */}
        {myRequests.length > 0 && (
          <div className="bg-card border border-default rounded-xl p-5">
            <h3 className="text-base font-bold text-primary mb-4">مێژووی داواکاریەکان</h3>
            {loadingRequests ? (
              <div className="flex justify-center py-4"><Loader2 className="w-5 h-5 text-accent animate-spin" /></div>
            ) : (
              <div className="space-y-2">
                {myRequests.map((r) => (
                  <div key={r.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary text-sm">
                    <div>
                      <p className="text-primary font-medium">{methodLabel(r.payment_method)}</p>
                      <p className="text-xs text-muted">{new Date(r.created_at).toLocaleDateString()}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      r.status === 'approved' ? 'bg-green-500/20 text-green-400' :
                      r.status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                      'bg-accent/20 text-accent'
                    }`}>
                      {statusLabel(r.status)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
