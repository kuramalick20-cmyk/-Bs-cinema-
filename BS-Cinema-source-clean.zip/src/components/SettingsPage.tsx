import { X, Sun, Moon, Send, MessageCircle } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';

interface SettingsPageProps {
  onClose: () => void;
}

const SOCIALS = [
  { name: 'TikTok', handle: 'bsstudio.official', url: 'https://tiktok.com/@bsstudio.official', color: '#000000', icon: 'tiktok' },
  { name: 'Snapchat', handle: 'lord.aries1', url: 'https://snapchat.com/add/lord.aries1', color: '#FFFC00', icon: 'snapchat' },
  { name: 'Telegram', handle: 'lordarys', url: 'https://t.me/lordarys', color: '#0088cc', icon: 'telegram' },
];

function TikTokIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
      <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.2v13.67a2.89 2.89 0 01-2.89 2.89 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.3 0 .59.04.86.13V9.4a6.1 6.1 0 00-.86-.06A6.09 6.09 0 005.64 15.43a6.09 6.09 0 006.09 6.09 6.09 6.09 0 006.09-6.09V8.7a8 8 0 004.77 1.55v-3.2a4.85 4.85 0 01-.01-.36z"/>
    </svg>
  );
}
function SnapchatIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
      <path d="M12.206.793c.99 0 4.347.276 5.93 3.821.529 1.193.403 3.219.299 4.547l-.003.06c-.012.18-.022.345-.03.51.075.042.221.094.435.094.334-.004.733-.135 1.155-.39.279-.17.583-.27.86-.27.207 0 .39.05.53.14.453.29.516.717.492.917-.07.567-.755.883-1.259 1.085-.092.037-.215.08-.346.127-.488.17-1.103.386-1.27.833-.085.226-.047.523.116.913.01.03 1.013 2.59 3.484 3.27.182.05.322.22.355.43.034.21-.05.42-.21.54-.41.27-1.13.48-2.05.57-.07.01-.13.05-.17.1-.05.07-.1.2-.16.34-.07.17-.14.34-.26.5-.04.05-.1.08-.17.08h-.01c-.1 0-.22-.02-.37-.06-.34-.1-.78-.18-1.31-.18-.31 0-.63.03-.95.08-.63.1-1.17.45-1.8.86-.9.59-1.92 1.26-3.47 1.26-.06 0-.13 0-.19-.01-.06.01-.13.01-.19.01-1.55 0-2.57-.67-3.47-1.26-.63-.41-1.17-.76-1.8-.86-.32-.05-.64-.08-.95-.08-.53 0-.97.08-1.31.18-.15.04-.27.06-.37.06-.07 0-.13-.03-.17-.08-.12-.16-.19-.33-.26-.5-.06-.14-.11-.27-.16-.34-.04-.05-.1-.09-.17-.1-.92-.09-1.64-.3-2.05-.57-.16-.12-.244-.33-.21-.54.033-.21.1-.38.282-.43 2.471-.68 3.474-3.24 3.484-3.27.163-.39.201-.687.116-.913-.167-.447-.782-.663-1.27-.833-.131-.047-.254-.09-.346-.127-.504-.202-1.189-.518-1.259-1.085-.024-.2.039-.627.492-.917.14-.09.323-.14.53-.14.277 0 .581.1.86.27.422.255.821.386 1.155.39.214 0 .36-.052.435-.094-.008-.165-.018-.33-.03-.51l-.003-.06c-.104-1.328-.23-3.354.299-4.547C7.859 1.069 11.216.793 12.206.793z"/>
    </svg>
  );
}
function TelegramIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
      <path d="M11.944 0A12 12 0 000 12a12 12 0 0012 12 12 12 0 0012-12A12 12 0 0012 0a12 12 0 00-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 01.171.325c.016.092.036.292.02.45-.18 1.895-.962 6.492-1.36 8.615-.168.9-.5 1.201-.822 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.915.49-1.305.48-.43-.01-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.327-.437.899-.663 3.522-1.535 5.868-2.406 7.038-2.614 1.13-.2 2.24-.4 2.36-.42z"/>
    </svg>
  );
}

export default function SettingsPage({ onClose }: SettingsPageProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="fixed inset-0 z-[60] overflow-y-auto bg-primary animate-fade-in">
      <div className="sticky top-0 glass border-b border-default px-4 py-3 flex items-center justify-between" style={{ paddingTop: 'calc(0.75rem + var(--safe-top))' }}>
        <h2 className="text-lg font-bold text-primary">ڕێکخستنەکان</h2>
        <button onClick={onClose} className="p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-2xl mx-auto p-4 md:p-6 space-y-6" style={{ paddingBottom: 'calc(1rem + var(--safe-bottom))' }}>
        {/* Theme toggle */}
        <div className="bg-card border border-default rounded-xl p-4">
          <h3 className="text-sm font-semibold text-primary mb-3">ڕووکار</h3>
          <div className="flex items-center justify-between">
            <span className="text-secondary text-sm flex items-center gap-2">
              {theme === 'dark' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              {theme === 'dark' ? 'تاریک' : 'ڕۆشن'}
            </span>
            <button
              onClick={toggleTheme}
              className="relative w-14 h-7 rounded-full transition-colors"
              style={{ background: theme === 'dark' ? 'var(--accent)' : 'var(--border-color)' }}
            >
              <div
                className="absolute top-1 w-5 h-5 rounded-full bg-white transition-all"
                style={{ left: theme === 'dark' ? '2px' : 'calc(100% - 22px)' }}
              />
            </button>
          </div>
        </div>

        {/* Social media */}
        <div className="bg-card border border-default rounded-xl p-4">
          <h3 className="text-sm font-semibold text-primary mb-4">تۆڕە کۆمەڵایەتییەکان</h3>
          <div className="space-y-3">
            {SOCIALS.map((social) => (
              <a
                key={social.name}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 rounded-lg bg-secondary border border-default hover:bg-hover transition-all group"
              >
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-white"
                  style={{ background: social.color === '#FFFC00' ? '#FFFC00' : social.color, color: social.color === '#FFFC00' ? '#000' : '#fff' }}
                >
                  {social.icon === 'tiktok' && <TikTokIcon />}
                  {social.icon === 'snapchat' && <SnapchatIcon />}
                  {social.icon === 'telegram' && <TelegramIcon />}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-primary">{social.name}</p>
                  <p className="text-xs text-secondary">{social.handle}</p>
                </div>
                <Send className="w-4 h-4 text-muted group-hover:text-accent transition-colors" />
              </a>
            ))}
          </div>
        </div>

        {/* FastPay */}
        <div className="bg-card border border-default rounded-xl p-4">
          <h3 className="text-sm font-semibold text-primary mb-3">FastPay</h3>
          <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary border border-default">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-primary">ژمارەی FastPay</p>
              <p className="text-lg font-bold text-accent" dir="ltr">0751 159 0023</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
