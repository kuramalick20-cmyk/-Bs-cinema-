import { Send, Ghost, Music2, MessageCircle, Wallet } from 'lucide-react';
import type { SocialLinks as SocialLinksData } from '@/lib/settings';
import { DEFAULT_SOCIAL_LINKS } from '@/lib/settings';

interface SocialLinksProps {
  links?: SocialLinksData | null;
  variant?: 'footer' | 'section';
}

export default function SocialLinks({ links, variant = 'footer' }: SocialLinksProps) {
  const resolvedLinks = links || DEFAULT_SOCIAL_LINKS;
  const socials = [
    {
      name: 'Telegram',
      handle: '@lordarys',
      url: resolvedLinks.telegram,
      icon: Send,
      color: '#229ED9',
    },
    {
      name: 'Snapchat',
      handle: 'lord.aries1',
      url: resolvedLinks.snapchat,
      icon: Ghost,
      color: '#FFFC00',
    },
    {
      name: 'TikTok',
      handle: 'bsstudio.offical',
      url: resolvedLinks.tiktok,
      icon: Music2,
      color: '#ff0050',
    },
    {
      name: 'WhatsApp',
      handle: '07511590023',
      url: resolvedLinks.whatsapp,
      icon: MessageCircle,
      color: '#25D366',
    },
    {
      name: 'FastPay',
      handle: resolvedLinks.fastpay_number || '07511590023',
      url: null,
      icon: Wallet,
      color: '#5B2D90',
    },
  ];

  if (variant === 'section') {
    return (
      <div className="flex flex-wrap items-center justify-center gap-3">
        {socials.map((s) => {
          const Icon = s.icon;
          const content = (
            <div className="flex items-center gap-2 sm:gap-2.5 px-3 sm:px-5 py-2.5 sm:py-3 rounded-xl bg-card border border-default hover:border-bright transition-all hover:scale-105 shadow-card">
              <Icon className="w-5 h-5" style={{ color: s.color }} />
              <div className="text-right">
                <p className="text-sm font-medium text-primary">{s.name}</p>
                <p className="text-xs text-muted">{s.handle}</p>
              </div>
            </div>
          );
          return s.url ? (
            <a key={s.name} href={s.url} target="_blank" rel="noopener noreferrer">
              {content}
            </a>
          ) : (
            <div key={s.name} className="cursor-default" title="FastPay — زانیاری زیاتر بژاردە">
              {content}
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-2">
      {socials.map((s) => {
        const Icon = s.icon;
        const content = (
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-card border border-default hover:border-bright transition-all">
            <Icon className="w-4 h-4" style={{ color: s.color }} />
            <div>
              <p className="text-xs font-medium text-primary">{s.name}</p>
              <p className="text-[10px] text-muted">{s.handle}</p>
            </div>
          </div>
        );
        return s.url ? (
          <a key={s.name} href={s.url} target="_blank" rel="noopener noreferrer">
            {content}
          </a>
        ) : (
          <div key={s.name} className="cursor-default" title="FastPay">
            {content}
          </div>
        );
      })}
    </div>
  );
}
