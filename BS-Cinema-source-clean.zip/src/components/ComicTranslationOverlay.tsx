import { useState, useEffect, useRef } from 'react';
import { X, Languages, Loader2, ChevronDown, ScanText, RefreshCw } from 'lucide-react';
import type { ComicImageTranslation, ComicPanel } from '@/lib/supabase';
import { fetchPanelTranslations, requestComicTranslation, savePanelTranslation, LANGUAGES } from '@/lib/comicTranslation';
import { recognizeTextInBubbles } from '@/lib/comicOCR';
import { detectLanguage } from '@/lib/comicVoice';
import { useAuth } from '@/context/AuthContext';

interface ComicTranslationOverlayProps {
  panel: ComicPanel;
  panelIndex: number;
  onClose: () => void;
}

interface OCRRegion {
  text: string;
  bbox: { x0: number; y0: number; x1: number; y1: number };
  confidence: number;
  normalizedX: number;
  normalizedY: number;
  normalizedWidth: number;
  normalizedHeight: number;
  translated: string;
  sourceLang: string;
}

export default function ComicTranslationOverlay({ panel, panelIndex, onClose }: ComicTranslationOverlayProps) {
  const { user } = useAuth();
  const [translations, setTranslations] = useState<ComicImageTranslation[]>([]);
  const [targetLang, setTargetLang] = useState('en');
  const [showLangDropdown, setShowLangDropdown] = useState(false);
  const [ocrRegions, setOcrRegions] = useState<OCRRegion[]>([]);
  const [scanning, setScanning] = useState(false);
  const [translating, setTranslating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [imageNaturalSize, setImageNaturalSize] = useState<{ w: number; h: number }>({ w: 0, h: 0 });
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    fetchPanelTranslations(panel.id).then(setTranslations);
  }, [panel.id]);

  const selectedLang = LANGUAGES.find((l) => l.code === targetLang);

  // Auto-OCR the panel image when overlay opens
  const autoScan = async () => {
    setScanning(true);
    setError(null);
    setOcrRegions([]);
    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      await new Promise<void>((resolve, reject) => {
        img.onload = () => {
          setImageNaturalSize({ w: img.naturalWidth, h: img.naturalHeight });
          resolve();
        };
        img.onerror = () => reject(new Error('Failed to load image'));
        img.src = panel.image_url;
      });

      const { regions, imageWidth: detectedW, imageHeight: detectedH } = await recognizeTextInBubbles(panel.image_url);
      if (regions.length === 0) {
        setError('هیچ دەقێک نەدۆزرایەوە لەناو قۆزی دەق. دڵنیابە لەوەی دەق لەناو قۆزی دەقدایە.');
        setScanning(false);
        return;
      }

      const imgW = detectedW || img.naturalWidth || imageNaturalSize.w || 1000;
      const imgH = detectedH || img.naturalHeight || imageNaturalSize.h || 1000;

      const ocrRegionsData: OCRRegion[] = regions
        .filter((r) => r.text && r.text.trim().length > 1 && r.confidence > 30)
        .map((r) => ({
          text: r.text.trim(),
          bbox: r.bbox,
          confidence: r.confidence,
          normalizedX: Math.max(0, r.bbox.x0) / imgW,
          normalizedY: Math.max(0, r.bbox.y0) / imgH,
          normalizedWidth: Math.min(imgW, r.bbox.x1 - r.bbox.x0) / imgW,
          normalizedHeight: Math.min(imgH, r.bbox.y1 - r.bbox.y0) / imgH,
          translated: '',
          sourceLang: detectLanguage(r.text.trim()),
        }));

      setOcrRegions(ocrRegionsData);

      if (ocrRegionsData.length > 0) {
        // Auto-translate all detected text
        await autoTranslateRegions(ocrRegionsData, targetLang);
      }
    } catch (err: any) {
      setError(err.message || 'هەڵە لە کاتی سکانکردندا');
    }
    setScanning(false);
  };

  // Auto-translate on mount
  useEffect(() => {
    autoScan();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [panel.id]);

  const autoTranslateRegions = async (regions: OCRRegion[], lang: string) => {
    if (regions.length === 0) return;
    setTranslating(true);
    setError(null);
    try {
      const texts = regions.map((r) => r.text);
      const { results, error: transError } = await requestComicTranslation(
        panel.id,
        texts,
        lang
      );
      if (transError) {
        setError(transError);
        setTranslating(false);
        return;
      }

      const updated = regions.map((r, i) => ({
        ...r,
        translated: results[i]?.translated || r.text,
        sourceLang: results[i]?.source_lang || r.sourceLang,
      }));
      setOcrRegions(updated);

      // Save translations to database
      for (let i = 0; i < updated.length; i++) {
        if (results[i]?.translated) {
          await savePanelTranslation(
            panel.id,
            updated[i].text,
            results[i].translated,
            lang,
            results[i].source_lang,
            {
              x: updated[i].normalizedX,
              y: updated[i].normalizedY,
              width: updated[i].normalizedWidth,
              height: updated[i].normalizedHeight,
            }
          );
        }
      }

      // Refresh saved translations
      fetchPanelTranslations(panel.id).then(setTranslations);
    } catch (err: any) {
      setError(err.message || 'وەرگێڕان سەرکەوتوو نەبوو');
    }
    setTranslating(false);
  };

  const handleLangChange = async (lang: string) => {
    setTargetLang(lang);
    setShowLangDropdown(false);
    if (ocrRegions.length > 0) {
      await autoTranslateRegions(ocrRegions, lang);
    }
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col">
      {/* Header bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-black/80 backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <Languages className="w-4 h-4 text-accent" />
          <span className="text-white text-xs font-medium">وەرگێڕانی خۆکار — پەنال {panelIndex + 1}</span>
          {scanning && (
            <span className="flex items-center gap-1 text-accent text-xs">
              <Loader2 className="w-3 h-3 animate-spin" /> سکانکردن...
            </span>
          )}
          {translating && (
            <span className="flex items-center gap-1 text-accent text-xs">
              <Loader2 className="w-3 h-3 animate-spin" /> وەرگێڕان...
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          {/* Language selector */}
          <div className="relative">
            <button
              onClick={() => setShowLangDropdown(!showLangDropdown)}
              className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg bg-white/10 text-white text-xs font-medium hover:bg-white/20 transition-colors"
            >
              <span>{selectedLang?.nativeName}</span>
              <ChevronDown className="w-3 h-3" />
            </button>
            {showLangDropdown && (
              <div className="absolute top-full right-0 mt-1 bg-card border border-default rounded-lg max-h-48 overflow-y-auto z-50 shadow-xl min-w-[140px]">
                {LANGUAGES.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => handleLangChange(l.code)}
                    className={`w-full flex items-center justify-between px-3 py-2 text-sm transition-colors ${
                      targetLang === l.code ? 'bg-accent text-white' : 'text-primary hover:bg-hover'
                    }`}
                  >
                    <span>{l.nativeName}</span>
                    <span className="text-xs text-muted">{l.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          {/* Re-scan button */}
          <button
            onClick={autoScan}
            disabled={scanning}
            className="p-1.5 rounded-lg glass text-white hover:text-accent disabled:opacity-50"
            title="دووبارە سکانکردن"
          >
            <RefreshCw className={`w-4 h-4 ${scanning ? 'animate-spin' : ''}`} />
          </button>
          <button onClick={onClose} className="p-1.5 rounded-lg glass text-white hover:text-accent">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Image with OCR-detected translation overlays */}
      <div className="relative flex-1 flex items-center justify-center bg-black/50 overflow-hidden">
        <div className="relative" style={{ maxWidth: '100%' }}>
          <img
            ref={imgRef}
            src={panel.image_url}
            alt={`پەنال ${panelIndex + 1}`}
            className="max-w-full max-h-[60vh] block"
          />

          {/* OCR-detected regions with translations overlaid */}
          {ocrRegions.map((region, i) => {
            const lang = LANGUAGES.find((l) => l.code === targetLang);
            const isRtl = lang?.dir === 'rtl';
            return (
              <div
                key={i}
                className="absolute border border-accent/40 rounded bg-black/75 flex items-center justify-center px-2 py-1 overflow-hidden transition-all"
                style={{
                  left: `${region.normalizedX * 100}%`,
                  top: `${region.normalizedY * 100}%`,
                  width: `${region.normalizedWidth * 100}%`,
                  minHeight: `${region.normalizedHeight * 100}%`,
                }}
                dir={isRtl ? 'rtl' : 'ltr'}
              >
                <p
                  className="text-white text-center leading-tight"
                  style={{
                    fontSize: 'clamp(8px, 2vw, 14px)',
                    wordBreak: 'break-word',
                  }}
                >
                  {region.translated || region.text}
                </p>
              </div>
            );
          })}

          {/* Scanning indicator overlay */}
          {scanning && ocrRegions.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/40">
              <div className="text-center">
                <ScanText className="w-8 h-8 text-accent mx-auto mb-2 animate-pulse" />
                <p className="text-white text-sm">OCR سکانکردنی دەق...</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Error message */}
      {error && (
        <div className="bg-red-500/20 border-t border-red-500/30 px-3 py-2">
          <p className="text-red-300 text-xs text-center">{error}</p>
        </div>
      )}

      {/* Info bar */}
      {!scanning && ocrRegions.length > 0 && (
        <div className="bg-black/60 px-3 py-2 text-center">
          <p className="text-xs text-white/70">
            {ocrRegions.length} دەق دۆزرایەوە و وەرگێڕدرا بۆ {selectedLang?.nativeName}
            {ocrRegions.some(r => r.sourceLang === 'ku') && ' • کوردی سۆرانی → '}
            {selectedLang?.name}
          </p>
        </div>
      )}

      {/* No text found */}
      {!scanning && ocrRegions.length === 0 && !error && (
        <div className="bg-black/60 px-3 py-2 text-center">
          <p className="text-xs text-white/70">هیچ دەقێک نەدۆزرایەوە. دووبارە سکان بکە لەسەر دوگمەی 🔄</p>
        </div>
      )}
    </div>
  );
}
