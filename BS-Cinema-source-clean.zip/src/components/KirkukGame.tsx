import { useRef, useEffect, useState, useCallback } from 'react';
import { X, Heart, DollarSign, Sword, ShoppingBag, MessageCircle, RotateCcw, Star, Crosshair } from 'lucide-react';
import {
  type GameState, type Entity, type Direction, TILE_SIZE, TILE_PROPS,
} from '@/lib/rpgTypes';
import {
  createInitialState, updateAI, movePlayer, playerAttack, stealFromNpc,
  buyItem, useHealthPotion, interactNearby, autoPickup, updateCamera,
  addMessage,
} from '@/lib/rpgEngine';
import { SHOP_ITEMS, type ShopItem } from '@/lib/rpgTypes';

interface KirkukGameProps {
  onClose: () => void;
}

export default function KirkukGame({ onClose }: KirkukGameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef<GameState>(createInitialState());
  const keysRef = useRef<Record<string, boolean>>({});
  const joystickRef = useRef<{ active: boolean; x: number; y: number; startX: number; startY: number }>({ active: false, x: 0, y: 0, startX: 0, startY: 0 });
  const animFrameRef = useRef<number>(0);
  const [hudMoney, setHudMoney] = useState(0);
  const [hudHp, setHudHp] = useState(100);
  const [hudWanted, setHudWanted] = useState(0);
  const [hudKills, setHudKills] = useState(0);
  const [messages, setMessages] = useState<{ id: string; text: string; color: string }[]>([]);
  const [showShop, setShowShop] = useState(false);
  const [showDialogue, setShowDialogue] = useState<{ name: string; text: string } | null>(null);
  const [showStealPrompt, setShowStealPrompt] = useState<string | null>(null);
  const [gameOver, setGameOver] = useState(false);
  const lastHudUpdate = useRef(0);

  // Game loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = canvas.clientWidth;
      canvas.height = canvas.clientHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    let lastTime = performance.now();

    const gameLoop = (now: number) => {
      const dt = Math.min(33, now - lastTime);
      lastTime = now;

      const state = stateRef.current;

      if (!state.gameOver && !state.paused && !showShop && !showDialogue) {
        // Player movement from keyboard
        let dx = 0, dy = 0;
        if (keysRef.current['w'] || keysRef.current['arrowup']) dy -= 1;
        if (keysRef.current['s'] || keysRef.current['arrowdown']) dy += 1;
        if (keysRef.current['a'] || keysRef.current['arrowleft']) dx -= 1;
        if (keysRef.current['d'] || keysRef.current['arrowright']) dx += 1;

        // Joystick movement
        if (joystickRef.current.active) {
          const jdx = joystickRef.current.x - joystickRef.current.startX;
          const jdy = joystickRef.current.y - joystickRef.current.startY;
          const jlen = Math.hypot(jdx, jdy);
          if (jlen > 5) {
            dx = jdx / jlen;
            dy = jdy / jlen;
          }
        }

        movePlayer(state, dx, dy);
        autoPickup(state);
        updateAI(state, dt);
        updateCamera(state, canvas.width, canvas.height);
      }

      // Render
      render(ctx, state, canvas.width, canvas.height);

      // Update HUD (throttled)
      if (now - lastHudUpdate.current > 200) {
        lastHudUpdate.current = now;
        setHudMoney(state.money);
        setHudHp(Math.max(0, Math.round(state.player.hp)));
        setHudWanted(state.wantedLevel);
        setHudKills(state.kills);
        setMessages([...state.messages.slice(-5)]);
        if (state.gameOver && !gameOver) setGameOver(true);
      }

      animFrameRef.current = requestAnimationFrame(gameLoop);
    };

    animFrameRef.current = requestAnimationFrame(gameLoop);

    return () => {
      cancelAnimationFrame(animFrameRef.current);
      window.removeEventListener('resize', resize);
    };
  }, [showShop, showDialogue, gameOver]);

  // Keyboard handlers
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = true;
      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        handleAction();
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = false;
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [showShop, showDialogue]);

  const handleAction = useCallback(() => {
    const state = stateRef.current;
    if (state.gameOver) return;
    const result = interactNearby(state);
    if (result.type === 'shop' && result.entity) {
      state.inShop = result.entity;
      setShowShop(true);
    } else if (result.type === 'steal' && result.entity) {
      stealFromNpc(state, result.entity);
    } else if (result.type === 'dialogue' && result.entity) {
      setShowDialogue({ name: result.entity.name, text: result.entity.dialogue || '...' });
    }
  }, []);

  const handleAttack = useCallback(() => {
    const state = stateRef.current;
    if (state.gameOver) return;
    playerAttack(state);
  }, []);

  const handleInteract = useCallback(() => {
    handleAction();
  }, [handleAction]);

  const handlePotion = useCallback(() => {
    const state = stateRef.current;
    useHealthPotion(state);
  }, []);

  const handleRestart = useCallback(() => {
    stateRef.current = createInitialState();
    setGameOver(false);
    setShowShop(false);
    setShowDialogue(null);
  }, []);

  // Joystick handlers
  const handleJoystickStart = (e: React.TouchEvent | React.MouseEvent) => {
    const touch = 'touches' in e ? e.touches[0] : e;
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    joystickRef.current = {
      active: true,
      startX: touch.clientX - rect.left,
      startY: touch.clientY - rect.top,
      x: touch.clientX - rect.left,
      y: touch.clientY - rect.top,
    };
  };

  const handleJoystickMove = (e: React.TouchEvent | React.MouseEvent) => {
    if (!joystickRef.current.active) return;
    e.preventDefault();
    const touch = 'touches' in e ? e.touches[0] : e;
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    joystickRef.current.x = touch.clientX - rect.left;
    joystickRef.current.y = touch.clientY - rect.top;
  };

  const handleJoystickEnd = () => {
    joystickRef.current.active = false;
  };

  // Shop buy handler
  const handleBuy = (item: ShopItem) => {
    buyItem(stateRef.current, item);
    setHudMoney(stateRef.current.money);
  };

  // Render the game
  function render(ctx: CanvasRenderingContext2D, state: GameState, w: number, h: number) {
    ctx.fillStyle = '#0a0a0f';
    ctx.fillRect(0, 0, w, h);

    const cam = state.camera;

    // Draw tiles (only visible ones)
    const startTx = Math.max(0, Math.floor(cam.x / TILE_SIZE));
    const endTx = Math.min(state.map.width, Math.ceil((cam.x + w) / TILE_SIZE));
    const startTy = Math.max(0, Math.floor(cam.y / TILE_SIZE));
    const endTy = Math.min(state.map.height, Math.ceil((cam.y + h) / TILE_SIZE));

    for (let ty = startTy; ty < endTy; ty++) {
      for (let tx = startTx; tx < endTx; tx++) {
        const tile = state.map.tiles[ty][tx];
        const props = TILE_PROPS[tile];
        const px = tx * TILE_SIZE - cam.x;
        const py = ty * TILE_SIZE - cam.y;
        ctx.fillStyle = props.color;
        ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);

        // Add detail to walls
        if (tile === 'wall') {
          ctx.strokeStyle = '#4a3a2a';
          ctx.lineWidth = 1;
          ctx.strokeRect(px + 1, py + 1, TILE_SIZE - 2, TILE_SIZE - 2);
        }
        if (tile === 'citadel_floor') {
          ctx.fillStyle = '#6a5a4a';
          ctx.fillRect(px + 4, py + 4, TILE_SIZE - 8, TILE_SIZE - 8);
        }
        if (tile === 'road') {
          // Road markings
          ctx.fillStyle = '#444';
          ctx.fillRect(px + TILE_SIZE / 2 - 1, py + 8, 2, 8);
          ctx.fillRect(px + TILE_SIZE / 2 - 1, py + 24, 2, 8);
        }
        if (tile === 'market') {
          ctx.strokeStyle = '#6a4a2a';
          ctx.lineWidth = 1;
          ctx.strokeRect(px + 2, py + 2, TILE_SIZE - 4, TILE_SIZE - 4);
        }
        if (tile === 'door') {
          ctx.fillStyle = '#6b4b2a';
          ctx.fillRect(px + 8, py + 4, TILE_SIZE - 16, TILE_SIZE - 8);
        }
      }
    }

    // Draw entities (sorted by Y for depth)
    const visibleEntities = state.entities
      .filter((e) => e.state !== 'dead' || e.name === 'پارە')
      .filter((e) => {
        const sx = e.pos.x - cam.x;
        const sy = e.pos.y - cam.y;
        return sx > -50 && sx < w + 50 && sy > -50 && sy < h + 50;
      })
      .sort((a, b) => a.pos.y - b.pos.y);

    for (const e of visibleEntities) {
      drawEntity(ctx, e, cam);
    }

    // Draw player
    drawEntity(ctx, state.player, cam);

    // Draw attack effect
    drawAttackEffect(ctx, state.player, cam);
  }

  function drawEntity(ctx: CanvasRenderingContext2D, e: Entity, cam: { x: number; y: number }) {
    if (e.state === 'dead' && e.name !== 'پارە') {
      // Draw a corpse marker
      const sx = e.pos.x - cam.x;
      const sy = e.pos.y - cam.y;
      ctx.fillStyle = '#3a1a1a';
      ctx.beginPath();
      ctx.ellipse(sx, sy, e.size, e.size / 2, 0, 0, Math.PI * 2);
      ctx.fill();
      return;
    }

    const sx = e.pos.x - cam.x;
    const sy = e.pos.y - cam.y;

    if (e.name === 'پارە') {
      // Draw money as a gold coin
      ctx.fillStyle = '#f9e300';
      ctx.beginPath();
      ctx.arc(sx, sy, e.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#c9b800';
      ctx.beginPath();
      ctx.arc(sx, sy, e.size - 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 8px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('$', sx, sy + 3);
      return;
    }

    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.beginPath();
    ctx.ellipse(sx, sy + e.size - 2, e.size, e.size / 3, 0, 0, Math.PI * 2);
    ctx.fill();

    // Body
    ctx.fillStyle = e.color;
    ctx.beginPath();
    ctx.arc(sx, sy, e.size, 0, Math.PI * 2);
    ctx.fill();

    // Direction indicator
    const dirOffset: Record<Direction, [number, number]> = {
      up: [0, -e.size],
      down: [0, e.size],
      left: [-e.size, 0],
      right: [e.size, 0],
    };
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(sx + dirOffset[e.dir][0], sy + dirOffset[e.dir][1], 3, 0, Math.PI * 2);
    ctx.fill();

    // Health bar (for non-player entities)
    if (e.type !== 'player' && e.hp < e.maxHp) {
      const barW = e.size * 2;
      const barX = sx - barW / 2;
      const barY = sy - e.size - 6;
      ctx.fillStyle = '#333';
      ctx.fillRect(barX, barY, barW, 3);
      ctx.fillStyle = e.hp > e.maxHp * 0.5 ? '#2bb24c' : e.hp > e.maxHp * 0.25 ? '#f9e300' : '#ef3340';
      ctx.fillRect(barX, barY, barW * (e.hp / e.maxHp), 3);
    }

    // Name tag for important entities
    if (e.type === 'shopkeeper' || e.type === 'guard') {
      ctx.fillStyle = '#fff';
      ctx.font = '9px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(e.name, sx, sy - e.size - 10);
    }

    // Hostile indicator
    if (e.isHostile && e.type === 'guard') {
      ctx.fillStyle = '#ef3340';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('!', sx, sy - e.size - 14);
    }
  }

  function drawAttackEffect(ctx: CanvasRenderingContext2D, player: Entity, cam: { x: number; y: number }) {
    const now = Date.now();
    if (now - player.lastAttackTime > 300) return;
    const progress = (now - player.lastAttackTime) / 300;
    const range = 50 * (1 - progress);
    const dirOffset: Record<Direction, [number, number]> = {
      up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0],
    };
    const sx = player.pos.x - cam.x + dirOffset[player.dir][0] * 20;
    const sy = player.pos.y - cam.y + dirOffset[player.dir][1] * 20;
    ctx.strokeStyle = `rgba(249, 227, 0, ${1 - progress})`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(sx, sy, range, 0, Math.PI * 2);
    ctx.stroke();
  }

  return (
    <div className="fixed inset-0 z-[60] bg-primary flex flex-col animate-fade-in">
      {/* Header */}
      <div className="glass-dark border-b border-default px-3 py-2 flex items-center justify-between flex-shrink-0">
        <h2 className="text-sm font-bold text-primary">قەڵای کەرکووک — RPG</h2>
        <button onClick={onClose} className="p-2 rounded-full text-secondary hover:text-accent hover:bg-hover transition-all">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Game area */}
      <div className="relative flex-1 overflow-hidden">
        <canvas
          ref={canvasRef}
          className="w-full h-full touch-none"
          onTouchStart={handleJoystickStart}
          onTouchMove={handleJoystickMove}
          onTouchEnd={handleJoystickEnd}
          onMouseDown={handleJoystickStart}
          onMouseMove={handleJoystickMove}
          onMouseUp={handleJoystickEnd}
          onMouseLeave={handleJoystickEnd}
        />

        {/* HUD — top */}
        <div className="absolute top-2 left-2 right-2 flex items-start justify-between pointer-events-none">
          {/* Stats */}
          <div className="glass-dark rounded-xl px-3 py-2 space-y-1.5 pointer-events-auto">
            <div className="flex items-center gap-1.5 text-xs">
              <Heart className="w-4 h-4 text-red-400" fill="#ef3340" />
              <div className="w-20 h-2 rounded-full bg-card overflow-hidden">
                <div className="h-full rounded-full transition-all" style={{ width: `${hudHp}%`, background: hudHp > 50 ? '#2bb24c' : hudHp > 25 ? '#f9e300' : '#ef3340' }} />
              </div>
              <span className="text-primary font-bold">{hudHp}</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-accent font-bold">
              <DollarSign className="w-4 h-4" /> {hudMoney} پارە
            </div>
            <div className="flex items-center gap-1 text-xs text-secondary">
              <Crosshair className="w-3.5 h-3.5" /> {hudKills} کوشتن
            </div>
          </div>

          {/* Wanted level */}
          {hudWanted > 0 && (
            <div className="glass-dark rounded-xl px-3 py-2 flex items-center gap-1 animate-pulse-glow pointer-events-auto">
              {Array.from({ length: hudWanted }).map((_, i) => (
                <Star key={i} className="w-4 h-4 text-yellow-400" fill="#f9e300" />
              ))}
              <span className="text-xs text-red-400 font-bold ml-1">تاوان!</span>
            </div>
          )}
        </div>

        {/* Messages */}
        <div className="absolute bottom-20 left-2 right-2 flex flex-col items-center gap-1 pointer-events-none">
          {messages.map((msg) => (
            <div key={msg.id} className="glass-dark rounded-lg px-3 py-1 text-xs font-medium animate-fade-in" style={{ color: msg.color }}>
              {msg.text}
            </div>
          ))}
        </div>

        {/* Mobile controls */}
        {!gameOver && !showShop && !showDialogue && (
          <>
            {/* Attack button */}
            <button
              onClick={handleAttack}
              className="absolute bottom-4 left-4 w-16 h-16 rounded-full bg-red-600/80 border-2 border-red-400 flex items-center justify-center text-white shadow-deep active:scale-90 transition-transform"
            >
              <Sword className="w-7 h-7" />
            </button>

            {/* Action button */}
            <button
              onClick={handleInteract}
              className="absolute bottom-4 left-24 w-14 h-14 rounded-full bg-accent/80 border-2 border-accent flex items-center justify-center text-black shadow-deep active:scale-90 transition-transform"
            >
              <MessageCircle className="w-6 h-6" />
            </button>

            {/* Potion button */}
            <button
              onClick={handlePotion}
              className="absolute bottom-4 left-44 w-12 h-12 rounded-full bg-green-600/70 border-2 border-green-400 flex items-center justify-center text-white shadow-deep active:scale-90 transition-transform"
            >
              <span className="text-lg">🧪</span>
            </button>

            {/* Joystick hint */}
            <div className="absolute bottom-4 right-4 w-24 h-24 rounded-full border-2 border-white/20 flex items-center justify-center pointer-events-none">
              <span className="text-[10px] text-white/30">جوڵە</span>
            </div>
          </>
        )}

        {/* Shop modal */}
        {showShop && stateRef.current.inShop && (
          <div className="absolute inset-0 z-20 bg-black/70 flex items-center justify-center p-4 animate-fade-in" onClick={() => setShowShop(false)}>
            <div className="bg-card border border-bright rounded-2xl p-4 max-w-sm w-full space-y-3" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-primary flex items-center gap-2"><ShoppingBag className="w-5 h-5 text-accent" /> بازاڕ</h3>
                <button onClick={() => setShowShop(false)} className="p-1.5 rounded-full text-secondary hover:text-primary"><X className="w-5 h-5" /></button>
              </div>
              <p className="text-sm text-accent">پارەی تۆ: {hudMoney}</p>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {SHOP_ITEMS.map((item) => (
                  <div key={item.id} className="flex items-center justify-between bg-hover rounded-xl p-2.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{item.icon}</span>
                      <div>
                        <p className="text-sm text-primary font-medium">{item.name}</p>
                        <p className="text-xs text-muted">
                          {item.type === 'weapon' ? `${item.value} زیانی` : item.type === 'health' ? `${item.value} HP` : `${item.value} بەرگری`}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleBuy(item)}
                      disabled={hudMoney < item.price}
                      className="px-3 py-1.5 rounded-lg bg-accent text-black text-xs font-bold disabled:opacity-40 hover:bg-[var(--accent-hover)] transition-all"
                    >
                      {item.price}$
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Dialogue modal */}
        {showDialogue && (
          <div className="absolute bottom-4 left-2 right-2 z-20 animate-slide-up">
            <div className="glass-dark border border-bright rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-accent">{showDialogue.name}</h3>
                <button onClick={() => setShowDialogue(null)} className="p-1 rounded-full text-secondary hover:text-primary"><X className="w-4 h-4" /></button>
              </div>
              <p className="text-sm text-primary" dir="auto">{showDialogue.text}</p>
            </div>
          </div>
        )}

        {/* Game over */}
        {gameOver && (
          <div className="absolute inset-0 z-30 bg-black/80 flex items-center justify-center animate-fade-in">
            <div className="text-center space-y-4">
              <p className="text-2xl font-bold text-red-400">تۆ مردیت!</p>
              <p className="text-sm text-secondary">کوشتن: {hudKills} | پارە: {hudMoney}</p>
              <button onClick={handleRestart} className="px-6 py-3 rounded-xl bg-accent text-black font-bold hover:bg-[var(--accent-hover)] transition-all flex items-center gap-2 mx-auto">
                <RotateCcw className="w-5 h-5" /> دووبارە یاری بکە
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
