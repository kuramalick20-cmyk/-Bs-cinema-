import { useMemo } from 'react';

interface Star {
  x: number;
  y: number;
  size: number;
  delay: number;
  duration: number;
  opacity: number;
}

interface ShootingStar {
  top: number;
  left: number;
  delay: number;
  duration: number;
}

export default function CosmicBackground() {
  const stars = useMemo<Star[]>(() => {
    const count = 200;
    return Array.from({ length: count }).map(() => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2 + 0.5,
      delay: Math.random() * 5,
      duration: Math.random() * 3 + 2,
      opacity: Math.random() * 0.6 + 0.2,
    }));
  }, []);

  const bigStars = useMemo<Star[]>(() => {
    return Array.from({ length: 30 }).map(() => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2 + 1.5,
      delay: Math.random() * 4,
      duration: Math.random() * 2 + 1.5,
      opacity: Math.random() * 0.4 + 0.4,
    }));
  }, []);

  const shootingStars = useMemo<ShootingStar[]>(() => {
    return Array.from({ length: 5 }).map(() => ({
      top: Math.random() * 60,
      left: Math.random() * 80 + 20,
      delay: Math.random() * 8 + 3,
      duration: Math.random() * 2 + 3,
    }));
  }, []);

  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden" aria-hidden="true">
      {/* Base gradient — deep midnight blue to black */}
      <div
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(180deg, #020410 0%, #040714 30%, #060a1c 60%, #040714 100%)',
        }}
      />

      {/* Nebula clouds — drifting */}
      <div
        className="absolute inset-0 animate-nebula-drift"
        style={{
          background: 'radial-gradient(ellipse 60% 40% at 20% 30%, rgba(107, 159, 255, 0.06) 0%, transparent 70%)',
        }}
      />
      <div
        className="absolute inset-0 animate-nebula-drift"
        style={{
          background: 'radial-gradient(ellipse 50% 35% at 80% 20%, rgba(167, 139, 255, 0.05) 0%, transparent 70%)',
          animationDelay: '5s',
        }}
      />
      <div
        className="absolute inset-0 animate-nebula-drift"
        style={{
          background: 'radial-gradient(ellipse 40% 30% at 50% 80%, rgba(74, 122, 208, 0.04) 0%, transparent 70%)',
          animationDelay: '10s',
        }}
      />

      {/* Luminous moon — top right area */}
      <div
        className="absolute animate-moon-glow"
        style={{
          top: '8%',
          right: '6%',
          width: '60px',
          height: '60px',
          borderRadius: '50%',
          background: 'radial-gradient(circle at 35% 35%, rgba(220, 230, 255, 0.12) 0%, rgba(180, 198, 224, 0.06) 40%, transparent 70%)',
          filter: 'blur(2px)',
        }}
      />
      <div
        className="absolute animate-moon-glow"
        style={{
          top: '8%',
          right: '6%',
          width: '40px',
          height: '40px',
          borderRadius: '50%',
          background: 'radial-gradient(circle at 35% 35%, rgba(240, 245, 255, 0.15) 0%, rgba(200, 215, 240, 0.08) 50%, transparent 80%)',
          filter: 'blur(1px)',
          animationDelay: '2s',
        }}
      />

      {/* Small twinkling stars */}
      {stars.map((star, i) => (
        <div
          key={`s-${i}`}
          className="absolute rounded-full animate-twinkle"
          style={{
            left: `${star.x}%`,
            top: `${star.y}%`,
            width: `${star.size}px`,
            height: `${star.size}px`,
            background: 'rgba(220, 230, 255, 0.9)',
            boxShadow: `0 0 ${star.size * 2}px rgba(184, 198, 224, 0.4)`,
            animationDelay: `${star.delay}s`,
            animationDuration: `${star.duration}s`,
            opacity: star.opacity,
          }}
        />
      ))}

      {/* Larger glowing stars */}
      {bigStars.map((star, i) => (
        <div
          key={`bs-${i}`}
          className="absolute rounded-full animate-twinkle"
          style={{
            left: `${star.x}%`,
            top: `${star.y}%`,
            width: `${star.size}px`,
            height: `${star.size}px`,
            background: 'rgba(200, 215, 245, 1)',
            boxShadow: `0 0 ${star.size * 4}px rgba(107, 159, 255, 0.5), 0 0 ${star.size * 8}px rgba(167, 139, 255, 0.2)`,
            animationDelay: `${star.delay}s`,
            animationDuration: `${star.duration}s`,
            opacity: star.opacity,
          }}
        />
      ))}

      {/* Shooting stars */}
      {shootingStars.map((ss, i) => (
        <div
          key={`sh-${i}`}
          className="absolute animate-shooting-star"
          style={{
            top: `${ss.top}%`,
            left: `${ss.left}%`,
            width: '2px',
            height: '2px',
            background: 'rgba(220, 230, 255, 1)',
            borderRadius: '50%',
            boxShadow: '0 0 6px rgba(184, 198, 224, 0.8)',
            animationDelay: `${ss.delay}s`,
            animationDuration: `${ss.duration}s`,
          }}
        >
          <div
            className="absolute"
            style={{
              top: '0',
              right: '0',
              width: '80px',
              height: '1px',
              background: 'linear-gradient(to left, rgba(220, 230, 255, 0.8), transparent)',
              transform: 'rotate(-25deg)',
              transformOrigin: 'right center',
            }}
          />
        </div>
      ))}
    </div>
  );
}
