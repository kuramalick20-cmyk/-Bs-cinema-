import { useEffect, useState } from 'react';
import { getSiteSettings, type SiteSettings } from '@/lib/settings';
import { supabase } from '@/lib/supabase';
import type { Ad } from '@/lib/supabase';

interface AdSlotProps {
  placement: 'homepage-top' | 'between-content' | 'sidebar' | 'mobile';
  className?: string;
}

export default function AdSlot({ placement, className = '' }: AdSlotProps) {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [isVip, setIsVip] = useState(false);
  const [customAd, setCustomAd] = useState<Ad | null>(null);

  useEffect(() => {
    getSiteSettings().then((s) => {
      setSettings(s);
      setLoaded(true);
    });

    // Check if user is VIP
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        supabase
          .from('profiles')
          .select('vip_status')
          .eq('id', session.user.id)
          .maybeSingle()
          .then(({ data }) => {
            setIsVip(data?.vip_status === 'vip' || data?.vip_status === 'trial');
          });
      }
    });

    // Fetch a custom ad for this placement
    supabase
      .from('ads')
      .select('*')
      .eq('position', placement)
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          setCustomAd(data as Ad);
          // Increment impressions
          supabase.from('ads').update({ impressions: (data as Ad).impressions + 1 }).eq('id', data.id);
        }
      });
  }, [placement]);

  // VIP users don't see ads
  if (!loaded || !settings?.ads_enabled || isVip) return null;

  const isSidebar = placement === 'sidebar';
  const isMobile = placement === 'mobile';
  const isBetween = placement === 'between-content';
  const isTop = placement === 'homepage-top';

  const baseClass = 'flex items-center justify-center rounded-xl border border-dashed border-default bg-card/50 overflow-hidden';

  let sizeClass = '';
  let label = 'ڕیکلام';

  if (isTop) {
    sizeClass = 'w-full min-h-[90px] md:min-h-[120px]';
  } else if (isBetween) {
    sizeClass = 'w-full min-h-[90px] md:min-h-[100px]';
  } else if (isSidebar) {
    sizeClass = 'w-full min-h-[250px] md:min-h-[600px] sticky top-20';
  } else if (isMobile) {
    sizeClass = 'w-full min-h-[60px] md:hidden';
  }

  // Show custom ad if available
  if (customAd?.image_url) {
    return (
      <a
        href={customAd.link_url || '#'}
        target="_blank"
        rel="noopener noreferrer"
        className={`block rounded-xl overflow-hidden ${sizeClass} ${className}`}
        onClick={(e) => { if (!customAd.link_url) e.preventDefault(); }}
      >
        <img src={customAd.image_url} alt={customAd.title || 'Advertisement'} className="w-full h-full object-cover" />
      </a>
    );
  }

  return (
    <div className={`${baseClass} ${sizeClass} ${className}`}>
      {settings.ad_client_id && settings.ad_provider === 'adsense' ? (
        <ins
          className="adsbygoogle"
          style={{ display: 'block', width: '100%', height: '100%' }}
          data-ad-client={settings.ad_client_id}
          data-ad-slot="auto"
          data-ad-format="auto"
          data-full-width-responsive="true"
        />
      ) : (
        <div className="flex flex-col items-center gap-1 text-muted">
          <span className="text-xs font-medium opacity-60">{label}</span>
          <span className="text-[10px] opacity-40">Ad Space — {placement}</span>
        </div>
      )}
    </div>
  );
}
