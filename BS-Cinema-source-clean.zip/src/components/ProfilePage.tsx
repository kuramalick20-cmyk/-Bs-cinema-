import { useState, useEffect } from 'react';
import { X, User, Mail, Phone, Save, Loader2, Upload, Crown, Clock } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { uploadFile } from '@/lib/storage';

interface ProfilePageProps {
  onClose: () => void;
}

export default function ProfilePage({ onClose }: ProfilePageProps) {
  const { user, profile, updateProfile } = useAuth();
  const [username, setUsername] = useState(profile?.username || '');
  const [avatarUrl, setAvatarUrl] = useState(profile?.avatar_url || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [savedMsg, setSavedMsg] = useState(false);

  useEffect(() => {
    if (profile) {
      setUsername(profile.username || '');
      setAvatarUrl(profile.avatar_url || '');
      setPhone(profile.phone || '');
    }
  }, [profile]);

  const handleAvatarUpload = async (file: File) => {
    setUploading(true);
    const url = await uploadFile('avatars', file);
    if (url) setAvatarUrl(url);
    setUploading(false);
  };

  const handleSave = async () => {
    setSaving(true);
    await updateProfile({ username, avatar_url: avatarUrl, phone });
    setSaving(false);
    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[60] overflow-y-auto bg-primary animate-fade-in">
      <div className="sticky top-0 glass border-b border-default px-4 py-3 flex items-center justify-between" style={{ paddingTop: 'calc(0.75rem + var(--safe-top))' }}>
        <h2 className="text-lg font-bold text-primary">پرۆفایلی من</h2>
        <button onClick={onClose} className="p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-2xl mx-auto p-4 md:p-6" style={{ paddingBottom: 'calc(1rem + var(--safe-bottom))' }}>
        {/* Avatar */}
        <div className="text-center mb-6">
          <div className="relative inline-block">
            <div className="w-24 h-24 rounded-full bg-accent flex items-center justify-center text-white text-3xl font-bold overflow-hidden mx-auto">
              {avatarUrl ? (
                <img src={avatarUrl} alt="avatar" className="w-full h-full object-cover" />
              ) : (
                (username || user?.email || 'U').charAt(0).toUpperCase()
              )}
            </div>
            <label className="absolute bottom-0 left-0 w-8 h-8 rounded-full bg-accent flex items-center justify-center cursor-pointer text-white shadow-lg">
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleAvatarUpload(e.target.files[0])}
              />
            </label>
          </div>
        </div>

        {/* Profile info */}
        <div className="bg-card border border-default rounded-xl p-4 space-y-4">
          <div>
            <label className="text-sm text-secondary mb-1.5 block">ناوی بەکارهێنەر</label>
            <div className="relative">
              <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pr-10 pl-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent"
              />
            </div>
          </div>

          <div>
            <label className="text-sm text-secondary mb-1.5 block">ئیمەیڵ</label>
            <div className="relative">
              <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
              <input
                type="email"
                value={user?.email || ''}
                disabled
                className="w-full pr-10 pl-4 py-2.5 rounded-lg bg-hover border border-default text-muted text-sm"
              />
            </div>
          </div>

          <div>
            <label className="text-sm text-secondary mb-1.5 block">ژمارەی مۆبایل</label>
            <div className="relative">
              <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+9647501234567"
                className="w-full pr-10 pl-4 py-2.5 rounded-lg bg-secondary border border-default text-primary text-sm outline-none focus:border-accent"
              />
            </div>
          </div>

          <button
            onClick={handleSave}
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-lg bg-accent text-white font-medium text-sm hover:bg-[var(--accent-hover)] transition-all disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            پاشەکەوتکردن
          </button>
          {savedMsg && <p className="text-center text-sm text-green-400">پاشەکەوتکرا!</p>}
        </div>

        {/* VIP Status */}
        <div className="bg-card border border-default rounded-xl p-4 mt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                profile?.vip_status === 'vip' ? 'bg-accent/20' : profile?.vip_status === 'trial' ? 'bg-accent/20' : 'bg-hover'
              }`}>
                {profile?.vip_status === 'vip' ? <Crown className="w-5 h-5 text-accent" /> : profile?.vip_status === 'trial' ? <Clock className="w-5 h-5 text-accent" /> : <Crown className="w-5 h-5 text-muted" />}
              </div>
              <div>
                <p className="text-sm text-secondary">ئەندامیەت</p>
                <p className="text-sm font-bold text-primary">
                  {profile?.vip_status === 'vip' ? 'VIP' : profile?.vip_status === 'trial' ? 'بەرایی (٣ ڕۆژ)' : 'بەخۆڕایی'}
                </p>
              </div>
            </div>
            {profile?.vip_status === 'vip' && profile?.vip_end_date && (
              <p className="text-xs text-accent">
                {Math.max(0, Math.ceil((new Date(profile.vip_end_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))} ڕۆژ ماوە
              </p>
            )}
            {profile?.vip_status === 'trial' && profile?.trial_end_date && (
              <p className="text-xs text-accent">
                {Math.max(0, Math.ceil((new Date(profile.trial_end_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))} ڕۆژ ماوە
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
