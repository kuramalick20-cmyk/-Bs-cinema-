import { useState, useEffect, useCallback, useRef } from 'react';
import { X, Bell, Film, Tv, BookOpen, Sparkles, MessageCircle, Check, Gamepad2, Phone } from 'lucide-react';
import { supabase, type Notification } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

interface NotificationsPanelProps {
  onClose: () => void;
  onNavigate?: (target: 'chat' | 'games' | 'content' | 'aichat') => void;
}

const NOTIFICATION_ICONS: Record<string, any> = {
  new_content: Film,
  new_episode: Tv,
  new_chapter: BookOpen,
  new_vip_content: Sparkles,
  chat_message: MessageCircle,
  game_invite: Gamepad2,
  voice_call: Phone,
  comment_reply: MessageCircle,
};

const NOTIFICATION_TARGETS: Record<string, 'chat' | 'games' | 'content' | 'aichat'> = {
  chat_message: 'chat',
  game_invite: 'games',
  voice_call: 'chat',
  comment_reply: 'content',
  new_content: 'content',
  new_episode: 'content',
  new_chapter: 'content',
  new_vip_content: 'content',
};

export default function NotificationsPanel({ onClose, onNavigate }: NotificationsPanelProps) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');
  const [toastNotif, setToastNotif] = useState<Notification | null>(null);
  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const audioCtxRef = useRef<any>(null);

  const playNotificationSound = useCallback(() => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      const oscillator = ctx.createOscillator();
      const gain = ctx.createGain();
      oscillator.connect(gain);
      gain.connect(ctx.destination);
      oscillator.frequency.setValueAtTime(880, ctx.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
      oscillator.start(ctx.currentTime);
      oscillator.stop(ctx.currentTime + 0.3);
    } catch {}
  }, []);

  const loadNotifications = useCallback(async () => {
    if (!user) return;
    let query = supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50);

    if (filter === 'unread') {
      query = query.eq('is_read', false);
    }

    const { data } = await query;
    setNotifications((data as Notification[]) || []);
    setLoading(false);
  }, [user, filter]);

  useEffect(() => {
    loadNotifications();
  }, [loadNotifications]);

  // Real-time subscription for new notifications
  useEffect(() => {
    if (!user) return;
    const sub = supabase
      .channel('notifications')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const newNotif = payload.new as Notification;
          loadNotifications();
          playNotificationSound();
          setToastNotif(newNotif);
          if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
          toastTimerRef.current = setTimeout(() => setToastNotif(null), 5000);
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'notifications', filter: `user_id=eq.${user.id}` },
        () => loadNotifications()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(sub);
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    };
  }, [user, loadNotifications, playNotificationSound]);

  const markAsRead = async (notif: Notification) => {
    if (!notif.is_read) {
      await supabase.from('notifications').update({ is_read: true }).eq('id', notif.id);
      setNotifications((prev) => prev.map((n) => (n.id === notif.id ? { ...n, is_read: true } : n)));
    }
    const target = NOTIFICATION_TARGETS[notif.type];
    if (target && onNavigate) {
      onNavigate(target);
      onClose();
    }
  };

  const markAllAsRead = async () => {
    if (!user) return;
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', user.id).eq('is_read', false);
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
  };

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  const handleToastClick = () => {
    if (toastNotif) {
      markAsRead(toastNotif);
    }
  };

  if (!user) {
    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-primary">
        <div className="text-center space-y-4">
          <Bell className="w-12 h-12 text-muted mx-auto" />
          <p className="text-secondary">تکایە پێشتر بچۆ ژوورەوە</p>
          <button onClick={onClose} className="px-4 py-2 rounded-lg bg-accent text-white text-sm">داخستن</button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[60] bg-primary overflow-y-auto animate-fade-in">
      {/* Realtime toast notification */}
      {toastNotif && (
        <div
          className="fixed top-0 left-0 right-0 z-[70] mx-auto max-w-md mt-2 px-3 animate-fade-in cursor-pointer"
          onClick={handleToastClick}
        >
          <div className="glass-dark border border-accent/40 rounded-xl p-3 flex items-center gap-3 shadow-glow">
            <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
              {(() => {
                const Icon = NOTIFICATION_ICONS[toastNotif.type] || Bell;
                return <Icon className="w-5 h-5 text-accent" />;
              })()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-primary truncate">{toastNotif.title}</p>
              {toastNotif.body && <p className="text-xs text-secondary truncate" dir="auto">{toastNotif.body}</p>}
            </div>
            <button
              onClick={(e) => { e.stopPropagation(); setToastNotif(null); }}
              className="p-1 rounded-full text-muted hover:text-primary flex-shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <div className="sticky top-0 glass border-b border-default px-4 py-3 flex items-center justify-between" style={{ paddingTop: 'calc(0.75rem + var(--safe-top))' }}>
        <h2 className="text-base sm:text-lg font-bold text-primary flex items-center gap-2">
          <Bell className="w-5 h-5 text-accent" /> ئاگادارکردنەوەکان
          {unreadCount > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-accent text-white text-xs font-bold">{unreadCount}</span>
          )}
        </h2>
        <button onClick={onClose} className="p-2 rounded-full text-secondary hover:text-primary hover:bg-hover transition-all">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-2xl mx-auto p-3 sm:p-4 space-y-3 sm:space-y-4" style={{ paddingBottom: 'calc(1rem + var(--safe-bottom))' }}>
        {/* Filter & actions */}
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex gap-2">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all ${filter === 'all' ? 'bg-accent text-white' : 'bg-card text-secondary border border-default'}`}
            >
              هەموو
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all ${filter === 'unread' ? 'bg-accent text-white' : 'bg-card text-secondary border border-default'}`}
            >
              نەخوێندراوە ({unreadCount})
            </button>
          </div>
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm text-accent hover:bg-accent/10 transition-colors"
            >
              <Check className="w-4 h-4" /> هەموو وەک خوێندراوە
            </button>
          )}
        </div>

        {/* Notifications list */}
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 border-2 border-accent border-t-transparent rounded-full animate-spin" />
          </div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-16">
            <Bell className="w-12 h-12 text-muted mx-auto mb-3" />
            <p className="text-secondary text-sm">هیچ ئاگادارکردنەوەیەک نییە</p>
          </div>
        ) : (
          <div className="space-y-2">
            {notifications.map((notif) => {
              const Icon = NOTIFICATION_ICONS[notif.type] || Bell;
              const target = NOTIFICATION_TARGETS[notif.type];
              return (
                <div
                  key={notif.id}
                  className={`flex items-start gap-3 p-3 sm:p-4 rounded-xl border transition-all ${target ? 'cursor-pointer hover:scale-[1.01]' : ''} ${
                    notif.is_read
                      ? 'bg-card border-default'
                      : 'bg-accent/5 border-accent/30 hover:bg-accent/10'
                  }`}
                  onClick={() => markAsRead(notif)}
                >
                  <div className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center flex-shrink-0 ${notif.is_read ? 'bg-hover' : 'bg-accent/20'}`}>
                    <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${notif.is_read ? 'text-muted' : 'text-accent'}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs sm:text-sm ${notif.is_read ? 'text-secondary' : 'text-primary font-medium'}`}>{notif.title}</p>
                    {notif.body && <p className="text-xs text-muted mt-1 line-clamp-2" dir="auto">{notif.body}</p>}
                    <p className="text-[10px] text-muted mt-1">{new Date(notif.created_at).toLocaleDateString()}</p>
                  </div>
                  {!notif.is_read && <div className="w-2 h-2 rounded-full bg-accent flex-shrink-0 mt-2" />}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
