import { useState, useRef, useEffect, useCallback } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize2, Minimize2, AlertCircle, SkipForward, SkipBack, RotateCcw, RotateCw, Subtitles, Languages, Loader2, Mic } from 'lucide-react';
import EngagementBar from './EngagementBar';
import CommentSection from './CommentSection';
import { fetchSubtitles, findActiveSubtitle } from '@/lib/subtitles';
import { autoGenerateAndSaveSubtitles, isSpeechRecognitionSupported, type STTSegment } from '@/lib/videoSTT';
import type { Subtitle as SubtitleType } from '@/lib/supabase';
import { LANGUAGES } from '@/lib/comicTranslation';

interface VideoPlayerProps {
  videoUrl: string;
  videoType: 'upload' | 'link' | 'gdrive';
  title?: string;
  episodes?: { id: string; episode_number: number; title: string | null; video_type: 'upload' | 'link' | 'gdrive'; video_url: string }[];
  currentEpisode?: number;
  onEpisodeChange?: (index: number) => void;
  episodeId?: string;
}

function getYouTubeId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

function getVimeoId(url: string): string | null {
  const m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  return m ? m[1] : null;
}

function getGoogleDriveId(url: string): string | null {
  const patterns = [
    /drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/,
    /drive\.google\.com\/open\?id=([a-zA-Z0-9_-]+)/,
    /docs\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

export default function VideoPlayer({ videoUrl, videoType, title, episodes, currentEpisode, onEpisodeChange, episodeId }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [error, setError] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showCenterPlay, setShowCenterPlay] = useState(false);
  const [buffering, setBuffering] = useState(false);
  const [seekFeedback, setSeekFeedback] = useState<'forward' | 'backward' | null>(null);
  const controlsTimeout = useRef<number | null>(null);
  const lastTapRef = useRef<number>(0);
  const tapTimeoutRef = useRef<number | null>(null);

  // Subtitle state
  const [subtitles, setSubtitles] = useState<SubtitleType[]>([]);
  const [showSubtitles, setShowSubtitles] = useState(false);
  const [subtitleLang, setSubtitleLang] = useState<'ku' | 'en'>('ku');
  const [activeSubtitle, setActiveSubtitle] = useState<SubtitleType | null>(null);
  const [translatedSubs, setTranslatedSubs] = useState<Record<string, string>>({});
  const [translating, setTranslating] = useState(false);
  const [subtitlesEnabled, setSubtitlesEnabled] = useState(false);
  const [showSubLangDropdown, setShowSubLangDropdown] = useState(false);
  const [selectedSubLang, setSelectedSubLang] = useState<string>('ku');

  // Auto subtitle generation state
  const [generatingSubs, setGeneratingSubs] = useState(false);
  const [genProgress, setGenProgress] = useState('');
  const [genSegmentCount, setGenSegmentCount] = useState(0);
  const [genError, setGenError] = useState<string | null>(null);
  const [showSubLangPicker, setShowSubLangPicker] = useState(false);
  const [autoGenAttempted, setAutoGenAttempted] = useState(false);

  // Load subtitles for current episode
  useEffect(() => {
    if (episodeId) {
      fetchSubtitles('episode', episodeId).then(setSubtitles);
    } else {
      setSubtitles([]);
    }
    setSubtitlesEnabled(false);
    setShowSubtitles(false);
    setTranslatedSubs({});
    setGenError(null);
    setAutoGenAttempted(false);
  }, [episodeId]);

  // Auto-generate subtitles when video first plays (if no subtitles exist yet)
  useEffect(() => {
    if (!playing || autoGenAttempted || generatingSubs) return;
    if (!episodeId || videoType !== 'upload') return;
    if (subtitles.length > 0) {
      setAutoGenAttempted(true);
      return;
    }
    if (!isSpeechRecognitionSupported()) {
      setAutoGenAttempted(true);
      return;
    }
    setAutoGenAttempted(true);
    handleAutoGenerateSubtitles('ku');
  }, [playing, autoGenAttempted, generatingSubs, episodeId, videoType, subtitles.length]);

  const handleAutoGenerateSubtitles = async (preferredLang: 'ku' | 'en') => {
    if (!videoRef.current || !episodeId) return;
    if (!isSpeechRecognitionSupported()) {
      setGenError('گۆڕاوی بەرنامەکە پشتگیری ناکات — تکایە Chrome بەکاربهێنە');
      setShowSubLangPicker(false);
      return;
    }
    setShowSubLangPicker(false);
    setGeneratingSubs(true);
    setGenError(null);
    setGenProgress('دەستپێکردنی ناسینەوەی قسە...');
    setGenSegmentCount(0);

    const video = videoRef.current;
    const wasPaused = video.paused;
    const wasMuted = video.muted;
    const wasVolume = video.volume;
    video.currentTime = 0;

    const result = await autoGenerateAndSaveSubtitles(video, episodeId, {
      preferredLanguage: preferredLang,
      onProgress: (text, count) => {
        setGenProgress(text || 'گوێ گرتن...');
        setGenSegmentCount(count);
      },
    });

    // Restore video state
    video.muted = wasMuted;
    video.volume = wasVolume;
    if (wasPaused) {
      video.pause();
    }
    video.currentTime = 0;

    setGeneratingSubs(false);
    setGenProgress('');

    if (result.success) {
      const subs = await fetchSubtitles('episode', episodeId);
      setSubtitles(subs);
      setSubtitlesEnabled(true);
      setShowSubtitles(true);
      setSubtitleLang(result.detectedLanguage);
    } else {
      setGenError(result.error || 'نەتوانرا ژێرنووس دروست بکرێت');
    }
  };

  const translateSubtitlesBatch = async (targetLang: string) => {
    if (subtitles.length === 0) return;
    const sourceSubs = subtitles.filter(s => s.language === 'ku' || s.language === 'en');
    if (sourceSubs.length === 0) return;
    const sourceLang = sourceSubs[0].language;
    if (sourceLang === targetLang) {
      setTranslatedSubs({});
      return;
    }

    // Check if we already have subtitles in the target language
    const existingInTarget = subtitles.filter(s => s.language === targetLang);
    if (existingInTarget.length > 0) {
      const newTranslations: Record<string, string> = {};
      sourceSubs.forEach((sub, i) => {
        if (existingInTarget[i]) newTranslations[sub.id] = existingInTarget[i].content;
      });
      setTranslatedSubs(newTranslations);
      return;
    }

    setTranslating(true);
    try {
      const texts = sourceSubs.map(s => s.content);
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/comic-translate`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({ texts, target_lang: targetLang, source_lang: sourceLang }),
      });
      if (response.ok) {
        const data = await response.json();
        const results = data.results || [];
        const newTranslations: Record<string, string> = {};
        sourceSubs.forEach((sub, i) => {
          if (results[i]?.translated) newTranslations[sub.id] = results[i].translated;
        });
        setTranslatedSubs(newTranslations);
      }
    } catch {
      // Translation failed — keep showing original
    }
    setTranslating(false);
  };
  // Update active subtitle based on video time
  useEffect(() => {
    if (!subtitlesEnabled || subtitles.length === 0) {
      setActiveSubtitle(null);
      return;
    }
  }, [subtitlesEnabled, subtitles, subtitleLang]);

  const handleTimeUpdateSubs = (currentTime: number) => {
    if (!subtitlesEnabled || subtitles.length === 0) return;
    // Find subtitle in original language or use translated subs
    const sourceLang = subtitles[0]?.language || 'ku';
    const active = findActiveSubtitle(subtitles, currentTime, sourceLang);
    if (active && selectedSubLang !== sourceLang && translatedSubs[active.id]) {
      setActiveSubtitle({ ...active, content: translatedSubs[active.id] });
    } else {
      setActiveSubtitle(active);
    }
  };

  useEffect(() => {
    setError(false);
    setPlaying(false);
    setProgress(0);
    setDuration(0);
  }, [videoUrl]);

  // Fullscreen change listener
  useEffect(() => {
    const onFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFsChange);
    document.addEventListener('webkitfullscreenchange', onFsChange);
    return () => {
      document.removeEventListener('fullscreenchange', onFsChange);
      document.removeEventListener('webkitfullscreenchange', onFsChange);
    };
  }, []);

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      v.play().then(() => setPlaying(true)).catch(() => setError(true));
    } else {
      v.pause();
      setPlaying(false);
    }
    // Show center indicator briefly
    setShowCenterPlay(true);
    window.setTimeout(() => setShowCenterPlay(false), 600);
  }, []);

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setMuted(v.muted);
  };

  const handleTimeUpdate = () => {
    const v = videoRef.current;
    if (!v || !v.duration) return;
    setProgress((v.currentTime / v.duration) * 100);
    handleTimeUpdateSubs(v.currentTime);
  };

  const handleLoadedMetadata = () => {
    const v = videoRef.current;
    if (v) setDuration(v.duration);
  };

  const handleWaiting = () => setBuffering(true);
  const handlePlaying = () => setBuffering(false);
  const handleCanPlay = () => setBuffering(false);

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const v = videoRef.current;
    if (!v || !v.duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    v.currentTime = pct * v.duration;
  };

  const seekBy = (seconds: number) => {
    const v = videoRef.current;
    if (!v || !v.duration) return;
    v.currentTime = Math.max(0, Math.min(v.duration, v.currentTime + seconds));
    setSeekFeedback(seconds > 0 ? 'forward' : 'backward');
    window.setTimeout(() => setSeekFeedback(null), 500);
  };

  const toggleFullscreen = () => {
    const el = containerRef.current;
    if (!el) return;
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else if (el.requestFullscreen) {
      el.requestFullscreen();
    } else if ((el as any).webkitRequestFullscreen) {
      (el as any).webkitRequestFullscreen();
    } else if ((el as any).msRequestFullscreen) {
      (el as any).msRequestFullscreen();
    }
  };

  const showControlsTemporarily = () => {
    setShowControls(true);
    if (controlsTimeout.current) window.clearTimeout(controlsTimeout.current);
    controlsTimeout.current = window.setTimeout(() => {
      if (playing) setShowControls(false);
    }, 3000);
  };

  // Single tap = toggle controls, double tap = play/pause
  const handleVideoClick = () => {
    const now = Date.now();
    if (now - lastTapRef.current < 300) {
      // Double tap
      if (tapTimeoutRef.current) {
        window.clearTimeout(tapTimeoutRef.current);
        tapTimeoutRef.current = null;
      }
      togglePlay();
    } else {
      // Single tap — wait to see if double tap follows
      tapTimeoutRef.current = window.setTimeout(() => {
        if (!playing) {
          togglePlay();
        } else {
          setShowControls((prev) => !prev);
        }
        tapTimeoutRef.current = null;
      }, 280);
    }
    lastTapRef.current = now;
  };

  const ytId = videoType === 'link' ? getYouTubeId(videoUrl) : null;
  const vimeoId = videoType === 'link' && !ytId ? getVimeoId(videoUrl) : null;
  const gdriveId = videoType === 'gdrive' ? getGoogleDriveId(videoUrl) : null;
  const isExternalEmbed = ytId || vimeoId || gdriveId;

  const formatTime = (s: number) => {
    if (!s || isNaN(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full">
      {episodes && episodes.length > 1 && (
        <div className="flex items-center gap-2 mb-3 overflow-x-auto scrollbar-hide pb-2">
          {episodes.map((ep, i) => (
            <button
              key={ep.id}
              onClick={() => onEpisodeChange?.(i)}
              className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                currentEpisode === i
                  ? 'bg-accent text-white shadow-glow'
                  : 'bg-card text-secondary border border-default hover:bg-hover'
              }`}
            >
              ئەلقە {ep.episode_number}
            </button>
          ))}
        </div>
      )}

      <div
        ref={containerRef}
        className="relative w-full aspect-video bg-black rounded-xl overflow-hidden group"
        onMouseMove={showControlsTemporarily}
        onMouseLeave={() => playing && setShowControls(false)}
        style={{ touchAction: 'manipulation' }}
      >
        {isExternalEmbed ? (
          ytId ? (
            <iframe
              src={`https://www.youtube.com/embed/${ytId}?rel=0&modestbranding=1`}
              title={title || 'Video'}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              loading="lazy"
            />
          ) : gdriveId ? (
            <iframe
              src={`https://drive.google.com/file/d/${gdriveId}/preview`}
              title={title || 'Video'}
              className="w-full h-full"
              allow="autoplay; fullscreen; picture-in-picture"
              allowFullScreen
              loading="lazy"
            />
          ) : (
            <iframe
              src={`https://player.vimeo.com/video/${vimeoId}`}
              title={title || 'Video'}
              className="w-full h-full"
              allow="autoplay; fullscreen; picture-in-picture"
              allowFullScreen
              loading="lazy"
            />
          )
        ) : (
          <>
            {error ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white/80 gap-3">
                <AlertCircle className="w-12 h-12 text-red-400" />
                <p className="text-sm">نەتوانرا ڤیدیۆکە بکاربێت</p>
              </div>
            ) : (
              <video
                ref={videoRef}
                src={videoUrl}
                className="w-full h-full object-contain"
                onClick={handleVideoClick}
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onEnded={() => setPlaying(false)}
                onError={() => setError(true)}
                onWaiting={handleWaiting}
                onPlaying={handlePlaying}
                onCanPlay={handleCanPlay}
                playsInline
                preload="metadata"
              />
            )}

            {/* Buffering spinner */}
            {buffering && !error && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-12 h-12 border-3 border-white/30 border-t-accent rounded-full animate-spin" style={{ borderWidth: '3px' }} />
              </div>
            )}

            {/* Center play/pause pulse indicator */}
            {showCenterPlay && !error && !buffering && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-16 h-16 rounded-full bg-black/50 flex items-center justify-center animate-scale-in">
                  {playing ? <Pause className="w-7 h-7 text-white" /> : <Play className="w-7 h-7 text-white ml-1" fill="white" />}
                </div>
              </div>
            )}

            {/* Seek feedback indicator */}
            {seekFeedback && !error && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-black/60 animate-scale-in">
                  {seekFeedback === 'forward' ? <RotateCw className="w-5 h-5 text-white" /> : <RotateCcw className="w-5 h-5 text-white" />}
                  <span className="text-white text-sm font-medium">10s</span>
                </div>
              </div>
            )}

            {/* Custom controls overlay */}
            {!error && (
              <div
                className={`absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/70 via-transparent to-transparent transition-opacity duration-300 ${
                  showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'
                }`}
              >
                {/* Progress bar */}
                <div className="px-3 sm:px-4 pb-2">
                  <div
                    className="group/bar h-2.5 sm:h-1.5 bg-white/20 rounded-full cursor-pointer relative touch-none"
                    onClick={handleSeek}
                  >
                    <div
                      className="h-full bg-accent rounded-full relative"
                      style={{ width: `${progress}%` }}
                    >
                      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3.5 h-3.5 sm:w-3 sm:h-3 bg-white rounded-full opacity-100 sm:opacity-0 sm:group-hover/bar:opacity-100 transition-opacity" />
                    </div>
                  </div>
                </div>
                {/* Controls */}
                <div className="flex flex-wrap items-center justify-between gap-y-1 px-3 sm:px-4 pb-3 gap-x-2">
                  <div className="flex items-center gap-2 sm:gap-3">
                    <button onClick={togglePlay} className="text-white hover:text-accent transition-colors p-1">
                      {playing ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" fill="white" />}
                    </button>
                    <button onClick={toggleMute} className="text-white hover:text-accent transition-colors p-1">
                      {muted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                    </button>
                    {/* Seek buttons */}
                    <button onClick={() => seekBy(-10)} className="text-white hover:text-accent transition-colors p-1" title="١٠ چرکە بەرەو دوا">
                      <RotateCcw className="w-5 h-5" />
                    </button>
                    <button onClick={() => seekBy(10)} className="text-white hover:text-accent transition-colors p-1" title="١٠ چرکە بەرەو پێش">
                      <RotateCw className="w-5 h-5" />
                    </button>
                    <span className="text-xs text-white/80">
                      {formatTime(videoRef.current?.currentTime ?? 0)} / {formatTime(duration)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 sm:gap-3">
                    {/* Auto-generate subtitles button with language picker */}
                    {episodeId && videoType === 'upload' && (
                      <div className="relative">
                        <button
                          onClick={() => setShowSubLangPicker(!showSubLangPicker)}
                          disabled={generatingSubs}
                          className={`transition-colors p-1 ${generatingSubs ? 'text-accent' : 'text-white hover:text-accent'}`}
                          title="دروستکردنی خۆکاری ژێرنووس (AI)"
                        >
                          {generatingSubs ? <Loader2 className="w-5 h-5 animate-spin" /> : <Mic className="w-5 h-5" />}
                        </button>
                        {showSubLangPicker && !generatingSubs && (
                          <div className="absolute bottom-full right-0 mb-2 bg-black/90 rounded-lg p-2 flex flex-col gap-1 min-w-[140px] z-20">
                            <p className="text-xs text-white/60 px-2 py-1">زمانی قسە:</p>
                            <button
                              onClick={() => handleAutoGenerateSubtitles('ku')}
                              className="px-3 py-2 rounded text-xs text-right transition-colors text-white hover:bg-white/10"
                            >
                              کوردی
                            </button>
                            <button
                              onClick={() => handleAutoGenerateSubtitles('en')}
                              className="px-3 py-2 rounded text-xs text-right transition-colors text-white hover:bg-white/10"
                            >
                              English
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                    {/* Subtitle toggle with language picker */}
                    {subtitles.length > 0 && (
                      <div className="relative">
                        <button
                          onClick={() => {
                            setSubtitlesEnabled(!subtitlesEnabled);
                            setShowSubtitles(!subtitlesEnabled);
                          }}
                          className={`transition-colors p-1 ${subtitlesEnabled ? 'text-accent' : 'text-white hover:text-accent'}`}
                          title="ژێرنووس"
                        >
                          <Subtitles className="w-5 h-5" />
                        </button>
                        {subtitlesEnabled && (
                          <div className="absolute bottom-full right-0 mb-2 bg-black/90 rounded-lg p-2 max-h-60 overflow-y-auto z-20 min-w-[160px]">
                            <p className="text-xs text-white/60 px-2 py-1 mb-1">زمانی ژێرنووس:</p>
                            {LANGUAGES.map((l) => (
                              <button
                                key={l.code}
                                onClick={async () => {
                                  setSubtitleLang(l.code as 'ku' | 'en');
                                  setSelectedSubLang(l.code);
                                  setShowSubLangDropdown(false);
                                  await translateSubtitlesBatch(l.code);
                                }}
                                className={`block w-full text-right px-3 py-2 rounded text-xs transition-colors ${selectedSubLang === l.code ? 'bg-accent text-white' : 'text-white hover:bg-white/10'}`}
                              >
                                {l.nativeName} {translating && selectedSubLang === l.code && <Loader2 className="w-3 h-3 inline animate-spin" />}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                    {episodes && episodes.length > 1 && (
                      <>
                        <button
                          onClick={() => onEpisodeChange?.(((currentEpisode ?? 0) - 1 + episodes.length) % episodes.length)}
                          className="text-white hover:text-accent transition-colors p-1"
                          title="ئەلقەی پێشوو"
                        >
                          <SkipBack className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => onEpisodeChange?.(((currentEpisode ?? 0) + 1) % episodes.length)}
                          className="text-white hover:text-accent transition-colors p-1"
                          title="ئەلقەی داهاتوو"
                        >
                          <SkipForward className="w-5 h-5" />
                        </button>
                      </>
                    )}
                    <button onClick={toggleFullscreen} className="text-white hover:text-accent transition-colors p-1" title="تەواوی شاشە">
                      {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
                    </button>
                  </div>
                </div>
              </div>
            )}
            {/* Subtitle overlay */}
            {subtitlesEnabled && activeSubtitle && !error && (
              <div className="absolute bottom-16 left-1/2 -translate-x-1/2 max-w-[80%] z-10 pointer-events-none">
                <div className="bg-black/75 rounded-lg px-4 py-2 text-center">
                  <p className="text-white text-sm md:text-base leading-relaxed" dir={selectedSubLang === 'ku' || selectedSubLang === 'ar' || selectedSubLang === 'fa' || selectedSubLang === 'ur' || selectedSubLang === 'ps' || selectedSubLang === 'he' ? 'rtl' : 'ltr'}>
                    {translatedSubs[activeSubtitle.id] || activeSubtitle.content}
                  </p>
                </div>
              </div>
            )}
          </>
        )}

        {/* Auto subtitle generation progress overlay */}
        {generatingSubs && !error && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60 z-20 pointer-events-none">
            <div className="text-center max-w-[80%]">
              <Loader2 className="w-10 h-10 text-accent animate-spin mx-auto mb-3" />
              <p className="text-white text-sm font-medium mb-1">AI ناسینەوەی قسە...</p>
              {genSegmentCount > 0 && (
                <p className="text-white/60 text-xs mb-2">{genSegmentCount} ژێرنووس دروستکراو</p>
              )}
              {genProgress && (
                <p className="text-accent text-xs truncate" dir="auto">{genProgress}</p>
              )}
            </div>
          </div>
        )}

        {/* Subtitle generation error */}
        {genError && !error && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-red-500/80 text-white text-xs px-4 py-2 rounded-lg z-20 max-w-[80%] text-center">
            {genError}
          </div>
        )}
      </div>

      {title && <h3 className="text-lg font-semibold text-primary mt-3">{title}</h3>}

      {episodeId && (
        <>
          <div className="mt-2">
            <EngagementBar itemType="episode" itemId={episodeId} />
          </div>
          <CommentSection itemType="episode" itemId={episodeId} />
        </>
      )}
    </div>
  );
}
