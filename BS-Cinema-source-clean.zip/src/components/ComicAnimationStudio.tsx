import { useState, useEffect, useCallback, useRef } from 'react';
import {
  X, Play, Pause, Loader2, Sparkles, Video, Camera, Clock,
  RefreshCw, AlertCircle, CheckCircle2, Film, Image as ImageIcon,
  ChevronDown, ChevronUp, Wand2, Download, Plus, Trash2,
  MessageSquare, User, Eye, Settings, Layers
} from 'lucide-react';
import type { ComicPanel, ComicCharacterRef, CameraMotion } from '@/lib/supabase';
import { supabase } from '@/lib/supabase';
import { uploadFile } from '@/lib/storage';
import { useAdmin } from '@/context/AdminContext';
import {
  fetchPanelAnimation, generatePanelVideo, analyzePanelWithChatGPT,
  improveAnimationPrompt, fetchProviderSettings,
  fetchCharacterRefs, createCharacterRef, updateCharacterRef, deleteCharacterRef,
  uploadCharacterReference, CAMERA_MOTIONS, buildChapterTimeline, type ChatGPTAnalysis,
} from '@/lib/comicAnimation';

interface ComicAnimationStudioProps {
  panels: ComicPanel[];
  chapterId: string;
  contentId: string;
  onClose: () => void;
}

type PanelStatus = 'idle' | 'analyzing' | 'generating' | 'completed' | 'failed';

interface PanelState {
  status: PanelStatus;
  animationId: string | null;
  videoUrl: string | null;
  analysis: ChatGPTAnalysis | null;
  duration: number;
  cameraMotion: CameraMotion;
  prompt: string;
  error: string | null;
}

export default function ComicAnimationStudio({ panels, chapterId, contentId, onClose }: ComicAnimationStudioProps) {
  const { isAdmin } = useAdmin();
  const [selectedPanelIdx, setSelectedPanelIdx] = useState(0);
  const [panelStates, setPanelStates] = useState<Record<string, PanelState>>({});
  const [settings, setSettings] = useState<{ default_duration: number; image_to_video_enabled: boolean; chatgpt_enabled: boolean } | null>(null);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [showCharacters, setShowCharacters] = useState(false);
  const [characters, setCharacters] = useState<ComicCharacterRef[]>([]);
  const [improving, setImproving] = useState(false);
  const [userInstruction, setUserInstruction] = useState('');
  const [timeline, setTimeline] = useState<Array<{ panelId: string; order: number; startTime: number; endTime: number; duration: number; hasVideo: boolean }>>([]);
  const [previewing, setPreviewing] = useState(false);
  const [previewIdx, setPreviewIdx] = useState(0);
  const previewTimerRef = useRef<number | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Load settings
  useEffect(() => {
    fetchProviderSettings().then(s => {
      if (s) {
        setSettings({
          default_duration: s.default_duration,
          image_to_video_enabled: s.image_to_video_enabled,
          chatgpt_enabled: s.chatgpt_enabled,
        });
      }
    });
  }, []);

  // Load existing animation states for all panels
  const loadPanelStates = useCallback(async () => {
    const states: Record<string, PanelState> = {};
    for (const panel of panels) {
      const anim = await fetchPanelAnimation(panel.id);
      states[panel.id] = {
        status: anim?.status === 'completed' ? 'completed' : 'idle',
        animationId: anim?.id || null,
        videoUrl: anim?.video_url || panel.video_url || null,
        analysis: anim?.chatgpt_analysis as ChatGPTAnalysis || null,
        duration: anim?.duration || settings?.default_duration || 4,
        cameraMotion: (anim?.camera_motion as CameraMotion) || 'static',
        prompt: anim?.animation_prompt || '',
        error: anim?.error_message || null,
      };
    }
    setPanelStates(states);
  }, [panels, settings?.default_duration]);

  useEffect(() => {
    if (settings) loadPanelStates();
  }, [settings, loadPanelStates]);

  // Load character refs
  useEffect(() => {
    if (contentId) {
      fetchCharacterRefs(contentId).then(setCharacters);
    }
  }, [contentId]);

  // Rebuild timeline when panel states change
  useEffect(() => {
    const durations = panels.map(p => panelStates[p.id]?.duration || settings?.default_duration || 4);
    let currentTime = 0;
    const tl = panels.map((panel, i) => {
      const dur = durations[i];
      const entry = {
        panelId: panel.id,
        order: panel.panel_order,
        startTime: currentTime,
        endTime: currentTime + dur,
        duration: dur,
        hasVideo: !!panelStates[panel.id]?.videoUrl,
      };
      currentTime = entry.endTime;
      return entry;
    });
    setTimeline(tl);
  }, [panels, panelStates, settings?.default_duration]);

  const selectedPanel = panels[selectedPanelIdx];
  const selectedState = selectedPanel ? panelStates[selectedPanel.id] : null;

  const updatePanelState = (panelId: string, updates: Partial<PanelState>) => {
    setPanelStates(prev => ({
      ...prev,
      [panelId]: { ...prev[panelId], status: 'idle', animationId: null, videoUrl: null, analysis: null, duration: 4, cameraMotion: 'static', prompt: '', error: null, ...updates },
    }));
  };

  // === ChatGPT Analysis ===
  const handleAnalyze = async () => {
    if (!selectedPanel) return;
    updatePanelState(selectedPanel.id, { status: 'analyzing', error: null });
    const { analysis, error } = await analyzePanelWithChatGPT(selectedPanel.image_url, userInstruction || undefined);
    if (error) {
      updatePanelState(selectedPanel.id, { status: 'failed', error });
    } else {
      updatePanelState(selectedPanel.id, { status: 'idle', analysis, cameraMotion: (analysis.camera as CameraMotion) || 'static', duration: analysis.duration || 4 });
      setShowAnalysis(true);
    }
  };

  // === Image-to-Video Generation ===
  const handleGenerate = async () => {
    if (!selectedPanel) return;
    updatePanelState(selectedPanel.id, { status: 'generating', error: null });
    const state = panelStates[selectedPanel.id];
    const { success, videoUrl, error } = await generatePanelVideo(
      selectedPanel.id,
      selectedPanel.image_url,
      {
        duration: state?.duration || 4,
        cameraMotion: state?.cameraMotion || 'static',
        animationPrompt: state?.prompt || '',
        analysis: state?.analysis || null,
      },
    );
    if (success && videoUrl) {
      updatePanelState(selectedPanel.id, { status: 'completed', videoUrl });
    } else {
      updatePanelState(selectedPanel.id, { status: 'failed', error });
    }
  };

  // === Improve Prompt with ChatGPT ===
  const handleImprovePrompt = async () => {
    if (!selectedPanel) return;
    setImproving(true);
    const state = panelStates[selectedPanel.id];
    const { prompt, camera, duration, motion, error } = await improveAnimationPrompt(
      selectedPanel.image_url,
      userInstruction || 'Make the scene feel alive with subtle motion',
      state?.analysis || null,
    );
    if (!error && prompt) {
      updatePanelState(selectedPanel.id, { prompt, cameraMotion: (camera as CameraMotion) || state?.cameraMotion || 'static', duration: duration || state?.duration || 4 });
    }
    setImproving(false);
  };

  // === Full chapter generation ===
  const handleGenerateAll = async () => {
    for (let i = 0; i < panels.length; i++) {
      const panel = panels[i];
      const state = panelStates[panel.id];
      if (state?.status === 'completed' && state.videoUrl) continue;
      setSelectedPanelIdx(i);
      updatePanelState(panel.id, { status: 'generating', error: null });
      const { success, videoUrl, error } = await generatePanelVideo(panel.id, panel.image_url, {
        duration: state?.duration || settings?.default_duration || 4,
        cameraMotion: state?.cameraMotion || 'static',
        animationPrompt: state?.prompt || '',
        analysis: state?.analysis || null,
      });
      if (success && videoUrl) {
        updatePanelState(panel.id, { status: 'completed', videoUrl });
      } else {
        updatePanelState(panel.id, { status: 'failed', error });
      }
    }
  };

  // === Preview system ===
  const handlePreviewFull = () => {
    setPreviewing(true);
    setPreviewIdx(0);
  };

  const handleStopPreview = () => {
    setPreviewing(false);
    if (previewTimerRef.current) {
      clearTimeout(previewTimerRef.current);
      previewTimerRef.current = null;
    }
  };

  // Auto-advance preview
  useEffect(() => {
    if (!previewing) return;
    const currentPanel = panels[previewIdx];
    const state = currentPanel ? panelStates[currentPanel.id] : null;
    const dur = (state?.duration || 4) * 1000;

    if (videoRef.current && state?.videoUrl) {
      videoRef.current.src = state.videoUrl;
      videoRef.current.play().catch(() => {});
    }

    previewTimerRef.current = window.setTimeout(() => {
      if (previewIdx < panels.length - 1) {
        setPreviewIdx(prev => prev + 1);
      } else {
        setPreviewing(false);
      }
    }, dur);

    return () => {
      if (previewTimerRef.current) clearTimeout(previewTimerRef.current);
    };
  }, [previewing, previewIdx, panels, panelStates]);

  const totalTime = timeline.length > 0 ? timeline[timeline.length - 1].endTime : 0;
  const completedCount = panels.filter(p => panelStates[p.id]?.status === 'completed').length;

  const [mobileView, setMobileView] = useState<'timeline' | 'editor' | 'panel'>('editor');

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2.5 border-b border-white/10 gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Film className="w-5 h-5 text-accent flex-shrink-0" />
          <span className="text-white font-bold text-sm sm:text-base truncate">ستودیۆی ئەنیمەیشنی کۆمیک</span>
          <span className="text-white/50 text-xs sm:text-sm flex-shrink-0">({completedCount}/{panels.length})</span>
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <button
            onClick={handlePreviewFull}
            disabled={completedCount === 0}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-2 rounded-lg bg-white/10 text-white text-xs sm:text-sm hover:bg-white/20 disabled:opacity-30"
          >
            <Play className="w-4 h-4" /> <span className="hidden sm:inline">پێشاندانی تەواو</span><span className="sm:hidden">پێشان</span>
          </button>
          <button
            onClick={handleGenerateAll}
            disabled={completedCount === panels.length || !settings?.image_to_video_enabled}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-2 rounded-lg bg-accent text-white text-xs sm:text-sm font-medium disabled:opacity-30"
          >
            <Sparkles className="w-4 h-4" /> <span className="hidden sm:inline">دروستکردنی هەموو</span><span className="sm:hidden">هەموو</span>
          </button>
          <button onClick={onClose} className="p-2 rounded-lg text-white/60 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {!settings?.image_to_video_enabled && (
        <div className="bg-accent/10 border-b border-accent/20 px-3 py-2 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-accent flex-shrink-0" />
          <span className="text-accent text-xs">Image-to-Video چالاک نەکراوە. لە پانێلی بەڕێوەبردن {'>'} AI چالاکی بکە.</span>
        </div>
      )}

      {/* Mobile view toggle */}
      <div className="lg:hidden flex gap-1 p-1 bg-white/5 border-b border-white/10">
        <button onClick={() => setMobileView('timeline')} className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${mobileView === 'timeline' ? 'bg-accent text-white' : 'text-white/60'}`}>
          کاتیشە
        </button>
        <button onClick={() => setMobileView('editor')} className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${mobileView === 'editor' ? 'bg-accent text-white' : 'text-white/60'}`}>
          دەستکاری
        </button>
        {(showAnalysis || showCharacters) && (
          <button onClick={() => setMobileView('panel')} className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${mobileView === 'panel' ? 'bg-accent text-white' : 'text-white/60'}`}>
            پانێل
          </button>
        )}
      </div>

      {/* Main content - desktop: 3 panels side by side, mobile: stacked with tabs */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Panel list / Timeline */}
        <div className={`w-full lg:w-72 flex-shrink-0 border-l border-white/10 overflow-y-auto ${mobileView === 'timeline' ? 'block' : 'hidden lg:block'}`} dir="ltr">
          <div className="p-3">
            <div className="flex items-center gap-2 mb-3">
              <Clock className="w-4 h-4 text-accent" />
              <span className="text-white/70 text-sm font-medium">کاتیشە</span>
              <span className="text-white/40 text-xs mr-auto">{totalTime.toFixed(1)}s</span>
            </div>

            {/* Horizontal scroll on mobile, vertical on desktop */}
            <div className="flex lg:flex-col gap-2 overflow-x-auto lg:overflow-x-visible scrollbar-hide pb-2 lg:pb-0">
              {timeline.map((entry, i) => {
                const panel = panels[i];
                const state = panelStates[entry.panelId];
                const isSelected = i === selectedPanelIdx;
                return (
                  <button
                    key={entry.panelId}
                    onClick={() => { setSelectedPanelIdx(i); setMobileView('editor'); }}
                    className={`flex items-center gap-2 p-2 rounded-lg transition-all flex-shrink-0 lg:w-full ${isSelected ? 'bg-accent/20 border border-accent/40' : 'hover:bg-white/5'}`}
                  >
                    <div className="w-12 h-16 rounded overflow-hidden flex-shrink-0 relative">
                      <img src={panel?.image_url} alt="" className="w-full h-full object-cover" />
                      {state?.videoUrl && (
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                          <Video className="w-4 h-4 text-green-400" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 text-left min-w-0">
                      <div className="text-white text-xs font-medium">پەنال {i + 1}</div>
                      <div className="text-white/40 text-xs">{entry.startTime.toFixed(1)}s - {entry.endTime.toFixed(1)}s</div>
                      <div className="flex items-center gap-1 mt-0.5">
                        {state?.status === 'generating' && <Loader2 className="w-3 h-3 text-accent animate-spin" />}
                        {state?.status === 'completed' && <CheckCircle2 className="w-3 h-3 text-green-400" />}
                        {state?.status === 'failed' && <AlertCircle className="w-3 h-3 text-red-400" />}
                        {state?.status === 'analyzing' && <Sparkles className="w-3 h-3 text-accent animate-pulse" />}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Center: Preview area */}
        <div className={`flex-1 flex flex-col items-center justify-center p-3 sm:p-4 overflow-y-auto ${mobileView === 'editor' ? 'block' : 'hidden lg:flex'}`}>
          {previewing ? (
            <PreviewPlayer
              panels={panels}
              panelStates={panelStates}
              currentIdx={previewIdx}
              videoRef={videoRef}
              onStop={handleStopPreview}
            />
          ) : selectedPanel ? (
            <div className="flex flex-col items-center max-w-full w-full">
              <div className="relative max-h-[35vh] sm:max-h-[50vh] rounded-xl overflow-hidden bg-black/50">
                {selectedState?.videoUrl ? (
                  <video
                    key={selectedState.videoUrl}
                    src={selectedState.videoUrl}
                    controls
                    loop
                    className="max-h-[35vh] sm:max-h-[50vh] max-w-full"
                  />
                ) : (
                  <img src={selectedPanel.image_url} alt="" className="max-h-[35vh] sm:max-h-[50vh] max-w-full" />
                )}
                {selectedState?.status === 'generating' && (
                  <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center">
                    <Loader2 className="w-8 h-8 sm:w-10 sm:h-10 text-accent animate-spin mb-2" />
                    <span className="text-white text-sm">دروستکردنی ڤیدیۆ...</span>
                  </div>
                )}
                {selectedState?.status === 'analyzing' && (
                  <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center">
                    <Sparkles className="w-8 h-8 sm:w-10 sm:h-10 text-accent mb-2 animate-pulse" />
                    <span className="text-white text-sm">شیکارکردنەوەی پەنال...</span>
                  </div>
                )}
              </div>

              {/* Controls below preview */}
              <div className="mt-3 sm:mt-4 w-full max-w-2xl space-y-3">
                {/* Error display */}
                {selectedState?.error && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                    <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                    <span className="text-red-400 text-xs">{selectedState.error}</span>
                  </div>
                )}

                {/* Action buttons */}
                <div className="flex flex-wrap gap-2">
                  {settings?.chatgpt_enabled && (
                    <button
                      onClick={handleAnalyze}
                      disabled={selectedState?.status === 'analyzing'}
                      className="flex items-center gap-1.5 px-3 py-2.5 rounded-lg bg-white/10 text-white text-sm hover:bg-white/20 disabled:opacity-50"
                    >
                      <Sparkles className="w-4 h-4" /> شیکارکردنەوەی ChatGPT
                    </button>
                  )}
                  <button
                    onClick={handleGenerate}
                    disabled={selectedState?.status === 'generating' || !settings?.image_to_video_enabled}
                    className="flex items-center gap-1.5 px-3 py-2.5 rounded-lg bg-accent text-white text-sm font-medium disabled:opacity-50"
                  >
                    {selectedState?.status === 'generating' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Video className="w-4 h-4" />}
                    {selectedState?.videoUrl ? 'دووبارە دروستکردن' : 'دروستکردنی ڤیدیۆ'}
                  </button>
                  <button
                    onClick={() => { setShowAnalysis(!showAnalysis); setShowCharacters(false); setMobileView('panel'); }}
                    className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-sm ${showAnalysis ? 'bg-white/20 text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}
                  >
                    <Layers className="w-4 h-4" /> شیکارکردنەوە
                  </button>
                  <button
                    onClick={() => { setShowCharacters(!showCharacters); setShowAnalysis(false); setMobileView('panel'); }}
                    className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-sm ${showCharacters ? 'bg-white/20 text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}
                  >
                    <User className="w-4 h-4" /> کەسایەتی
                  </button>
                </div>

                {/* Camera motion + Duration */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-white/50 text-xs mb-1 block flex items-center gap-1">
                      <Camera className="w-3 h-3" /> جوڵانی کامێرا
                    </label>
                    <select
                      value={selectedState?.cameraMotion || 'static'}
                      onChange={(e) => updatePanelState(selectedPanel.id, { cameraMotion: e.target.value as CameraMotion })}
                      className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-white text-sm outline-none focus:border-accent"
                    >
                      {CAMERA_MOTIONS.map(m => (
                        <option key={m.value} value={m.value} className="bg-gray-800">{m.labelEn}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-white/50 text-xs mb-1 block flex items-center gap-1">
                      <Clock className="w-3 h-3" /> ماوە (چرکە)
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={settings ? settings.default_duration : 10}
                      value={selectedState?.duration || 4}
                      onChange={(e) => updatePanelState(selectedPanel.id, { duration: parseInt(e.target.value) || 4 })}
                      className="w-full px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-white text-sm outline-none focus:border-accent"
                    />
                  </div>
                </div>

                {/* Prompt textarea */}
                <div>
                  <label className="text-white/50 text-xs mb-1 block">ڕێنمایی ئەنیمەیشن</label>
                  <textarea
                    value={selectedState?.prompt || ''}
                    onChange={(e) => updatePanelState(selectedPanel.id, { prompt: e.target.value })}
                    placeholder="وەسفی جوڵان بنووسە... (م: چاو لێدان، هەناسە، جوڵانی قژ)"
                    dir="rtl"
                    rows={2}
                    className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm outline-none focus:border-accent resize-none placeholder:text-white/30"
                  />
                </div>

                {/* AI Prompt Assistant */}
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={userInstruction}
                    onChange={(e) => setUserInstruction(e.target.value)}
                    placeholder="ڕێنمایی بۆ ChatGPT... (م: کچەکە سەیری کەسایەتی سوورەکە بکات)"
                    dir="rtl"
                    className="flex-1 px-3 py-2.5 rounded-lg bg-white/5 border border-white/10 text-white text-sm outline-none focus:border-accent placeholder:text-white/30 min-w-0"
                  />
                  <button
                    onClick={handleImprovePrompt}
                    disabled={improving || !settings?.chatgpt_enabled}
                    className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg bg-white/10 text-white text-sm hover:bg-white/20 disabled:opacity-50 whitespace-nowrap flex-shrink-0"
                  >
                    {improving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                    باشترکردن بە ChatGPT
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-white/40 text-sm">هیچ پەنالێک نییە</div>
          )}
        </div>

        {/* Right: Analysis / Characters panel */}
        {(showAnalysis || showCharacters) && selectedPanel && (
          <div className={`w-full lg:w-80 flex-shrink-0 border-r border-white/10 overflow-y-auto p-3 ${mobileView === 'panel' ? 'block' : 'hidden lg:block'}`} dir="rtl">
            {showCharacters ? (
              <CharacterPanel contentId={contentId} characters={characters} onReload={() => fetchCharacterRefs(contentId).then(setCharacters)} />
            ) : (
              <AnalysisPanel analysis={selectedState?.analysis || null} />
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// === Preview Player ===
function PreviewPlayer({
  panels, panelStates, currentIdx, videoRef, onStop,
}: {
  panels: ComicPanel[];
  panelStates: Record<string, PanelState>;
  currentIdx: number;
  videoRef: React.RefObject<HTMLVideoElement>;
  onStop: () => void;
}) {
  const panel = panels[currentIdx];
  const state = panel ? panelStates[panel.id] : null;

  return (
    <div className="flex flex-col items-center">
      <div className="relative rounded-xl overflow-hidden bg-black max-h-[60vh]">
        {state?.videoUrl ? (
          <video
            ref={videoRef}
            src={state.videoUrl}
            autoPlay
            className="max-h-[60vh] max-w-full"
          />
        ) : (
          <img src={panel?.image_url} alt="" className="max-h-[60vh] max-w-full" />
        )}
        <div className="absolute bottom-0 left-0 right-0 bg-black/60 px-4 py-2 flex items-center justify-between">
          <span className="text-white text-sm">پەنال {currentIdx + 1} / {panels.length}</span>
          <button onClick={onStop} className="flex items-center gap-1 text-white/80 text-sm hover:text-white">
            <X className="w-4 h-4" /> وەستان
          </button>
        </div>
      </div>
    </div>
  );
}

// === Analysis Panel ===
function AnalysisPanel({ analysis }: { analysis: ChatGPTAnalysis | null }) {
  if (!analysis) {
    return (
      <div className="text-center py-8">
        <Sparkles className="w-8 h-8 text-white/20 mx-auto mb-2" />
        <p className="text-white/40 text-sm">هێشتا شیکارکردنەوە نییە. کلیک لە "شیکارکردنەوەی ChatGPT" بکە</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
    <h4 className="text-white font-medium text-sm flex items-center gap-1.5">
      <Sparkles className="w-4 h-4 text-accent" /> شیکارکردنەوەی پەنال
    </h4>

    {analysis.scene && (
      <div>
        <span className="text-white/50 text-xs">دیمەن</span>
        <p className="text-white/80 text-xs mt-0.5">{analysis.scene}</p>
      </div>
    )}

    {analysis.characters && analysis.characters.length > 0 && (
      <div>
        <span className="text-white/50 text-xs">کەسایەتیەکان</span>
        <div className="space-y-1 mt-1">
          {analysis.characters.map((c, i) => (
            <div key={i} className="p-2 rounded-lg bg-white/5">
              <span className="text-white text-xs font-medium">{c.name}</span>
              {c.description && <p className="text-white/60 text-xs mt-0.5">{c.description}</p>}
              <div className="flex flex-wrap gap-1 mt-1">
                {c.clothing && <span className="text-xs px-1.5 py-0.5 rounded bg-white/5 text-white/50">{c.clothing}</span>}
                {c.hair && <span className="text-xs px-1.5 py-0.5 rounded bg-white/5 text-white/50">{c.hair}</span>}
                {c.eye_color && <span className="text-xs px-1.5 py-0.5 rounded bg-white/5 text-white/50">{c.eye_color}</span>}
              </div>
            </div>
          ))}
        </div>
      </div>
    )}

    {analysis.dialogue && analysis.dialogue.length > 0 && (
      <div>
        <span className="text-white/50 text-xs">دیالۆگ</span>
        <div className="space-y-1 mt-1">
          {analysis.dialogue.map((d, i) => (
            <div key={i} className="p-2 rounded-lg bg-white/5">
              <span className="text-accent text-xs">{d.character}: </span>
              <span className="text-white/80 text-xs" dir={d.language === 'ku' || d.language === 'ar' ? 'rtl' : 'ltr'}>{d.text}</span>
            </div>
          ))}
        </div>
      </div>
    )}

    {analysis.motion && analysis.motion.length > 0 && (
      <div>
        <span className="text-white/50 text-xs">جوڵانە پێشنیارکراوەکان</span>
        <ul className="space-y-0.5 mt-1">
          {analysis.motion.map((m, i) => (
            <li key={i} className="text-white/70 text-xs flex items-start gap-1">
              <span className="text-accent">•</span> {m}
            </li>
          ))}
        </ul>
      </div>
    )}

    {analysis.style && (
      <div>
        <span className="text-white/50 text-xs">شێوازی هونەری</span>
        <p className="text-white/80 text-xs mt-0.5">{analysis.style}</p>
      </div>
    )}
  </div>
  );
}

// === Character Panel ===
function CharacterPanel({ contentId, characters, onReload }: {
  contentId: string;
  characters: ComicCharacterRef[];
  onReload: () => void;
}) {
  const [adding, setAdding] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [newChar, setNewChar] = useState({
    name: '', description: '', clothing: '', hair: '', eye_color: '', dialogue_sample: '', reference_image_url: '',
  });

  const handleAdd = async () => {
    if (!newChar.name.trim()) return;
    const created = await createCharacterRef({
      content_id: contentId,
      character_id: null,
      name: newChar.name,
      description: newChar.description || null,
      clothing: newChar.clothing || null,
      hair: newChar.hair || null,
      eye_color: newChar.eye_color || null,
      reference_image_url: newChar.reference_image_url || null,
      dialogue_sample: newChar.dialogue_sample || null,
    });
    if (created) {
      setNewChar({ name: '', description: '', clothing: '', hair: '', eye_color: '', dialogue_sample: '', reference_image_url: '' });
      setAdding(false);
      onReload();
    }
  };

  const handleUploadImage = async (file: File) => {
    setUploading(true);
    const url = await uploadCharacterReference(contentId, file);
    if (url) {
      setNewChar(prev => ({ ...prev, reference_image_url: url }));
    }
    setUploading(false);
  };

  const handleDelete = async (id: string) => {
    await deleteCharacterRef(id);
    onReload();
  };

  const handleUpdate = async (id: string, updates: Partial<ComicCharacterRef>) => {
    await updateCharacterRef(id, updates);
    onReload();
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="text-white font-medium text-sm flex items-center gap-1.5">
          <User className="w-4 h-4 text-accent" /> کەسایەتیەکان
        </h4>
        <button onClick={() => setAdding(!adding)} className="flex items-center gap-1 px-2 py-1 rounded-lg bg-accent text-white text-xs">
          <Plus className="w-3 h-3" /> زیادکردن
        </button>
      </div>

      {adding && (
        <div className="p-3 rounded-lg bg-white/5 space-y-2 border border-white/10">
          {newChar.reference_image_url && (
            <img src={newChar.reference_image_url} alt="" className="w-full h-32 rounded-lg object-cover" />
          )}
          <label className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg bg-white/10 text-white text-xs cursor-pointer">
            {uploading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />}
            وێنەی سەرچاوە
            <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleUploadImage(e.target.files[0])} />
          </label>
          <input
            type="text" value={newChar.name} onChange={(e) => setNewChar(prev => ({ ...prev, name: e.target.value }))}
            placeholder="ناو" dir="rtl"
            className="w-full px-2 py-1.5 rounded bg-white/5 border border-white/10 text-white text-xs outline-none focus:border-accent placeholder:text-white/30"
          />
          <input
            type="text" value={newChar.description} onChange={(e) => setNewChar(prev => ({ ...prev, description: e.target.value }))}
            placeholder="وەسف" dir="rtl"
            className="w-full px-2 py-1.5 rounded bg-white/5 border border-white/10 text-white text-xs outline-none focus:border-accent placeholder:text-white/30"
          />
          <div className="grid grid-cols-2 gap-2">
            <input
              type="text" value={newChar.clothing} onChange={(e) => setNewChar(prev => ({ ...prev, clothing: e.target.value }))}
              placeholder="جلی" dir="rtl"
              className="px-2 py-1.5 rounded bg-white/5 border border-white/10 text-white text-xs outline-none focus:border-accent placeholder:text-white/30"
            />
            <input
              type="text" value={newChar.hair} onChange={(e) => setNewChar(prev => ({ ...prev, hair: e.target.value }))}
              placeholder="قژ" dir="rtl"
              className="px-2 py-1.5 rounded bg-white/5 border border-white/10 text-white text-xs outline-none focus:border-accent placeholder:text-white/30"
            />
          </div>
          <input
            type="text" value={newChar.eye_color} onChange={(e) => setNewChar(prev => ({ ...prev, eye_color: e.target.value }))}
            placeholder="ڕەنگی چاو" dir="rtl"
            className="w-full px-2 py-1.5 rounded bg-white/5 border border-white/10 text-white text-xs outline-none focus:border-accent placeholder:text-white/30"
          />
          <input
            type="text" value={newChar.dialogue_sample} onChange={(e) => setNewChar(prev => ({ ...prev, dialogue_sample: e.target.value }))}
            placeholder="نموونەی دیالۆگ" dir="rtl"
            className="w-full px-2 py-1.5 rounded bg-white/5 border border-white/10 text-white text-xs outline-none focus:border-accent placeholder:text-white/30"
          />
          <div className="flex gap-2">
            <button onClick={handleAdd} disabled={!newChar.name.trim()} className="flex-1 py-1.5 rounded-lg bg-accent text-white text-xs font-medium disabled:opacity-50">
              پاشکەوتی
            </button>
            <button onClick={() => setAdding(false)} className="px-3 py-1.5 rounded-lg bg-white/10 text-white text-xs">
              هەڵوەشاندن
            </button>
          </div>
        </div>
      )}

      {characters.length === 0 && !adding && (
        <p className="text-white/40 text-xs text-center py-4">هیچ کەسایەتیەک نییە</p>
      )}

      {characters.map((char) => (
        <div key={char.id} className="p-2 rounded-lg bg-white/5 space-y-2">
          <div className="flex items-start gap-2">
            {char.reference_image_url && (
              <img src={char.reference_image_url} alt="" className="w-12 h-12 rounded-lg object-cover flex-shrink-0" />
            )}
            <div className="flex-1 min-w-0">
              <input
                type="text" value={char.name} onChange={(e) => handleUpdate(char.id, { name: e.target.value })}
                dir="rtl"
                className="w-full bg-transparent text-white text-xs font-medium outline-none"
              />
              {char.description && <p className="text-white/50 text-xs mt-0.5">{char.description}</p>}
            </div>
            <button onClick={() => handleDelete(char.id)} className="p-1 rounded text-white/40 hover:text-red-400">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="flex flex-wrap gap-1">
            {char.clothing && <span className="text-xs px-1.5 py-0.5 rounded bg-white/5 text-white/50">جلی: {char.clothing}</span>}
            {char.hair && <span className="text-xs px-1.5 py-0.5 rounded bg-white/5 text-white/50">قژ: {char.hair}</span>}
            {char.eye_color && <span className="text-xs px-1.5 py-0.5 rounded bg-white/5 text-white/50">چاو: {char.eye_color}</span>}
          </div>
          {char.dialogue_sample && (
            <p className="text-white/60 text-xs italic border-r-2 border-accent/40 pr-2" dir="rtl">"{char.dialogue_sample}"</p>
          )}
        </div>
      ))}
    </div>
  );
}
