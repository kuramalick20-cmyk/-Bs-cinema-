import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { Capacitor } from '@capacitor/core';
import { Browser } from '@capacitor/browser';
import { App } from '@capacitor/app';
import { supabase, type Profile } from '@/lib/supabase';
import { getGoogleIdToken, isGoogleOAuthRedirect } from '@/lib/googleAuth';
import { isNativeApp } from '@/lib/platform';

interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signUp: (email: string, password: string, username: string) => Promise<{ error: string | null }>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signInWithGoogle: () => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<Profile>) => Promise<{ error: string | null }>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  // Ensure a profile row exists for a user (Google OAuth users won't have one yet)
  const ensureProfile = async (authUser: User): Promise<Profile | null> => {
    const { data: existing } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', authUser.id)
      .maybeSingle();

    if (existing) return existing as Profile;

    // Create a profile for this Google user
    // Extract username from Google metadata, fall back to email prefix
    const meta = authUser.user_metadata || {};
    const googleEmail = meta.email || authUser.email || '';
    const googleName = meta.full_name || meta.name || '';
    const googleAvatar = meta.avatar_url || meta.picture || null;
    const username = googleName || (googleEmail ? googleEmail.split('@')[0] : 'user');

    const trialStart = new Date();
    const trialEnd = new Date(trialStart.getTime() + 3 * 24 * 60 * 60 * 1000);

    const newProfile = {
      id: authUser.id,
      username,
      avatar_url: googleAvatar,
      phone: null, // Phone is a separate field — never copied from Google
      vip_status: 'trial' as const,
      trial_start_date: trialStart.toISOString(),
      trial_end_date: trialEnd.toISOString(),
      trial_used: true,
      is_admin: false,
    };

    const { data: created, error } = await supabase
      .from('profiles')
      .insert(newProfile)
      .select('*')
      .maybeSingle();

    if (error) {
      // If insert failed (e.g. race condition), try to fetch again
      const { data: retry } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authUser.id)
        .maybeSingle();
      return retry as Profile | null;
    }

    return created as Profile;
  };

  // Check and expire VIP/trial status
  const checkVipExpiry = (profileData: Profile): { profile: Profile; needsUpdate: boolean; updates: Partial<Profile> } => {
    const now = new Date();
    let needsUpdate = false;
    const updates: Partial<Profile> = {};
    if (profileData.vip_status === 'trial' && profileData.trial_end_date && new Date(profileData.trial_end_date) < now) {
      updates.vip_status = 'free';
      needsUpdate = true;
    }
    if (profileData.vip_status === 'vip' && profileData.vip_end_date && new Date(profileData.vip_end_date) < now) {
      updates.vip_status = 'free';
      needsUpdate = true;
    }
    return { profile: needsUpdate ? { ...profileData, ...updates } : profileData, needsUpdate, updates };
  };

  const loadProfile = async (authUser: User) => {
    let profileData = await ensureProfile(authUser);
    if (!profileData) {
      setProfile(null);
      return;
    }

    const { profile: updatedProfile, needsUpdate, updates } = checkVipExpiry(profileData);
    if (needsUpdate) {
      await supabase.from('profiles').update(updates).eq('id', authUser.id);
    }
    setProfile(updatedProfile);
  };

  useEffect(() => {
    // Handle Google OAuth redirect callback
    if (isGoogleOAuthRedirect()) {
      setLoading(true);
    }

    let mounted = true;

    // Restore existing session synchronously from localStorage to prevent
    // the "logged out" flash on page refresh / app restart.
    try {
      const stored = localStorage.getItem('sb-' + (import.meta.env.VITE_SUPABASE_URL?.replace(/[^a-z0-9]/gi, '') || '') + '-auth-token');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed?.currentSession?.user) {
          setSession(parsed.currentSession);
          setUser(parsed.currentSession.user);
        }
      }
    } catch {
      // localStorage parse failure — getSession will handle it
    }

    // Get the authoritative session from Supabase
    supabase.auth.getSession().then(async ({ data }) => {
      if (!mounted) return;
      setSession(data.session);
      setUser(data.session?.user ?? null);
      if (data.session?.user) {
        await loadProfile(data.session.user);
      } else {
        // No valid session — clear any stale localStorage data
        setProfile(null);
      }
      if (mounted) setLoading(false);
    }).catch(() => {
      if (mounted) setLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((event, newSession) => {
      (async () => {
        if (!mounted) return;
        // Skip the INITIAL_SESSION event — getSession already handles it
        if (event === 'INITIAL_SESSION') return;

        setSession(newSession);
        setUser(newSession?.user ?? null);
        if (newSession?.user) {
          await loadProfile(newSession.user);
        } else {
          setProfile(null);
        }
        if (mounted) setLoading(false);
      })();
    });

    // Native deep link handler — captures OAuth callback URL from system browser
    let appUrlListener: { remove: () => void } | undefined;
    if (isNativeApp()) {
      App.addListener('appUrlOpen', async ({ url }: { url: string }) => {
        if (!mounted) return;
        // Supabase implicit flow returns tokens in the URL fragment
        // Construct a URL that supabase can parse
        const parsedUrl = new URL(url);
        const hashParams = new URLSearchParams(parsedUrl.hash.substring(1));
        const accessToken = hashParams.get('access_token');
        const refreshToken = hashParams.get('refresh_token');
        const expiresIn = hashParams.get('expires_in');

        if (accessToken) {
          const { data, error } = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken || '',
          });
          if (!error && data.session?.user) {
            setSession(data.session);
            setUser(data.session.user);
            await loadProfile(data.session.user);
          }
          if (mounted) setLoading(false);
        }
      }).then((listener) => { appUrlListener = listener; });
    }

    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
      appUrlListener?.remove();
    };
  }, []);

  const signUp = async (email: string, password: string, username: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { username } },
    });
    if (error) return { error: error.message };
    if (data.user) {
      const trialStart = new Date();
      const trialEnd = new Date(trialStart.getTime() + 3 * 24 * 60 * 60 * 1000);
      await supabase.from('profiles').upsert({
        id: data.user.id,
        username,
        phone: null,
        vip_status: 'trial',
        trial_start_date: trialStart.toISOString(),
        trial_end_date: trialEnd.toISOString(),
        trial_used: true,
        is_admin: false,
      }, { onConflict: 'id' });

      // If the session was created immediately (no email confirmation), load profile
      if (data.session?.user) {
        await loadProfile(data.user);
      }
    }
    return { error: null };
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  };

  const signInWithGoogle = async () => {
    try {
      // On native Android, GIS won't work in WebView — use OAuth redirect via system browser
      if (isNativeApp()) {
        const redirectTo = Capacitor.getPlatform() === 'android'
          ? 'com.bsstudio.bscinema://auth/callback'
          : window.location.origin;

        const { data, error } = await supabase.auth.signInWithOAuth({
          provider: 'google',
          options: {
            redirectTo,
            skipBrowserRedirect: true,
          },
        });

        if (error) {
          return { error: error.message };
        }

        if (data?.url) {
          // Open the OAuth URL in the system browser (not WebView)
          await Browser.open({ url: data.url });
        }
        return { error: null };
      }

      // Web flow — try GIS ID-token first, fall back to OAuth redirect
      const result = await getGoogleIdToken();
      if ('error' in result) {
        const { error } = await supabase.auth.signInWithOAuth({
          provider: 'google',
          options: {
            redirectTo: window.location.origin,
          },
        });
        if (error) {
          return { error: error.message };
        }
        return { error: null };
      }

      const { data, error } = await supabase.auth.signInWithIdToken({
        provider: 'google',
        token: result.idToken,
      });
      if (error) {
        const { error: redirectError } = await supabase.auth.signInWithOAuth({
          provider: 'google',
          options: {
            redirectTo: window.location.origin,
          },
        });
        if (redirectError) {
          return { error: redirectError.message };
        }
        return { error: null };
      }
      if (data.user) {
        await loadProfile(data.user);
      }
      return { error: null };
    } catch (err: any) {
      // Last-resort fallback: OAuth redirect
      if (isNativeApp()) {
        return { error: 'هەڵە لە کاتی چوونەژوورەوەی Google. تکایە دووبارە هەوڵ بدە.' };
      }
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin,
        },
      });
      if (error) {
        return { error: error.message || 'هەڵە لە کاتی چوونەژوورەوەی Google' };
      }
      return { error: null };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setUser(null);
    setProfile(null);
  };

  const updateProfile = async (updates: Partial<Profile>) => {
    if (!user) return { error: 'Not authenticated' };
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', user.id)
      .select()
      .maybeSingle();
    if (error) return { error: error.message };
    if (data) setProfile(data as Profile);
    return { error: null };
  };

  const refreshProfile = async () => {
    if (!user) return;
    const { data: prof } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();
    setProfile(prof as Profile | null);
  };

  return (
    <AuthContext.Provider
      value={{ session, user, profile, loading, signUp, signIn, signInWithGoogle, signOut, updateProfile, refreshProfile }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
