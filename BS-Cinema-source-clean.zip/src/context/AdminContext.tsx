import { createContext, useContext, useState, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';

interface AdminContextType {
  isAdmin: boolean;
  adminUnlock: (password: string) => Promise<{ error: string | null }>;
  adminLock: () => void;
  adminLoading: boolean;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

const ADMIN_PASSWORD = 'ares2324';
const ADMIN_EMAIL = 'kuramalick20@gmail.com';

export function AdminProvider({ children }: { children: ReactNode }) {
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminLoading, setAdminLoading] = useState(false);

  const adminUnlock = async (password: string) => {
    setAdminLoading(true);
    try {
      if (password !== ADMIN_PASSWORD) {
        return { error: 'وشەی نهێنی هەڵەیە' };
      }

      const { data: existingSession } = await supabase.auth.getSession();
      if (existingSession.session?.user) {
        const { data: prof } = await supabase
          .from('profiles')
          .select('is_admin')
          .eq('id', existingSession.session.user.id)
          .maybeSingle();
        if (prof?.is_admin) {
          setIsAdmin(true);
          return { error: null };
        }
        await supabase.auth.signOut();
      }

      const { data, error } = await supabase.auth.signInWithPassword({
        email: ADMIN_EMAIL,
        password: ADMIN_PASSWORD,
      });
      if (error) {
        return { error: 'هەڵە لە چوونەژوورەوە: ' + error.message };
      }
      if (!data.user) {
        return { error: 'هەژمار نەدۆزرایەوە' };
      }

      const { data: profile } = await supabase
        .from('profiles')
        .select('is_admin')
        .eq('id', data.user.id)
        .maybeSingle();

      if (!profile?.is_admin) {
        await supabase.auth.signOut();
        return { error: 'ئەم بەکارهێنەرە ئەدمین نییە' };
      }

      setIsAdmin(true);
      return { error: null };
    } catch {
      return { error: 'هەڵەیەک ڕوویدا لە کاتی چوونەژوورەوە' };
    } finally {
      setAdminLoading(false);
    }
  };

  const adminLock = () => setIsAdmin(false);

  return (
    <AdminContext.Provider value={{ isAdmin, adminUnlock, adminLock, adminLoading }}>
      {children}
    </AdminContext.Provider>
  );
}

export function useAdmin() {
  const ctx = useContext(AdminContext);
  if (!ctx) throw new Error('useAdmin must be used within AdminProvider');
  return ctx;
}

export { ADMIN_PASSWORD };
