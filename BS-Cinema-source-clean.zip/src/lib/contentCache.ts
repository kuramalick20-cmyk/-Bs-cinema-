import type { ContentItem, ContentCategory, Episode, ComicChapter, ComicPanel } from './supabase';
import { supabase } from './supabase';

// Content list projection — only columns needed for cards
// Note: view_count and star_count are NOT columns on the content table;
// they are fetched via RPC functions (get_view_count, get_star_count).
const CONTENT_LIST_COLUMNS = 'id,title,description,category,cover_image_url,tags,dubbing_group,author_name,chapter_notice,is_vip,created_at';

interface CacheEntry<T> {
  data: T;
  timestamp: number;
}

const TTL = 60_000; // 60 seconds

const listCache = new Map<string, CacheEntry<ContentItem[]>>();
const episodesCache = new Map<string, CacheEntry<Episode[]>>();
const chaptersCache = new Map<string, CacheEntry<ComicChapter[]>>();
const panelsCache = new Map<string, CacheEntry<ComicPanel[]>>();

function isFresh<T>(entry: CacheEntry<T> | undefined): entry is CacheEntry<T> {
  return !!entry && Date.now() - entry.timestamp < TTL;
}

export function invalidateContentCache(contentId?: string) {
  if (contentId) {
    episodesCache.delete(contentId);
    chaptersCache.delete(contentId);
    panelsCache.delete(contentId);
  }
  listCache.clear();
}

export async function fetchContentList(category: ContentCategory | 'all', searchQuery: string): Promise<ContentItem[]> {
  const cacheKey = `${category}:${searchQuery.trim()}`;
  const cached = listCache.get(cacheKey);
  if (isFresh(cached)) return cached.data;

  let query = supabase.from('content').select(CONTENT_LIST_COLUMNS).order('created_at', { ascending: false });
  if (category !== 'all') query = query.eq('category', category);
  if (searchQuery.trim()) query = query.ilike('title', `%${searchQuery.trim()}%`);
  const { data, error } = await query;
  if (error) throw new Error(error.message);

  const items = (data as ContentItem[]) || [];
  listCache.set(cacheKey, { data: items, timestamp: Date.now() });
  return items;
}

export async function fetchEpisodes(contentId: string): Promise<Episode[]> {
  const cached = episodesCache.get(contentId);
  if (isFresh(cached)) return cached.data;

  const { data, error } = await supabase
    .from('episodes')
    .select('*')
    .eq('content_id', contentId)
    .order('episode_number', { ascending: true });
  if (error) throw new Error(error.message);

  const episodes = (data as Episode[]) || [];
  episodesCache.set(contentId, { data: episodes, timestamp: Date.now() });
  return episodes;
}

export async function fetchChapters(contentId: string): Promise<ComicChapter[]> {
  const cached = chaptersCache.get(contentId);
  if (isFresh(cached)) return cached.data;

  const { data, error } = await supabase
    .from('comic_chapters')
    .select('*')
    .eq('content_id', contentId)
    .order('chapter_number', { ascending: true });
  if (error) throw new Error(error.message);

  const chapters = (data as ComicChapter[]) || [];
  chaptersCache.set(contentId, { data: chapters, timestamp: Date.now() });
  return chapters;
}

export async function fetchPanels(chapterId: string): Promise<ComicPanel[]> {
  const cached = panelsCache.get(chapterId);
  if (isFresh(cached)) return cached.data;

  const { data, error } = await supabase
    .from('comic_panels')
    .select('*')
    .eq('chapter_id', chapterId)
    .order('panel_order', { ascending: true });
  if (error) throw new Error(error.message);

  const panels = (data as ComicPanel[]) || [];
  panelsCache.set(chapterId, { data: panels, timestamp: Date.now() });
  return panels;
}
