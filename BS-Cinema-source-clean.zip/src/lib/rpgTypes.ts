// Kirkuk RPG — Types and World Data

export type TileType = 'grass' | 'road' | 'wall' | 'floor' | 'water' | 'sand' | 'door' | 'market' | 'citadel_floor';

export interface TileMap {
  width: number;
  height: number;
  tiles: TileType[][];  // [y][x]
}

export type Direction = 'up' | 'down' | 'left' | 'right';

export interface Vec2 {
  x: number;
  y: number;
}

export type EntityType = 'player' | 'npc' | 'guard' | 'shopkeeper' | 'enemy';
export type NPCState = 'idle' | 'wander' | 'flee' | 'chase' | 'attack' | 'dead';

export interface Entity {
  id: string;
  type: EntityType;
  name: string;
  pos: Vec2;          // pixel position
  dir: Direction;
  hp: number;
  maxHp: number;
  speed: number;
  state: NPCState;
  // AI fields
  homePos?: Vec2;
  wanderTarget?: Vec2 | null;
  wanderTimer?: number;
  // Combat
  attackCooldown: number;
  lastAttackTime: number;
  // Guard specific
  visionRange?: number;
  patrolPath?: Vec2[];
  patrolIndex?: number;
  isHostile?: boolean;
  // NPC specific
  dialogue?: string;
  shopInventory?: ShopItem[];
  // Money/items
  money: number;
  inventory: InventoryItem[];
  // Visual
  color: string;
  size: number;
}

export interface ShopItem {
  id: string;
  name: string;
  price: number;
  type: 'weapon' | 'health' | 'misc';
  value: number; // damage for weapons, heal for health
  icon: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  type: 'weapon' | 'health' | 'misc' | 'money';
  quantity: number;
  value: number;
  icon: string;
}

export interface GameState {
  player: Entity;
  entities: Entity[];
  map: TileMap;
  money: number;
  wantedLevel: number;    // 0-5 stars
  wantedTimer: number;    // seconds remaining of wanted status
  camera: Vec2;
  messages: GameMessage[];
  kills: number;
  itemsStolen: number;
  gameOver: boolean;
  gameWon: boolean;
  paused: boolean;
  inShop: Entity | null;
  dialogueNpc: Entity | null;
}

export interface GameMessage {
  id: string;
  text: string;
  time: number;
  color: string;
}

// Kirkuk city map — 60x40 tile grid
// Tile size = 40px
export const TILE_SIZE = 40;
export const MAP_WIDTH = 60;
export const MAP_HEIGHT = 40;

// Generate the Kirkuk city map
export function generateKirkukMap(): TileMap {
  const tiles: TileType[][] = [];
  for (let y = 0; y < MAP_HEIGHT; y++) {
    const row: TileType[] = [];
    for (let x = 0; x < MAP_WIDTH; x++) {
      // Default to grass (open ground)
      row.push('grass');
    }
    tiles.push(row);
  }

  // Main roads — horizontal and vertical
  // Horizontal road at y=10
  for (let x = 0; x < MAP_WIDTH; x++) tiles[10][x] = 'road';
  // Horizontal road at y=20
  for (let x = 0; x < MAP_WIDTH; x++) tiles[20][x] = 'road';
  // Horizontal road at y=30
  for (let x = 0; x < MAP_WIDTH; x++) tiles[30][x] = 'road';
  // Vertical road at x=15
  for (let y = 0; y < MAP_HEIGHT; y++) tiles[y][15] = 'road';
  // Vertical road at x=30
  for (let y = 0; y < MAP_HEIGHT; y++) tiles[y][30] = 'road';
  // Vertical road at x=45
  for (let y = 0; y < MAP_HEIGHT; y++) tiles[y][45] = 'road';

  // Kirkuk Citadel — top-right area, large walled structure
  // Citadel walls
  for (let x = 48; x < 58; x++) {
    tiles[2][x] = 'wall';
    tiles[9][x] = 'wall';
  }
  for (let y = 2; y < 10; y++) {
    tiles[y][48] = 'wall';
    tiles[y][57] = 'wall';
  }
  // Citadel interior
  for (let y = 3; y < 9; y++) {
    for (let x = 49; x < 57; x++) {
      tiles[y][x] = 'citadel_floor';
    }
  }
  // Citadel door
  tiles[9][52] = 'door';
  tiles[9][53] = 'door';

  // Houses — clusters of wall/floor blocks
  const houses: { x: number; y: number; w: number; h: number }[] = [
    // District 1 — top-left
    { x: 2, y: 2, w: 4, h: 3 },
    { x: 8, y: 3, w: 3, h: 2 },
    { x: 2, y: 6, w: 5, h: 3 },
    // District 2 — between roads
    { x: 17, y: 2, w: 4, h: 3 },
    { x: 23, y: 3, w: 3, h: 3 },
    { x: 17, y: 7, w: 5, h: 2 },
    { x: 24, y: 8, w: 4, h: 2 },
    // District 3 — mid area
    { x: 2, y: 12, w: 4, h: 3 },
    { x: 8, y: 13, w: 3, h: 3 },
    { x: 2, y: 16, w: 5, h: 3 },
    { x: 9, y: 17, w: 4, h: 2 },
    // District 4 — central
    { x: 17, y: 12, w: 4, h: 3 },
    { x: 23, y: 13, w: 5, h: 3 },
    { x: 17, y: 17, w: 3, h: 2 },
    { x: 22, y: 17, w: 5, h: 2 },
    // District 5 — right of central road
    { x: 32, y: 2, w: 4, h: 3 },
    { x: 38, y: 3, w: 4, h: 3 },
    { x: 32, y: 7, w: 5, h: 2 },
    { x: 39, y: 8, w: 3, h: 2 },
    // District 6 — lower mid
    { x: 2, y: 22, w: 4, h: 3 },
    { x: 8, y: 23, w: 3, h: 3 },
    { x: 2, y: 26, w: 5, h: 3 },
    { x: 9, y: 27, w: 4, h: 2 },
    // District 7 — lower central
    { x: 17, y: 22, w: 4, h: 3 },
    { x: 23, y: 23, w: 5, h: 3 },
    { x: 17, y: 27, w: 3, h: 2 },
    { x: 22, y: 27, w: 5, h: 2 },
    // District 8 — lower right
    { x: 32, y: 22, w: 4, h: 3 },
    { x: 38, y: 23, w: 4, h: 3 },
    { x: 32, y: 27, w: 5, h: 2 },
    { x: 39, y: 27, w: 3, h: 2 },
    // District 9 — bottom
    { x: 2, y: 32, w: 4, h: 3 },
    { x: 8, y: 33, w: 5, h: 3 },
    { x: 2, y: 36, w: 4, h: 3 },
    { x: 9, y: 37, w: 4, h: 2 },
    // District 10 — bottom mid
    { x: 17, y: 32, w: 4, h: 3 },
    { x: 23, y: 33, w: 5, h: 3 },
    { x: 17, y: 37, w: 4, h: 2 },
    { x: 23, y: 37, w: 5, h: 2 },
    // District 11 — bottom right
    { x: 32, y: 32, w: 4, h: 3 },
    { x: 38, y: 33, w: 4, h: 3 },
    { x: 32, y: 37, w: 5, h: 2 },
    { x: 39, y: 37, w: 3, h: 2 },
  ];

  for (const house of houses) {
    for (let y = house.y; y < house.y + house.h; y++) {
      for (let x = house.x; x < house.x + house.w; x++) {
        if (y >= 0 && y < MAP_HEIGHT && x >= 0 && x < MAP_WIDTH) {
          // Walls on perimeter, floor inside
          const isPerimeter = y === house.y || y === house.y + house.h - 1 || x === house.x || x === house.x + house.w - 1;
          tiles[y][x] = isPerimeter ? 'wall' : 'floor';
        }
      }
    }
    // Add a door
    const doorX = house.x + Math.floor(house.w / 2);
    const doorY = house.y + house.h - 1;
    if (doorY < MAP_HEIGHT && doorX < MAP_WIDTH) {
      tiles[doorY][doorX] = 'door';
    }
  }

  // Market area — bottom-left near a road intersection
  for (let y = 22; y < 26; y++) {
    for (let x = 32; x < 36; x++) {
      if (tiles[y][x] === 'grass') tiles[y][x] = 'market';
    }
  }

  // Sand patches — Kurdistan terrain
  for (let y = 35; y < 39; y++) {
    for (let x = 45; x < 50; x++) {
      if (tiles[y][x] === 'grass') tiles[y][x] = 'sand';
    }
  }

  return { width: MAP_WIDTH, height: MAP_HEIGHT, tiles };
}

// Tile properties
export const TILE_PROPS: Record<TileType, { solid: boolean; color: string }> = {
  grass: { solid: false, color: '#2d4a2d' },
  road: { solid: false, color: '#3a3a3a' },
  wall: { solid: true, color: '#5a4a3a' },
  floor: { solid: false, color: '#6b5b4a' },
  water: { solid: true, color: '#1a3a5a' },
  sand: { solid: false, color: '#c4a86a' },
  door: { solid: false, color: '#8b6b3a' },
  market: { solid: false, color: '#8a6a3a' },
  citadel_floor: { solid: false, color: '#7a6a5a' },
};

// Shop items available in the market
export const SHOP_ITEMS: ShopItem[] = [
  { id: 'sword_basic', name: 'شمشێری سادە', price: 50, type: 'weapon', value: 20, icon: '⚔' },
  { id: 'sword_steel', name: 'شمشێری پۆڵا', price: 150, type: 'weapon', value: 40, icon: '⚔' },
  { id: 'potion_hp', name: 'دەرمانی تەندروستی', price: 30, type: 'health', value: 50, icon: '🧪' },
  { id: 'potion_hp_big', name: 'دەرمانی گەورە', price: 80, type: 'health', value: 100, icon: '🧪' },
  { id: 'shield', name: 'قەڵغەن', price: 100, type: 'misc', value: 25, icon: '🛡' },
];

export function isSolidTile(map: TileMap, tx: number, ty: number): boolean {
  if (tx < 0 || tx >= map.width || ty < 0 || ty >= map.height) return true;
  return TILE_PROPS[map.tiles[ty][tx]].solid;
}

export function isSolidPixel(map: TileMap, px: number, py: number, radius: number): boolean {
  // Check 4 corners of the entity's collision box
  const corners = [
    { x: px - radius, y: py - radius },
    { x: px + radius, y: py - radius },
    { x: px - radius, y: py + radius },
    { x: px + radius, y: py + radius },
  ];
  for (const c of corners) {
    const tx = Math.floor(c.x / TILE_SIZE);
    const ty = Math.floor(c.y / TILE_SIZE);
    if (isSolidTile(map, tx, ty)) return true;
  }
  return false;
}
