// Complete Dominoes Game Engine

export interface DominoTile {
  id: string;
  left: number;
  right: number;
}

export type Placement = 'left' | 'right';

export interface BoardTile {
  tile: DominoTile;
  leftPip: number;  // the open-left pip value after placement
  rightPip: number; // the open-right pip value after placement
}

export interface DominoGameState {
  board: BoardTile[];      // tiles on the board in order
  boneyard: DominoTile[];  // remaining drawable tiles
  player1Hand: DominoTile[];
  player2Hand: DominoTile[];
  currentTurn: 'player1' | 'player2';
  leftEnd: number | null;  // open pip on left side
  rightEnd: number | null; // open pip on right side
  passes: number;          // consecutive passes (2 = game over)
  status: 'playing' | 'completed';
  winner: 'player1' | 'player2' | 'draw' | null;
  winReason: 'empty_hand' | 'blocked' | null;
  player1Score: number;
  player2Score: number;
}

// Generate the full double-six tile set (28 tiles)
export function generateTileSet(): DominoTile[] {
  const tiles: DominoTile[] = [];
  for (let i = 0; i <= 6; i++) {
    for (let j = i; j <= 6; j++) {
      tiles.push({ id: `${i}-${j}`, left: i, right: j });
    }
  }
  return tiles;
}

function shuffle<T>(arr: T[]): T[] {
  const result = [...arr];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

export function newGameState(): DominoGameState {
  const allTiles = shuffle(generateTileSet());
  const player1Hand = allTiles.slice(0, 7);
  const player2Hand = allTiles.slice(7, 14);
  const boneyard = allTiles.slice(14);

  return {
    board: [],
    boneyard,
    player1Hand,
    player2Hand,
    currentTurn: 'player1',
    leftEnd: null,
    rightEnd: null,
    passes: 0,
    status: 'playing',
    winner: null,
    winReason: null,
    player1Score: 0,
    player2Score: 0,
  };
}

// Check if a tile can be placed on the board
export function canPlaceTile(state: DominoGameState, tile: DominoTile): { canPlace: boolean; placement?: Placement; flipped?: boolean }[] {
  const results: { canPlace: boolean; placement: Placement; flipped: boolean }[] = [];

  if (state.board.length === 0) {
    // First tile — any tile can be played
    results.push({ canPlace: true, placement: 'left', flipped: false });
    return results;
  }

  // Check left end
  if (state.leftEnd !== null) {
    if (tile.left === state.leftEnd) {
      results.push({ canPlace: true, placement: 'left', flipped: false });
    } else if (tile.right === state.leftEnd) {
      results.push({ canPlace: true, placement: 'left', flipped: true });
    }
  }

  // Check right end
  if (state.rightEnd !== null) {
    if (tile.right === state.rightEnd) {
      results.push({ canPlace: true, placement: 'right', flipped: false });
    } else if (tile.left === state.rightEnd) {
      results.push({ canPlace: true, placement: 'right', flipped: true });
    }
  }

  return results;
}

export function hasAnyLegalMove(hand: DominoTile[], state: DominoGameState): boolean {
  return hand.some((tile) => canPlaceTile(state, tile).length > 0);
}

// Place a tile on the board
export function placeTile(
  state: DominoGameState,
  tile: DominoTile,
  placement: Placement,
  flipped: boolean,
  player: 'player1' | 'player2',
): DominoGameState {
  const newState: DominoGameState = {
    ...state,
    board: [...state.board],
    boneyard: [...state.boneyard],
    player1Hand: [...state.player1Hand],
    player2Hand: [...state.player2Hand],
  };

  // Remove tile from player's hand
  const hand = player === 'player1' ? newState.player1Hand : newState.player2Hand;
  const handIdx = hand.findIndex((t) => t.id === tile.id);
  if (handIdx === -1) return state; // tile not in hand
  hand.splice(handIdx, 1);

  // Determine the actual left/right values after flipping
  const actualLeft = flipped ? tile.right : tile.left;
  const actualRight = flipped ? tile.left : tile.right;

  const boardTile: BoardTile = {
    tile: { ...tile, left: actualLeft, right: actualRight },
    leftPip: actualLeft,
    rightPip: actualRight,
  };

  if (newState.board.length === 0) {
    // First tile
    newState.board.push(boardTile);
    newState.leftEnd = actualLeft;
    newState.rightEnd = actualRight;
  } else if (placement === 'left') {
    // Place on left: the tile's right pip connects to the left end
    // The new left end becomes the tile's left pip
    newState.board.unshift(boardTile);
    newState.leftEnd = actualLeft;
  } else {
    // Place on right: the tile's left pip connects to the right end
    // The new right end becomes the tile's right pip
    newState.board.push(boardTile);
    newState.rightEnd = actualRight;
  }

  // Reset pass counter
  newState.passes = 0;

  // Check if player has emptied their hand (win)
  if (hand.length === 0) {
    newState.status = 'completed';
    newState.winner = player;
    newState.winReason = 'empty_hand';
    const opponentHand = player === 'player1' ? newState.player2Hand : newState.player1Hand;
    const opponentPips = opponentHand.reduce((sum, t) => sum + t.left + t.right, 0);
    if (player === 'player1') {
      newState.player1Score += opponentPips;
    } else {
      newState.player2Score += opponentPips;
    }
  }

  // Switch turn (if game still playing)
  if (newState.status === 'playing') {
    newState.currentTurn = player === 'player1' ? 'player2' : 'player1';
  }

  return newState;
}

// Draw a tile from the boneyard
export function drawTile(
  state: DominoGameState,
  player: 'player1' | 'player2',
): DominoGameState {
  if (state.boneyard.length === 0) return state;

  const newState: DominoGameState = {
    ...state,
    boneyard: [...state.boneyard],
    player1Hand: [...state.player1Hand],
    player2Hand: [...state.player2Hand],
  };

  const tile = newState.boneyard.pop()!;
  if (player === 'player1') {
    newState.player1Hand.push(tile);
  } else {
    newState.player2Hand.push(tile);
  }

  return newState;
}

// Pass turn (no legal move and boneyard empty)
export function passTurn(
  state: DominoGameState,
  player: 'player1' | 'player2',
): DominoGameState {
  const newState: DominoGameState = { ...state, passes: state.passes + 1 };

  // Two consecutive passes = blocked game
  if (newState.passes >= 2) {
    newState.status = 'completed';
    newState.winReason = 'blocked';
    // Calculate pips for each player
    const p1Pips = state.player1Hand.reduce((sum, t) => sum + t.left + t.right, 0);
    const p2Pips = state.player2Hand.reduce((sum, t) => sum + t.left + t.right, 0);
    if (p1Pips < p2Pips) {
      newState.winner = 'player1';
      newState.player1Score += p2Pips - p1Pips;
    } else if (p2Pips < p1Pips) {
      newState.winner = 'player2';
      newState.player2Score += p1Pips - p2Pips;
    } else {
      newState.winner = 'draw';
    }
  } else {
    newState.currentTurn = player === 'player1' ? 'player2' : 'player1';
  }

  return newState;
}

// Serialize for storage
export function serializeDominoState(state: DominoGameState): string {
  return JSON.stringify(state);
}

export function deserializeDominoState(json: string): DominoGameState {
  return JSON.parse(json) as DominoGameState;
}

// Simple domino bot AI: pick the move that plays the highest-pip tile
export function getDominoBotMove(state: DominoGameState, botPlayer: 'player1' | 'player2'): { tile: DominoTile; placement: Placement; flipped: boolean } | { draw: true } | { pass: true } {
  const hand = botPlayer === 'player1' ? state.player1Hand : state.player2Hand;

  // Find all legal moves
  const legalMoves: { tile: DominoTile; placement: Placement; flipped: boolean; pips: number }[] = [];
  for (const tile of hand) {
    const options = canPlaceTile(state, tile);
    for (const opt of options) {
      legalMoves.push({ tile, placement: opt.placement!, flipped: opt.flipped!, pips: tile.left + tile.right });
    }
  }

  if (legalMoves.length > 0) {
    // Prefer doubles, then highest pip count
    legalMoves.sort((a, b) => {
      const aDouble = a.tile.left === a.tile.right ? 1 : 0;
      const bDouble = b.tile.left === b.tile.right ? 1 : 0;
      if (aDouble !== bDouble) return bDouble - aDouble;
      return b.pips - a.pips;
    });
    return { tile: legalMoves[0].tile, placement: legalMoves[0].placement, flipped: legalMoves[0].flipped };
  }

  // No legal move — try to draw
  if (state.boneyard.length > 0) {
    return { draw: true };
  }

  // Must pass
  return { pass: true };
}

// Render pips for a tile face
export function getPipPositions(value: number): [number, number][] {
  const positions: [number, number][] = [];
  // Using a 3x3 grid, positions 0-8
  // 0 1 2
  // 3 4 5
  // 6 7 8
  const pipLayouts: Record<number, number[]> = {
    0: [],
    1: [4],
    2: [0, 8],
    3: [0, 4, 8],
    4: [0, 2, 6, 8],
    5: [0, 2, 4, 6, 8],
    6: [0, 2, 3, 5, 6, 8],
  };
  for (const pos of pipLayouts[value] || []) {
    const row = Math.floor(pos / 3);
    const col = pos % 3;
    positions.push([row, col]);
  }
  return positions;
}
