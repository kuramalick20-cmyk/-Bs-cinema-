import { supabase, type ComicImageTranslation } from './supabase';

export async function fetchPanelTranslations(panelId: string): Promise<ComicImageTranslation[]> {
  const { data, error } = await supabase
    .from('comic_image_translations')
    .select('*')
    .eq('panel_id', panelId)
    .eq('is_approved', true);
  if (error) return [];
  return (data as ComicImageTranslation[]) || [];
}

export async function requestComicTranslation(
  panelId: string,
  texts: string[],
  targetLang: string,
  sourceLang?: string
): Promise<{ results: Array<{ original: string; translated: string; source_lang: string | null }>; error: string | null }> {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/comic-translate`;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
    };
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify({ texts, target_lang: targetLang, source_lang: sourceLang }),
    });
    if (!response.ok) {
      return { results: [], error: `Translation failed (${response.status})` };
    }
    const data = await response.json();
    if (data.error) {
      return { results: [], error: data.error };
    }
    return { results: data.results || [], error: null };
  } catch (err: any) {
    return { results: [], error: err.message || 'Translation request failed' };
  }
}

export async function savePanelTranslation(
  panelId: string,
  originalText: string,
  translatedText: string,
  targetLang: string,
  sourceLang: string | null,
  region?: { x: number; y: number; width: number; height: number }
): Promise<ComicImageTranslation | null> {
  const { data, error } = await supabase
    .from('comic_image_translations')
    .insert({
      panel_id: panelId,
      original_text: originalText,
      translated_text: translatedText,
      target_language: targetLang,
      source_language: sourceLang,
      region_x: region?.x ?? 0.1,
      region_y: region?.y ?? 0.1,
      region_width: region?.width ?? 0.8,
      region_height: region?.height ?? 0.15,
      is_approved: false,
    })
    .select('*')
    .single();
  if (error) return null;
  return data as ComicImageTranslation;
}

export const LANGUAGES: Array<{ code: string; name: string; nativeName: string; dir: 'ltr' | 'rtl' }> = [
  { code: 'en', name: 'English', nativeName: 'English', dir: 'ltr' },
  { code: 'ku', name: 'Kurdish Sorani', nativeName: 'کوردی', dir: 'rtl' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', dir: 'rtl' },
  { code: 'fa', name: 'Persian', nativeName: 'فارسی', dir: 'rtl' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', dir: 'ltr' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', dir: 'rtl' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', dir: 'ltr' },
  { code: 'ps', name: 'Pashto', nativeName: 'پښتو', dir: 'rtl' },
  { code: 'he', name: 'Hebrew', nativeName: 'עברית', dir: 'rtl' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', dir: 'ltr' },
  { code: 'uk', name: 'Ukrainian', nativeName: 'Українська', dir: 'ltr' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', dir: 'ltr' },
  { code: 'fr', name: 'French', nativeName: 'Français', dir: 'ltr' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', dir: 'ltr' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', dir: 'ltr' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', dir: 'ltr' },
  { code: 'zh', name: 'Chinese', nativeName: '中文', dir: 'ltr' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', dir: 'ltr' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', dir: 'ltr' },
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt', dir: 'ltr' },
  { code: 'th', name: 'Thai', nativeName: 'ไทย', dir: 'ltr' },
  { code: 'id', name: 'Indonesian', nativeName: 'Indonesia', dir: 'ltr' },
  { code: 'ms', name: 'Malay', nativeName: 'Melayu', dir: 'ltr' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', dir: 'ltr' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', dir: 'ltr' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', dir: 'ltr' },
  { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili', dir: 'ltr' },
  { code: 'el', name: 'Greek', nativeName: 'Ελληνικά', dir: 'ltr' },
  { code: 'pl', name: 'Polish', nativeName: 'Polski', dir: 'ltr' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands', dir: 'ltr' },
];
