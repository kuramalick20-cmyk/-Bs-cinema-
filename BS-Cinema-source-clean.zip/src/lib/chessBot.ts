// Chess AI Bot — minimax with alpha-beta pruning, Elo-scaled difficulty
import {
  type GameState, type Move, type PieceColor,
  applyMove, getLegalMoves, evaluatePosition, isInCheck,
} from './chessEngine';

interface BotConfig {
  elo: number;
  depth: number;
  randomness: number; // 0..1 — chance to pick a suboptimal move
  useQuiescence: boolean;
}

// Map Elo to search depth and randomness
function eloToConfig(elo: number): BotConfig {
  if (elo <= 400) return { elo, depth: 1, randomness: 0.5, useQuiescence: false };
  if (elo <= 600) return { elo, depth: 1, randomness: 0.35, useQuiescence: false };
  if (elo <= 800) return { elo, depth: 2, randomness: 0.25, useQuiescence: false };
  if (elo <= 1000) return { elo, depth: 2, randomness: 0.15, useQuiescence: false };
  if (elo <= 1200) return { elo, depth: 2, randomness: 0.08, useQuiescence: true };
  if (elo <= 1400) return { elo, depth: 3, randomness: 0.05, useQuiescence: true };
  if (elo <= 1600) return { elo, depth: 3, randomness: 0.02, useQuiescence: true };
  if (elo <= 1800) return { elo, depth: 3, randomness: 0, useQuiescence: true };
  if (elo <= 2000) return { elo, depth: 4, randomness: 0, useQuiescence: true };
  return { elo, depth: 4, randomness: 0, useQuiescence: true };
}

export const BOT_ELO_LEVELS = [400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000];

// Order moves: captures first (MVV-LVA), then checks
function orderMoves(state: GameState, moves: Move[]): Move[] {
  return moves.sort((a, b) => {
    const aScore = scoreMoveForOrdering(a);
    const bScore = scoreMoveForOrdering(b);
    return bScore - aScore;
  });
}

function scoreMoveForOrdering(move: Move): number {
  let score = 0;
  if (move.captured) {
    const victimValue = pieceValue(move.captured.type);
    const attackerValue = pieceValue(move.piece.type);
    score += 10 * victimValue - attackerValue;
  }
  if (move.promotion) {
    score += pieceValue(move.promotion);
  }
  return score;
}

function pieceValue(type: string): number {
  const values: Record<string, number> = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 20000 };
  return values[type] || 0;
}

// Minimax with alpha-beta pruning
function minimax(
  state: GameState,
  depth: number,
  alpha: number,
  beta: number,
  maximizing: boolean,
  botColor: PieceColor,
  useQuiescence: boolean,
): number {
  if (depth === 0) {
    if (useQuiescence) {
      return quiescenceSearch(state, alpha, beta, maximizing, botColor);
    }
    const evalScore = evaluatePosition(state);
    return botColor === 'w' ? evalScore : -evalScore;
  }

  const currentColor = state.turn;
  const moves = getLegalMoves(state, currentColor);

  if (moves.length === 0) {
    if (isInCheck(state, currentColor)) {
      // Checkmate — very bad for the side to move
      return maximizing ? -100000 - depth : 100000 + depth;
    }
    return 0; // Stalemate
  }

  const orderedMoves = orderMoves(state, moves);

  if (maximizing) {
    let maxEval = -Infinity;
    for (const move of orderedMoves) {
      const newState = applyMove(state, move);
      const evalScore = minimax(newState, depth - 1, alpha, beta, false, botColor, useQuiescence);
      maxEval = Math.max(maxEval, evalScore);
      alpha = Math.max(alpha, evalScore);
      if (beta <= alpha) break;
    }
    return maxEval;
  } else {
    let minEval = Infinity;
    for (const move of orderedMoves) {
      const newState = applyMove(state, move);
      const evalScore = minimax(newState, depth - 1, alpha, beta, true, botColor, useQuiescence);
      minEval = Math.min(minEval, evalScore);
      beta = Math.min(beta, evalScore);
      if (beta <= alpha) break;
    }
    return minEval;
  }
}

// Quiescence search — only search captures to avoid horizon effect
function quiescenceSearch(
  state: GameState,
  alpha: number,
  beta: number,
  maximizing: boolean,
  botColor: PieceColor,
): number {
  const standPat = evaluatePosition(state);
  const evalFromBotPerspective = botColor === 'w' ? standPat : -standPat;

  if (maximizing) {
    if (evalFromBotPerspective >= beta) return beta;
    if (evalFromBotPerspective > alpha) alpha = evalFromBotPerspective;
  } else {
    if (evalFromBotPerspective <= alpha) return alpha;
    if (evalFromBotPerspective < beta) beta = evalFromBotPerspective;
  }

  const moves = getLegalMoves(state, state.turn).filter((m) => m.captured);
  const orderedMoves = orderMoves(state, moves);

  for (const move of orderedMoves) {
    const newState = applyMove(state, move);
    const score = quiescenceSearch(newState, alpha, beta, !maximizing, botColor);
    if (maximizing) {
      if (score >= beta) return beta;
      if (score > alpha) alpha = score;
    } else {
      if (score <= alpha) return alpha;
      if (score < beta) beta = score;
    }
  }

  return maximizing ? alpha : beta;
}

export function getBotMove(state: GameState, botColor: PieceColor, elo: number): Move | null {
  const config = eloToConfig(elo);
  const legalMoves = getLegalMoves(state, botColor);
  if (legalMoves.length === 0) return null;

  // For very low Elo, sometimes pick a random legal move
  if (config.randomness > 0 && Math.random() < config.randomness) {
    // Pick from the lower half of moves (blunder zone)
    const shuffled = [...legalMoves].sort(() => Math.random() - 0.5);
    return shuffled[0];
  }

  // Evaluate all top-level moves with minimax
  const orderedMoves = orderMoves(state, legalMoves);
  let bestMove = orderedMoves[0];
  let bestScore = botColor === 'w' ? -Infinity : Infinity;

  const scoredMoves: { move: Move; score: number }[] = [];

  for (const move of orderedMoves) {
    const newState = applyMove(state, move);
    const score = minimax(
      newState,
      config.depth - 1,
      -Infinity,
      Infinity,
      botColor === 'w' ? false : true,
      botColor,
      config.useQuiescence,
    );
    scoredMoves.push({ move, score });

    if (botColor === 'w') {
      if (score > bestScore) {
        bestScore = score;
        bestMove = move;
      }
    } else {
      if (score < bestScore) {
        bestScore = score;
        bestMove = move;
      }
    }
  }

  // For mid-range Elo, sometimes pick the 2nd or 3rd best move
  if (config.randomness > 0 && scoredMoves.length > 1) {
    scoredMoves.sort((a, b) => botColor === 'w' ? b.score - a.score : a.score - b.score);
    if (Math.random() < config.randomness * 2 && scoredMoves.length > 2) {
      return scoredMoves[1 + Math.floor(Math.random() * Math.min(2, scoredMoves.length - 1))].move;
    }
  }

  return bestMove;
}
