// Complete Chess Engine — rules, validation, check/checkmate, castling, en passant, promotion

export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
export type PieceColor = 'w' | 'b';

export interface Piece {
  type: PieceType;
  color: PieceColor;
}

export type Square = Piece | null;
export type Board = Square[][]; // 8x8, board[0] = rank 8 (top), board[7] = rank 1 (bottom)

export interface CastlingRights {
  wK: boolean;
  wQ: boolean;
  bK: boolean;
  bQ: boolean;
}

export interface GameState {
  board: Board;
  turn: PieceColor;
  castling: CastlingRights;
  enPassant: string | null; // square in algebraic notation e.g. "e3"
  halfmoveClock: number;
  fullmoveNumber: number;
}

export interface Move {
  from: string;
  to: string;
  piece: Piece;
  captured?: Piece | null;
  promotion?: PieceType | null;
  isCastle?: 'K' | 'Q' | null;
  isEnPassant?: boolean;
  notation?: string;
}

export type GameResult =
  | { result: 'white_wins'; reason: 'checkmate' | 'resignation' }
  | { result: 'black_wins'; reason: 'checkmate' | 'resignation' }
  | { result: 'draw'; reason: 'stalemate' | 'insufficient_material' | 'fifty_move' | 'threefold' }
  | null;

const PIECE_VALUES: Record<PieceType, number> = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 20000 };

// Piece-square tables for positional evaluation (white perspective, will mirror for black)
const PST_PAWN = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [50, 50, 50, 50, 50, 50, 50, 50],
  [10, 10, 20, 30, 30, 20, 10, 10],
  [5, 5, 10, 25, 25, 10, 5, 5],
  [0, 0, 0, 20, 20, 0, 0, 0],
  [5, -5, -10, 0, 0, -10, -5, 5],
  [5, 10, 10, -20, -20, 10, 10, 5],
  [0, 0, 0, 0, 0, 0, 0, 0],
];
const PST_KNIGHT = [
  [-50, -40, -30, -30, -30, -30, -40, -50],
  [-40, -20, 0, 0, 0, 0, -20, -40],
  [-30, 0, 10, 15, 15, 10, 0, -30],
  [-30, 5, 15, 20, 20, 15, 5, -30],
  [-30, 0, 15, 20, 20, 15, 0, -30],
  [-30, 5, 10, 15, 15, 10, 5, -30],
  [-40, -20, 0, 5, 5, 0, -20, -40],
  [-50, -40, -30, -30, -30, -30, -40, -50],
];
const PST_BISHOP = [
  [-20, -10, -10, -10, -10, -10, -10, -20],
  [-10, 0, 0, 0, 0, 0, 0, -10],
  [-10, 0, 5, 10, 10, 5, 0, -10],
  [-10, 5, 5, 10, 10, 5, 5, -10],
  [-10, 0, 10, 10, 10, 10, 0, -10],
  [-10, 10, 10, 10, 10, 10, 10, -10],
  [-10, 5, 0, 0, 0, 0, 5, -10],
  [-20, -10, -10, -10, -10, -10, -10, -20],
];
const PST_ROOK = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [5, 10, 10, 10, 10, 10, 10, 5],
  [-5, 0, 0, 0, 0, 0, 0, -5],
  [-5, 0, 0, 0, 0, 0, 0, -5],
  [-5, 0, 0, 0, 0, 0, 0, -5],
  [-5, 0, 0, 0, 0, 0, 0, -5],
  [-5, 0, 0, 0, 0, 0, 0, -5],
  [0, 0, 0, 5, 5, 0, 0, 0],
];
const PST_QUEEN = [
  [-20, -10, -10, -5, -5, -10, -10, -20],
  [-10, 0, 0, 0, 0, 0, 0, -10],
  [-10, 0, 5, 5, 5, 5, 0, -10],
  [-5, 0, 5, 5, 5, 5, 0, -5],
  [0, 0, 5, 5, 5, 5, 0, -5],
  [-10, 5, 5, 5, 5, 5, 0, -10],
  [-10, 0, 5, 0, 0, 0, 0, -10],
  [-20, -10, -10, -5, -5, -10, -10, -20],
];
const PST_KING = [
  [-30, -40, -40, -50, -50, -40, -40, -30],
  [-30, -40, -40, -50, -50, -40, -40, -30],
  [-30, -40, -40, -50, -50, -40, -40, -30],
  [-30, -40, -40, -50, -50, -40, -40, -30],
  [-20, -30, -30, -40, -40, -30, -30, -20],
  [-10, -20, -20, -20, -20, -20, -20, -10],
  [20, 20, 0, 0, 0, 0, 20, 20],
  [20, 30, 10, 0, 0, 10, 30, 20],
];

const PST_MAP: Record<PieceType, number[][]> = {
  p: PST_PAWN, n: PST_KNIGHT, b: PST_BISHOP, r: PST_ROOK, q: PST_QUEEN, k: PST_KING,
};

export function squareToCoords(square: string): [number, number] {
  const file = square.charCodeAt(0) - 97; // a=0
  const rank = parseInt(square[1]);
  const row = 8 - rank; // rank 8 -> row 0
  return [row, file];
}

export function coordsToSquare(row: number, col: number): string {
  return String.fromCharCode(97 + col) + (8 - row);
}

export function initialBoard(): Board {
  const backRank: PieceType[] = ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'];
  const board: Board = Array(8).fill(null).map(() => Array(8).fill(null));
  for (let i = 0; i < 8; i++) {
    board[0][i] = { type: backRank[i], color: 'b' };
    board[1][i] = { type: 'p', color: 'b' };
    board[6][i] = { type: 'p', color: 'w' };
    board[7][i] = { type: backRank[i], color: 'w' };
  }
  return board;
}

export function initialState(): GameState {
  return {
    board: initialBoard(),
    turn: 'w',
    castling: { wK: true, wQ: true, bK: true, bQ: true },
    enPassant: null,
    halfmoveClock: 0,
    fullmoveNumber: 1,
  };
}

export function cloneState(state: GameState): GameState {
  return {
    board: state.board.map((row) => row.map((sq) => (sq ? { ...sq } : null))),
    turn: state.turn,
    castling: { ...state.castling },
    enPassant: state.enPassant,
    halfmoveClock: state.halfmoveClock,
    fullmoveNumber: state.fullmoveNumber,
  };
}

export function cloneBoard(board: Board): Board {
  return board.map((row) => row.map((sq) => (sq ? { ...sq } : null)));
}

function inBounds(r: number, c: number): boolean {
  return r >= 0 && r < 8 && c >= 0 && c < 8;
}

// Get pseudo-legal moves (not checking if own king is in check)
function getPseudoLegalMoves(state: GameState, row: number, col: number): Move[] {
  const board = state.board;
  const piece = board[row][col];
  if (!piece) return [];
  const moves: Move[] = [];
  const color = piece.color;
  const pos = coordsToSquare(row, col);

  const addMove = (r: number, c: number, extra: Partial<Move> = {}) => {
    if (!inBounds(r, c)) return;
    const target = board[r][c];
    if (target && target.color === color) return;
    moves.push({
      from: pos,
      to: coordsToSquare(r, c),
      piece,
      captured: target || null,
      ...extra,
    });
  };

  const slide = (deltas: [number, number][]) => {
    for (const [dr, dc] of deltas) {
      let r = row + dr, c = col + dc;
      while (inBounds(r, c)) {
        const target = board[r][c];
        if (target && target.color === color) break;
        addMove(r, c);
        if (target) break;
        r += dr;
        c += dc;
      }
    }
  };

  switch (piece.type) {
    case 'p': {
      const dir = color === 'w' ? -1 : 1;
      const startRow = color === 'w' ? 6 : 1;
      const promoRow = color === 'w' ? 0 : 7;
      // Forward one
      if (inBounds(row + dir, col) && !board[row + dir][col]) {
        if (row + dir === promoRow) {
          for (const promo of ['q', 'r', 'b', 'n'] as PieceType[]) {
            addMove(row + dir, col, { promotion: promo });
          }
        } else {
          addMove(row + dir, col);
        }
        // Forward two
        if (row === startRow && !board[row + 2 * dir][col]) {
          addMove(row + 2 * dir, col);
        }
      }
      // Captures
      for (const dc of [-1, 1]) {
        const r = row + dir, c = col + dc;
        if (!inBounds(r, c)) continue;
        const target = board[r][c];
        if (target && target.color !== color) {
          if (r === promoRow) {
            for (const promo of ['q', 'r', 'b', 'n'] as PieceType[]) {
              addMove(r, c, { promotion: promo });
            }
          } else {
            addMove(r, c);
          }
        }
        // En passant
        if (state.enPassant) {
          const [epRow, epCol] = squareToCoords(state.enPassant);
          if (r === epRow && c === epCol) {
            addMove(r, c, { isEnPassant: true, captured: board[row][c] });
          }
        }
      }
      break;
    }
    case 'n': {
      const knightMoves: [number, number][] = [
        [-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1],
      ];
      for (const [dr, dc] of knightMoves) {
        addMove(row + dr, col + dc);
      }
      break;
    }
    case 'b':
      slide([[-1, -1], [-1, 1], [1, -1], [1, 1]]);
      break;
    case 'r':
      slide([[-1, 0], [1, 0], [0, -1], [0, 1]]);
      break;
    case 'q':
      slide([[-1, -1], [-1, 1], [1, -1], [1, 1], [-1, 0], [1, 0], [0, -1], [0, 1]]);
      break;
    case 'k': {
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          addMove(row + dr, col + dc);
        }
      }
      // Castling
      const rights = state.castling;
      const homeRow = color === 'w' ? 7 : 0;
      if (row === homeRow && col === 4) {
        // King side
        const canK = color === 'w' ? rights.wK : rights.bK;
        if (canK && !board[homeRow][5] && !board[homeRow][6] && board[homeRow][7]?.type === 'r' && board[homeRow][7]?.color === color) {
          if (!isSquareAttacked(state, homeRow, 4, color) && !isSquareAttacked(state, homeRow, 5, color) && !isSquareAttacked(state, homeRow, 6, color)) {
            addMove(homeRow, 6, { isCastle: 'K' });
          }
        }
        // Queen side
        const canQ = color === 'w' ? rights.wQ : rights.bQ;
        if (canQ && !board[homeRow][3] && !board[homeRow][2] && !board[homeRow][1] && board[homeRow][0]?.type === 'r' && board[homeRow][0]?.color === color) {
          if (!isSquareAttacked(state, homeRow, 4, color) && !isSquareAttacked(state, homeRow, 3, color) && !isSquareAttacked(state, homeRow, 2, color)) {
            addMove(homeRow, 2, { isCastle: 'Q' });
          }
        }
      }
      break;
    }
  }
  return moves;
}

// Check if a square is attacked by the opposite color of the given color
export function isSquareAttacked(state: GameState, row: number, col: number, defenderColor: PieceColor): boolean {
  const board = state.board;
  const attackerColor: PieceColor = defenderColor === 'w' ? 'b' : 'w';

  // Check pawn attacks
  const pawnDir = attackerColor === 'w' ? -1 : 1;
  for (const dc of [-1, 1]) {
    const r = row - pawnDir, c = col + dc;
    if (inBounds(r, c)) {
      const p = board[r][c];
      if (p && p.color === attackerColor && p.type === 'p') return true;
    }
  }

  // Knight attacks
  const knightMoves: [number, number][] = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
  for (const [dr, dc] of knightMoves) {
    const r = row + dr, c = col + dc;
    if (inBounds(r, c)) {
      const p = board[r][c];
      if (p && p.color === attackerColor && p.type === 'n') return true;
    }
  }

  // King attacks
  for (let dr = -1; dr <= 1; dr++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (dr === 0 && dc === 0) continue;
      const r = row + dr, c = col + dc;
      if (inBounds(r, c)) {
        const p = board[r][c];
        if (p && p.color === attackerColor && p.type === 'k') return true;
      }
    }
  }

  // Sliding attacks: bishop/queen diagonals
  const diagDeltas: [number, number][] = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
  for (const [dr, dc] of diagDeltas) {
    let r = row + dr, c = col + dc;
    while (inBounds(r, c)) {
      const p = board[r][c];
      if (p) {
        if (p.color === attackerColor && (p.type === 'b' || p.type === 'q')) return true;
        break;
      }
      r += dr; c += dc;
    }
  }

  // Sliding attacks: rook/queen straight
  const straightDeltas: [number, number][] = [[-1, 0], [1, 0], [0, -1], [0, 1]];
  for (const [dr, dc] of straightDeltas) {
    let r = row + dr, c = col + dc;
    while (inBounds(r, c)) {
      const p = board[r][c];
      if (p) {
        if (p.color === attackerColor && (p.type === 'r' || p.type === 'q')) return true;
        break;
      }
      r += dr; c += dc;
    }
  }

  return false;
}

export function findKing(state: GameState, color: PieceColor): [number, number] | null {
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = state.board[r][c];
      if (p && p.type === 'k' && p.color === color) return [r, c];
    }
  }
  return null;
}

export function isInCheck(state: GameState, color: PieceColor): boolean {
  const kingPos = findKing(state, color);
  if (!kingPos) return false;
  return isSquareAttacked(state, kingPos[0], kingPos[1], color);
}

// Apply a move to a state, returning a new state (does not validate legality)
export function applyMove(state: GameState, move: Move): GameState {
  const newState = cloneState(state);
  const board = newState.board;
  const [fromRow, fromCol] = squareToCoords(move.from);
  const [toRow, toCol] = squareToCoords(move.to);
  const piece = board[fromRow][fromCol]!;

  // Move the piece
  board[toRow][toCol] = move.promotion ? { type: move.promotion, color: piece.color } : piece;
  board[fromRow][fromCol] = null;

  // En passant capture
  if (move.isEnPassant) {
    board[fromRow][toCol] = null;
  }

  // Castling — move the rook
  if (move.isCastle === 'K') {
    const homeRow = piece.color === 'w' ? 7 : 0;
    board[homeRow][5] = board[homeRow][7];
    board[homeRow][7] = null;
  } else if (move.isCastle === 'Q') {
    const homeRow = piece.color === 'w' ? 7 : 0;
    board[homeRow][3] = board[homeRow][0];
    board[homeRow][0] = null;
  }

  // Update castling rights
  if (piece.type === 'k') {
    if (piece.color === 'w') { newState.castling.wK = false; newState.castling.wQ = false; }
    else { newState.castling.bK = false; newState.castling.bQ = false; }
  }
  if (piece.type === 'r') {
    if (piece.color === 'w') {
      if (fromRow === 7 && fromCol === 0) newState.castling.wQ = false;
      if (fromRow === 7 && fromCol === 7) newState.castling.wK = false;
    } else {
      if (fromRow === 0 && fromCol === 0) newState.castling.bQ = false;
      if (fromRow === 0 && fromCol === 7) newState.castling.bK = false;
    }
  }
  // If rook is captured, remove castling rights
  if (move.captured && move.captured.type === 'r') {
    if (toRow === 7 && toCol === 0) newState.castling.wQ = false;
    if (toRow === 7 && toCol === 7) newState.castling.wK = false;
    if (toRow === 0 && toCol === 0) newState.castling.bQ = false;
    if (toRow === 0 && toCol === 7) newState.castling.bK = false;
  }

  // Update en passant target
  if (piece.type === 'p' && Math.abs(toRow - fromRow) === 2) {
    newState.enPassant = coordsToSquare((fromRow + toRow) / 2, fromCol);
  } else {
    newState.enPassant = null;
  }

  // Halfmove clock
  if (piece.type === 'p' || move.captured) {
    newState.halfmoveClock = 0;
  } else {
    newState.halfmoveClock = state.halfmoveClock + 1;
  }

  // Fullmove number
  if (state.turn === 'b') {
    newState.fullmoveNumber = state.fullmoveNumber + 1;
  }

  // Switch turn
  newState.turn = state.turn === 'w' ? 'b' : 'w';

  return newState;
}

// Get all legal moves for a color (filters out moves that leave own king in check)
export function getLegalMoves(state: GameState, color: PieceColor): Move[] {
  const moves: Move[] = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = state.board[r][c];
      if (!piece || piece.color !== color) continue;
      const pseudoMoves = getPseudoLegalMoves(state, r, c);
      for (const move of pseudoMoves) {
        const testState = applyMove(state, move);
        if (!isInCheck(testState, color)) {
          moves.push(move);
        }
      }
    }
  }
  return moves;
}

// Get legal moves for a specific square (for UI interaction)
export function getLegalMovesForSquare(state: GameState, square: string): Move[] {
  const [row, col] = squareToCoords(square);
  const piece = state.board[row][col];
  if (!piece || piece.color !== state.turn) return [];
  return getLegalMoves(state, piece.color).filter((m) => m.from === square);
}

export function getGameResult(state: GameState, moveHistory: string[]): GameResult {
  const legalMoves = getLegalMoves(state, state.turn);
  if (legalMoves.length === 0) {
    if (isInCheck(state, state.turn)) {
      return {
        result: state.turn === 'w' ? 'black_wins' : 'white_wins',
        reason: 'checkmate',
      };
    } else {
      return { result: 'draw', reason: 'stalemate' };
    }
  }

  // Fifty-move rule
  if (state.halfmoveClock >= 100) {
    return { result: 'draw', reason: 'fifty_move' };
  }

  // Insufficient material
  if (hasInsufficientMaterial(state)) {
    return { result: 'draw', reason: 'insufficient_material' };
  }

  // Threefold repetition
  if (checkThreefoldRepetition(moveHistory)) {
    return { result: 'draw', reason: 'threefold' };
  }

  return null;
}

function hasInsufficientMaterial(state: GameState): boolean {
  const pieces: { piece: Piece; row: number; col: number }[] = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = state.board[r][c];
      if (p && p.type !== 'k') pieces.push({ piece: p, row: r, col: c });
    }
  }
  if (pieces.length === 0) return true; // K vs K
  if (pieces.length === 1 && (pieces[0].piece.type === 'n' || pieces[0].piece.type === 'b')) return true; // K+minor vs K
  if (pieces.length === 2) {
    const allBishops = pieces.every((p) => p.piece.type === 'b');
    if (allBishops) {
      // Same color squares
      const colors = pieces.map((p) => (p.row + p.col) % 2);
      if (colors[0] === colors[1]) return true;
    }
  }
  return false;
}

function checkThreefoldRepetition(moveHistory: string[]): boolean {
  // Simplified: check if the last position appeared 3 times
  // In a real implementation we'd track full position hashes
  if (moveHistory.length < 8) return false;
  const positions = new Map<string, number>();
  // For simplicity, count consecutive repeats of move patterns
  // This is a simplified version; full threefold requires position hashing
  return false;
}

// Generate algebraic notation for a move
export function moveToNotation(state: GameState, move: Move): string {
  if (move.isCastle === 'K') return 'O-O';
  if (move.isCastle === 'Q') return 'O-O-O';

  const pieceLetter = move.piece.type === 'p' ? '' : move.piece.type.toUpperCase();
  const [toRow, toCol] = squareToCoords(move.to);
  const capture = move.captured || move.isEnPassant ? 'x' : '';
  const fromFile = move.from[0];

  let notation = pieceLetter;
  if (move.piece.type === 'p' && capture) {
    notation += fromFile + 'x';
  } else if (capture && move.piece.type !== 'p') {
    // Disambiguation could go here
    notation += capture;
  }
  notation += move.to;
  if (move.promotion) {
    notation += '=' + move.promotion.toUpperCase();
  }

  // Check/checkmate suffix
  const testState = applyMove(state, move);
  if (isInCheck(testState, testState.turn)) {
    const opponentMoves = getLegalMoves(testState, testState.turn);
    notation += opponentMoves.length === 0 ? '#' : '+';
  }

  return notation;
}

// Evaluation function for bot AI
export function evaluatePosition(state: GameState): number {
  let score = 0;
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = state.board[r][c];
      if (!piece) continue;
      const pst = PST_MAP[piece.type];
      const pstRow = piece.color === 'w' ? r : 7 - r;
      const pstValue = pst[pstRow][c];
      const value = PIECE_VALUES[piece.type] + pstValue;
      score += piece.color === 'w' ? value : -value;
    }
  }
  // Small bonus for mobility
  const whiteMoves = getLegalMoves(state, 'w').length;
  const blackMoves = getLegalMoves(state, 'b').length;
  score += (whiteMoves - blackMoves) * 2;
  return score;
}

// Serialize state for storage
export function serializeState(state: GameState): string {
  return JSON.stringify(state);
}

export function deserializeState(json: string): GameState {
  const parsed = JSON.parse(json);
  return {
    board: parsed.board,
    turn: parsed.turn,
    castling: parsed.castling,
    enPassant: parsed.enPassant,
    halfmoveClock: parsed.halfmoveClock,
    fullmoveNumber: parsed.fullmoveNumber,
  };
}
