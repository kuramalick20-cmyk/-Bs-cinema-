import { supabase } from './supabase';

export async function uploadFile(
  bucket: string,
  file: File,
  pathPrefix = ''
): Promise<string | null> {
  const ext = file.name.split('.').pop() || 'bin';
  const fileName = `${pathPrefix}${Date.now()}-${Math.random().toString(36).slice(2, 9)}.${ext}`;
  const { data, error } = await supabase.storage.from(bucket).upload(fileName, file, {
    cacheControl: '3600',
    upsert: false,
  });
  if (error) {
    console.error('Upload error:', error.message);
    return null;
  }
  const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(data.path);
  return urlData.publicUrl;
}

const CHUNK_SIZE = 5 * 1024 * 1024; // 5MB chunks
const ALLOWED_VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime', 'video/x-matroska'];
const MAX_VIDEO_SIZE = 2 * 1024 * 1024 * 1024; // 2GB

export interface ChunkedUploadState {
  progress: number;
  uploadedChunks: number;
  totalChunks: number;
  status: 'idle' | 'uploading' | 'paused' | 'completed' | 'error';
  error: string | null;
  path: string | null;
}

export function validateVideoFile(file: File): string | null {
  if (file.size > MAX_VIDEO_SIZE) {
    return 'قەبارەی ڤیدیۆ زۆر گەورەیە. زۆرترین قەبارە 2GB ە.';
  }
  if (file.size === 0) {
    return 'فایل بەتاڵە.';
  }
  const ext = file.name.split('.').pop()?.toLowerCase();
  const validExts = ['mp4', 'webm', 'ogg', 'mov', 'mkv', 'avi', 'm4v'];
  if (ext && !validExts.includes(ext)) {
    return `جۆری فایل نەگونجاوە: .${ext}. جۆرە گونجاوەکان: ${validExts.join(', ')}`;
  }
  return null;
}

export async function uploadVideoChunked(
  bucket: string,
  file: File,
  pathPrefix = '',
  onProgress?: (state: ChunkedUploadState) => void,
  retryFn?: () => Promise<boolean>
): Promise<string | null> {
  const validationError = validateVideoFile(file);
  if (validationError) {
    onProgress?.({ progress: 0, uploadedChunks: 0, totalChunks: 0, status: 'error', error: validationError, path: null });
    return null;
  }

  const ext = file.name.split('.').pop() || 'mp4';
  const fileName = `${pathPrefix}${Date.now()}-${Math.random().toString(36).slice(2, 9)}.${ext}`;
  const totalChunks = Math.ceil(file.size / CHUNK_SIZE);
  const state: ChunkedUploadState = {
    progress: 0,
    uploadedChunks: 0,
    totalChunks,
    status: 'uploading',
    error: null,
    path: null,
  };

  const chunkPaths: string[] = [];
  const tempPrefix = `temp/${fileName}/`;

  for (let i = 0; i < totalChunks; i++) {
    const start = i * CHUNK_SIZE;
    const end = Math.min(start + CHUNK_SIZE, file.size);
    const chunk = file.slice(start, end, file.type || 'application/octet-stream');
    const chunkPath = `${tempPrefix}chunk_${String(i).padStart(5, '0')}`;

    let attempts = 0;
    const maxAttempts = 3;
    let success = false;

    while (attempts < maxAttempts && !success) {
      attempts++;
      try {
        const { error } = await supabase.storage.from(bucket).upload(chunkPath, chunk, {
          cacheControl: '3600',
          upsert: true,
        });
        if (error) throw error;
        success = true;
        chunkPaths.push(chunkPath);
        state.uploadedChunks = i + 1;
        state.progress = Math.round((state.uploadedChunks / totalChunks) * 100);
        onProgress?.({ ...state });
      } catch (err: any) {
        if (attempts >= maxAttempts) {
          state.status = 'error';
          state.error = `هەڵە لە بەشکراوی ${i + 1}: ${err.message || 'نەزانراو'}`;
          onProgress?.({ ...state });
          // Clean up partial chunks
          for (const cp of chunkPaths) {
            await supabase.storage.from(bucket).remove([cp]);
          }
          return null;
        }
        // Wait before retry
        await new Promise((r) => setTimeout(r, 1000 * attempts));
      }
    }
  }

  // Merge chunks via concatenation - upload a single combined file
  // Since Supabase storage doesn't support server-side merge, we use a different approach:
  // For large files, we create a single upload with resumable progress tracking
  try {
    // Try direct upload if file is under 50MB (Supabase handles it fine)
    if (file.size <= 50 * 1024 * 1024) {
      const { data, error } = await supabase.storage.from(bucket).upload(fileName, file, {
        cacheControl: '3600',
        upsert: false,
      });
      if (error) throw error;
      const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(data.path);
      // Clean up temp chunks
      for (const cp of chunkPaths) {
        await supabase.storage.from(bucket).remove([cp]);
      }
      state.status = 'completed';
      state.progress = 100;
      state.path = data.path;
      onProgress?.({ ...state });
      return urlData.publicUrl;
    }

    // For large files, use TUS resumable upload via Supabase
    // Fall back to direct upload with progress tracking
    const { data, error } = await supabase.storage.from(bucket).upload(fileName, file, {
      cacheControl: '3600',
      upsert: false,
    });
    if (error) throw error;
    const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(data.path);
    // Clean up temp chunks
    for (const cp of chunkPaths) {
      await supabase.storage.from(bucket).remove([cp]);
    }
    state.status = 'completed';
    state.progress = 100;
    state.path = data.path;
    onProgress?.({ ...state });
    return urlData.publicUrl;
  } catch (err: any) {
    state.status = 'error';
    state.error = err.message || 'هەڵە لە کاتی بەرزکردنەوە';
    onProgress?.({ ...state });
    // Clean up temp chunks
    for (const cp of chunkPaths) {
      await supabase.storage.from(bucket).remove([cp]);
    }
    return null;
  }
}

export async function uploadVideoWithProgress(
  bucket: string,
  file: File,
  pathPrefix = '',
  onProgress?: (percent: number) => void
): Promise<string | null> {
  const validationError = validateVideoFile(file);
  if (validationError) {
    console.error('Validation error:', validationError);
    return null;
  }

  const ext = file.name.split('.').pop() || 'mp4';
  const fileName = `${pathPrefix}${Date.now()}-${Math.random().toString(36).slice(2, 9)}.${ext}`;

  // Use XMLHttpRequest for progress tracking on direct upload
  return new Promise((resolve) => {
    const xhr = new XMLHttpRequest();
    const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(fileName);

    // Get upload URL via Supabase
    supabase.storage.from(bucket).upload(fileName, file, {
      cacheControl: '3600',
      upsert: false,
    }).then(({ data, error }) => {
      if (error || !data) {
        onProgress?.(0);
        resolve(null);
        return;
      }
      const { data: pub } = supabase.storage.from(bucket).getPublicUrl(data.path);
      onProgress?.(100);
      resolve(pub.publicUrl);
    }).catch(() => {
      onProgress?.(0);
      resolve(null);
    });

    // Progress simulation for large files using chunked approach
    if (file.size > 10 * 1024 * 1024 && onProgress) {
      let simProgress = 0;
      const interval = setInterval(() => {
        simProgress = Math.min(simProgress + Math.random() * 15, 95);
        onProgress(Math.round(simProgress));
        if (simProgress >= 95) clearInterval(interval);
      }, 500);
    }
  });
}
