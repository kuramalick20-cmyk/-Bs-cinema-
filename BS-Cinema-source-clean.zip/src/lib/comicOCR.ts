import Tesseract from 'tesseract.js';
import { supabase, type ComicSpeechBubble } from './supabase';
import { detectLanguage } from './comicVoice';

export interface OCRTextRegion {
  text: string;
  bbox: { x0: number; y0: number; x1: number; y1: number };
  confidence: number;
}

export interface OCRResult {
  panelId: string;
  regions: OCRTextRegion[];
  imageUrl: string;
  width: number;
  height: number;
}

let multiWorker: Tesseract.Worker | null = null;
let workerLoading: Promise<Tesseract.Worker> | null = null;

async function getWorker(): Promise<Tesseract.Worker> {
  if (multiWorker) return multiWorker;
  if (workerLoading) return workerLoading;

  workerLoading = (async () => {
    try {
      multiWorker = await Tesseract.createWorker('eng+ara');
    } catch {
      try {
        multiWorker = await Tesseract.createWorker('ara');
      } catch {
        multiWorker = await Tesseract.createWorker('eng');
      }
    }
    return multiWorker;
  })();

  return workerLoading;
}

// === Text Quality Filtering ===
// Strictly filters OCR output to reject garbage, noise, and non-bubble text

function isGarbageText(text: string): boolean {
  const trimmed = text.trim();
  if (trimmed.length < 2) return true;

  // Reject strings that are mostly non-alphanumeric (punctuation, symbols, spaces)
  const alphanumeric = trimmed.replace(/[\s\p{P}\p{S}]/gu, '');
  if (alphanumeric.length < 2) return true;

  // Reject excessive repeated characters (e.g., "aaaaaaa", "......", "------")
  const repeatedChar = /(.)\1{4,}/;
  if (repeatedChar.test(trimmed)) return true;

  // Reject strings that look like filenames (contain file extensions)
  if (/\.(jpg|png|gif|bmp|webp|mp4|avi|mov|pdf|txt|json|xml|html|js|css)$/i.test(trimmed)) return true;

  // Reject strings with code/markup characters that should never appear in speech
  if (/[<>{}[\]\\|]/.test(trimmed)) return true;

  // Reject strings that are mostly digits (page numbers, metadata)
  const digits = trimmed.replace(/[^\d]/g, '');
  if (digits.length > alphanumeric.length * 0.7 && digits.length > 3) return true;

  // Reject strings with no actual letters (only symbols and numbers)
  const letters = trimmed.replace(/[\p{L}]/gu, '');
  if (letters.length === trimmed.length) return true;

  // Reject strings that are just a single repeated word/char pattern
  const words = trimmed.split(/\s+/).filter((w) => w.length > 0);
  if (words.length > 0 && words.every((w) => w === words[0]) && words.length > 2) return true;

  // Reject very long strings with no spaces and no word boundaries (likely OCR noise)
  if (trimmed.length > 50 && /\s/.test(trimmed) === false) return true;

  // Reject strings with high ratio of special characters
  const specialChars = trimmed.replace(/[\p{L}\p{N}\s]/gu, '');
  if (specialChars.length > trimmed.length * 0.25) return true;

  return false;
}

function cleanText(text: string): string {
  return text
    .trim()
    // Remove stray leading/trailing punctuation that's likely OCR artifacts
    .replace(/^[\s|·•●▪◆◇○●□■\-=*#~`'"]+/u, '')
    .replace(/[\s|·•●▪◆◇○●□■\-=*#~`'"]+$/u, '')
    // Collapse multiple spaces
    .replace(/\s{2,}/g, ' ')
    // Remove control characters
    .replace(/[\x00-\x1f\x7f]/g, '')
    .trim();
}

// === Speech Bubble Detection ===
// Uses canvas to detect light-colored regions (speech bubbles) in the image.
// Only text inside these regions will be kept.

interface DetectedRegion {
  x: number;
  y: number;
  width: number;
  height: number;
}

async function loadImageToCanvas(imageUrl: string): Promise<{ canvas: HTMLCanvasElement; width: number; height: number }> {
  const img = new Image();
  img.crossOrigin = 'anonymous';
  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = imageUrl;
  });

  const width = img.naturalWidth;
  const height = img.naturalHeight;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Canvas context not available');
  ctx.drawImage(img, 0, 0);
  return { canvas, width, height };
}

async function detectSpeechBubbleRegions(
  imageUrl: string,
  imageWidth: number,
  imageHeight: number
): Promise<DetectedRegion[]> {
  try {
    const { canvas, width, height } = await loadImageToCanvas(imageUrl);
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return [];

    // Downsample to a grid for efficiency
    const cellSize = Math.max(8, Math.floor(Math.min(width, height) / 100));
    const gridW = Math.ceil(width / cellSize);
    const gridH = Math.ceil(height / cellSize);

    // Mark cells as "light" (potential bubble interior)
    const lightGrid: boolean[] = new Array(gridW * gridH).fill(false);
    const imageData = ctx.getImageData(0, 0, width, height);
    const data = imageData.data;

    const brightnessThreshold = 180; // R+G+B average > 180 = light

    for (let gy = 0; gy < gridH; gy++) {
      for (let gx = 0; gx < gridW; gx++) {
        let rSum = 0, gSum = 0, bSum = 0, count = 0;
        const startX = gx * cellSize;
        const startY = gy * cellSize;
        const endX = Math.min(startX + cellSize, width);
        const endY = Math.min(startY + cellSize, height);

        for (let y = startY; y < endY; y += 2) {
          for (let x = startX; x < endX; x += 2) {
            const idx = (y * width + x) * 4;
            rSum += data[idx];
            gSum += data[idx + 1];
            bSum += data[idx + 2];
            count++;
          }
        }

        if (count > 0) {
          const avgBrightness = (rSum + gSum + bSum) / (3 * count);
          if (avgBrightness > brightnessThreshold) {
            lightGrid[gy * gridW + gx] = true;
          }
        }
      }
    }

    // Find connected components of light cells using BFS flood fill
    const visited: boolean[] = new Array(gridW * gridH).fill(false);
    const regions: DetectedRegion[] = [];

    const minCells = Math.max(4, Math.floor((gridW * gridH) * 0.002)); // Min region size
    const maxCells = Math.floor((gridW * gridH) * 0.5); // Max region size (avoid background)

    for (let gy = 0; gy < gridH; gy++) {
      for (let gx = 0; gx < gridW; gx++) {
        const idx = gy * gridW + gx;
        if (!lightGrid[idx] || visited[idx]) continue;

        // BFS flood fill
        const queue: Array<[number, number]> = [[gx, gy]];
        visited[idx] = true;
        let minX = gx, maxX = gx, minY = gy, maxY = gy;
        let cellCount = 0;

        while (queue.length > 0) {
          const [cx, cy] = queue.shift()!;
          cellCount++;
          if (cx < minX) minX = cx;
          if (cx > maxX) maxX = cx;
          if (cy < minY) minY = cy;
          if (cy > maxY) maxY = cy;

          // Check 4 neighbors
          const neighbors: Array<[number, number]> = [
            [cx + 1, cy], [cx - 1, cy],
            [cx, cy + 1], [cx, cy - 1],
          ];
          for (const [nx, ny] of neighbors) {
            if (nx < 0 || nx >= gridW || ny < 0 || ny >= gridH) continue;
            const nidx = ny * gridW + nx;
            if (lightGrid[nidx] && !visited[nidx]) {
              visited[nidx] = true;
              queue.push([nx, ny]);
            }
          }
        }

        // Filter by size — only keep regions that could be speech bubbles
        if (cellCount >= minCells && cellCount <= maxCells) {
          const regionX = minX * cellSize;
          const regionY = minY * cellSize;
          const regionW = (maxX - minX + 1) * cellSize;
          const regionH = (maxY - minY + 1) * cellSize;

          // Aspect ratio filter — bubbles are roughly square or wider than tall
          const aspectRatio = regionW / regionH;
          if (aspectRatio > 0.2 && aspectRatio < 8) {
            // Add padding around the detected region
            const pad = cellSize * 2;
            regions.push({
              x: Math.max(0, regionX - pad),
              y: Math.max(0, regionY - pad),
              width: Math.min(width, regionW + pad * 2),
              height: Math.min(height, regionH + pad * 2),
            });
          }
        }
      }
    }

    return regions;
  } catch (err) {
    console.error('Bubble detection failed:', err);
    return [];
  }
}

// Check if an OCR text region overlaps with any detected bubble region
function isInsideBubble(
  textBbox: { x0: number; y0: number; x1: number; y1: number },
  bubbleRegions: DetectedRegion[]
): boolean {
  if (bubbleRegions.length === 0) return false;

  const textCx = (textBbox.x0 + textBbox.x1) / 2;
  const textCy = (textBbox.y0 + textBbox.y1) / 2;

  for (const region of bubbleRegions) {
    // Check if text center is inside the bubble region
    if (textCx >= region.x && textCx <= region.x + region.width &&
        textCy >= region.y && textCy <= region.y + region.height) {
      return true;
    }
    // Also check for significant overlap
    const overlapX = Math.max(0, Math.min(textBbox.x1, region.x + region.width) - Math.max(textBbox.x0, region.x));
    const overlapY = Math.max(0, Math.min(textBbox.y1, region.y + region.height) - Math.max(textBbox.y0, region.y));
    const overlapArea = overlapX * overlapY;
    const textArea = (textBbox.x1 - textBbox.x0) * (textBbox.y1 - textBbox.y0);
    if (textArea > 0 && overlapArea / textArea > 0.4) {
      return true;
    }
  }
  return false;
}

export async function recognizeTextInImage(
  imageUrl: string
): Promise<OCRTextRegion[]> {
  const worker = await getWorker();
  const { data } = await worker.recognize(imageUrl);
  const regions: OCRTextRegion[] = [];

  const MIN_CONFIDENCE = 55;

  // Tesseract v7: Page → blocks → paragraphs → lines → words
  if (data.blocks && data.blocks.length > 0) {
    for (const block of data.blocks) {
      if (!block.paragraphs) continue;
      for (const para of block.paragraphs) {
        if (!para.lines) continue;
        for (const line of para.lines) {
          if (!line.text || !line.text.trim()) continue;
          if (line.confidence < MIN_CONFIDENCE) continue;

          const cleaned = cleanText(line.text);
          if (!cleaned || isGarbageText(cleaned)) continue;

          regions.push({
            text: cleaned,
            bbox: line.bbox,
            confidence: line.confidence,
          });
        }
      }
    }
  }

  // NO raw-text fallback — the old fallback created garbage from all text
  return regions;
}

// Recognize text but ONLY within detected speech bubble regions
export async function recognizeTextInBubbles(
  imageUrl: string
): Promise<{ regions: OCRTextRegion[]; bubbleRegions: DetectedRegion[]; imageWidth: number; imageHeight: number }> {
  // Load image to get dimensions
  const img = new Image();
  img.crossOrigin = 'anonymous';
  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = imageUrl;
  });

  const imageWidth = img.naturalWidth;
  const imageHeight = img.naturalHeight;
  if (imageWidth === 0 || imageHeight === 0) {
    return { regions: [], bubbleRegions: [], imageWidth: 0, imageHeight: 0 };
  }

  // Step 1: Detect speech bubble regions using canvas analysis
  const bubbleRegions = await detectSpeechBubbleRegions(imageUrl, imageWidth, imageHeight);

  // Step 2: Run OCR on the full image
  const allRegions = await recognizeTextInImage(imageUrl);

  if (allRegions.length === 0) {
    return { regions: [], bubbleRegions, imageWidth, imageHeight };
  }

  // Step 3: If we detected bubble regions, filter OCR text to only keep text inside bubbles
  if (bubbleRegions.length > 0) {
    const filteredRegions = allRegions.filter((r) => isInsideBubble(r.bbox, bubbleRegions));
    return { regions: filteredRegions, bubbleRegions, imageWidth, imageHeight };
  }

  // Step 4: If no bubble regions detected (dark/colored bubbles), apply strict filtering only
  // This is more conservative — only keep high-confidence text
  const strictRegions = allRegions.filter((r) => r.confidence >= 85 && !isGarbageText(r.text));
  return { regions: strictRegions, bubbleRegions: [], imageWidth, imageHeight };
}

function groupRegionsIntoBubbles(
  regions: OCRTextRegion[],
  imageWidth: number,
  imageHeight: number
): Array<{ text: string; x: number; y: number; width: number; height: number }> {
  if (regions.length === 0) return [];

  const padding = 10;
  const lineTolerance = imageHeight * 0.02;

  const sorted = [...regions].sort((a, b) => {
    const yDiff = Math.abs(a.bbox.y0 - b.bbox.y0);
    if (yDiff < lineTolerance) {
      return a.bbox.x0 - b.bbox.x0;
    }
    return a.bbox.y0 - b.bbox.y0;
  });

  const lines: OCRTextRegion[][] = [];
  let currentLine: OCRTextRegion[] = [sorted[0]];

  for (let i = 1; i < sorted.length; i++) {
    const prev = currentLine[currentLine.length - 1];
    const curr = sorted[i];
    if (Math.abs(curr.bbox.y0 - prev.bbox.y0) < lineTolerance) {
      currentLine.push(curr);
    } else {
      lines.push(currentLine);
      currentLine = [curr];
    }
  }
  lines.push(currentLine);

  const bubbles: Array<{ text: string; x: number; y: number; width: number; height: number }> = [];
  let currentBubbleLines: OCRTextRegion[][] = [];
  let currentBubbleText: string[] = [];

  for (const line of lines) {
    const lineText = line.map((r) => r.text).join(' ').trim();
    const lineY0 = Math.min(...line.map((r) => r.bbox.y0));
    const lineY1 = Math.max(...line.map((r) => r.bbox.y1));
    const lineX0 = Math.min(...line.map((r) => r.bbox.x0));
    const lineX1 = Math.max(...line.map((r) => r.bbox.x1));

    if (currentBubbleLines.length === 0) {
      currentBubbleLines = [line];
      currentBubbleText = [lineText];
      continue;
    }

    const prevLine = currentBubbleLines[currentBubbleLines.length - 1];
    const prevY1 = Math.max(...prevLine.map((r) => r.bbox.y1));
    const prevX0 = Math.min(...prevLine.map((r) => r.bbox.x0));
    const prevX1 = Math.max(...prevLine.map((r) => r.bbox.x1));
    const xOverlap = Math.min(lineX1, prevX1) - Math.max(lineX0, prevX0);
    const minWidth = Math.min(lineX1 - lineX0, prevX1 - prevX0);
    const xOverlapRatio = minWidth > 0 ? xOverlap / minWidth : 0;
    const yGap = lineY0 - prevY1;

    if (yGap < lineTolerance * 2 && (xOverlapRatio > 0.3 || yGap < lineTolerance * 0.5)) {
      currentBubbleLines.push(line);
      currentBubbleText.push(lineText);
    } else {
      if (currentBubbleText.length > 0) {
        bubbles.push(createBubble(currentBubbleLines, currentBubbleText, imageWidth, imageHeight, padding));
      }
      currentBubbleLines = [line];
      currentBubbleText = [lineText];
    }
  }

  if (currentBubbleText.length > 0) {
    bubbles.push(createBubble(currentBubbleLines, currentBubbleText, imageWidth, imageHeight, padding));
  }

  return bubbles.filter((b) => b.text.length > 1);
}

function createBubble(
  lines: OCRTextRegion[][],
  texts: string[],
  imageWidth: number,
  imageHeight: number,
  padding: number
): { text: string; x: number; y: number; width: number; height: number } {
  const allRegions = lines.flat();
  const x0 = Math.min(...allRegions.map((r) => r.bbox.x0)) - padding;
  const y0 = Math.min(...allRegions.map((r) => r.bbox.y0)) - padding;
  const x1 = Math.max(...allRegions.map((r) => r.bbox.x1)) + padding;
  const y1 = Math.max(...allRegions.map((r) => r.bbox.y1)) + padding;

  const detectedLang = detectLanguage(texts.join(' '));
  const isRtl = detectedLang === 'ku' || detectedLang === 'ar' || detectedLang === 'fa';

  return {
    text: isRtl ? texts.reverse().join('\n') : texts.join('\n'),
    x: Math.max(0, x0) / imageWidth,
    y: Math.max(0, y0) / imageHeight,
    width: Math.min(imageWidth, x1 - x0) / imageWidth,
    height: Math.min(imageHeight, y1 - y0) / imageHeight,
  };
}

export async function autoOCRPanel(
  imageUrl: string,
  panelId: string
): Promise<Array<{ text: string; x: number; y: number; width: number; height: number }>> {
  try {
    const { regions, imageWidth, imageHeight } = await recognizeTextInBubbles(imageUrl);

    if (regions.length === 0 || imageWidth === 0 || imageHeight === 0) return [];

    const bubbles = groupRegionsIntoBubbles(regions, imageWidth, imageHeight);
    return bubbles;
  } catch (err) {
    console.error('OCR failed for panel:', err);
    return [];
  }
}

export async function autoOCRAndSaveBubbles(
  imageUrl: string,
  panelId: string
): Promise<ComicSpeechBubble[]> {
  const { data: existing } = await supabase
    .from('comic_speech_bubbles')
    .select('id, text')
    .eq('panel_id', panelId);

  if (existing && existing.length > 0 && existing.every((b: any) => b.text && b.text.trim())) {
    const { data } = await supabase
      .from('comic_speech_bubbles')
      .select('*, character:comic_characters(*)')
      .eq('panel_id', panelId)
      .order('bubble_order', { ascending: true });
    return (data as ComicSpeechBubble[]) || [];
  }

  if (existing && existing.length > 0) {
    await supabase.from('comic_speech_bubbles').delete().eq('panel_id', panelId);
  }

  const bubbleRegions = await autoOCRPanel(imageUrl, panelId);
  if (bubbleRegions.length === 0) return [];

  const inserts = bubbleRegions.map((b, i) => ({
    panel_id: panelId,
    text: b.text,
    character_id: null,
    region_x: b.x,
    region_y: b.y,
    region_width: b.width,
    region_height: b.height,
    bubble_order: i,
  }));

  const { data: saved } = await supabase
    .from('comic_speech_bubbles')
    .insert(inserts)
    .select('*, character:comic_characters(*)');

  return (saved as ComicSpeechBubble[]) || [];
}

export async function reOCRPanel(
  imageUrl: string,
  panelId: string
): Promise<ComicSpeechBubble[]> {
  await supabase.from('comic_speech_bubbles').delete().eq('panel_id', panelId);

  const bubbleRegions = await autoOCRPanel(imageUrl, panelId);
  if (bubbleRegions.length === 0) return [];

  const inserts = bubbleRegions.map((b, i) => ({
    panel_id: panelId,
    text: b.text,
    character_id: null,
    region_x: b.x,
    region_y: b.y,
    region_width: b.width,
    region_height: b.height,
    bubble_order: i,
  }));

  const { data: saved } = await supabase
    .from('comic_speech_bubbles')
    .insert(inserts)
    .select('*, character:comic_characters(*)');

  return (saved as ComicSpeechBubble[]) || [];
}
