import { useRef, useState, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export type CallState = 'idle' | 'calling' | 'incoming' | 'connected' | 'ended';

interface VoiceCallConfig {
  userId: string;
  otherUserId: string;
  conversationId: string;
}

interface VoiceChatHook {
  callState: CallState;
  micEnabled: boolean;
  speakerEnabled: boolean;
  callDuration: number;
  startCall: () => Promise<void>;
  acceptCall: () => Promise<void>;
  declineCall: () => void;
  endCall: () => void;
  toggleMic: () => void;
  toggleSpeaker: () => void;
  incomingFrom: string | null;
}

export function useVoiceCall({ userId, otherUserId, conversationId }: VoiceCallConfig): VoiceChatHook {
  const [callState, setCallState] = useState<CallState>('idle');
  const [micEnabled, setMicEnabled] = useState(true);
  const [speakerEnabled, setSpeakerEnabled] = useState(true);
  const [callDuration, setCallDuration] = useState(0);
  const [incomingFrom, setIncomingFrom] = useState<string | null>(null);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const channelRef = useRef<any>(null);
  const isCallerRef = useRef(false);
  const pendingOfferRef = useRef<any>(null);
  const configRef = useRef({ userId, otherUserId, conversationId });
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const ringtoneRef = useRef<HTMLAudioElement | null>(null);
  const speakerRef = useRef(true);

  useEffect(() => {
    speakerRef.current = speakerEnabled;
  }, [speakerEnabled]);

  useEffect(() => {
    configRef.current = { userId, otherUserId, conversationId };
  }, [userId, otherUserId, conversationId]);

  const startTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    setCallDuration(0);
    timerRef.current = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
  }, []);

  const stopTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setCallDuration(0);
  }, []);

  const playRingtone = useCallback(() => {
    try {
      const audio = new Audio('data:audio/wav;base64,UQkBAFIGA1BSQAFiUWAGAENBRkE/w8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8P/AAA=');
      audio.loop = true;
      audio.volume = 0.5;
      audio.play().catch(() => {});
      ringtoneRef.current = audio;
    } catch {}
  }, []);

  const stopRingtone = useCallback(() => {
    if (ringtoneRef.current) {
      ringtoneRef.current.pause();
      ringtoneRef.current = null;
    }
  }, []);

  const setupChannel = useCallback(() => {
    if (channelRef.current) return channelRef.current;

    const channel = supabase.channel(`voice:${conversationId}`);

    channel
      .on('broadcast', { event: 'offer' }, ({ payload }) => {
        if (payload.to !== configRef.current.userId) return;
        pendingOfferRef.current = payload.sdp;
        setIncomingFrom(payload.from);
        setCallState('incoming');
        playRingtone();
      })
      .on('broadcast', { event: 'answer' }, async ({ payload }) => {
        if (payload.to !== configRef.current.userId) return;
        const pc = pcRef.current;
        if (pc && payload.sdp) {
          try {
            await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
            setCallState('connected');
            startTimer();
          } catch (e) {
            console.error('Failed to set remote answer:', e);
          }
        }
      })
      .on('broadcast', { event: 'ice' }, async ({ payload }) => {
        if (payload.to !== configRef.current.userId) return;
        const pc = pcRef.current;
        if (pc && payload.candidate) {
          try {
            await pc.addIceCandidate(new RTCIceCandidate(payload.candidate));
          } catch {}
        }
      })
      .on('broadcast', { event: 'decline' }, ({ payload }) => {
        if (payload.to !== configRef.current.userId) return;
        stopRingtone();
        cleanup();
        setCallState('ended');
        setTimeout(() => setCallState('idle'), 2000);
      })
      .on('broadcast', { event: 'end' }, ({ payload }) => {
        if (payload.to !== configRef.current.userId) return;
        stopRingtone();
        cleanup();
        setCallState('ended');
        setTimeout(() => setCallState('idle'), 2000);
      })
      .subscribe();

    channelRef.current = channel;
    return channel;
  }, [conversationId, playRingtone, stopRingtone, startTimer]);

  const cleanup = useCallback(() => {
    stopRingtone();
    stopTimer();
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
    }
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    if (remoteAudioRef.current) {
      remoteAudioRef.current.srcObject = null;
      remoteAudioRef.current = null;
    }
    pendingOfferRef.current = null;
    setMicEnabled(true);
    setSpeakerEnabled(true);
  }, [stopRingtone, stopTimer]);

  const createPeerConnection = useCallback(() => {
    const pc = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' },
        { urls: 'stun:stun2.l.google.com:19302' },
        { urls: 'stun:stun3.l.google.com:19302' },
      ],
    });

    pc.onicecandidate = (event) => {
      if (event.candidate && channelRef.current) {
        channelRef.current.send({
          type: 'broadcast',
          event: 'ice',
          payload: {
            from: configRef.current.userId,
            to: configRef.current.otherUserId,
            candidate: event.candidate.toJSON(),
          },
        });
      }
    };

    pc.ontrack = (event) => {
      const audio = remoteAudioRef.current || new Audio();
      audio.srcObject = event.streams[0];
      audio.autoplay = true;
      audio.volume = speakerRef.current ? 1.0 : 0.0;
      audio.play().catch(() => {});
      remoteAudioRef.current = audio;
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
        cleanup();
        setCallState('ended');
        setTimeout(() => setCallState('idle'), 2000);
      }
    };

    pcRef.current = pc;
    return pc;
  }, [cleanup]);

  const startCall = useCallback(async () => {
    const channel = setupChannel();
    isCallerRef.current = true;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      localStreamRef.current = stream;

      const pc = createPeerConnection();
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      setCallState('calling');

      channel.send({
        type: 'broadcast',
        event: 'offer',
        payload: {
          from: configRef.current.userId,
          to: configRef.current.otherUserId,
          sdp: { type: offer.type, sdp: offer.sdp },
        },
      });
    } catch (err) {
      console.error('Failed to start call:', err);
      cleanup();
      setCallState('idle');
    }
  }, [setupChannel, createPeerConnection, cleanup]);

  const acceptCall = useCallback(async () => {
    const channel = setupChannel();
    stopRingtone();

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      localStreamRef.current = stream;

      const pc = createPeerConnection();
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      const offerSdp = pendingOfferRef.current;
      if (!offerSdp) {
        cleanup();
        setCallState('idle');
        return;
      }

      await pc.setRemoteDescription(new RTCSessionDescription(offerSdp));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      setCallState('connected');
      startTimer();

      channel.send({
        type: 'broadcast',
        event: 'answer',
        payload: {
          from: configRef.current.userId,
          to: configRef.current.otherUserId,
          sdp: { type: answer.type, sdp: answer.sdp },
        },
      });

      pendingOfferRef.current = null;
    } catch (err) {
      console.error('Failed to accept call:', err);
      cleanup();
      setCallState('idle');
    }
  }, [setupChannel, createPeerConnection, cleanup, stopRingtone, startTimer]);

  const declineCall = useCallback(() => {
    stopRingtone();
    if (channelRef.current) {
      channelRef.current.send({
        type: 'broadcast',
        event: 'decline',
        payload: {
          from: configRef.current.userId,
          to: configRef.current.otherUserId,
        },
      });
    }
    pendingOfferRef.current = null;
    setIncomingFrom(null);
    setCallState('idle');
  }, [stopRingtone]);

  const endCall = useCallback(() => {
    if (channelRef.current) {
      channelRef.current.send({
        type: 'broadcast',
        event: 'end',
        payload: {
          from: configRef.current.userId,
          to: configRef.current.otherUserId,
        },
      });
    }
    cleanup();
    setCallState('ended');
    setTimeout(() => setCallState('idle'), 1500);
  }, [cleanup]);

  const toggleMic = useCallback(() => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setMicEnabled(audioTrack.enabled);
      }
    }
  }, []);

  const toggleSpeaker = useCallback(() => {
    setSpeakerEnabled((prev) => {
      const newVal = !prev;
      if (remoteAudioRef.current) {
        remoteAudioRef.current.volume = newVal ? 1.0 : 0.0;
      }
      return newVal;
    });
  }, []);

  // Proactively set up channel to listen for incoming calls
  useEffect(() => {
    if (!conversationId || !userId) return;
    setupChannel();
    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
  }, [conversationId, userId, setupChannel]);

  useEffect(() => {
    return () => {
      cleanup();
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
  }, [cleanup]);

  return {
    callState,
    micEnabled,
    speakerEnabled,
    callDuration,
    startCall,
    acceptCall,
    declineCall,
    endCall,
    toggleMic,
    toggleSpeaker,
    incomingFrom,
  };
}
