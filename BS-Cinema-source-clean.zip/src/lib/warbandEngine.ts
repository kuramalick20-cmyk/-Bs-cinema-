import type {
  GameCharacter, WorldLocation, Faction, Item, Companion, Enemy,
  Quest, MarriageCandidate, WarbandGameState, BattleLogEntry, CombatAction,
  FactionId, LocationType, WeaponType, CharacterRole, ArmyUnit,
} from './warbandTypes';

// === Character Definitions (6 main characters) ===

export const CHARACTERS: GameCharacter[] = [
  {
    id: 'aris',
    name: 'ARIS',
    title: 'King of Greece',
    description: 'Long red hair, red eyes, a cold and charismatic warrior-king. His presence is godlike on the battlefield.',
    faction: 'greece',
    role: 'leader',
    weapon: 'sword',
    hairColor: '#cc2222',
    eyeColor: '#cc0000',
    faceType: 'cold',
    appearance: 'Tall, muscular, long flowing red hair, crimson eyes, golden armor with laurel crown',
    personality: 'Cold, calculating, fiercely charismatic. Commands absolute loyalty.',
    abilities: ['Sword Mastery', 'Battle Cry', 'Royal Authority', 'Phalanx Formation'],
    isPlayable: true,
    level: 10,
    hp: 120,
    maxHp: 120,
    attack: 35,
    defense: 28,
    speed: 22,
    leadership: 40,
    charisma: 35,
    portraitColor: '#8b0000',
    accentColor: '#ffcc00',
  },
  {
    id: 'khasraw',
    name: 'KHASRAW',
    title: 'Champion of Kurdistan',
    description: 'Long black hair, piercing yellow eyes, a cold and powerful warrior with a godlike presence.',
    faction: 'kurdistan',
    role: 'leader',
    weapon: 'sword',
    hairColor: '#1a1a1a',
    eyeColor: '#d4a017',
    faceType: 'cold',
    appearance: 'Tall, broad-shouldered, long black hair, golden-yellow eyes, dark iron armor with golden trim',
    personality: 'Cold, silent, fiercely protective of his people. His charisma is undeniable.',
    abilities: ['Sword Mastery', 'Mountain Strength', 'Warlord\'s Roar', 'Kurdish Fury'],
    isPlayable: true,
    level: 10,
    hp: 125,
    maxHp: 125,
    attack: 36,
    defense: 30,
    speed: 20,
    leadership: 38,
    charisma: 36,
    portraitColor: '#2a2a3e',
    accentColor: '#d4a017',
  },
  {
    id: 'darius',
    name: 'DARIUS',
    title: 'Shadow of Persia',
    description: 'A cunning archer-strategist with short dark hair and piercing green eyes. Master of the bow and political intrigue.',
    faction: 'persia',
    role: 'archer',
    weapon: 'bow',
    hairColor: '#2a2a2a',
    eyeColor: '#2bb24c',
    faceType: 'sharp',
    appearance: 'Lean, agile, short dark hair, emerald green eyes, dark leather armor with silver accents',
    personality: 'Cunning, patient, strategic. Prefers to win battles before they start.',
    abilities: ['Precision Shot', 'Poison Arrow', 'Tactical Mind', 'Persian Ambush'],
    isPlayable: true,
    level: 8,
    hp: 90,
    maxHp: 90,
    attack: 32,
    defense: 18,
    speed: 30,
    leadership: 28,
    charisma: 30,
    portraitColor: '#1a4a2a',
    accentColor: '#c0c0c0',
  },
  {
    id: 'nefera',
    name: 'NEFERA',
    title: 'Sorceress of Egypt',
    description: 'A mysterious healer-mage with braided black hair and deep violet eyes. Wields ancient magic and the mace.',
    faction: 'egypt',
    role: 'healer',
    weapon: 'mace',
    hairColor: '#1a1a2a',
    eyeColor: '#8a2be2',
    faceType: 'mystical',
    appearance: 'Slender, elegant, long braided black hair with gold threads, violet eyes, white linen robes with golden jewelry',
    personality: 'Mysterious, wise, compassionate but stern. Her magic heals allies and curses enemies.',
    abilities: ['Healing Light', 'Curse of Anubis', 'Desert Mirage', 'Royal Blessing'],
    isPlayable: true,
    level: 8,
    hp: 85,
    maxHp: 85,
    attack: 24,
    defense: 20,
    speed: 25,
    leadership: 22,
    charisma: 38,
    portraitColor: '#4a3a6a',
    accentColor: '#ffd700',
  },
  {
    id: 'maximus',
    name: 'MAXIMUS',
    title: 'Bulwark of Rome',
    description: 'A towering cavalry commander with shaved head and steel-grey eyes. Unbreakable shield-wall specialist.',
    faction: 'rome',
    role: 'cavalry',
    weapon: 'spear',
    hairColor: '#5a5a5a',
    eyeColor: '#888888',
    faceType: 'stoic',
    appearance: 'Massive, muscular, shaved head, grey eyes, bronze legionary armor with red cape',
    personality: 'Stoic, disciplined, unbreakable. His shield wall has never been breached.',
    abilities: ['Shield Bash', 'Cavalry Charge', 'Roman Discipline', 'Testudo Formation'],
    isPlayable: true,
    level: 9,
    hp: 110,
    maxHp: 110,
    attack: 30,
    defense: 35,
    speed: 18,
    leadership: 32,
    charisma: 25,
    portraitColor: '#6a4a2a',
    accentColor: '#cc2222',
  },
  {
    id: 'erik',
    name: 'ERIK',
    title: 'Frost Wolf of the North',
    description: 'A fierce scout-warrior with long blonde braids and ice-blue eyes. Wields a massive battle axe.',
    faction: 'nord',
    role: 'scout',
    weapon: 'axe',
    hairColor: '#daa520',
    eyeColor: '#4169e1',
    faceType: 'wild',
    appearance: 'Tall, wiry, long blonde braided hair, ice-blue eyes, fur armor with iron plates',
    personality: 'Wild, fearless, unpredictable. Lives for the thrill of battle.',
    abilities: ['Berserker Rage', 'Frost Strike', 'Wolf Howl', 'Nordic Sprint'],
    isPlayable: true,
    level: 9,
    hp: 100,
    maxHp: 100,
    attack: 34,
    defense: 22,
    speed: 28,
    leadership: 24,
    charisma: 27,
    portraitColor: '#2a3a5a',
    accentColor: '#daa520',
  },
];

// === Factions ===

export const FACTIONS: Faction[] = [
  { id: 'greece', name: 'Kingdom of Greece', color: '#8b0000', banner: 'Λ', description: 'Disciplined hoplites and naval power.', territories: 0, atWarWith: ['persia'], atPeaceWith: ['kurdistan', 'egypt'], strength: 80 },
  { id: 'kurdistan', name: 'Kurdish Realm', color: '#d4a017', banner: '☀', description: 'Mountain warriors and fierce cavalry.', territories: 0, atWarWith: ['persia'], atPeaceWith: ['greece', 'rome'], strength: 75 },
  { id: 'persia', name: 'Persian Empire', color: '#1a4a2a', banner: '✦', description: 'Archers, cavalry, and vast wealth.', territories: 0, atWarWith: ['greece', 'kurdistan'], atPeaceWith: ['egypt'], strength: 85 },
  { id: 'egypt', name: 'Kingdom of Egypt', color: '#ffd700', banner: '☥', description: 'Mystical healers and desert warriors.', territories: 0, atWarWith: ['rome'], atPeaceWith: ['greece', 'persia'], strength: 70 },
  { id: 'rome', name: 'Roman Republic', color: '#cc2222', banner: 'SPQR', description: 'Legionaries, siege engines, and roads.', territories: 0, atWarWith: ['egypt', 'nord'], atPeaceWith: ['kurdistan'], strength: 90 },
  { id: 'nord', name: 'Nordic Clans', color: '#2a3a5a', banner: 'ᚱ', description: 'Berserkers, longships, and frost magic.', territories: 0, atWarWith: ['rome'], atPeaceWith: ['kurdistan', 'greece'], strength: 72 },
];

// === World Map Locations ===

export const LOCATIONS: WorldLocation[] = [
  // Greece
  { id: 'athens', name: 'Athens', type: 'city', faction: 'greece', x: 55, y: 35, garrison: 50, wealth: 300, isCapital: true, description: 'The jewel of Greece, home of philosophers and warriors.', visited: false },
  { id: 'sparta', name: 'Sparta', type: 'castle', faction: 'greece', x: 50, y: 42, garrison: 40, wealth: 200, isCapital: false, description: 'A militaristic city-state with fierce warriors.', visited: false },
  { id: 'thebes', name: 'Thebes', type: 'village', faction: 'greece', x: 58, y: 38, garrison: 15, wealth: 80, isCapital: false, description: 'A trading village in central Greece.', visited: false },

  // Kurdistan
  { id: 'erbil', name: 'Erbil', type: 'city', faction: 'kurdistan', x: 40, y: 35, garrison: 45, wealth: 250, isCapital: true, description: 'The ancient citadel city of Kurdistan.', visited: false },
  { id: 'kirkuk', name: 'Kirkuk', type: 'castle', faction: 'kurdistan', x: 38, y: 40, garrison: 35, wealth: 180, isCapital: false, description: 'A fortified city at the crossroads of empires.', visited: false },
  { id: 'sulay', name: 'Sulaymaniyah', type: 'village', faction: 'kurdistan', x: 43, y: 33, garrison: 12, wealth: 70, isCapital: false, description: 'A cultural mountain village.', visited: false },

  // Persia
  { id: 'persepolis', name: 'Persepolis', type: 'city', faction: 'persia', x: 60, y: 55, garrison: 60, wealth: 400, isCapital: true, description: 'The magnificent capital of the Persian Empire.', visited: false },
  { id: 'babylon', name: 'Babylon', type: 'castle', faction: 'persia', x: 52, y: 50, garrison: 45, wealth: 300, isCapital: false, description: 'Ancient city of hanging gardens.', visited: false },
  { id: 'susa', name: 'Susa', type: 'village', faction: 'persia', x: 56, y: 48, garrison: 18, wealth: 100, isCapital: false, description: 'A royal Persian residence.', visited: false },

  // Egypt
  { id: 'alexandria', name: 'Alexandria', type: 'city', faction: 'egypt', x: 30, y: 60, garrison: 40, wealth: 280, isCapital: true, description: 'The great Mediterranean port of Egypt.', visited: false },
  { id: 'memphis', name: 'Memphis', type: 'castle', faction: 'egypt', x: 34, y: 64, garrison: 30, wealth: 200, isCapital: false, description: 'Ancient capital of Lower Egypt.', visited: false },
  { id: 'giza', name: 'Giza', type: 'ruins', faction: 'egypt', x: 32, y: 62, garrison: 8, wealth: 150, isCapital: false, description: 'The great pyramids and hidden treasures.', visited: false },

  // Rome
  { id: 'rome_city', name: 'Rome', type: 'city', faction: 'rome', x: 25, y: 45, garrison: 55, wealth: 350, isCapital: true, description: 'The eternal city, heart of the Republic.', visited: false },
  { id: 'capua', name: 'Capua', type: 'castle', faction: 'rome', x: 28, y: 48, garrison: 35, wealth: 220, isCapital: false, description: 'A fortified Roman colony.', visited: false },
  { id: 'ostia', name: 'Ostia', type: 'village', faction: 'rome', x: 22, y: 47, garrison: 14, wealth: 90, isCapital: false, description: 'Rome\'s port village.', visited: false },

  // Nordic
  { id: 'fjord', name: 'Frostfjord', type: 'city', faction: 'nord', x: 20, y: 20, garrison: 38, wealth: 200, isCapital: true, description: 'The great Nordic harbor city.', visited: false },
  { id: 'ironhold', name: 'Ironhold', type: 'castle', faction: 'nord', x: 24, y: 24, garrison: 30, wealth: 150, isCapital: false, description: 'A mountain fortress of the north.', visited: false },
  { id: 'wolves', name: 'Wolf\'s Den', type: 'village', faction: 'nord', x: 18, y: 26, garrison: 10, wealth: 60, isCapital: false, description: 'A remote hunting village.', visited: false },

  // Neutral/contested
  { id: 'darkwood', name: 'Darkwood Forest', type: 'forest', faction: 'persia', x: 48, y: 45, garrison: 5, wealth: 30, isCapital: false, description: 'A dense forest hiding bandits and treasures.', visited: false },
  { id: 'stonepeak', name: 'Stonepeak Mountain', type: 'mountain', faction: 'kurdistan', x: 36, y: 28, garrison: 0, wealth: 0, isCapital: false, description: 'A treacherous mountain pass.', visited: false },
  { id: 'battleground', name: 'The Old Battlefield', type: 'field', faction: 'persia', x: 46, y: 52, garrison: 0, wealth: 0, isCapital: false, description: 'An ancient battlefield, haunted by old wars.', visited: false },
];

// === Shop Items ===

export const SHOP_ITEMS: Item[] = [
  { id: 'iron_sword', name: 'Iron Sword', type: 'weapon', weaponType: 'sword', attackBonus: 8, price: 120, description: 'A reliable iron sword.', icon: '⚔' },
  { id: 'steel_sword', name: 'Steel Sword', type: 'weapon', weaponType: 'sword', attackBonus: 15, price: 300, description: 'A finely crafted steel blade.', icon: '⚔' },
  { id: 'war_axe', name: 'War Axe', type: 'weapon', weaponType: 'axe', attackBonus: 18, price: 350, description: 'A devastating battle axe.', icon: '🪓' },
  { id: 'long_bow', name: 'Long Bow', type: 'weapon', weaponType: 'bow', attackBonus: 12, price: 200, description: 'A powerful long-range bow.', icon: '🏹' },
  { id: 'spear', name: 'Battle Spear', type: 'weapon', weaponType: 'spear', attackBonus: 14, price: 250, description: 'A versatile polearm.', icon: '🔱' },
  { id: 'war_mace', name: 'War Mace', type: 'weapon', weaponType: 'mace', attackBonus: 16, price: 280, description: 'A crushing war mace.', icon: '🔨' },
  { id: 'leather_armor', name: 'Leather Armor', type: 'armor', defenseBonus: 8, price: 150, description: 'Light leather protection.', icon: '🦺' },
  { id: 'iron_armor', name: 'Iron Armor', type: 'armor', defenseBonus: 15, hpBonus: 20, price: 400, description: 'Heavy iron plate armor.', icon: '🛡' },
  { id: 'iron_shield', name: 'Iron Shield', type: 'shield', defenseBonus: 10, price: 180, description: 'A sturdy iron shield.', icon: '🛡' },
  { id: 'health_potion', name: 'Health Potion', type: 'potion', hpBonus: 50, price: 50, description: 'Restores 50 HP.', icon: '🧪' },
  { id: 'great_potion', name: 'Great Potion', type: 'potion', hpBonus: 120, price: 120, description: 'Restores 120 HP.', icon: '🧪' },
  { id: 'war_horse', name: 'War Horse', type: 'mount', speedBonus: 15, price: 500, description: 'A trained war horse for fast travel.', icon: '🐎' },
  { id: 'arabian_horse', name: 'Arabian Stallion', type: 'mount', speedBonus: 25, hpBonus: 15, price: 800, description: 'The finest horse in the known world.', icon: '🐎' },
];

// === Companions for hire ===

export const COMPANIONS: Companion[] = [
  { id: 'comp1', name: 'Leonidas', faction: 'greece', role: 'warrior', weapon: 'spear', hp: 80, maxHp: 80, attack: 25, defense: 20, level: 5, recruited: false, cost: 200, description: 'A Spartan hoplite veteran.', portraitColor: '#8b0000' },
  { id: 'comp2', name: 'Rojhat', faction: 'kurdistan', role: 'cavalry', weapon: 'sword', hp: 75, maxHp: 75, attack: 22, defense: 18, level: 5, recruited: false, cost: 200, description: 'A Kurdish mountain rider.', portraitColor: '#d4a017' },
  { id: 'comp3', name: 'Cyrus', faction: 'persia', role: 'archer', weapon: 'bow', hp: 60, maxHp: 60, attack: 20, defense: 12, level: 4, recruited: false, cost: 150, description: 'A Persian marksman.', portraitColor: '#1a4a2a' },
  { id: 'comp4', name: 'Cleopatra', faction: 'egypt', role: 'healer', weapon: 'mace', hp: 55, maxHp: 55, attack: 15, defense: 14, level: 4, recruited: false, cost: 250, description: 'An Egyptian priestess-healer.', portraitColor: '#4a3a6a' },
  { id: 'comp5', name: 'Brutus', faction: 'rome', role: 'warrior', weapon: 'sword', hp: 90, maxHp: 90, attack: 24, defense: 22, level: 6, recruited: false, cost: 300, description: 'A Roman legionary centurion.', portraitColor: '#6a4a2a' },
  { id: 'comp6', name: 'Ragnar', faction: 'nord', role: 'scout', weapon: 'axe', hp: 70, maxHp: 70, attack: 23, defense: 15, level: 5, recruited: false, cost: 180, description: 'A Nordic berserker scout.', portraitColor: '#2a3a5a' },
];

// === Quests ===

export const QUESTS: Quest[] = [
  { id: 'q1', title: 'First Conquest', description: 'Conquer your first castle or city.', type: 'conquer', target: 'any', reward: 200, rewardXp: 100, completed: false },
  { id: 'q2', title: 'Build Your Army', description: 'Recruit your first companion.', type: 'recruit', target: 'any', reward: 150, rewardXp: 80, completed: false },
  { id: 'q3', title: 'Merchant\'s Fortune', description: 'Accumulate 1000 gold.', type: 'trade', target: 'gold:1000', reward: 300, rewardXp: 120, completed: false },
  { id: 'q4', title: 'Warlord', description: 'Win 5 battles.', type: 'battle', target: 'battles:5', reward: 250, rewardXp: 150, completed: false },
  { id: 'q5', title: 'Alliance by Marriage', description: 'Marry an NPC for political alliance.', type: 'marry', target: 'any', reward: 400, rewardXp: 200, completed: false },
  { id: 'q6', title: 'Explorer', description: 'Visit 10 different locations.', type: 'explore', target: 'locations:10', reward: 200, rewardXp: 100, completed: false },
  { id: 'q7', title: 'Empire Builder', description: 'Conquer 5 territories.', type: 'conquer', target: 'territories:5', reward: 500, rewardXp: 300, completed: false },
  { id: 'q8', title: 'Champion of the Realm', description: 'Reach level 15.', type: 'battle', target: 'level:15', reward: 600, rewardXp: 400, completed: false },
];

// === Marriage Candidates ===

export const MARRIAGE_CANDIDATES: MarriageCandidate[] = [
  { id: 'm1', name: 'Princess Helena', faction: 'greece', description: 'Beautiful and wise princess of Athens.', dowry: 500, charmRequired: 25, married: false, portraitColor: '#8b0000', benefit: '+5 Charisma, +200 gold dowry' },
  { id: 'm2', name: 'Lady Shilan', faction: 'kurdistan', description: 'Noble Kurdish lady from Erbil.', dowry: 400, charmRequired: 22, married: false, portraitColor: '#d4a017', benefit: '+3 Leadership, +150 gold dowry' },
  { id: 'm3', name: 'Princess Roxana', faction: 'persia', description: 'Exotic Persian princess with secret knowledge.', dowry: 600, charmRequired: 30, married: false, portraitColor: '#1a4a2a', benefit: '+5 Charisma, +300 gold dowry' },
  { id: 'm4', name: 'Lady Neith', faction: 'egypt', description: 'Egyptian noblewoman with healing gifts.', dowry: 450, charmRequired: 24, married: false, portraitColor: '#4a3a6a', benefit: '+10 Max HP, +200 gold dowry' },
  { id: 'm5', name: 'Lady Livia', faction: 'rome', description: 'Roman patrician with political connections.', dowry: 550, charmRequired: 28, married: false, portraitColor: '#6a4a2a', benefit: '+4 Leadership, +250 gold dowry' },
  { id: 'm6', name: 'Shieldmaiden Astrid', faction: 'nord', description: 'Fierce Nordic warrior woman.', dowry: 350, charmRequired: 20, married: false, portraitColor: '#2a3a5a', benefit: '+5 Attack, +150 gold dowry' },
];

// === Initial State ===

export function createInitialState(selectedChar: GameCharacter): WarbandGameState {
  const locations = LOCATIONS.map(l => ({ ...l }));
  const factions = FACTIONS.map(f => ({
    ...f,
    territories: locations.filter(l => l.faction === f.id).length,
  }));

  // Player starts at their faction's capital
  const capital = locations.find(l => l.faction === selectedChar.faction && l.isCapital) || locations[0];
  capital.visited = true;

  return {
    screen: 'world-map',
    selectedCharacter: selectedChar,
    characters: CHARACTERS,
    gold: 300,
    xp: 0,
    level: selectedChar.level,
    day: 1,
    hp: selectedChar.hp,
    maxHp: selectedChar.maxHp,
    attack: selectedChar.attack,
    defense: selectedChar.defense,
    speed: selectedChar.speed,
    leadership: selectedChar.leadership,
    charisma: selectedChar.charisma,
    currentLocationId: capital.id,
    locations,
    factions,
    inventory: [
      { id: 'starter_weapon', name: 'Bronze Sword', type: 'weapon', weaponType: 'sword', attackBonus: 5, price: 0, description: 'A basic bronze sword.', icon: '⚔', qty: 1 },
      { id: 'starter_potion', name: 'Health Potion', type: 'potion', hpBonus: 50, price: 50, description: 'Restores 50 HP.', icon: '🧪', qty: 3 },
    ],
    equippedWeapon: { id: 'starter_weapon', name: 'Bronze Sword', type: 'weapon', weaponType: 'sword', attackBonus: 5, price: 0, description: 'A basic bronze sword.', icon: '⚔', qty: 1 },
    equippedArmor: null,
    equippedShield: null,
    mount: null,
    army: [{ type: 'infantry', count: 10, faction: selectedChar.faction }],
    companions: COMPANIONS.map(c => ({ ...c })),
    quests: QUESTS.map(q => ({ ...q })),
    marriageCandidates: MARRIAGE_CANDIDATES.map(m => ({ ...m })),
    marriedTo: null,
    battleEnemy: null,
    battleEnemies: [],
    battleLog: [],
    battleIndex: 0,
    companionsInBattle: [],
    dialogueNode: null,
    worldX: capital.x,
    worldY: capital.y,
    isTraveling: false,
    travelTarget: null,
    message: null,
    ownedTerritories: [],
    playerFaction: selectedChar.faction,
    totalBattlesWon: 0,
    totalCastlesConquered: 0,
    cameraMode: 'third-person',
    player3D: { x: 0, z: 0, vx: 0, vz: 0, angle: 0, camYaw: 0, camPitch: 0.3, camDist: 6, isMoving: false, isRunning: false, isBlocking: false, isMounted: false, attackCooldown: 0, attackAnim: 0, blockAnim: 0, dodgeAnim: 0, hitFlash: 0, currentHp: selectedChar.hp },
    worldEntities: [],
    nearbyLocationId: null,
    combatLog: [],
    joystickActive: false,
    joystickDX: 0,
    joystickDY: 0,
  };
}

// === Combat Engine ===

let battleLogCounter = 0;

function makeLog(text: string, type: BattleLogEntry['type']): BattleLogEntry {
  return { id: battleLogCounter++, text, type };
}

export function generateEnemy(faction: FactionId, level: number, locationType: string): Enemy {
  const factionData = FACTIONS.find(f => f.id === faction) || FACTIONS[0];
  const roles: CharacterRole[] = ['warrior', 'archer', 'cavalry', 'scout'];
  const weapons: WeaponType[] = ['sword', 'axe', 'spear', 'bow', 'mace'];
  const role = roles[Math.floor(Math.random() * roles.length)];
  const weapon = weapons[Math.floor(Math.random() * weapons.length)];
  const isLeader = locationType === 'castle' || locationType === 'city';

  const baseHp = isLeader ? 100 : 60;
  const baseAtk = isLeader ? 28 : 18;
  const baseDef = isLeader ? 22 : 12;

  const names: Record<FactionId, string[]> = {
    greece: ['Achilles', 'Hector', 'Agamemnon', 'Ajax'],
    kurdistan: ['Salahaddin', 'Karim', 'Diyar', 'Hawar'],
    persia: ['Xerxes', 'Darius', 'Cambyses', 'Artaxerxes'],
    egypt: ['Ramses', 'Tutankhamun', 'Akhenaten', 'Thutmose'],
    rome: ['Caesar', 'Pompey', 'Crassus', 'Augustus'],
    nord: ['Odin', 'Thor', 'Bjorn', 'Ivar'],
  };
  const nameList = names[faction] || names.greece;
  const name = nameList[Math.floor(Math.random() * nameList.length)] + (isLeader ? ' (Commander)' : '');

  return {
    id: `enemy_${Date.now()}_${Math.random()}`,
    name,
    faction,
    hp: baseHp + level * 8,
    maxHp: baseHp + level * 8,
    attack: baseAtk + level * 3,
    defense: baseDef + level * 2,
    speed: 15 + level * 2,
    weapon,
    role,
    level,
    isLeader,
    portraitColor: factionData.color,
    accentColor: factionData.color,
  };
}

export function generateBattleEnemies(state: WarbandGameState): Enemy[] {
  const loc = state.locations.find(l => l.id === state.currentLocationId);
  if (!loc) return [];
  const count = loc.type === 'city' ? 3 : loc.type === 'castle' ? 2 : 1;
  const enemies: Enemy[] = [];
  for (let i = 0; i < count; i++) {
    enemies.push(generateEnemy(loc.faction, state.level, loc.type));
  }
  return enemies;
}

export function startBattle(state: WarbandGameState): WarbandGameState {
  const enemies = generateBattleEnemies(state);
  const recruitedCompanions = state.companions.filter(c => c.recruited);
  battleLogCounter = 0;

  return {
    ...state,
    screen: 'battle',
    battleEnemies: enemies,
    battleEnemy: enemies[0],
    battleIndex: 0,
    companionsInBattle: recruitedCompanions,
    battleLog: [
      makeLog(`Battle begins! ${enemies.length} enemy warrior(s) appear.`, 'system'),
      makeLog(`${enemies[0].name} steps forward!`, 'enemy'),
    ],
  };
}

export function performCombatAction(state: WarbandGameState, action: CombatAction): WarbandGameState {
  if (!state.battleEnemy || state.screen !== 'battle') return state;

  const log = [...state.battleLog];
  let playerHp = state.hp;
  let enemy = { ...state.battleEnemy };
  let goldReward = 0;
  let xpReward = 0;
  let battleEnemies = [...state.battleEnemies];
  let battleIndex = state.battleIndex;
  let companions = [...state.companionsInBattle];

  const playerAttack = state.attack + (state.equippedWeapon?.attackBonus || 0);
  const playerDefense = state.defense + (state.equippedArmor?.defenseBonus || 0) + (state.equippedShield?.defenseBonus || 0);

  // Player turn
  if (action === 'attack') {
    const damage = Math.max(5, playerAttack - enemy.defense + Math.floor(Math.random() * 10) - 5);
    enemy.hp -= damage;
    log.push(makeLog(`You strike ${enemy.name} for ${damage} damage!`, 'player'));
  } else if (action === 'block') {
    log.push(makeLog(`You raise your shield, bracing for impact.`, 'player'));
  } else if (action === 'dodge') {
    log.push(makeLog(`You dodge swiftly!`, 'player'));
  } else if (action === 'special') {
    const damage = Math.max(10, playerAttack * 1.5 - enemy.defense + Math.floor(Math.random() * 15));
    enemy.hp -= Math.floor(damage);
    log.push(makeLog(`You unleash ${state.selectedCharacter.abilities[0]}! ${damage} damage to ${enemy.name}!`, 'player'));
  }

  // Check enemy defeat
  if (enemy.hp <= 0) {
    log.push(makeLog(`${enemy.name} is defeated!`, 'victory'));
    const reward = 50 + enemy.level * 15;
    const xp = 30 + enemy.level * 10;
    goldReward += reward;
    xpReward += xp;
    log.push(makeLog(`+${reward} gold, +${xp} XP`, 'system'));

    battleEnemies[battleIndex] = enemy;
    battleIndex++;

    if (battleIndex >= battleEnemies.length) {
      // All enemies defeated — battle won
      log.push(makeLog(`Victory! All enemies defeated!`, 'victory'));
      const newGold = state.gold + goldReward;
      const newXp = state.xp + xpReward;
      const newLevel = Math.floor(newXp / 200) + 1;
      const levelUp = newLevel > state.level;
      if (levelUp) {
        log.push(makeLog(`Level Up! You are now level ${newLevel}!`, 'system'));
      }

      // Check quest completion
      const totalBattles = state.totalBattlesWon + 1;
      const quests = state.quests.map(q => {
        if (!q.completed && q.type === 'battle' && q.target === 'battles:5' && totalBattles >= 5) {
          return { ...q, completed: true };
        }
        if (!q.completed && q.type === 'battle' && q.target === 'level:15' && newLevel >= 15) {
          return { ...q, completed: true };
        }
        return q;
      });

      return {
        ...state,
        screen: 'world-map',
        hp: playerHp,
        gold: newGold + (levelUp ? 100 : 0),
        xp: newXp,
        level: newLevel,
        maxHp: levelUp ? state.maxHp + 20 : state.maxHp,
        attack: levelUp ? state.attack + 3 : state.attack,
        defense: levelUp ? state.defense + 2 : state.defense,
        battleEnemy: null,
        battleEnemies: [],
        battleLog: [],
        battleIndex: 0,
        companionsInBattle: [],
        totalBattlesWon: totalBattles,
        quests,
        message: `Victory! +${goldReward} gold, +${xpReward} XP${levelUp ? ', Level Up!' : ''}`,
      };
    }

    // Next enemy
    const nextEnemy = battleEnemies[battleIndex];
    log.push(makeLog(`${nextEnemy.name} steps forward!`, 'enemy'));
    return {
      ...state,
      battleEnemies,
      battleEnemy: nextEnemy,
      battleIndex,
      battleLog: log.slice(-12),
      hp: playerHp,
      gold: state.gold + goldReward,
      xp: state.xp + xpReward,
    };
  }

  // Enemy turn
  const enemyAttack = enemy.attack;
  let enemyDamage = 0;
  if (action === 'block') {
    enemyDamage = Math.max(2, Math.floor((enemyAttack - playerDefense - 10) * 0.5));
  } else if (action === 'dodge') {
    if (Math.random() > 0.4) {
      enemyDamage = 0;
      log.push(makeLog(`${enemy.name} attacks but you dodge completely!`, 'system'));
    } else {
      enemyDamage = Math.max(3, enemyAttack - playerDefense);
      log.push(makeLog(`${enemy.name} hits you for ${enemyDamage} damage! (dodge failed)`, 'enemy'));
    }
  } else {
    enemyDamage = Math.max(3, enemyAttack - playerDefense + Math.floor(Math.random() * 8) - 4);
    log.push(makeLog(`${enemy.name} strikes you for ${enemyDamage} damage!`, 'enemy'));
  }
  playerHp -= enemyDamage;

  // Companion turn (each recruited companion attacks)
  for (const comp of companions) {
    if (comp.hp > 0 && enemy.hp > 0) {
      const compDamage = Math.max(3, comp.attack - enemy.defense + Math.floor(Math.random() * 6) - 3);
      enemy.hp -= compDamage;
      log.push(makeLog(`${comp.name} attacks ${enemy.name} for ${compDamage} damage!`, 'companion'));
    }
  }

  // Check player defeat
  if (playerHp <= 0) {
    log.push(makeLog(`You have been defeated...`, 'defeat'));
    const retreatGold = Math.max(0, Math.floor(state.gold * 0.1));
    return {
      ...state,
      screen: 'world-map',
      hp: Math.floor(state.maxHp * 0.3),
      gold: state.gold - retreatGold,
      battleEnemy: null,
      battleEnemies: [],
      battleLog: [],
      battleIndex: 0,
      companionsInBattle: [],
      message: `Defeated! You lost ${retreatGold} gold and retreated.`,
    };
  }

  battleEnemies[battleIndex] = enemy;

  return {
    ...state,
    hp: playerHp,
    battleEnemy: enemy,
    battleEnemies,
    battleLog: log.slice(-15),
  };
}

// === Travel ===

export function travelTo(state: WarbandGameState, locationId: string): WarbandGameState {
  const loc = state.locations.find(l => l.id === locationId);
  if (!loc) return state;
  const current = state.locations.find(l => l.id === state.currentLocationId);
  if (!current) return state;

  const dx = loc.x - current.x;
  const dy = loc.y - current.y;
  const dist = Math.sqrt(dx * dx + dy * dy);
  const speedBonus = state.mount?.speedBonus || 0;
  const travelTime = Math.max(1, Math.ceil(dist / (8 + speedBonus)));

  const newLocations = state.locations.map(l =>
    l.id === locationId ? { ...l, visited: true } : l
  );

  const visitedCount = newLocations.filter(l => l.visited).length;
  const quests = state.quests.map(q => {
    if (!q.completed && q.type === 'explore' && q.target === 'locations:10' && visitedCount >= 10) {
      return { ...q, completed: true };
    }
    return q;
  });

  // Random encounter chance during travel (20%)
  const encounter = Math.random() < 0.2 && loc.faction !== state.playerFaction;

  const newState: WarbandGameState = {
    ...state,
    currentLocationId: locationId,
    locations: newLocations,
    worldX: loc.x,
    worldY: loc.y,
    day: state.day + travelTime,
    screen: loc.type === 'city' || loc.type === 'castle' || loc.type === 'village' ? 'town' : 'world-map',
    quests,
    message: `Arrived at ${loc.name} after ${travelTime} day(s).`,
  };

  if (encounter) {
    return startBattle(newState);
  }

  return newState;
}

// === Conquest ===

export function conquerLocation(state: WarbandGameState): WarbandGameState {
  const loc = state.locations.find(l => l.id === state.currentLocationId);
  if (!loc) return state;
  if (loc.faction === state.playerFaction) return state;

  const newLocations = state.locations.map(l =>
    l.id === loc.id ? { ...l, faction: state.playerFaction, garrison: Math.max(10, l.garrison) } : l
  );

  const ownedTerritories = [...state.ownedTerritories, loc.id];
  const totalConquered = state.totalCastlesConquered + 1;

  // Update faction territories
  const factions = state.factions.map(f => ({
    ...f,
    territories: newLocations.filter(l => l.faction === f.id).length,
  }));

  // Collect wealth from conquered location
  const goldGain = loc.wealth;
  const xpGain = 150 + (loc.isCapital ? 200 : 0);

  // Check quests
  const quests = state.quests.map(q => {
    if (!q.completed && q.type === 'conquer' && q.target === 'any') {
      return { ...q, completed: true };
    }
    if (!q.completed && q.type === 'conquer' && q.target === 'territories:5' && totalConquered >= 5) {
      return { ...q, completed: true };
    }
    return q;
  });

  // Check gold quest
  const newGold = state.gold + goldGain + 100;
  const goldQuests = quests.map(q => {
    if (!q.completed && q.type === 'trade' && q.target === 'gold:1000' && newGold >= 1000) {
      return { ...q, completed: true };
    }
    return q;
  });

  return {
    ...state,
    locations: newLocations,
    ownedTerritories,
    totalCastlesConquered: totalConquered,
    factions,
    gold: newGold,
    xp: state.xp + xpGain,
    quests: goldQuests,
    message: `${loc.name} conquered! +${goldGain} gold, +${xpGain} XP`,
  };
}

// === Shop / Inventory ===

export function buyItem(state: WarbandGameState, itemId: string): WarbandGameState {
  const item = SHOP_ITEMS.find(i => i.id === itemId);
  if (!item || state.gold < item.price) return state;

  const existing = state.inventory.find(i => i.id === itemId);
  let inventory;
  if (existing) {
    inventory = state.inventory.map(i => i.id === itemId ? { ...i, qty: (i.qty || 1) + 1 } : i);
  } else {
    inventory = [...state.inventory, { ...item, qty: 1 }];
  }

  return {
    ...state,
    gold: state.gold - item.price,
    inventory,
    message: `Bought ${item.name} for ${item.price} gold.`,
  };
}

export function equipItem(state: WarbandGameState, itemId: string): WarbandGameState {
  const item = state.inventory.find(i => i.id === itemId);
  if (!item) return state;

  let { equippedWeapon, equippedArmor, equippedShield, mount, inventory } = state;

  if (item.type === 'weapon') {
    if (equippedWeapon) {
      inventory = inventory.map(i => i.id === equippedWeapon.id ? { ...i, qty: (i.qty || 1) + 1 } : i);
    }
    equippedWeapon = item;
  } else if (item.type === 'armor') {
    if (equippedArmor) {
      inventory = inventory.map(i => i.id === equippedArmor.id ? { ...i, qty: (i.qty || 1) + 1 } : i);
    }
    equippedArmor = item;
  } else if (item.type === 'shield') {
    if (equippedShield) {
      inventory = inventory.map(i => i.id === equippedShield.id ? { ...i, qty: (i.qty || 1) + 1 } : i);
    }
    equippedShield = item;
  } else if (item.type === 'mount') {
    if (mount) {
      inventory = inventory.map(i => i.id === mount.id ? { ...i, qty: (i.qty || 1) + 1 } : i);
    }
    mount = item;
  }

  return {
    ...state,
    equippedWeapon,
    equippedArmor,
    equippedShield,
    mount,
    inventory: inventory.map(i => i.id === itemId ? { ...i, qty: Math.max(0, (i.qty || 1) - 1) } : i).filter(i => (i.qty || 0) > 0),
    message: `Equipped ${item.name}.`,
  };
}

export function usePotion(state: WarbandGameState, itemId: string): WarbandGameState {
  const item = state.inventory.find(i => i.id === itemId);
  if (!item || item.type !== 'potion') return state;

  const healAmount = item.hpBonus || 0;
  const newHp = Math.min(state.maxHp, state.hp + healAmount);

  const inventory = state.inventory
    .map(i => i.id === itemId ? { ...i, qty: (i.qty || 1) - 1 } : i)
    .filter(i => (i.qty || 0) > 0);

  return {
    ...state,
    hp: newHp,
    inventory,
    message: `Used ${item.name}. Restored ${healAmount} HP.`,
  };
}

// === Companions ===

export function recruitCompanion(state: WarbandGameState, companionId: string): WarbandGameState {
  const companion = state.companions.find(c => c.id === companionId);
  if (!companion || companion.recruited || state.gold < companion.cost) return state;

  const quests = state.quests.map(q => {
    if (!q.completed && q.type === 'recruit' && q.target === 'any') {
      return { ...q, completed: true };
    }
    return q;
  });

  return {
    ...state,
    gold: state.gold - companion.cost,
    companions: state.companions.map(c => c.id === companionId ? { ...c, recruited: true } : c),
    army: [...state.army, { type: roleToUnitType(companion.role), count: 5, faction: companion.faction }],
    quests,
    message: `${companion.name} joined your party!`,
  };
}

function roleToUnitType(role: CharacterRole): 'infantry' | 'archer' | 'cavalry' {
  if (role === 'archer') return 'archer';
  if (role === 'cavalry') return 'cavalry';
  return 'infantry';
}

// === Marriage ===

export function marryCandidate(state: WarbandGameState, candidateId: string): WarbandGameState {
  const candidate = state.marriageCandidates.find(m => m.id === candidateId);
  if (!candidate || candidate.married || state.charisma < candidate.charmRequired || state.gold < candidate.dowry) {
    return { ...state, message: 'Cannot marry — not enough charisma or gold.' };
  }

  const quests = state.quests.map(q => {
    if (!q.completed && q.type === 'marry' && q.target === 'any') {
      return { ...q, completed: true };
    }
    return q;
  });

  const benefits: Record<string, Partial<WarbandGameState>> = {
    m1: { charisma: state.charisma + 5 },
    m2: { leadership: state.leadership + 3 },
    m3: { charisma: state.charisma + 5 },
    m4: { maxHp: state.maxHp + 10, hp: state.hp + 10 },
    m5: { leadership: state.leadership + 4 },
    m6: { attack: state.attack + 5 },
  };

  const benefit = benefits[candidateId] || {};

  return {
    ...state,
    ...benefit,
    gold: state.gold + candidate.dowry,
    marriedTo: candidate.name,
    marriageCandidates: state.marriageCandidates.map(m => m.id === candidateId ? { ...m, married: true } : m),
    quests,
    message: `You married ${candidate.name}! ${candidate.benefit}`,
  };
}

// === Rest / Heal ===

export function rest(state: WarbandGameState): WarbandGameState {
  const healAmount = Math.floor(state.maxHp * 0.5);
  return {
    ...state,
    hp: Math.min(state.maxHp, state.hp + healAmount),
    day: state.day + 1,
    message: `You rested and recovered ${healAmount} HP.`,
  };
}

// === Claim quest rewards ===

export function claimQuestReward(state: WarbandGameState, questId: string): WarbandGameState {
  const quest = state.quests.find(q => q.id === questId);
  if (!quest || !quest.completed) return state;

  // Check if already claimed (use a simple flag)
  const claimedKey = `claimed_${questId}`;
  if ((state as any)[claimedKey]) return state;

  return {
    ...state,
    gold: state.gold + quest.reward,
    xp: state.xp + quest.rewardXp,
    quests: state.quests.map(q => q.id === questId ? { ...q, completed: true } : q),
    message: `Quest "${quest.title}" reward claimed: +${quest.reward} gold, +${quest.rewardXp} XP`,
    ...( { [claimedKey]: true } as any),
  } as WarbandGameState;
}

// === Get faction strength for display ===

export function getFactionStrength(factionId: FactionId, locations: WorldLocation[]): number {
  return locations.filter(l => l.faction === factionId).reduce((sum, l) => sum + l.garrison, 0);
}
