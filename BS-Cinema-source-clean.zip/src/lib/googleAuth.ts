const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID as string;

export function isGoogleOAuthRedirect(): boolean {
  const hash = window.location.hash;
  return hash.includes('access_token') || hash.includes('error_description');
}

interface GoogleCredentialResponse {
  credential: string;
}

interface GoogleUser {
  sub: string;
  email: string;
  email_verified: boolean;
  name: string;
  given_name?: string;
  family_name?: string;
  picture: string;
  locale?: string;
}

declare global {
  interface Window {
    google?: any;
  }
}

export async function initGoogleAuth(): Promise<void> {
  return new Promise((resolve) => {
    if (window.google?.accounts?.id) {
      resolve();
      return;
    }
    const check = setInterval(() => {
      if (window.google?.accounts?.id) {
        clearInterval(check);
        resolve();
      }
    }, 100);
    setTimeout(() => {
      clearInterval(check);
      resolve();
    }, 5000);
  });
}

function decodeJwtPayload(token: string): GoogleUser | null {
  try {
    const payload = token.split('.')[1];
    const decoded = atob(payload.replace(/-/g, '+').replace(/_/g, '/'));
    return JSON.parse(decoded) as GoogleUser;
  } catch {
    return null;
  }
}

// Render a Google Sign-In button into a container element.
// This is more reliable than the One Tap prompt which gets dismissed by browsers.
export async function renderGoogleButton(
  containerId: string,
  onSuccess: (idToken: string, user: GoogleUser) => void,
  onError: (error: string) => void
): Promise<boolean> {
  if (!GOOGLE_CLIENT_ID) {
    onError('Google Client ID is not configured. Add VITE_GOOGLE_CLIENT_ID to .env');
    return false;
  }

  await initGoogleAuth();

  if (!window.google?.accounts?.id) {
    onError('Google Identity Services could not load. Please refresh and try again.');
    return false;
  }

  const container = document.getElementById(containerId);
  if (!container) {
    onError('Google button container not found');
    return false;
  }

  window.google.accounts.id.initialize({
    client_id: GOOGLE_CLIENT_ID,
    callback: (response: GoogleCredentialResponse) => {
      if (!response.credential) {
        onError('No Google token received');
        return;
      }
      const user = decodeJwtPayload(response.credential);
      if (!user) {
        onError('Could not parse Google user data');
        return;
      }
      onSuccess(response.credential, user);
    },
  });

  window.google.accounts.id.renderButton(container, {
    type: 'standard',
    theme: 'outline',
    size: 'large',
    text: 'continue_with',
    shape: 'pill',
    width: 320,
    locale: 'en',
  });

  return true;
}

// Legacy function — kept for backward compatibility but now uses renderButton internally
export async function getGoogleIdToken(): Promise<{ idToken: string; user: GoogleUser } | { error: string }> {
  if (!GOOGLE_CLIENT_ID) {
    return { error: 'Google Client ID is not configured.' };
  }

  await initGoogleAuth();

  if (!window.google?.accounts?.id) {
    return { error: 'Google Identity Services could not load. Please refresh and try again.' };
  }

  return new Promise((resolve) => {
    let resolved = false;

    window.google.accounts.id.initialize({
      client_id: GOOGLE_CLIENT_ID,
      callback: (response: GoogleCredentialResponse) => {
        if (resolved) return;
        resolved = true;
        if (!response.credential) {
          resolve({ error: 'No Google token received' });
          return;
        }
        const user = decodeJwtPayload(response.credential);
        if (!user) {
          resolve({ error: 'Could not parse Google user data' });
          return;
        }
        resolve({ idToken: response.credential, user });
      },
    });

    // Try One Tap prompt, but fall back gracefully
    window.google.accounts.id.prompt((notification: any) => {
      if (resolved) return;
      if (notification.isNotDisplayed() || notification.isSkippedMoment()) {
        // Instead of erroring, resolve with a message indicating fallback to OAuth redirect
        resolved = true;
        resolve({ error: '__FALLBACK_REDIRECT__' });
      }
    });
  });
}
