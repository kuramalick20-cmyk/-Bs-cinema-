import { supabase } from './supabase';
import type { ItemType, Comment } from './supabase';

const DEVICE_ID_KEY = 'bs_device_id';

export function getDeviceId(): string {
  let id = localStorage.getItem(DEVICE_ID_KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(DEVICE_ID_KEY, id);
  }
  return id;
}

export async function recordView(itemType: ItemType, itemId: string): Promise<number> {
  const deviceId = getDeviceId();
  const { data, error } = await supabase.rpc('increment_view', {
    p_item_type: itemType,
    p_item_id: itemId,
    p_device_id: deviceId,
  });
  if (error) {
    console.error('Failed to record view:', error);
    return 0;
  }
  return (data as number) || 0;
}

export async function getViewCount(itemType: ItemType, itemId: string): Promise<number> {
  const { data, error } = await supabase.rpc('get_view_count', {
    p_item_type: itemType,
    p_item_id: itemId,
  });
  if (error) return 0;
  return (data as number) || 0;
}

export async function getStarCount(itemType: ItemType, itemId: string): Promise<number> {
  const { data, error } = await supabase.rpc('get_star_count', {
    p_item_type: itemType,
    p_item_id: itemId,
  });
  if (error) return 0;
  return (data as number) || 0;
}

export async function hasStarred(itemType: ItemType, itemId: string): Promise<boolean> {
  const deviceId = getDeviceId();
  const { data, error } = await supabase.rpc('has_starred', {
    p_item_type: itemType,
    p_item_id: itemId,
    p_device_id: deviceId,
  });
  if (error) return false;
  return (data as boolean) || false;
}

export async function toggleStar(
  itemType: ItemType,
  itemId: string
): Promise<{ starred: boolean; star_count: number } | null> {
  const deviceId = getDeviceId();
  const { data, error } = await supabase.rpc('toggle_star', {
    p_item_type: itemType,
    p_item_id: itemId,
    p_device_id: deviceId,
  });
  if (error) {
    console.error('Failed to toggle star:', error);
    return null;
  }
  return data as { starred: boolean; star_count: number };
}

export async function fetchComments(itemType: ItemType, itemId: string): Promise<Comment[]> {
  const { data, error } = await supabase
    .from('comments')
    .select('*, profiles:profiles(username, avatar_url)')
    .eq('item_type', itemType)
    .eq('item_id', itemId)
    .order('created_at', { ascending: false });
  if (error) return [];
  return (data as Comment[]) || [];
}

export async function postComment(
  itemType: ItemType,
  itemId: string,
  text: string
): Promise<Comment | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from('comments')
    .insert({ item_type: itemType, item_id: itemId, text, user_id: user.id })
    .select('*, profiles:profiles(username, avatar_url)')
    .maybeSingle();
  if (error) {
    console.error('Failed to post comment:', error);
    return null;
  }
  return data as Comment;
}

export async function deleteComment(commentId: string): Promise<boolean> {
  const { error } = await supabase.from('comments').delete().eq('id', commentId);
  if (error) {
    console.error('Failed to delete comment:', error);
    return false;
  }
  return true;
}

export function formatCount(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, '') + 'K';
  return n.toLocaleString();
}
