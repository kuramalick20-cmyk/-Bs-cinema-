import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

export type Lang = 'ku' | 'en';

const STORAGE_KEY = 'bs_lang';

const dict = {
  ku: {
    // Navbar
    all: 'سەرجەم',
    comic: 'کۆمیک',
    series: 'زنجیرە',
    movie: 'فیلم',
    anime: 'ئەنیمی',
    animeSeries: 'زنجیرەی ئەنیمی',
    animeMovies: 'فیلمی ئەنیمی',
    animation: 'ئەنیمەیشن',
    cartoonSeries: 'زنجیرەی کارتۆن',
    animationSeries: 'زنجیرەی ئەنیمەیشن',
    movies: 'فیلمە گشتییەکان',
    yadiJaran: 'یادی جاران',
    bookStore: 'کتێبخانە',
    aiChat: 'AI چات',
    games: 'یاریەکان',
    chat: 'چات',
    notifications: 'ئاگادارکردنەوەکان',
    settings: 'ڕێکخستنەکان',
    about: 'دەربارە',
    profile: 'پرۆفایل',
    login: 'چوونەژوورەوە',
    logout: 'چوونەدەرەوە',
    becomeVip: 'ببە VIP',
    search: 'گەڕان...',
    lightMode: 'ڕۆشنایی',
    darkMode: 'تاریک',
    // Home
    topContent: 'بەرزترین ناوەڕۆک',
    searchResults: 'گەڕان',
    followUs: 'بەدوامان بکە لە سۆشیاڵ میدیا',
    // Settings
    settingsTitle: 'ڕێکخستنەکان',
    appearance: 'ڕووکار',
    language: 'زمان',
    kurdish: 'کوردی',
    english: 'English',
    socialMedia: 'تۆڕە کۆمەڵایەتییەکان',
    fastpay: 'FastPay',
    fastpayNumber: 'ژمارەی FastPay',
    // Footer
    links: 'بەستەرەکان',
    follow: 'بەدوامان بکە',
    rightsReserved: '© 2026 BS Cinema — هەموو مافەکان پارێزراون',
    // Auth
    loginTitle: 'چوونەژوورەوە',
    signupTitle: 'دروستکردنی هەژمار',
    loginSubtitle: 'بەخێرایی بێیتەوە بۆ BS Cinema',
    signupSubtitle: 'هەژمارێکی نوێ دروست بکە',
    continueWithGoogle: 'بەردەوام بە بە Google',
    or: 'یان',
    username: 'ناوی بەکارهێنەر',
    email: 'ئیمەیڵ',
    password: 'وشەی نهێنی',
    noAccount: 'هەژمارت نییە؟ ',
    haveAccount: 'هەژمارت هەیە؟ ',
    createOne: 'دروستی بکە',
    signInHere: 'چوە ژوورەوە',
    // Comic
    chapters: 'بەشەکان',
    chapter: 'بەشی',
    noChapters: 'هیچ بەشێک بەردەست نییە',
    noEpisodes: 'هیچ ئەلقەیەک بەردەست نییە',
    bookAnimation: 'پەڕە وەرگێڕان',
    bookAnimationDesc: 'پەڕە بە شێوەی کتێب بەرز بکەرەوە',
    pageBack: 'گەڕانەوە',
    pageNext: 'پەڕەی داهاتوو',
    // Book store
    bookStoreTitle: 'کتێبخانە',
    buyNow: 'ئێستا بیکڕە',
    bookPrice: 'نرخ',
    bookAuthor: 'نووسەر',
    paymentMethod: 'ڕێگای پارەدان',
    fastpayMethod: 'FastPay',
    cashMethod: 'نەقد',
    purchaseRequest: 'داواکاری کڕین',
    paymentNote: 'تێبینی پارەدان',
    submitRequest: 'ناردنی داواکاری',
    requestSent: 'داواکاریەکەت نێردرا!',
    yourRequests: 'داواکاریەکانت',
    orderBook: 'داواکاری کتێب',
    orderViaWebsite: 'داواکاری لە ڕێگەی وێبسایت',
    orderViaWhatsapp: 'داواکاری لە ڕێگەی واتساپ',
    whatsappNumber: '07511590023',
    deliveryLocation: 'شوێنی گەیاندن',
    selectLocation: 'هەڵبژاردنی شوێن لە نەخشە',
    locationSelected: 'شوێن هەڵبژێردرا',
    deliveryNote: 'تێبینی گەیاندن',
    deliveryNotePlaceholder: 'ناوچە، شوێنی ماڵ، وردەکاری...',
    phoneNumber: 'ژمارەی مۆبایل',
    phoneNumberPlaceholder: '0750XXXXXXX',
    deliveryOnlySuly: 'خزمەتگوزاری گەیاندن تەنها لە سلێمانی',
    step: 'هەنگاو',
    fillAllFields: 'تکایە هەموو خانەکان پڕبکەرەوە',
    orderPlaced: 'داواکاریەکەت تۆمارکرا!',
    confirmOrder: 'پشتڕاستکردنەوەی داواکاری',
    // AI Chat
    aiChatTitle: 'AI چات',
    typeMessage: 'نووسین...',
    send: 'ناردن',
    newChat: 'چاتی نوێ',
    thinking: 'بیر دەکاتەوە...',
    welcomeAi: 'بەخێرایی بێیت! چۆن دەتوانم یارمەتیت بدەم؟',
    // Yadi Jaran
    yadiJaranDesc: 'گۆرانی و فیلمە کۆنەکان',
    oldSongs: 'گۆرانی کۆن',
    oldMovies: 'فیلمە کۆنەکان',
    noContent: 'هیچ ناوەڕۆکێک نەدۆزرایەوە',
    noContentSoon: 'بەم زووانە ناوەڕۆک زیاد دەکرێت',
    loading: 'بارکردن...',
  },
  en: {
    all: 'All',
    comic: 'Comics',
    series: 'Series',
    movie: 'Movies',
    anime: 'Anime',
    animeSeries: 'Anime Series',
    animeMovies: 'Anime Movies',
    animation: 'Animation',
    cartoonSeries: 'Cartoon Series',
    animationSeries: 'Animation Series',
    movies: 'All Movies',
    yadiJaran: 'Memories',
    bookStore: 'Book Store',
    aiChat: 'AI Chat',
    games: 'Games',
    chat: 'Chat',
    notifications: 'Notifications',
    settings: 'Settings',
    about: 'About',
    profile: 'Profile',
    login: 'Login',
    logout: 'Logout',
    becomeVip: 'Get VIP',
    search: 'Search...',
    lightMode: 'Light',
    darkMode: 'Dark',
    topContent: 'Top Content',
    searchResults: 'Search',
    followUs: 'Follow us on social media',
    settingsTitle: 'Settings',
    appearance: 'Appearance',
    language: 'Language',
    kurdish: 'کوردی',
    english: 'English',
    socialMedia: 'Social Media',
    fastpay: 'FastPay',
    fastpayNumber: 'FastPay Number',
    links: 'Links',
    follow: 'Follow',
    rightsReserved: '© 2026 BS Cinema — All rights reserved',
    loginTitle: 'Login',
    signupTitle: 'Create Account',
    loginSubtitle: 'Welcome back to BS Cinema',
    signupSubtitle: 'Create a new account',
    continueWithGoogle: 'Continue with Google',
    or: 'or',
    username: 'Username',
    email: 'Email',
    password: 'Password',
    noAccount: "Don't have an account? ",
    haveAccount: 'Already have an account? ',
    createOne: 'Sign up',
    signInHere: 'Sign in',
    chapters: 'Chapters',
    chapter: 'Chapter',
    noChapters: 'No chapters available',
    noEpisodes: 'No episodes available',
    bookAnimation: 'Book Page Turn',
    bookAnimationDesc: 'Flip pages like a real book',
    pageBack: 'Previous',
    pageNext: 'Next Page',
    bookStoreTitle: 'Book Store',
    buyNow: 'Buy Now',
    bookPrice: 'Price',
    bookAuthor: 'Author',
    paymentMethod: 'Payment Method',
    fastpayMethod: 'FastPay',
    cashMethod: 'Cash',
    purchaseRequest: 'Purchase Request',
    paymentNote: 'Payment Note',
    submitRequest: 'Submit Request',
    requestSent: 'Your request has been sent!',
    yourRequests: 'Your Requests',
    orderBook: 'Order Book',
    orderViaWebsite: 'Order via Website',
    orderViaWhatsapp: 'Order via WhatsApp',
    whatsappNumber: '07511590023',
    deliveryLocation: 'Delivery Location',
    selectLocation: 'Select location on map',
    locationSelected: 'Location selected',
    deliveryNote: 'Delivery Note',
    deliveryNotePlaceholder: 'Area, house details, landmarks...',
    phoneNumber: 'Mobile Number',
    phoneNumberPlaceholder: '0750XXXXXXX',
    deliveryOnlySuly: 'Delivery available only in Sulaymaniyah',
    step: 'Step',
    fillAllFields: 'Please fill in all fields',
    orderPlaced: 'Your order has been placed!',
    confirmOrder: 'Confirm Order',
    aiChatTitle: 'AI Chat',
    typeMessage: 'Type...',
    send: 'Send',
    newChat: 'New Chat',
    thinking: 'Thinking...',
    welcomeAi: "Welcome! How can I help you?",
    yadiJaranDesc: 'Old songs and old movies',
    oldSongs: 'Old Songs',
    oldMovies: 'Old Movies',
    noContent: 'No content found',
    noContentSoon: 'Content will be added soon',
    loading: 'Loading...',
  },
} as const;

export type DictKey = keyof typeof dict['ku'];

interface I18nContextType {
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: (key: DictKey) => string;
  dir: 'rtl' | 'ltr';
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return (saved === 'en' || saved === 'ku') ? saved : 'ku';
  });

  const setLang = (newLang: Lang) => {
    setLangState(newLang);
    localStorage.setItem(STORAGE_KEY, newLang);
  };

  const dir = lang === 'ku' ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.dir = dir;
    document.documentElement.lang = lang === 'ku' ? 'ckb' : 'en';
  }, [dir, lang]);

  const t = (key: DictKey) => dict[lang][key] || dict.ku[key] || key;

  return (
    <I18nContext.Provider value={{ lang, setLang, t, dir }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used within I18nProvider');
  return ctx;
}
