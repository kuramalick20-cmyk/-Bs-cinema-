// Multiplayer game sync layer — manages match state via Supabase realtime
import { supabase, type Profile, type GameChatMessage } from './supabase';
import { type GameState, initialState, serializeState, deserializeState, applyMove, type Move, getGameResult, moveToNotation } from './chessEngine';
import { type DominoGameState, newGameState, serializeDominoState, deserializeDominoState } from './dominoEngine';

export interface GameMatch {
  id: string;
  game_type: 'chess' | 'dominoes';
  mode: 'multiplayer' | 'bot';
  status: 'waiting' | 'active' | 'completed' | 'resigned';
  player_white: string;
  player_black: string | null;
  bot_elo: number | null;
  current_turn: 'white' | 'black';
  game_state: any;
  move_history: string[];
  result: string | null;
  result_reason: string | null;
  winner_id: string | null;
  invited_player: string | null;
  created_at: string;
  completed_at: string | null;
}

export interface GameInvite {
  id: string;
  game_type: 'chess' | 'dominoes';
  from_user: string;
  to_user: string;
  status: 'pending' | 'accepted' | 'declined' | 'expired';
  match_id: string | null;
  created_at: string;
  from_profile?: Profile | null;
  to_profile?: Profile | null;
}

// Create a game invite
export async function createGameInvite(
  fromUserId: string,
  toUserId: string,
  gameType: 'chess' | 'dominoes',
): Promise<GameInvite | null> {
  const { data, error } = await supabase
    .from('game_invites')
    .insert({
      game_type: gameType,
      from_user: fromUserId,
      to_user: toUserId,
      status: 'pending',
    })
    .select('*')
    .single();
  if (error) return null;

  const { data: fromProfile } = await supabase
    .from('profiles')
    .select('username')
    .eq('id', fromUserId)
    .maybeSingle();

  const gameLabel = gameType === 'chess' ? 'شەترەنج' : 'دۆمینۆ';
  await supabase.from('notifications').insert({
    user_id: toUserId,
    type: 'game_invite',
    title: `${fromProfile?.username || 'بەکارهێنەر'} بانگی کردیت بۆ یاری ${gameLabel}`,
    body: null,
    is_read: false,
  });

  return data as GameInvite;
}

// Accept a game invite — creates the match
export async function acceptGameInvite(inviteId: string, fromUserId: string, toUserId: string, gameType: 'chess' | 'dominoes'): Promise<GameMatch | null> {
  // Create the match
  const initState = gameType === 'chess' ? serializeState(initialState()) : serializeDominoState(newGameState());
  const { data: match, error: matchError } = await supabase
    .from('game_matches')
    .insert({
      game_type: gameType,
      mode: 'multiplayer',
      status: 'active',
      player_white: fromUserId,
      player_black: toUserId,
      current_turn: 'white',
      game_state: JSON.parse(initState),
      move_history: [],
    })
    .select('*')
    .single();
  if (matchError || !match) return null;

  // Update the invite
  await supabase
    .from('game_invites')
    .update({ status: 'accepted', match_id: match.id, responded_at: new Date().toISOString() })
    .eq('id', inviteId);

  return match as GameMatch;
}

// Decline a game invite
export async function declineGameInvite(inviteId: string): Promise<void> {
  await supabase
    .from('game_invites')
    .update({ status: 'declined', responded_at: new Date().toISOString() })
    .eq('id', inviteId);
}

// Get pending invites for a user
export async function getPendingInvites(userId: string): Promise<GameInvite[]> {
  const { data } = await supabase
    .from('game_invites')
    .select('*')
    .eq('to_user', userId)
    .eq('status', 'pending')
    .order('created_at', { ascending: false });
  return (data as GameInvite[]) || [];
}

// Create a bot match
export async function createBotMatch(
  userId: string,
  gameType: 'chess' | 'dominoes',
  botElo: number,
): Promise<GameMatch | null> {
  const initState = gameType === 'chess' ? serializeState(initialState()) : serializeDominoState(newGameState());
  const { data, error } = await supabase
    .from('game_matches')
    .insert({
      game_type: gameType,
      mode: 'bot',
      status: 'active',
      player_white: userId,
      player_black: null,
      bot_elo: botElo,
      current_turn: 'white',
      game_state: JSON.parse(initState),
      move_history: [],
    })
    .select('*')
    .single();
  if (error) return null;
  return data as GameMatch;
}

// Get active matches for a user
export async function getActiveMatches(userId: string): Promise<GameMatch[]> {
  const { data } = await supabase
    .from('game_matches')
    .select('*')
    .or(`player_white.eq.${userId},player_black.eq.${userId}`)
    .in('status', ['active', 'waiting'])
    .order('created_at', { ascending: false });
  return (data as GameMatch[]) || [];
}

// Get match history
export async function getMatchHistory(userId: string): Promise<GameMatch[]> {
  const { data } = await supabase
    .from('game_matches')
    .select('*')
    .or(`player_white.eq.${userId},player_black.eq.${userId}`)
    .eq('status', 'completed')
    .order('completed_at', { ascending: false })
    .limit(20);
  return (data as GameMatch[]) || [];
}

// Submit a chess move to the server
export async function submitChessMove(
  matchId: string,
  playerId: string,
  state: GameState,
  move: Move,
  moveNumber: number,
): Promise<{ success: boolean; result?: string | null; resultReason?: string | null }> {
  const newState = applyMove(state, move);
  const notation = moveToNotation(state, move);
  const gameResult = getGameResult(newState, []);

  // Record the move
  await supabase.from('game_moves').insert({
    match_id: matchId,
    move_number: moveNumber,
    player_id: playerId,
    move_data: { from: move.from, to: move.to, promotion: move.promotion },
    notation,
  });

  // Fetch current move_history from the match
  const { data: currentMatch } = await supabase
    .from('game_matches')
    .select('move_history')
    .eq('id', matchId)
    .maybeSingle();

  const existingHistory: string[] = (currentMatch?.move_history as string[]) || [];
  const newHistory = [...existingHistory, notation];

  const updateData: any = {
    game_state: JSON.parse(serializeState(newState)),
    current_turn: newState.turn,
    move_history: newHistory,
    updated_at: new Date().toISOString(),
  };

  if (gameResult) {
    updateData.status = 'completed';
    updateData.completed_at = new Date().toISOString();
    updateData.result = gameResult.result;
    updateData.result_reason = gameResult.reason;
    if (gameResult.result === 'white_wins') {
      // The player who just moved wins — determine color from the state before the move
      updateData.winner_id = state.turn === 'w' ? playerId : null;
    } else if (gameResult.result === 'black_wins') {
      updateData.winner_id = state.turn === 'b' ? playerId : null;
    }
  }

  const { error } = await supabase.from('game_matches').update(updateData).eq('id', matchId);
  return { success: !error, result: gameResult?.result || null, resultReason: gameResult?.reason || null };
}

// Submit a domino move
export async function submitDominoMove(
  matchId: string,
  playerId: string,
  state: DominoGameState,
  moveData: any,
  moveNumber: number,
): Promise<{ success: boolean }> {
  await supabase.from('game_moves').insert({
    match_id: matchId,
    move_number: moveNumber,
    player_id: playerId,
    move_data: moveData,
  });

  const updateData: any = {
    game_state: JSON.parse(serializeDominoState(state)),
    current_turn: state.currentTurn === 'player1' ? 'white' : 'black',
    updated_at: new Date().toISOString(),
  };

  if (state.status === 'completed') {
    updateData.status = 'completed';
    updateData.completed_at = new Date().toISOString();
    if (state.winner === 'draw') {
      updateData.result = 'draw';
    } else {
      updateData.result = state.winner === 'player1' ? 'white_wins' : 'black_wins';
    }
    updateData.result_reason = state.winReason === 'empty_hand' ? 'checkmate' : 'stalemate';
  }

  await supabase.from('game_matches').update(updateData).eq('id', matchId);
  return { success: true };
}

// Resign from a match
export async function resignMatch(matchId: string, resigningPlayerId: string, opponentId: string | null): Promise<void> {
  // Fetch the match to determine correct result based on colors
  const { data: match } = await supabase
    .from('game_matches')
    .select('player_white, player_black')
    .eq('id', matchId)
    .maybeSingle();

  const isWhite = match?.player_white === resigningPlayerId;
  const result = isWhite ? 'black_wins' : 'white_wins';

  await supabase.from('game_matches').update({
    status: 'resigned',
    result,
    result_reason: 'resignation',
    winner_id: opponentId,
    completed_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }).eq('id', matchId);
}

// Subscribe to match updates (realtime)
export function subscribeToMatch(matchId: string, onUpdate: (match: GameMatch) => void): () => void {
  const channel = supabase
    .channel(`match:${matchId}`)
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'game_matches', filter: `id=eq.${matchId}` }, (payload) => {
      onUpdate(payload.new as GameMatch);
    })
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'game_moves', filter: `match_id=eq.${matchId}` }, () => {
      // Refetch match to get latest state
      supabase.from('game_matches').select('*').eq('id', matchId).single().then(({ data }) => {
        if (data) onUpdate(data as GameMatch);
      });
    })
    .subscribe();

  return () => { supabase.removeChannel(channel); };
}

// Subscribe to incoming invites
export function subscribeToInvites(userId: string, onInvite: () => void): () => void {
  const channel = supabase
    .channel(`invites:${userId}`)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'game_invites', filter: `to_user=eq.${userId}` }, () => {
      onInvite();
    })
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'game_invites', filter: `from_user=eq.${userId}` }, () => {
      onInvite();
    })
    .subscribe();

  return () => { supabase.removeChannel(channel); };
}

// Get a match by ID
export async function getMatch(matchId: string): Promise<GameMatch | null> {
  const { data } = await supabase.from('game_matches').select('*').eq('id', matchId).maybeSingle();
  return data as GameMatch | null;
}

// Get a profile by user ID
export async function getProfile(userId: string): Promise<Profile | null> {
  const { data } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
  return data as Profile | null;
}

// === In-game real-time text chat ===

export async function fetchGameChatMessages(matchId: string): Promise<GameChatMessage[]> {
  const { data, error } = await supabase
    .from('game_chat_messages')
    .select('*')
    .eq('match_id', matchId)
    .order('created_at', { ascending: true });
  if (error) return [];
  return (data as GameChatMessage[]) || [];
}

export async function sendGameChatMessage(matchId: string, text: string): Promise<GameChatMessage | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data, error } = await supabase
    .from('game_chat_messages')
    .insert({ match_id: matchId, sender_id: user.id, text })
    .select('*')
    .maybeSingle();
  if (error) {
    console.error('Failed to send game chat message:', error);
    return null;
  }
  return data as GameChatMessage;
}

export function subscribeToGameChat(matchId: string, onMessage: (msg: GameChatMessage) => void): () => void {
  const channel = supabase
    .channel(`game-chat:${matchId}`)
    .on('postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'game_chat_messages', filter: `match_id=eq.${matchId}` },
      (payload) => onMessage(payload.new as GameChatMessage)
    )
    .subscribe();
  return () => { supabase.removeChannel(channel); };
}
