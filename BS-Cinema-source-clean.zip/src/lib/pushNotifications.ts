import { LocalNotifications } from '@capacitor/local-notifications';
import { supabase, type Notification } from '@/lib/supabase';
import { isNativeApp } from '@/lib/platform';

let initialized = false;
let channelId = 1;

export async function initLocalNotifications(): Promise<void> {
  if (!isNativeApp() || initialized) return;
  initialized = true;

  try {
    // Request notification permission (Android 13+)
    const { display } = await LocalNotifications.requestPermissions();
    if (display !== 'granted') return;

    // Create a notification channel for Android
    await LocalNotifications.createChannel({
      id: 'bs-cinema-notifications',
      name: 'BS Cinema Notifications',
      description: 'Notifications from BS Cinema',
      importance: 4,
      visibility: 1,
      sound: 'default',
    });
  } catch {
    // Permissions/channel creation failed — in-app notifications still work
  }
}

export async function showLocalNotification(notif: Notification): Promise<void> {
  if (!isNativeApp()) return;

  try {
    await LocalNotifications.schedule({
      notifications: [
        {
          id: channelId++,
          title: notif.title || 'BS Cinema',
          body: notif.body || '',
          channelId: 'bs-cinema-notifications',
          schedule: { at: new Date(Date.now() + 100) },
          smallIcon: 'ic_stat_icon',
          iconColor: '#ef3340',
        },
      ],
    });
  } catch {
    // Notification scheduling failed — in-app notifications still work
  }
}

export function subscribeToPushNotifications(
  userId: string,
  onNewNotification?: (notif: Notification) => void
): () => void {
  if (!userId) return () => {};

  const channel = supabase
    .channel('push-notifications')
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${userId}` },
      (payload) => {
        const notif = payload.new as Notification;
        if (isNativeApp()) {
          showLocalNotification(notif);
        }
        onNewNotification?.(notif);
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}
