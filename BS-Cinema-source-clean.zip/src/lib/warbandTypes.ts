// === Warband-style RPG Game Types ===

export type GameScreen = 'world-map' | 'town' | 'battle' | 'character' | 'inventory' | 'dialogue' | 'explore';
export type FactionId = 'greece' | 'kurdistan' | 'persia' | 'egypt' | 'rome' | 'nord';
export type LocationType = 'city' | 'castle' | 'village' | 'camp' | 'ruins' | 'forest' | 'mountain' | 'field';
export type CombatAction = 'attack' | 'block' | 'dodge' | 'special';
export type CameraMode = 'third-person' | 'first-person';

// Real-time 3D world entity
export interface WorldEntity {
  id: string;
  type: 'enemy' | 'npc' | 'companion' | 'horse';
  name: string;
  faction: FactionId;
  x: number;
  z: number;
  vx: number;
  vz: number;
  angle: number;
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
  speed: number;
  weapon: WeaponType;
  role: CharacterRole;
  level: number;
  state: 'idle' | 'chase' | 'attack' | 'flee' | 'dead' | 'follow';
  targetId: string | null;
  attackCooldown: number;
  hitFlash: number;
  portraitColor: string;
  accentColor: string;
}

export interface PlayerState3D {
  x: number;
  z: number;
  vx: number;
  vz: number;
  angle: number;
  camYaw: number;
  camPitch: number;
  camDist: number;
  isMoving: boolean;
  isRunning: boolean;
  isBlocking: boolean;
  isMounted: boolean;
  attackCooldown: number;
  attackAnim: number;
  blockAnim: number;
  dodgeAnim: number;
  hitFlash: number;
  currentHp: number;
}
export type ItemType = 'weapon' | 'armor' | 'shield' | 'potion' | 'mount' | 'misc' | 'treasure';
export type WeaponType = 'sword' | 'axe' | 'spear' | 'bow' | 'mace';
export type CharacterRole = 'leader' | 'warrior' | 'archer' | 'cavalry' | 'healer' | 'scout';

export interface GameCharacter {
  id: string;
  name: string;
  title: string;
  description: string;
  faction: FactionId;
  role: CharacterRole;
  weapon: WeaponType;
  hairColor: string;
  eyeColor: string;
  faceType: string;
  appearance: string;
  personality: string;
  abilities: string[];
  isPlayable: boolean;
  level: number;
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
  speed: number;
  leadership: number;
  charisma: number;
  portraitColor: string;
  accentColor: string;
}

export interface WorldLocation {
  id: string;
  name: string;
  type: LocationType;
  faction: FactionId;
  x: number;
  y: number;
  garrison: number;
  wealth: number;
  isCapital: boolean;
  description: string;
  visited: boolean;
}

export interface Faction {
  id: FactionId;
  name: string;
  color: string;
  banner: string;
  description: string;
  territories: number;
  atWarWith: FactionId[];
  atPeaceWith: FactionId[];
  strength: number;
}

export interface Item {
  id: string;
  name: string;
  type: ItemType;
  weaponType?: WeaponType;
  attackBonus?: number;
  defenseBonus?: number;
  hpBonus?: number;
  speedBonus?: number;
  price: number;
  description: string;
  icon: string;
  qty?: number;
}

export interface ArmyUnit {
  type: 'infantry' | 'archer' | 'cavalry';
  count: number;
  faction: FactionId;
}

export interface Enemy {
  id: string;
  name: string;
  faction: FactionId;
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
  speed: number;
  weapon: WeaponType;
  role: CharacterRole;
  level: number;
  isLeader: boolean;
  portraitColor: string;
  accentColor: string;
}

export interface Companion {
  id: string;
  name: string;
  faction: FactionId;
  role: CharacterRole;
  weapon: WeaponType;
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
  level: number;
  recruited: boolean;
  cost: number;
  description: string;
  portraitColor: string;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  type: 'conquer' | 'recruit' | 'trade' | 'marry' | 'battle' | 'explore';
  target: string;
  reward: number;
  rewardXp: number;
  completed: boolean;
  factionId?: FactionId;
}

export interface MarriageCandidate {
  id: string;
  name: string;
  faction: FactionId;
  description: string;
  dowry: number;
  charmRequired: number;
  married: boolean;
  portraitColor: string;
  benefit: string;
}

export interface DialogueNode {
  id: string;
  npc: string;
  text: string;
  options: { label: string; next?: string; action?: string }[];
}

export interface BattleLogEntry {
  id: number;
  text: string;
  type: 'player' | 'enemy' | 'system' | 'companion' | 'victory' | 'defeat';
}

export interface WarbandGameState {
  screen: GameScreen;
  selectedCharacter: GameCharacter;
  characters: GameCharacter[];
  gold: number;
  xp: number;
  level: number;
  day: number;
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
  speed: number;
  leadership: number;
  charisma: number;
  currentLocationId: string;
  locations: WorldLocation[];
  factions: Faction[];
  inventory: Item[];
  equippedWeapon: Item | null;
  equippedArmor: Item | null;
  equippedShield: Item | null;
  mount: Item | null;
  army: ArmyUnit[];
  companions: Companion[];
  quests: Quest[];
  marriageCandidates: MarriageCandidate[];
  marriedTo: string | null;
  battleEnemy: Enemy | null;
  battleEnemies: Enemy[];
  battleLog: BattleLogEntry[];
  battleIndex: number;
  companionsInBattle: Companion[];
  dialogueNode: DialogueNode | null;
  worldX: number;
  worldY: number;
  isTraveling: boolean;
  travelTarget: string | null;
  message: string | null;
  ownedTerritories: string[];
  playerFaction: FactionId;
  totalBattlesWon: number;
  totalCastlesConquered: number;
  cameraMode: CameraMode;
  player3D: PlayerState3D;
  worldEntities: WorldEntity[];
  nearbyLocationId: string | null;
  combatLog: { id: number; text: string; time: number }[];
  joystickActive: boolean;
  joystickDX: number;
  joystickDY: number;
}
