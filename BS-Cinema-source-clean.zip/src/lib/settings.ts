import { supabase } from './supabase';

export interface SocialLinks {
  telegram: string;
  snapchat: string;
  tiktok: string;
  whatsapp: string;
  fastpay_number: string;
}

export interface SiteSettings {
  id: number;
  social_links: SocialLinks;
  ads_enabled: boolean;
  ad_provider: string;
  ad_client_id: string | null;
  updated_at: string;
}

export const DEFAULT_SOCIAL_LINKS: SocialLinks = {
  telegram: 'https://t.me/lordarys',
  snapchat: 'https://www.snapchat.com/add/lord.aries1',
  tiktok: 'https://www.tiktok.com/@bsstudio.offical',
  whatsapp: 'https://wa.me/9647511590023',
  fastpay_number: '07511590023',
};

export async function getSiteSettings(): Promise<SiteSettings | null> {
  const { data, error } = await supabase
    .from('site_settings')
    .select('*')
    .eq('id', 1)
    .maybeSingle();
  if (error) return null;
  return data as SiteSettings | null;
}

export async function updateSiteSettings(
  updates: Partial<Pick<SiteSettings, 'social_links' | 'ads_enabled' | 'ad_provider' | 'ad_client_id'>>
): Promise<boolean> {
  const { error } = await supabase
    .from('site_settings')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', 1);
  return !error;
}
