import { supabase, type Subtitle } from './supabase';
import { detectLanguage } from './comicVoice';

declare global {
  interface Window {
    SpeechRecognition?: any;
    webkitSpeechRecognition?: any;
  }
}

export interface STTSegment {
  text: string;
  startTime: number;
  endTime: number;
  language: 'ku' | 'en';
}

export function isSpeechRecognitionSupported(): boolean {
  return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
}

function createRecognition(lang: 'ku' | 'en'): any {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) return null;

  const recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  // Kurdish Sorani uses Arabic script; ar-IQ is the closest locale Chrome supports
  recognition.lang = lang === 'ku' ? 'ar-IQ' : 'en-US';
  return recognition;
}

interface STTResult {
  segments: STTSegment[];
  detectedLanguage: 'ku' | 'en';
  error: string | null;
}

export async function recognizeSpeechFromVideo(
  videoElement: HTMLVideoElement,
  options: {
    preferredLanguage?: 'ku' | 'en';
    maxDuration?: number;
    onProgress?: (text: string, segmentCount: number) => void;
  } = {}
): Promise<STTResult> {
  const supported = isSpeechRecognitionSupported();
  if (!supported) {
    return { segments: [], detectedLanguage: 'en', error: 'Speech recognition is not supported in this browser. Please use Chrome or Edge.' };
  }

  let audioContext: AudioContext | null = null;
  let mediaStreamDest: MediaStreamAudioDestinationNode | null = null;
  let gainNode: GainNode | null = null;
  let originalGetUserMedia: typeof navigator.mediaDevices.getUserMedia | null = null;
  let recognition: any = null;
  let isFinished = false;
  let sourceNode: MediaElementAudioSourceNode | null = null;
  const savedVolume = videoElement.volume;
  const savedMuted = videoElement.muted;

  function restoreVideo() {
    try {
      videoElement.volume = savedVolume;
      videoElement.muted = savedMuted;
    } catch {}
  }

  function cleanup() {
    if (originalGetUserMedia) {
      try {
        navigator.mediaDevices.getUserMedia = originalGetUserMedia.bind(navigator.mediaDevices);
      } catch {}
      originalGetUserMedia = null;
    }
    try { recognition?.stop(); } catch {}
    try { audioContext?.close(); } catch {}
    audioContext = null;
    mediaStreamDest = null;
    gainNode = null;
    sourceNode = null;
    restoreVideo();
  }

  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioContext = new AudioContextClass();

    // If audio context is suspended (autoplay policy), resume it
    if (audioContext.state === 'suspended') {
      await audioContext.resume();
    }

    // Route video audio through AudioContext
    sourceNode = audioContext.createMediaElementSource(videoElement);

    // Create a gain node at 0 so no audio plays through speakers
    gainNode = audioContext.createGain();
    gainNode.gain.value = 0;

    // Connect: source → gain (silent speakers) → destination (required for audio to flow)
    sourceNode.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // Also connect source → MediaStreamDestination for capture
    mediaStreamDest = audioContext.createMediaStreamDestination();
    sourceNode.connect(mediaStreamDest);

    const audioStream = mediaStreamDest.stream;
    const audioTracks = audioStream.getAudioTracks();
    if (audioTracks.length === 0) {
      cleanup();
      return { segments: [], detectedLanguage: 'en', error: 'This video has no audio track.' };
    }

    // Override getUserMedia so SpeechRecognition receives the video's audio stream
    // instead of requesting microphone access
    const fakeStream = new MediaStream(audioTracks);
    originalGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
    navigator.mediaDevices.getUserMedia = async (_constraints?: MediaStreamConstraints) => fakeStream;

    recognition = createRecognition(options.preferredLanguage || 'en');
    if (!recognition) {
      cleanup();
      return { segments: [], detectedLanguage: 'en', error: 'Could not initialize speech recognition.' };
    }

    const segments: STTSegment[] = [];
    let currentSegmentText = '';
    let segmentStartTime = 0;
    let lastFinalTime = 0;

    return new Promise<STTResult>((resolve) => {
      let resolveCalled = false;
      const finish = (result: STTResult) => {
        if (resolveCalled || isFinished) return;
        isFinished = true;
        resolveCalled = true;
        cleanup();
        resolve(result);
      };

      const flushSegment = () => {
        if (currentSegmentText.trim()) {
          segments.push({
            text: currentSegmentText.trim(),
            startTime: segmentStartTime,
            endTime: lastFinalTime,
            language: (options.preferredLanguage || 'en') as 'ku' | 'en',
          });
          currentSegmentText = '';
          options.onProgress?.('', segments.length);
        }
      };

      recognition.onresult = (event: any) => {
        let interimText = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          if (result.isFinal) {
            const text = result[0].transcript.trim();
            if (text) {
              if (!currentSegmentText) {
                segmentStartTime = videoElement.currentTime;
              }
              currentSegmentText += (currentSegmentText ? ' ' : '') + text;
              lastFinalTime = videoElement.currentTime;
              options.onProgress?.(currentSegmentText, segments.length);
            }
          } else {
            interimText += result[0].transcript;
          }
        }
        if (interimText) {
          options.onProgress?.(interimText, segments.length);
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error === 'no-speech' || event.error === 'aborted') return;
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          finish({ segments, detectedLanguage: (options.preferredLanguage || 'en') as 'ku' | 'en', error: 'Audio capture not allowed. The browser blocked audio access.' });
        }
        // For other errors (network, audio-capture), try to continue
      };

      recognition.onend = () => {
        if (isFinished) return;
        flushSegment();
        // Auto-restart if recognition ended early (Chrome stops after ~60s of silence)
        if (!isFinished && segments.length === 0 && videoElement && !videoElement.ended) {
          try {
            recognition.start();
            return;
          } catch {}
        }
        if (segments.length === 0) {
          finish({ segments: [], detectedLanguage: (options.preferredLanguage || 'en') as 'ku' | 'en', error: 'No speech detected. Try the other language option or check that the video has audible speech.' });
        } else {
          const detectedLang = detectLanguage(segments.map((s) => s.text).join(' ')) as 'ku' | 'en';
          finish({ segments, detectedLanguage: detectedLang === 'ku' ? 'ku' : 'en', error: null });
        }
      };

      try {
        recognition.start();
      } catch (err) {
        finish({ segments: [], detectedLanguage: (options.preferredLanguage || 'en') as 'ku' | 'en', error: 'Failed to start speech recognition.' });
        return;
      }

      // Play the video so audio flows through the AudioContext pipeline
      videoElement.currentTime = 0;
      videoElement.muted = false; // Must be unmuted for AudioContext to process audio
      videoElement.volume = 0; // GainNode already silences output, but set volume to 0 as backup
      videoElement.play().catch(() => {
        finish({ segments: [], detectedLanguage: (options.preferredLanguage || 'en') as 'ku' | 'en', error: 'Failed to play video for speech recognition. Click the video first to enable autoplay.' });
      });

      const maxDuration = options.maxDuration || 300;
      const timeoutId = setTimeout(() => {
        flushSegment();
        if (segments.length > 0) {
          const detectedLang = detectLanguage(segments.map((s) => s.text).join(' ')) as 'ku' | 'en';
          finish({ segments, detectedLanguage: detectedLang === 'ku' ? 'ku' : 'en', error: null });
        } else {
          finish({ segments: [], detectedLanguage: (options.preferredLanguage || 'en') as 'ku' | 'en', error: 'No speech detected within the time limit.' });
        }
      }, maxDuration * 1000);

      videoElement.addEventListener('ended', () => {
        clearTimeout(timeoutId);
        flushSegment();
        if (segments.length > 0) {
          const detectedLang = detectLanguage(segments.map((s) => s.text).join(' ')) as 'ku' | 'en';
          finish({ segments, detectedLanguage: detectedLang === 'ku' ? 'ku' : 'en', error: null });
        } else {
          finish({ segments: [], detectedLanguage: (options.preferredLanguage || 'en') as 'ku' | 'en', error: 'No speech detected in this video.' });
        }
      }, { once: true });
    });
  } catch (err: any) {
    cleanup();
    return { segments: [], detectedLanguage: 'en', error: err.message || 'Speech recognition failed.' };
  }
}

export async function autoGenerateAndSaveSubtitles(
  videoElement: HTMLVideoElement,
  episodeId: string,
  options: {
    preferredLanguage?: 'ku' | 'en';
    onProgress?: (text: string, segmentCount: number) => void;
  } = {}
): Promise<{ success: boolean; segments: STTSegment[]; detectedLanguage: 'ku' | 'en'; error: string | null }> {
  const { segments, detectedLanguage, error } = await recognizeSpeechFromVideo(videoElement, {
    preferredLanguage: options.preferredLanguage,
    onProgress: options.onProgress,
  });

  if (error || segments.length === 0) {
    return { success: false, segments: [], detectedLanguage, error };
  }

  // Save original language subtitles
  await saveSubtitlesToDb(episodeId, detectedLanguage, segments);

  // Translate and save the opposite language subtitles
  const oppositeLang: 'ku' | 'en' = detectedLanguage === 'ku' ? 'en' : 'ku';
  const translatedSegments = await translateSegments(segments, detectedLanguage, oppositeLang);
  if (translatedSegments.length > 0) {
    await saveSubtitlesToDb(episodeId, oppositeLang, translatedSegments);
  }

  return { success: true, segments, detectedLanguage, error: null };
}

async function saveSubtitlesToDb(episodeId: string, language: 'ku' | 'en', segments: STTSegment[]): Promise<void> {
  await supabase
    .from('subtitles')
    .delete()
    .eq('item_type', 'episode')
    .eq('item_id', episodeId)
    .eq('language', language)
    .eq('is_ai_generated', true);

  const rows = segments.map((s) => ({
    item_type: 'episode',
    item_id: episodeId,
    language,
    content: s.text,
    start_time: s.startTime,
    end_time: s.endTime,
    is_ai_generated: true,
    ai_status: 'completed',
    source_text: s.text,
  }));

  await supabase.from('subtitles').insert(rows);

  await supabase
    .from('ai_subtitle_jobs')
    .update({ status: 'completed', completed_at: new Date().toISOString() })
    .eq('episode_id', episodeId)
    .eq('language', language)
    .eq('status', 'processing');
}

async function translateSegments(
  segments: STTSegment[],
  fromLang: 'ku' | 'en',
  toLang: 'ku' | 'en'
): Promise<STTSegment[]> {
  try {
    const texts = segments.map((s) => s.text);
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/comic-translate`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({ texts, target_lang: toLang, source_lang: fromLang }),
    });
    if (!response.ok) return [];
    const data = await response.json();
    if (data.error) return [];
    const results = data.results || [];
    return segments.map((s, i) => ({
      ...s,
      text: results[i]?.translated || s.text,
      language: toLang,
    }));
  } catch {
    return [];
  }
}
