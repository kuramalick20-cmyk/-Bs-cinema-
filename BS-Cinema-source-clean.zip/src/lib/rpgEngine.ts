// Kirkuk RPG — Game Engine (movement, combat, AI, crime, economy)
import {
  type GameState, type Entity, type Vec2, type Direction, type TileMap,
  type ShopItem, generateKirkukMap, isSolidPixel, TILE_SIZE, MAP_WIDTH, MAP_HEIGHT,
  TILE_PROPS, SHOP_ITEMS,
} from './rpgTypes';

let entityIdCounter = 0;
function nextId(): string { return `e${++entityIdCounter}`; }
let messageIdCounter = 0;
function nextMsgId(): string { return `m${++messageIdCounter}`; }

function dist(a: Vec2, b: Vec2): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function dirFromVec(dx: number, dy: number): Direction {
  if (Math.abs(dx) > Math.abs(dy)) return dx > 0 ? 'right' : 'left';
  return dy > 0 ? 'down' : 'up';
}

export function createInitialState(): GameState {
  const map = generateKirkukMap();
  entityIdCounter = 0;

  // Player starts near center
  const player: Entity = {
    id: nextId(),
    type: 'player',
    name: 'تۆ',
    pos: { x: 15 * TILE_SIZE + 20, y: 20 * TILE_SIZE + 20 },
    dir: 'down',
    hp: 100,
    maxHp: 100,
    speed: 2.5,
    state: 'idle',
    attackCooldown: 0,
    lastAttackTime: 0,
    money: 0,
    inventory: [
      { id: 'sword_basic', name: 'شمشێری سادە', type: 'weapon', quantity: 1, value: 20, icon: '⚔' },
    ],
    color: '#f9e300',
    size: 12,
  };

  const entities: Entity[] = [];

  // Guards — patrol the citadel and city
  const guardPatrols: { start: Vec2; path: Vec2[] }[] = [
    { start: { x: 52 * TILE_SIZE, y: 5 * TILE_SIZE }, path: [
      { x: 50 * TILE_SIZE, y: 5 * TILE_SIZE }, { x: 55 * TILE_SIZE, y: 5 * TILE_SIZE },
      { x: 55 * TILE_SIZE, y: 7 * TILE_SIZE }, { x: 50 * TILE_SIZE, y: 7 * TILE_SIZE },
    ]},
    { start: { x: 30 * TILE_SIZE, y: 20 * TILE_SIZE }, path: [
      { x: 20 * TILE_SIZE, y: 20 * TILE_SIZE }, { x: 40 * TILE_SIZE, y: 20 * TILE_SIZE },
    ]},
    { start: { x: 15 * TILE_SIZE, y: 10 * TILE_SIZE }, path: [
      { x: 15 * TILE_SIZE, y: 5 * TILE_SIZE }, { x: 15 * TILE_SIZE, y: 15 * TILE_SIZE },
    ]},
    { start: { x: 45 * TILE_SIZE, y: 30 * TILE_SIZE }, path: [
      { x: 35 * TILE_SIZE, y: 30 * TILE_SIZE }, { x: 55 * TILE_SIZE, y: 30 * TILE_SIZE },
    ]},
  ];

  for (let i = 0; i < guardPatrols.length; i++) {
    const g = guardPatrols[i];
    entities.push({
      id: nextId(),
      type: 'guard',
      name: ` پاسنگەر ${i + 1}`,
      pos: { ...g.start },
      dir: 'down',
      hp: 80,
      maxHp: 80,
      speed: 1.8,
      state: 'wander',
      attackCooldown: 0,
      lastAttackTime: 0,
      visionRange: 180,
      patrolPath: g.path,
      patrolIndex: 0,
      isHostile: false,
      money: 20 + Math.floor(Math.random() * 30),
      inventory: [],
      color: '#3a7a3a',
      size: 12,
    });
  }

  // NPCs — citizens wandering around
  const npcSpawns: { x: number; y: number; name: string; dialogue: string; money: number }[] = [
    { x: 20 * TILE_SIZE, y: 15 * TILE_SIZE, name: 'باسک', dialogue: 'سڵاو! بازاڕ لە خوارەوەیە.', money: 15 },
    { x: 35 * TILE_SIZE, y: 25 * TILE_SIZE, name: 'ئاراس', dialogue: 'پاسنگەرەکان زۆر توندن، وریابە!', money: 25 },
    { x: 10 * TILE_SIZE, y: 35 * TILE_SIZE, name: 'هێڤی', dialogue: 'قەڵای کەرکووک لە سەرەوەیە.', money: 10 },
    { x: 25 * TILE_SIZE, y: 5 * TILE_SIZE, name: 'شیلان', dialogue: 'دەرمان بکڕە لە بازاڕ.', money: 20 },
    { x: 40 * TILE_SIZE, y: 18 * TILE_SIZE, name: 'ڕۆژ', dialogue: 'پارە لەسەر زەوی بدۆزەرە!', money: 30 },
    { x: 5 * TILE_SIZE, y: 25 * TILE_SIZE, name: 'بەفر', dialogue: 'چاودێر پاسنگەرەکان بکە.', money: 18 },
  ];

  for (const npc of npcSpawns) {
    entities.push({
      id: nextId(),
      type: 'npc',
      name: npc.name,
      pos: { x: npc.x, y: npc.y },
      dir: 'down',
      hp: 50,
      maxHp: 50,
      speed: 1.0,
      state: 'wander',
      attackCooldown: 0,
      lastAttackTime: 0,
      homePos: { x: npc.x, y: npc.y },
      wanderTarget: null,
      wanderTimer: Math.random() * 200,
      dialogue: npc.dialogue,
      money: npc.money,
      inventory: [],
      color: '#7a9acd',
      size: 11,
    });
  }

  // Shopkeeper — at the market
  entities.push({
    id: nextId(),
    type: 'shopkeeper',
    name: 'بازاڕچی',
    pos: { x: 34 * TILE_SIZE, y: 24 * TILE_SIZE },
    dir: 'down',
    hp: 100,
    maxHp: 100,
    speed: 0,
    state: 'idle',
    attackCooldown: 0,
    lastAttackTime: 0,
    dialogue: 'بییان بکە — شمشێر و دەرمان هەیە!',
    shopInventory: SHOP_ITEMS,
    money: 200,
    inventory: [],
    color: '#c89a3a',
    size: 12,
  });

  // Enemies — bandits in back alleys
  const enemySpawns: { x: number; y: number }[] = [
    { x: 5 * TILE_SIZE, y: 5 * TILE_SIZE },
    { x: 50 * TILE_SIZE, y: 35 * TILE_SIZE },
    { x: 25 * TILE_SIZE, y: 35 * TILE_SIZE },
    { x: 40 * TILE_SIZE, y: 12 * TILE_SIZE },
  ];

  for (let i = 0; i < enemySpawns.length; i++) {
    entities.push({
      id: nextId(),
      type: 'enemy',
      name: `دزی ${i + 1}`,
      pos: { x: enemySpawns[i].x, y: enemySpawns[i].y },
      dir: 'down',
      hp: 60,
      maxHp: 60,
      speed: 1.6,
      state: 'wander',
      attackCooldown: 0,
      lastAttackTime: 0,
      visionRange: 120,
      homePos: { x: enemySpawns[i].x, y: enemySpawns[i].y },
      wanderTarget: null,
      wanderTimer: Math.random() * 200,
      isHostile: false,
      money: 30 + Math.floor(Math.random() * 50),
      inventory: [],
      color: '#aa3333',
      size: 12,
    });
  }

  // Money pickups scattered on the map
  const moneySpawns: Vec2[] = [
    { x: 8 * TILE_SIZE, y: 12 * TILE_SIZE },
    { x: 22 * TILE_SIZE, y: 28 * TILE_SIZE },
    { x: 38 * TILE_SIZE, y: 6 * TILE_SIZE },
    { x: 48 * TILE_SIZE, y: 25 * TILE_SIZE },
    { x: 6 * TILE_SIZE, y: 35 * TILE_SIZE },
    { x: 28 * TILE_SIZE, y: 12 * TILE_SIZE },
    { x: 42 * TILE_SIZE, y: 35 * TILE_SIZE },
    { x: 12 * TILE_SIZE, y: 25 * TILE_SIZE },
  ];

  for (const m of moneySpawns) {
    entities.push({
      id: nextId(),
      type: 'npc' as any,
      name: 'پارە',
      pos: { x: m.x, y: m.y },
      dir: 'down',
      hp: 1,
      maxHp: 1,
      speed: 0,
      state: 'idle' as any,
      attackCooldown: 0,
      lastAttackTime: 0,
      money: 10 + Math.floor(Math.random() * 20),
      inventory: [],
      color: '#f9e300',
      size: 8,
    });
  }

  return {
    player,
    entities,
    map,
    money: 0,
    wantedLevel: 0,
    wantedTimer: 0,
    camera: { x: player.pos.x, y: player.pos.y },
    messages: [],
    kills: 0,
    itemsStolen: 0,
    gameOver: false,
    gameWon: false,
    paused: false,
    inShop: null,
    dialogueNpc: null,
  };
}

export function addMessage(state: GameState, text: string, color = '#f5f5f7'): void {
  state.messages.push({ id: nextMsgId(), text, time: Date.now(), color });
  if (state.messages.length > 6) state.messages.shift();
}

// Move entity with collision detection
function moveEntity(entity: Entity, dx: number, dy: number, map: TileMap): void {
  if (dx === 0 && dy === 0) return;
  const newX = entity.pos.x + dx;
  const newY = entity.pos.y + dy;
  // Check X movement
  if (!isSolidPixel(map, newX, entity.pos.y, entity.size)) {
    entity.pos.x = newX;
  }
  // Check Y movement
  if (!isSolidPixel(map, entity.pos.x, newY, entity.size)) {
    entity.pos.y = newY;
  }
  // Update direction
  if (dx !== 0 || dy !== 0) {
    entity.dir = dirFromVec(dx, dy);
  }
}

// Line of sight check — simple raycast
function hasLineOfSight(from: Vec2, to: Vec2, map: TileMap): boolean {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const steps = Math.ceil(Math.hypot(dx, dy) / (TILE_SIZE / 2));
  if (steps === 0) return true;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const px = from.x + dx * t;
    const py = from.y + dy * t;
    const tx = Math.floor(px / TILE_SIZE);
    const ty = Math.floor(py / TILE_SIZE);
    if (tx >= 0 && tx < map.width && ty >= 0 && ty < map.height) {
      if (TILE_PROPS[map.tiles[ty][tx]].solid) return false;
    }
  }
  return true;
}

// Player attack — hits entities in front within range
export function playerAttack(state: GameState): void {
  const p = state.player;
  const now = Date.now();
  if (now - p.lastAttackTime < 400) return; // attack cooldown
  p.lastAttackTime = now;

  const range = 50;
  const dirOffset: Record<Direction, Vec2> = {
    up: { x: 0, y: -range },
    down: { x: 0, y: range },
    left: { x: -range, y: 0 },
    right: { x: range, y: 0 },
  };
  const attackPos = { x: p.pos.x + dirOffset[p.dir].x, y: p.pos.y + dirOffset[p.dir].y };

  for (const e of state.entities) {
    if (e === p || e.state === 'dead') continue;
    if (dist(e.pos, attackPos) < range) {
      // Hit!
      const weapon = p.inventory.find((i) => i.type === 'weapon');
      const damage = weapon ? weapon.value : 10;
      e.hp -= damage;

      if (e.type === 'npc' || e.type === 'shopkeeper') {
        // Crime! Witnesses see it
        state.wantedLevel = Math.min(5, state.wantedLevel + 1);
        state.wantedTimer = 30;
        addMessage(state, `تاوان! پاسنگەرەکان بگەڕێ! +${state.wantedLevel}⭐`, '#ef3340');
        // Make all guards hostile
        for (const g of state.entities) {
          if (g.type === 'guard' && g.state !== 'dead') {
            g.state = 'chase';
            g.isHostile = true;
          }
        }
      }

      if (e.type === 'enemy') {
        e.isHostile = true;
        e.state = 'attack';
      }

      if (e.hp <= 0) {
        e.state = 'dead';
        // Drop money
        state.money += e.money;
        addMessage(state, `${e.name} کوشت! +${e.money} پارە 💰`, '#f9e300');
        if (e.type === 'enemy' || e.type === 'guard' || e.type === 'npc') {
          state.kills++;
        }
      } else {
        addMessage(state, `${e.name} بریندار کرا! (-${damage} HP)`, '#ff6666');
        // Guard fights back
        if (e.type === 'guard') {
          e.state = 'attack';
          e.isHostile = true;
        }
      }
    }
  }
}

// Steal from NPC — take their money
export function stealFromNpc(state: GameState, npc: Entity): void {
  if (npc.money <= 0) {
    addMessage(state, `${npc.name} پارەی نییە!`, '#999');
    return;
  }
  const stolen = npc.money;
  state.money += stolen;
  npc.money = 0;
  state.itemsStolen++;
  state.wantedLevel = Math.min(5, state.wantedLevel + 1);
  state.wantedTimer = 20;
  addMessage(state, `${stolen} پارە دزرایت! ⭐ تاوان`, '#ef3340');

  // Check if any guard sees
  for (const g of state.entities) {
    if (g.type === 'guard' && g.state !== 'dead') {
      if (dist(g.pos, state.player.pos) < (g.visionRange || 180) && hasLineOfSight(g.pos, state.player.pos, state.map)) {
        g.state = 'chase';
        g.isHostile = true;
        addMessage(state, 'پاسنگەر تۆی بینی!', '#ef3340');
      }
    }
  }
}

// Buy item from shopkeeper
export function buyItem(state: GameState, item: ShopItem): boolean {
  if (state.money < item.price) {
    addMessage(state, 'پارەی پێشتر نییە!', '#ef3340');
    return false;
  }
  state.money -= item.price;
  // Add to inventory
  const existing = state.player.inventory.find((i) => i.id === item.id);
  if (existing) {
    existing.quantity++;
  } else {
    state.player.inventory.push({
      id: item.id, name: item.name, type: item.type, quantity: 1,
      value: item.value, icon: item.icon,
    });
  }
  addMessage(state, `${item.name} کڕیت! (-${item.price} پارە)`, '#2bb24c');
  return true;
}

// Use a health potion
export function useHealthPotion(state: GameState): void {
  const potion = state.player.inventory.find((i) => i.type === 'health' && i.quantity > 0);
  if (!potion) {
    addMessage(state, 'دەرمانت نییە!', '#999');
    return;
  }
  state.player.hp = Math.min(state.player.maxHp, state.player.hp + potion.value);
  potion.quantity--;
  if (potion.quantity <= 0) {
    state.player.inventory = state.player.inventory.filter((i) => i !== potion);
  }
  addMessage(state, `دەرمان خواردی! (+${potion.value} HP)`, '#2bb24c');
}

// Pick up nearby money
export function pickupNearbyMoney(state: GameState): void {
  const p = state.player;
  for (const e of state.entities) {
    if (e.name === 'پارە' && e.state !== 'dead' && dist(e.pos, p.pos) < 30) {
      state.money += e.money;
      addMessage(state, `${e.money} پارە دۆزیتەوە! 💰`, '#f9e300');
      e.state = 'dead' as any;
    }
  }
  // Remove dead money entities
  state.entities = state.entities.filter((e) => !(e.name === 'پارە' && e.state === 'dead'));
}

// Interact with nearby NPC/shopkeeper
export function interactNearby(state: GameState): { type: 'dialogue' | 'shop' | 'steal' | 'none'; entity: Entity | null } {
  const p = state.player;
  let nearest: Entity | null = null;
  let nearestDist = 50;
  for (const e of state.entities) {
    if (e === p || e.state === 'dead') continue;
    const d = dist(e.pos, p.pos);
    if (d < nearestDist) {
      nearest = e;
      nearestDist = d;
    }
  }
  if (!nearest) return { type: 'none', entity: null };
  if (nearest.type === 'shopkeeper') return { type: 'shop', entity: nearest };
  if (nearest.type === 'npc' && nearest.money > 0) return { type: 'steal', entity: nearest };
  return { type: 'dialogue', entity: nearest };
}

// --- AI UPDATE ---
export function updateAI(state: GameState, dt: number): void {
  const player = state.player;
  if (player.state === 'dead' || state.gameOver) return;

  // Update wanted timer
  if (state.wantedTimer > 0) {
    state.wantedTimer -= dt / 60;
    if (state.wantedTimer <= 0) {
      state.wantedLevel = 0;
      // Guards calm down
      for (const g of state.entities) {
        if (g.type === 'guard' && g.state !== 'dead') {
          g.isHostile = false;
          g.state = 'wander';
        }
      }
      addMessage(state, 'تاوان لابوو. پاسنگەرەکان ئارام بوونەوە.', '#2bb24c');
    }
  }

  for (const e of state.entities) {
    if (e === player || e.state === 'dead') continue;
    if (e.name === 'پارە') continue; // money pickups don't move

    switch (e.type) {
      case 'guard':
        updateGuard(e, state, dt);
        break;
      case 'enemy':
        updateEnemy(e, state, dt);
        break;
      case 'npc':
        updateNpc(e, state, dt);
        break;
      case 'shopkeeper':
        // Stationary
        break;
    }
  }
}

function updateGuard(guard: Entity, state: GameState, dt: number): void {
  const player = state.player;

  if (guard.isHostile) {
    // Chase and attack player
    const d = dist(guard.pos, player.pos);
    if (d < 400) {
      guard.state = d < 50 ? 'attack' : 'chase';
      // Move toward player
      const dx = player.pos.x - guard.pos.x;
      const dy = player.pos.y - guard.pos.y;
      const len = Math.hypot(dx, dy) || 1;
      moveEntity(guard, (dx / len) * guard.speed, (dy / len) * guard.speed, state.map);

      if (d < 50 && Date.now() - guard.lastAttackTime > 800) {
        guard.lastAttackTime = Date.now();
        player.hp -= 15;
        addMessage(state, `پاسنگەر تۆی لێی دا! (-15 HP)`, '#ef3340');
        if (player.hp <= 0) {
          player.hp = 0;
          player.state = 'dead';
          state.gameOver = true;
          addMessage(state, 'تۆ مردیت! یاری کۆتایی هات.', '#ef3340');
        }
      }
    } else {
      // Lost sight — return to patrol
      guard.state = 'wander';
      guard.isHostile = false;
    }
    return;
  }

  // Patrol
  if (!guard.patrolPath || guard.patrolPath.length === 0) return;
  const target = guard.patrolPath[guard.patrolIndex || 0];
  const d = dist(guard.pos, target);
  if (d < 10) {
    guard.patrolIndex = ((guard.patrolIndex || 0) + 1) % guard.patrolPath.length;
  } else {
    const dx = target.x - guard.pos.x;
    const dy = target.y - guard.pos.y;
    const len = Math.hypot(dx, dy) || 1;
    moveEntity(guard, (dx / len) * guard.speed * 0.5, (dy / len) * guard.speed * 0.5, state.map);
  }

  // Check if player is committing crime in vision range
  if (state.wantedLevel > 0 && dist(guard.pos, player.pos) < (guard.visionRange || 180) && hasLineOfSight(guard.pos, player.pos, state.map)) {
    guard.state = 'chase';
    guard.isHostile = true;
  }
}

function updateEnemy(enemy: Entity, state: GameState, dt: number): void {
  const player = state.player;
  const d = dist(enemy.pos, player.pos);

  if (enemy.isHostile && d < 300) {
    enemy.state = d < 45 ? 'attack' : 'chase';
    const dx = player.pos.x - enemy.pos.x;
    const dy = player.pos.y - enemy.pos.y;
    const len = Math.hypot(dx, dy) || 1;
    moveEntity(enemy, (dx / len) * enemy.speed, (dy / len) * enemy.speed, state.map);

    if (d < 45 && Date.now() - enemy.lastAttackTime > 700) {
      enemy.lastAttackTime = Date.now();
      player.hp -= 12;
      addMessage(state, `${enemy.name} تۆی لێی دا! (-12 HP)`, '#ff6666');
      if (player.hp <= 0) {
        player.hp = 0;
        player.state = 'dead';
        state.gameOver = true;
        addMessage(state, 'تۆ مردیت!', '#ef3340');
      }
    }
  } else {
    // Detect player
    if (d < (enemy.visionRange || 120) && hasLineOfSight(enemy.pos, player.pos, state.map)) {
      enemy.isHostile = true;
    } else {
      // Wander
      wanderEntity(enemy, state, dt);
    }
  }
}

function updateNpc(npc: Entity, state: GameState, dt: number): void {
  // Flee if player is attacking
  if (npc.hp < npc.maxHp) {
    const d = dist(npc.pos, state.player.pos);
    if (d < 100) {
      npc.state = 'flee';
      const dx = npc.pos.x - state.player.pos.x;
      const dy = npc.pos.y - state.player.pos.y;
      const len = Math.hypot(dx, dy) || 1;
      moveEntity(npc, (dx / len) * npc.speed * 1.5, (dy / len) * npc.speed * 1.5, state.map);
      return;
    }
  }
  wanderEntity(npc, state, dt);
}

function wanderEntity(e: Entity, state: GameState, dt: number): void {
  e.wanderTimer = (e.wanderTimer || 0) - dt;
  if (!e.wanderTarget || e.wanderTimer <= 0) {
    // Pick new wander target near home
    const home = e.homePos || e.pos;
    const angle = Math.random() * Math.PI * 2;
    const r = 50 + Math.random() * 100;
    e.wanderTarget = {
      x: Math.max(TILE_SIZE, Math.min((MAP_WIDTH - 1) * TILE_SIZE, home.x + Math.cos(angle) * r)),
      y: Math.max(TILE_SIZE, Math.min((MAP_HEIGHT - 1) * TILE_SIZE, home.y + Math.sin(angle) * r)),
    };
    e.wanderTimer = 100 + Math.random() * 200;
    return;
  }
  const d = dist(e.pos, e.wanderTarget);
  if (d < 8) {
    e.wanderTarget = null;
    return;
  }
  const dx = e.wanderTarget.x - e.pos.x;
  const dy = e.wanderTarget.y - e.pos.y;
  const len = Math.hypot(dx, dy) || 1;
  moveEntity(e, (dx / len) * e.speed * 0.4, (dy / len) * e.speed * 0.4, state.map);
}

// Player movement
export function movePlayer(state: GameState, dx: number, dy: number): void {
  const p = state.player;
  if (p.state === 'dead') return;
  const len = Math.hypot(dx, dy);
  if (len > 0) {
    dx = (dx / len) * p.speed;
    dy = (dy / len) * p.speed;
    moveEntity(p, dx, dy, state.map);
    p.state = 'idle';
  }
}

// Auto-pickup money and check interactions
export function autoPickup(state: GameState): void {
  pickupNearbyMoney(state);
}

// Update camera to follow player
export function updateCamera(state: GameState, canvasW: number, canvasH: number): void {
  const targetX = state.player.pos.x - canvasW / 2;
  const targetY = state.player.pos.y - canvasH / 2;
  // Smooth camera
  state.camera.x += (targetX - state.camera.x) * 0.1;
  state.camera.y += (targetY - state.camera.y) * 0.1;
  // Clamp to map bounds
  const maxX = MAP_WIDTH * TILE_SIZE - canvasW;
  const maxY = MAP_HEIGHT * TILE_SIZE - canvasH;
  state.camera.x = Math.max(0, Math.min(maxX, state.camera.x));
  state.camera.y = Math.max(0, Math.min(maxY, state.camera.y));
}
