import type {
  WarbandGameState, WorldEntity, PlayerState3D, CameraMode,
} from './warbandTypes';
import { generateEnemy } from './warbandEngine';

// === World layout — each location gets a 3D position ===
// World is a flat plane, locations placed at scaled coords.
// World size: 200x200 units. Map coords (0-100) -> world coords (-100 to 100).

export function mapToWorld(loc: { x: number; y: number }): { x: number; z: number } {
  return {
    x: (loc.x - 50) * 2,
    z: (loc.y - 50) * 2,
  };
}

export function worldToMap(x: number, z: number): { x: number; y: number } {
  return { x: x / 2 + 50, y: z / 2 + 50 };
}

// Generate 3D entities around a location when entering explore mode
export function generateExploreEntities(
  state: WarbandGameState,
  locId: string,
): WorldEntity[] {
  const loc = state.locations.find((l) => l.id === locId);
  if (!loc) return [];

  const entities: WorldEntity[] = [];
  const { x: cx, z: cz } = mapToWorld(loc);
  const isEnemyTerritory = loc.faction !== state.playerFaction;

  // Spawn enemies if enemy territory
  const enemyCount = loc.type === 'city' ? 4 : loc.type === 'castle' ? 3 : loc.type === 'village' ? 2 : isEnemyTerritory ? 2 : 1;
  for (let i = 0; i < enemyCount; i++) {
    const angle = (i / enemyCount) * Math.PI * 2;
    const dist = 15 + Math.random() * 10;
    const enemy = generateEnemy(loc.faction, state.level, loc.type);
    entities.push({
      id: enemy.id,
      type: 'enemy',
      name: enemy.name,
      faction: loc.faction,
      x: cx + Math.cos(angle) * dist,
      z: cz + Math.sin(angle) * dist,
      vx: 0, vz: 0,
      angle: Math.atan2(cx - (cx + Math.cos(angle) * dist), cz - (cz + Math.sin(angle) * dist)),
      hp: enemy.hp,
      maxHp: enemy.maxHp,
      attack: enemy.attack,
      defense: enemy.defense,
      speed: enemy.speed,
      weapon: enemy.weapon,
      role: enemy.role,
      level: enemy.level,
      state: 'idle',
      targetId: null,
      attackCooldown: 0,
      hitFlash: 0,
      portraitColor: enemy.portraitColor,
      accentColor: enemy.accentColor,
    });
  }

  // Spawn a horse near the location entrance
  entities.push({
    id: `horse_${Date.now()}`,
    type: 'horse',
    name: 'Wild Horse',
    faction: loc.faction,
    x: cx + 5,
    z: cz + 8,
    vx: 0, vz: 0,
    angle: 0,
    hp: 50, maxHp: 50,
    attack: 0, defense: 5, speed: 40,
    weapon: 'sword',
    role: 'scout',
    level: 1,
    state: 'idle',
    targetId: null,
    attackCooldown: 0,
    hitFlash: 0,
    portraitColor: '#8b4513',
    accentColor: '#daa520',
  });

  // Spawn friendly NPC in own territory
  if (!isEnemyTerritory && (loc.type === 'city' || loc.type === 'castle' || loc.type === 'village')) {
    entities.push({
      id: `npc_${Date.now()}`,
      type: 'npc',
      name: 'Villager',
      faction: loc.faction,
      x: cx + 3,
      z: cz + 3,
      vx: 0, vz: 0,
      angle: 0,
      hp: 30, maxHp: 30,
      attack: 5, defense: 5, speed: 10,
      weapon: 'sword',
      role: 'warrior',
      level: 1,
      state: 'idle',
      targetId: null,
      attackCooldown: 0,
      hitFlash: 0,
      portraitColor: '#4a7a4a',
      accentColor: '#90ee90',
    });
  }

  return entities;
}

// Enter explore mode at a location
export function enterExplore(state: WarbandGameState, locId: string): WarbandGameState {
  const loc = state.locations.find((l) => l.id === locId);
  if (!loc) return state;
  const { x, z } = mapToWorld(loc);
  const entities = generateExploreEntities(state, locId);

  return {
    ...state,
    screen: 'explore',
    currentLocationId: locId,
    nearbyLocationId: locId,
    worldEntities: entities,
    player3D: {
      ...state.player3D,
      x: x + 8,
      z: z + 12,
      vx: 0, vz: 0,
      angle: Math.atan2(x - (x + 8), z - (z + 12)),
      camYaw: Math.atan2(x - (x + 8), z - (z + 12)),
      isMounted: false,
      isBlocking: false,
      isMoving: false,
      attackCooldown: 0,
      attackAnim: 0,
      currentHp: state.hp,
    },
  };
}

// Leave explore mode back to world map
export function exitExplore(state: WarbandGameState): WarbandGameState {
  return {
    ...state,
    screen: 'world-map',
    worldEntities: [],
    hp: state.player3D.currentHp > 0 ? state.player3D.currentHp : state.hp,
    player3D: { ...state.player3D, isMoving: false, isMounted: false },
  };
}

// Toggle camera mode
export function toggleCamera(state: WarbandGameState): WarbandGameState {
  const newMode: CameraMode = state.cameraMode === 'third-person' ? 'first-person' : 'third-person';
  return { ...state, cameraMode: newMode };
}

// Find nearest entity within range
function findNearestEntity(player: PlayerState3D, entities: WorldEntity[], maxDist: number, filter?: (e: WorldEntity) => boolean): WorldEntity | null {
  let nearest: WorldEntity | null = null;
  let minDist = maxDist;
  for (const e of entities) {
    if (e.state === 'dead') continue;
    if (filter && !filter(e)) continue;
    const dx = e.x - player.x;
    const dz = e.z - player.z;
    const d = Math.sqrt(dx * dx + dz * dz);
    if (d < minDist) {
      minDist = d;
      nearest = e;
    }
  }
  return nearest;
}

// === Main update loop — called every frame with delta time ===
export function updateWorld3D(
  state: WarbandGameState,
  dt: number,
  joystickDX: number,
  joystickDY: number,
  actions: { attack: boolean; block: boolean; dodge: boolean; mount: boolean; interact: boolean },
): WarbandGameState {
  const p = { ...state.player3D };
  const entities = state.worldEntities.map((e) => ({ ...e }));
  let log = [...state.combatLog];
  let gold = state.gold;
  let xp = state.xp;
  let level = state.level;
  let maxHp = state.maxHp;
  let attack = state.attack;
  let totalBattlesWon = state.totalBattlesWon;
  let quests = state.quests;

  // Player movement
  const moveSpeed = (p.isMounted ? 18 : 8) * (actions.block ? 0.3 : 1);
  const joyMag = Math.sqrt(joystickDX * joystickDX + joystickDY * joystickDY);
  p.isMoving = joyMag > 0.1;
  p.isRunning = joyMag > 0.7;
  p.isBlocking = actions.block;

  if (p.isMoving) {
    // Camera-relative movement: joystick up = forward (camera direction)
    const camForward = { x: Math.sin(p.camYaw), z: Math.cos(p.camYaw) };
    const camRight = { x: Math.cos(p.camYaw), z: -Math.sin(p.camYaw) };
    const moveX = camRight.x * joystickDX + camForward.x * (-joystickDY);
    const moveZ = camRight.z * joystickDX + camForward.z * (-joystickDY);
    const mag = Math.sqrt(moveX * moveX + moveZ * moveZ) || 1;
    p.vx = (moveX / mag) * moveSpeed * Math.min(joyMag, 1);
    p.vz = (moveZ / mag) * moveSpeed * Math.min(joyMag, 1);
    p.angle = Math.atan2(p.vx, p.vz);
  } else {
    p.vx *= 0.85;
    p.vz *= 0.85;
  }

  p.x += p.vx * dt;
  p.z += p.vz * dt;

  // Clamp to world bounds
  p.x = Math.max(-100, Math.min(100, p.x));
  p.z = Math.max(-100, Math.min(100, p.z));

  // Attack
  p.attackCooldown = Math.max(0, p.attackCooldown - dt);
  p.attackAnim = Math.max(0, p.attackAnim - dt * 3);
  p.blockAnim = Math.max(0, p.blockAnim - dt * 3);
  p.dodgeAnim = Math.max(0, p.dodgeAnim - dt * 5);
  p.hitFlash = Math.max(0, p.hitFlash - dt * 3);

  if (actions.attack && p.attackCooldown <= 0) {
    p.attackCooldown = 0.6;
    p.attackAnim = 1;
    const pAtk = attack + (state.equippedWeapon?.attackBonus || 0);
    // Find nearest enemy within attack range
    const target = findNearestEntity(p, entities, 4, (e) => e.type === 'enemy');
    if (target) {
      const damage = Math.max(5, pAtk - target.defense + Math.floor(Math.random() * 10) - 5);
      target.hp -= damage;
      target.hitFlash = 1;
      target.vx += (target.x - p.x) * 0.5;
      target.vz += (target.z - p.z) * 0.5;
      log.push({ id: Date.now() + Math.random(), text: `Hit ${target.name} for ${damage}!`, time: Date.now() });
      if (target.hp <= 0) {
        target.state = 'dead';
        const reward = 30 + target.level * 12;
        const xpGain = 20 + target.level * 8;
        gold += reward;
        xp += xpGain;
        log.push({ id: Date.now() + Math.random(), text: `Defeated ${target.name}! +${reward}g +${xpGain}xp`, time: Date.now() });
        totalBattlesWon++;
        // Level up check
        const newLevel = Math.floor(xp / 200) + 1;
        if (newLevel > level) {
          level = newLevel;
          maxHp += 20;
          attack += 3;
          log.push({ id: Date.now() + Math.random(), text: `Level Up! Now level ${newLevel}!`, time: Date.now() });
        }
      } else {
        target.state = 'chase';
        target.targetId = 'player';
      }
    }
  }

  // Dodge
  if (actions.dodge && p.dodgeAnim <= 0) {
    p.dodgeAnim = 1;
    // Quick dash forward
    p.vx *= 3;
    p.vz *= 3;
  }

  // Mount/dismount
  if (actions.mount) {
    if (p.isMounted) {
      p.isMounted = false;
      log.push({ id: Date.now() + Math.random(), text: 'Dismounted horse', time: Date.now() });
    } else {
      const horse = findNearestEntity(p, entities, 5, (e) => e.type === 'horse');
      if (horse) {
        p.isMounted = true;
        log.push({ id: Date.now() + Math.random(), text: 'Mounted horse! Use joystick to ride.', time: Date.now() });
      }
    }
  }

  // Interact with NPC / location
  let nearbyLocationId = state.nearbyLocationId;
  if (actions.interact) {
    const npc = findNearestEntity(p, entities, 4, (e) => e.type === 'npc');
    if (npc) {
      log.push({ id: Date.now() + Math.random(), text: `${npc.name}: "Welcome, traveler!"`, time: Date.now() });
    }
  }

  // Check if near a location structure
  const currentLoc = state.locations.find((l) => l.id === state.currentLocationId);
  if (currentLoc) {
    const { x: lx, z: lz } = mapToWorld(currentLoc);
    const distToLoc = Math.sqrt((p.x - lx) ** 2 + (p.z - lz) ** 2);
    if (distToLoc < 6) {
      nearbyLocationId = currentLoc.id;
    } else {
      nearbyLocationId = null;
    }
  }

  // === Enemy AI ===
  for (const e of entities) {
    if (e.state === 'dead') continue;
    e.attackCooldown = Math.max(0, e.attackCooldown - dt);
    e.hitFlash = Math.max(0, e.hitFlash - dt * 3);

    if (e.type === 'enemy') {
      const dx = p.x - e.x;
      const dz = p.z - e.z;
      const dist = Math.sqrt(dx * dx + dz * dz);
      const aggroRange = 25;

      if (dist < aggroRange && e.state === 'idle') {
        e.state = 'chase';
        e.targetId = 'player';
      }

      if (e.state === 'chase' || e.state === 'attack') {
        if (dist < 3 && e.attackCooldown <= 0) {
          // Attack player
          e.state = 'attack';
          e.attackCooldown = 1.2;
          const pDef = state.defense + (state.equippedArmor?.defenseBonus || 0) + (state.equippedShield?.defenseBonus || 0);
          let dmg = Math.max(3, e.attack - pDef + Math.floor(Math.random() * 6) - 3);
          if (p.isBlocking) dmg = Math.floor(dmg * 0.3);
          if (p.dodgeAnim > 0.3 && Math.random() > 0.4) dmg = 0;
          p.currentHp -= dmg;
          p.hitFlash = dmg > 0 ? 1 : 0;
          if (dmg > 0) {
            log.push({ id: Date.now() + Math.random(), text: `${e.name} hit you for ${dmg}!`, time: Date.now() });
          } else if (p.isBlocking) {
            log.push({ id: Date.now() + Math.random(), text: `Blocked ${e.name}'s attack!`, time: Date.now() });
          }
        } else if (dist < aggroRange) {
          e.state = 'chase';
          const sp = e.speed * 0.6;
          e.vx = (dx / dist) * sp;
          e.vz = (dz / dist) * sp;
          e.angle = Math.atan2(e.vx, e.vz);
        } else {
          e.state = 'idle';
          e.vx *= 0.8;
          e.vz *= 0.8;
        }
      }

      if (e.state === 'idle') {
        // Wander
        if (Math.random() < 0.01) {
          const a = Math.random() * Math.PI * 2;
          e.vx = Math.cos(a) * 2;
          e.vz = Math.sin(a) * 2;
          e.angle = Math.atan2(e.vx, e.vz);
        }
        e.vx *= 0.9;
        e.vz *= 0.9;
      }

      // Flee if low HP
      if (e.hp < e.maxHp * 0.2) {
        e.state = 'flee';
        const sp = e.speed * 0.8;
        e.vx = -(dx / dist) * sp;
        e.vz = -(dz / dist) * sp;
        e.angle = Math.atan2(e.vx, e.vz);
      }
    }

    // Horse wander
    if (e.type === 'horse' && e.state === 'idle') {
      if (Math.random() < 0.005) {
        const a = Math.random() * Math.PI * 2;
        e.vx = Math.cos(a) * 3;
        e.vz = Math.sin(a) * 3;
        e.angle = Math.atan2(e.vx, e.vz);
      }
      e.vx *= 0.9;
      e.vz *= 0.9;
    }

    // Apply velocity
    e.x += e.vx * dt;
    e.z += e.vz * dt;
    e.x = Math.max(-100, Math.min(100, e.x));
    e.z = Math.max(-100, Math.min(100, e.z));
  }

  // Player death
  if (p.currentHp <= 0) {
    p.currentHp = Math.floor(state.maxHp * 0.3);
    const lossGold = Math.floor(gold * 0.1);
    gold -= lossGold;
    log.push({ id: Date.now() + Math.random(), text: `Defeated! Lost ${lossGold} gold.`, time: Date.now() });
    return {
      ...state,
      screen: 'world-map',
      hp: p.currentHp,
      gold,
      worldEntities: [],
      player3D: { ...p, isMoving: false, isMounted: false },
      combatLog: log.slice(-20),
    };
  }

  // Check if all enemies defeated -> can conquer
  const aliveEnemies = entities.filter((e) => e.type === 'enemy' && e.state !== 'dead');
  if (aliveEnemies.length === 0 && currentLoc && currentLoc.faction !== state.playerFaction) {
    // Auto-conquer if all enemies dead
    const newLocations = state.locations.map((l) =>
      l.id === currentLoc.id ? { ...l, faction: state.playerFaction, garrison: Math.max(10, l.garrison) } : l,
    );
    const ownedTerritories = state.ownedTerritories.includes(currentLoc.id)
      ? state.ownedTerritories
      : [...state.ownedTerritories, currentLoc.id];
    const factions = state.factions.map((f) => ({
      ...f,
      territories: newLocations.filter((l) => l.faction === f.id).length,
    }));
    const goldGain = currentLoc.wealth;
    const xpGain = 100;
    gold += goldGain;
    xp += xpGain;
    log.push({ id: Date.now() + Math.random(), text: `${currentLoc.name} conquered! +${goldGain}g +${xpGain}xp`, time: Date.now() });
    quests = quests.map((q) => {
      if (!q.completed && q.type === 'conquer' && q.target === 'any') return { ...q, completed: true };
      return q;
    });
    return {
      ...state,
      player3D: p,
      worldEntities: entities,
      locations: newLocations,
      ownedTerritories,
      factions,
      gold,
      xp,
      level,
      maxHp,
      attack,
      totalBattlesWon,
      quests,
      nearbyLocationId,
      combatLog: log.slice(-20),
    };
  }

  return {
    ...state,
    player3D: p,
    worldEntities: entities,
    gold,
    xp,
    level,
    maxHp,
    attack,
    totalBattlesWon,
    nearbyLocationId,
    combatLog: log.slice(-20),
  };
}

// Update camera from touch drag
export function updateCamera(state: WarbandGameState, dYaw: number, dPitch: number): WarbandGameState {
  const p = { ...state.player3D };
  p.camYaw += dYaw;
  p.camPitch = Math.max(-0.5, Math.min(1.0, p.camPitch + dPitch));
  return { ...state, player3D: p };
}
