import { supabase, type Subtitle, type AiSubtitleJob } from './supabase';

export async function fetchSubtitles(itemType: 'episode' | 'comic_panel', itemId: string): Promise<Subtitle[]> {
  const { data, error } = await supabase
    .from('subtitles')
    .select('*')
    .eq('item_type', itemType)
    .eq('item_id', itemId)
    .order('start_time', { ascending: true, nullsFirst: false });
  if (error) return [];
  return (data as Subtitle[]) || [];
}

export function findActiveSubtitle(subtitles: Subtitle[], currentTime: number, language: 'ku' | 'en'): Subtitle | null {
  return subtitles.find(
    (s) => s.language === language &&
    s.start_time != null && s.end_time != null &&
    currentTime >= s.start_time && currentTime <= s.end_time
  ) || null;
}

export async function translateSubtitle(
  text: string,
  targetLang: string = 'en'
): Promise<{ translated: string; error: string | null }> {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/translate`;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
    };
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify({ text, target_lang: targetLang }),
    });
    if (!response.ok) {
      return { translated: '', error: `Translation failed (${response.status})` };
    }
    const data = await response.json();
    if (data.error) {
      return { translated: '', error: data.error };
    }
    return { translated: data.translated || '', error: null };
  } catch (err: any) {
    return { translated: '', error: err.message || 'Translation request failed' };
  }
}

// === AI Subtitle Management ===
export async function saveAISubtitles(
  episodeId: string,
  language: 'ku' | 'en',
  subtitles: Array<{ content: string; start_time: number; end_time: number; source_text?: string }>
): Promise<{ success: boolean; error: string | null }> {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-subtitles`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({ episode_id: episodeId, language, subtitles }),
    });
    if (!response.ok) {
      return { success: false, error: `Failed to save AI subtitles (${response.status})` };
    }
    const data = await response.json();
    if (data.error) {
      return { success: false, error: data.error };
    }
    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err.message || 'Failed to save AI subtitles' };
  }
}

export async function deleteSubtitles(episodeId: string, language: 'ku' | 'en'): Promise<void> {
  await supabase
    .from('subtitles')
    .delete()
    .eq('item_type', 'episode')
    .eq('item_id', episodeId)
    .eq('language', language);
}

export async function fetchSubtitleJobs(episodeId: string): Promise<AiSubtitleJob[]> {
  const { data, error } = await supabase
    .from('ai_subtitle_jobs')
    .select('*')
    .eq('episode_id', episodeId)
    .order('created_at', { ascending: false });
  if (error) return [];
  return (data as AiSubtitleJob[]) || [];
}

export async function generateSubtitlesFromTranscript(
  episodeId: string,
  language: 'ku' | 'en',
  transcript: string,
  sourceLanguage?: string
): Promise<{ success: boolean; error: string | null }> {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-subtitles`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({ episode_id: episodeId, language, transcript, source_language: sourceLanguage }),
    });
    if (!response.ok) {
      return { success: false, error: `Failed to generate subtitles (${response.status})` };
    }
    const data = await response.json();
    if (data.error) {
      return { success: false, error: data.error };
    }
    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err.message || 'Failed to generate subtitles' };
  }
}

