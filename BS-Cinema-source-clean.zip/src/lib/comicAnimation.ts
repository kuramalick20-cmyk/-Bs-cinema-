import { supabase, type AiVideoProvider, type AiProviderSettings, type ComicPanelAnimation, type ComicPanelSubtitle, type ComicCharacterRef, type CameraMotion, type AnimationStatus } from './supabase';
import { uploadFile } from './storage';

// === Provider Settings ===

export async function fetchProviderSettings(): Promise<AiProviderSettings | null> {
  const { data } = await supabase
    .from('ai_provider_settings')
    .select('*')
    .limit(1)
    .maybeSingle();
  return data as AiProviderSettings | null;
}

export async function updateProviderSettings(updates: Partial<AiProviderSettings>): Promise<boolean> {
  const { data: existing } = await supabase
    .from('ai_provider_settings')
    .select('id')
    .limit(1)
    .maybeSingle();

  if (existing) {
    const { error } = await supabase
      .from('ai_provider_settings')
      .update(updates)
      .eq('id', existing.id);
    return !error;
  }

  const { error } = await supabase
    .from('ai_provider_settings')
    .insert(updates);
  return !error;
}

// === Video Providers CRUD ===

export async function fetchVideoProviders(): Promise<AiVideoProvider[]> {
  const { data } = await supabase
    .from('ai_video_providers')
    .select('*')
    .order('created_at', { ascending: true });
  return (data as AiVideoProvider[]) || [];
}

export async function createVideoProvider(provider: Omit<AiVideoProvider, 'id' | 'created_at' | 'updated_at'>): Promise<AiVideoProvider | null> {
  // If setting as default, unset other defaults first
  if (provider.is_default) {
    await supabase.from('ai_video_providers').update({ is_default: false }).neq('id', '00000000-0000-0000-0000-000000000000');
  }
  const { data, error } = await supabase
    .from('ai_video_providers')
    .insert(provider)
    .select('*')
    .single();
  if (error) return null;
  return data as AiVideoProvider;
}

export async function updateVideoProvider(id: string, updates: Partial<AiVideoProvider>): Promise<boolean> {
  if (updates.is_default) {
    await supabase.from('ai_video_providers').update({ is_default: false }).neq('id', id);
  }
  const { error } = await supabase
    .from('ai_video_providers')
    .update(updates)
    .eq('id', id);
  return !error;
}

export async function deleteVideoProvider(id: string): Promise<boolean> {
  const { error } = await supabase
    .from('ai_video_providers')
    .delete()
    .eq('id', id);
  return !error;
}

// === Panel Animations ===

export async function fetchPanelAnimation(panelId: string): Promise<ComicPanelAnimation | null> {
  const { data } = await supabase
    .from('comic_panel_animations')
    .select('*')
    .eq('panel_id', panelId)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();
  return data as ComicPanelAnimation | null;
}

export async function fetchPanelAnimationsByChapter(chapterId: string): Promise<ComicPanelAnimation[]> {
  const { data: panels } = await supabase
    .from('comic_panels')
    .select('id')
    .eq('chapter_id', chapterId);
  if (!panels || panels.length === 0) return [];

  const panelIds = panels.map((p: any) => p.id);
  const { data } = await supabase
    .from('comic_panel_animations')
    .select('*')
    .in('panel_id', panelIds)
    .order('created_at', { ascending: false });

  // Keep only the latest animation per panel
  const seen = new Set<string>();
  const result: ComicPanelAnimation[] = [];
  for (const anim of (data as ComicPanelAnimation[]) || []) {
    if (!seen.has(anim.panel_id)) {
      seen.add(anim.panel_id);
      result.push(anim);
    }
  }
  return result;
}

// === ChatGPT Panel Analysis ===

export interface ChatGPTAnalysis {
  characters: Array<{
    name: string;
    description: string;
    clothing: string;
    hair: string;
    eye_color: string;
    position: string;
    expression: string;
  }>;
  dialogue: Array<{
    text: string;
    character: string;
    position: string;
    language: string;
  }>;
  scene: string;
  camera: string;
  motion: string[];
  duration: number;
  style: string;
}

export async function analyzePanelWithChatGPT(
  imageUrl: string,
  userInstruction?: string,
): Promise<{ analysis: ChatGPTAnalysis; error: string | null }> {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/comic-animation?action=analyze`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({ image_url: imageUrl, user_instruction: userInstruction }),
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      return { analysis: {} as ChatGPTAnalysis, error: errData.error || `Analysis failed (${response.status})` };
    }

    const data = await response.json();
    return { analysis: data.analysis as ChatGPTAnalysis, error: null };
  } catch (err: any) {
    return { analysis: {} as ChatGPTAnalysis, error: err.message || 'Analysis request failed' };
  }
}

// === Image-to-Video Generation ===

export async function generatePanelVideo(
  panelId: string,
  imageUrl: string,
  options: {
    duration?: number;
    cameraMotion?: CameraMotion;
    animationPrompt?: string;
    analysis?: ChatGPTAnalysis | null;
  } = {},
): Promise<{ success: boolean; videoUrl: string | null; jobId: string | null; error: string | null }> {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/comic-animation?action=generate`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({
        panel_id: panelId,
        image_url: imageUrl,
        duration: options.duration || 4,
        camera_motion: options.cameraMotion || 'static',
        animation_prompt: options.animationPrompt || '',
        analysis: options.analysis || null,
      }),
    });

    const data = await response.json();
    if (!response.ok) {
      return { success: false, videoUrl: null, jobId: data.job_id || null, error: data.error || `Generation failed (${response.status})` };
    }

    return { success: true, videoUrl: data.video_url, jobId: data.job_id, error: null };
  } catch (err: any) {
    return { success: false, videoUrl: null, jobId: null, error: err.message || 'Generation request failed' };
  }
}

// === Improve Prompt with ChatGPT ===

export async function improveAnimationPrompt(
  imageUrl: string,
  userInstruction: string,
  currentAnalysis?: ChatGPTAnalysis | null,
): Promise<{ prompt: string; camera: string; duration: number; motion: string[]; error: string | null }> {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/comic-animation?action=improve-prompt`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({
        image_url: imageUrl,
        user_instruction: userInstruction,
        current_analysis: currentAnalysis,
      }),
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      return { prompt: '', camera: 'static', duration: 4, motion: [], error: errData.error || 'Prompt improvement failed' };
    }

    const data = await response.json();
    const result = data.result || {};
    return {
      prompt: result.prompt || '',
      camera: result.camera || 'static',
      duration: result.duration || 4,
      motion: result.motion || [],
      error: null,
    };
  } catch (err: any) {
    return { prompt: '', camera: 'static', duration: 4, motion: [], error: err.message || 'Request failed' };
  }
}

// === Check Job Status ===

export async function checkAnimationStatus(jobId: string): Promise<{ status: AnimationStatus; videoUrl: string | null; error: string | null }> {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/comic-animation?action=status`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({ job_id: jobId }),
    });

    if (!response.ok) return { status: 'failed', videoUrl: null, error: 'Status check failed' };
    const data = await response.json();
    const job = data.job;
    return {
      status: job.status,
      videoUrl: job.video_url,
      error: job.error_message,
    };
  } catch {
    return { status: 'failed', videoUrl: null, error: 'Request failed' };
  }
}

// === Panel Subtitles ===

export async function fetchPanelSubtitles(panelId: string): Promise<ComicPanelSubtitle[]> {
  const { data } = await supabase
    .from('comic_panel_subtitles')
    .select('*')
    .eq('panel_id', panelId)
    .order('start_time', { ascending: true });
  return (data as ComicPanelSubtitle[]) || [];
}

export async function savePanelSubtitle(sub: Omit<ComicPanelSubtitle, 'id' | 'created_at'>): Promise<ComicPanelSubtitle | null> {
  const { data, error } = await supabase
    .from('comic_panel_subtitles')
    .insert(sub)
    .select('*')
    .single();
  if (error) return null;
  return data as ComicPanelSubtitle;
}

export async function updatePanelSubtitle(id: string, updates: Partial<ComicPanelSubtitle>): Promise<boolean> {
  const { error } = await supabase
    .from('comic_panel_subtitles')
    .update(updates)
    .eq('id', id);
  return !error;
}

export async function deletePanelSubtitle(id: string): Promise<boolean> {
  const { error } = await supabase
    .from('comic_panel_subtitles')
    .delete()
    .eq('id', id);
  return !error;
}

// === Camera Motion Options ===

export const CAMERA_MOTIONS: Array<{ value: CameraMotion; label: string; labelEn: string }> = [
  { value: 'static', label: 'جێگیر', labelEn: 'Static' },
  { value: 'zoom_in', label: 'نزیکبوونەوە', labelEn: 'Slow Zoom In' },
  { value: 'zoom_out', label: 'دووربوون', labelEn: 'Slow Zoom Out' },
  { value: 'pan_left', label: 'جوڵاندن بۆ چەپ', labelEn: 'Pan Left' },
  { value: 'pan_right', label: 'جوڵاندن بۆ ڕاست', labelEn: 'Pan Right' },
  { value: 'subtle', label: 'جوڵانی بچووک', labelEn: 'Subtle Movement' },
];

// === Timeline Helper ===

export function buildChapterTimeline(
  panels: Array<{ id: string; panel_order: number; video_url: string | null }>,
  animations: ComicPanelAnimation[],
  defaultDuration: number,
): Array<{ panelId: string; order: number; startTime: number; endTime: number; duration: number; hasVideo: boolean }> {
  let currentTime = 0;
  return panels
    .sort((a, b) => a.panel_order - b.panel_order)
    .map((panel) => {
      const anim = animations.find((a) => a.panel_id === panel.id && a.status === 'completed');
      const duration = anim?.duration || defaultDuration;
      const timeline = {
        panelId: panel.id,
        order: panel.panel_order,
        startTime: currentTime,
        endTime: currentTime + duration,
        duration,
        hasVideo: !!(panel.video_url || anim?.video_url),
      };
      currentTime = timeline.endTime;
      return timeline;
    });
}

// === Upload reference image for character ===

export async function uploadCharacterReference(contentId: string, file: File): Promise<string | null> {
  const path = `character-refs/${contentId}/${Date.now()}-${file.name}`;
  return await uploadFile('panels', file, path);
}

// === Character References CRUD ===

export async function fetchCharacterRefs(contentId: string): Promise<ComicCharacterRef[]> {
  const { data } = await supabase
    .from('comic_character_refs')
    .select('*')
    .eq('content_id', contentId)
    .order('created_at', { ascending: true });
  return (data as ComicCharacterRef[]) || [];
}

export async function createCharacterRef(ref: Omit<ComicCharacterRef, 'id' | 'created_at' | 'updated_at'>): Promise<ComicCharacterRef | null> {
  const { data, error } = await supabase
    .from('comic_character_refs')
    .insert(ref)
    .select('*')
    .single();
  if (error) return null;
  return data as ComicCharacterRef;
}

export async function updateCharacterRef(id: string, updates: Partial<ComicCharacterRef>): Promise<boolean> {
  const { error } = await supabase
    .from('comic_character_refs')
    .update(updates)
    .eq('id', id);
  return !error;
}

export async function deleteCharacterRef(id: string): Promise<boolean> {
  const { error } = await supabase
    .from('comic_character_refs')
    .delete()
    .eq('id', id);
  return !error;
}
