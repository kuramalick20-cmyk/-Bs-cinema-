import { supabase, type ComicCharacter, type ComicSpeechBubble } from './supabase';

// === Language Detection ===
// Detects the language of a given text based on Unicode character ranges
export function detectLanguage(text: string): string {
  if (!text || !text.trim()) return 'ku';

  const sample = text.trim();

  // Arabic range: U+0600-U+06FF, U+0750-U+077F, U+08A0-U+08FF
  // Kurdish Sorani uses Arabic script with extra letters (ڕ, ڵ, ۆ, ێ, ێ, ۏ)
  const kurdishSpecific = /[\u0695\u06B5\u06C6\u06CE\u06D0\u06CF\u0686]/;
  const arabicRange = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]/;

  // Persian specific: گ, چ, پ, ژ
  const persianSpecific = /[\u06AF\u0686\u067E\u0698]/;

  // Hebrew: U+0590-U+05FF
  const hebrewRange = /[\u0590-\u05FF]/;

  // Cyrillic (Russian, Ukrainian): U+0400-U+04FF
  const cyrillicRange = /[\u0400-\u04FF]/;

  // Latin (English, French, German, Spanish, Turkish, etc.)
  const latinRange = /[\u0041-\u005A\u0061-\u007A]/;

  // CJK (Chinese, Japanese, Korean)
  const cjkRange = /[\u4E00-\u9FFF\u3040-\u309F\u30A0-\u30FF\uAC00-\uD7AF]/;

  // Devanagari (Hindi)
  const devanagariRange = /[\u0900-\u097F]/;

  // Thai
  const thaiRange = /[\u0E00-\u0E7F]/;

  if (kurdishSpecific.test(sample) || arabicRange.test(sample)) {
    // Check if it's Kurdish specifically (has Kurdish-specific letters)
    if (kurdishSpecific.test(sample)) return 'ku';
    // Check if it's Persian
    if (persianSpecific.test(sample)) return 'fa';
    // Default to Arabic for Arabic script without Kurdish/Persian specifics
    return 'ar';
  }

  if (hebrewRange.test(sample)) return 'he';
  if (cyrillicRange.test(sample)) {
    // Could be Russian or Ukrainian, default to Russian
    return 'ru';
  }
  if (cjkRange.test(sample)) {
    // Distinguish: Japanese has hiragana/katakana, Korean has Hangul
    if (/[\u3040-\u309F\u30A0-\u30FF]/.test(sample)) return 'ja';
    if (/[\uAC00-\uD7AF]/.test(sample)) return 'ko';
    return 'zh';
  }
  if (devanagariRange.test(sample)) return 'hi';
  if (thaiRange.test(sample)) return 'th';
  if (latinRange.test(sample)) {
    // Default to English for Latin script
    return 'en';
  }

  return 'ku';
}

export async function fetchComicCharacters(contentId: string): Promise<ComicCharacter[]> {
  const { data, error } = await supabase
    .from('comic_characters')
    .select('*')
    .eq('content_id', contentId)
    .order('created_at', { ascending: true });
  if (error) return [];
  return (data as ComicCharacter[]) || [];
}

export async function fetchPanelBubbles(panelId: string): Promise<ComicSpeechBubble[]> {
  const { data, error } = await supabase
    .from('comic_speech_bubbles')
    .select('*, character:comic_characters(*)')
    .eq('panel_id', panelId)
    .order('bubble_order', { ascending: true });
  if (error) return [];
  return (data as ComicSpeechBubble[]) || [];
}

export async function fetchChapterBubbles(chapterId: string): Promise<ComicSpeechBubble[]> {
  const { data: panels } = await supabase
    .from('comic_panels')
    .select('id, panel_order')
    .eq('chapter_id', chapterId)
    .order('panel_order', { ascending: true });
  if (!panels || panels.length === 0) return [];

  const panelIds = panels.map((p) => (p as any).id);
  const panelOrderMap: Record<string, number> = {};
  for (const p of panels as any[]) {
    panelOrderMap[p.id] = p.panel_order;
  }

  const { data: bubbles } = await supabase
    .from('comic_speech_bubbles')
    .select('*, character:comic_characters(*)')
    .in('panel_id', panelIds);

  const allBubbles = (bubbles as ComicSpeechBubble[]) || [];
  // Sort by panel_order first, then bubble_order
  allBubbles.sort((a, b) => {
    const pa = panelOrderMap[a.panel_id] ?? 0;
    const pb = panelOrderMap[b.panel_id] ?? 0;
    if (pa !== pb) return pa - pb;
    return a.bubble_order - b.bubble_order;
  });

  return allBubbles;
}

// === Character CRUD ===
export async function saveCharacter(
  contentId: string,
  name: string,
  voiceType: 'male' | 'female',
  voiceLanguage: string
): Promise<ComicCharacter | null> {
  const { data, error } = await supabase
    .from('comic_characters')
    .insert({ content_id: contentId, name, voice_type: voiceType, voice_language: voiceLanguage })
    .select('*')
    .single();
  if (error) return null;
  return data as ComicCharacter;
}

export async function deleteCharacter(id: string): Promise<void> {
  await supabase.from('comic_characters').delete().eq('id', id);
}

export async function updateCharacter(id: string, updates: Partial<ComicCharacter>): Promise<void> {
  await supabase.from('comic_characters').update(updates).eq('id', id);
}

// === Speech Bubble CRUD ===
export async function saveBubble(
  panelId: string,
  text: string,
  characterId: string | null,
  region: { x: number; y: number; width: number; height: number },
  bubbleOrder: number
): Promise<ComicSpeechBubble | null> {
  const { data, error } = await supabase
    .from('comic_speech_bubbles')
    .insert({
      panel_id: panelId,
      text,
      character_id: characterId,
      region_x: region.x,
      region_y: region.y,
      region_width: region.width,
      region_height: region.height,
      bubble_order: bubbleOrder,
    })
    .select('*, character:comic_characters(*)')
    .single();
  if (error) return null;
  return data as ComicSpeechBubble;
}

export async function updateBubble(id: string, updates: Record<string, any>): Promise<void> {
  await supabase.from('comic_speech_bubbles').update(updates).eq('id', id);
}

export async function deleteBubble(id: string): Promise<void> {
  await supabase.from('comic_speech_bubbles').delete().eq('id', id);
}

// === AI Voice using Web Speech API ===
let voicesCache: SpeechSynthesisVoice[] = [];

export function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    const existing = window.speechSynthesis.getVoices();
    if (existing.length > 0) {
      voicesCache = existing;
      resolve(existing);
      return;
    }
    const handler = () => {
      voicesCache = window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = null;
      resolve(voicesCache);
    };
    window.speechSynthesis.onvoiceschanged = handler;
    // Fallback timeout
    setTimeout(() => {
      if (voicesCache.length === 0) {
        voicesCache = window.speechSynthesis.getVoices();
        resolve(voicesCache);
      }
    }, 2000);
  });
}

export function findVoiceForLanguage(lang: string, voiceType: 'male' | 'female'): SpeechSynthesisVoice | null {
  const voices = voicesCache.length > 0 ? voicesCache : window.speechSynthesis.getVoices();
  if (voices.length === 0) return null;

  // Map languages that browsers don't have voices for to closest available
  const langMap: Record<string, string> = {
    ku: 'ar', // Kurdish Sorani -> Arabic voice (same script)
    ar: 'ar',
    fa: 'ar', // Persian -> Arabic voice fallback
    ps: 'ar', // Pashto -> Arabic voice fallback
    ur: 'ur', // Urdu may have voices on some platforms
    hi: 'hi',
  };
  const mappedLang = langMap[lang] || lang;

  // Try exact language match, then prefix match
  const langVoices = voices.filter((v) =>
    v.lang.toLowerCase().startsWith(mappedLang.toLowerCase()) ||
    v.lang.toLowerCase().replace('_', '-').startsWith(mappedLang.toLowerCase())
  );

  // Prefer en-US for English
  if (lang === 'en' || mappedLang === 'en') {
    const usVoice = langVoices.find((v) => v.lang.toLowerCase().includes('en-us'));
    if (usVoice) return usVoice;
  }

  const femaleNames = ['samantha', 'victoria', 'karen', 'tessa', 'fiona', 'zira', 'sara', 'anna', 'amelie', 'ellen', 'kate', 'moira', 'veena', 'laila', 'tarik', 'mona', 'hoda', 'salma'];
  const maleNames = ['daniel', 'alex', 'fred', 'tom', 'david', 'george', 'james', 'oliver', 'rishi', 'yannick', 'thomas', 'jorge', 'diego', 'amir', 'majed', 'naayf', 'tariq'];

  const byGender = langVoices.find((v) => {
    const name = v.name.toLowerCase();
    if (voiceType === 'female') return femaleNames.some((n) => name.includes(n));
    return maleNames.some((n) => name.includes(n));
  });

  if (byGender) return byGender;
  if (langVoices.length > 0) return langVoices[0];

  // Last resort: any voice, prefer matching gender by name
  const anyGender = voices.find((v) => {
    const name = v.name.toLowerCase();
    if (voiceType === 'female') return femaleNames.some((n) => name.includes(n));
    return maleNames.some((n) => name.includes(n));
  });
  return anyGender || voices[0];
}

export interface AIVoiceController {
  play: (bubbles: ComicSpeechBubble[], startIndex?: number, onProgress?: (index: number) => void, onComplete?: () => void) => void;
  pause: () => void;
  resume: () => void;
  replay: () => void;
  stop: () => void;
  setVolume: (vol: number) => void;
  isPlaying: () => boolean;
  isPaused: () => boolean;
}

export function createAIVoiceController(): AIVoiceController {
  let volume = 1.0;
  let currentBubbles: ComicSpeechBubble[] = [];
  let currentIndex = 0;
  let playing = false;
  let paused = false;
  let progressCallback: ((index: number) => void) | null = null;
  let completeCallback: (() => void) | null = null;

  const speakBubble = (index: number) => {
    if (index >= currentBubbles.length) {
      playing = false;
      paused = false;
      completeCallback?.();
      return;
    }

    const bubble = currentBubbles[index];
    const text = bubble.translated_text || bubble.text;
    if (!text || !text.trim()) {
      currentIndex = index + 1;
      speakBubble(currentIndex);
      return;
    }

    const voiceType = bubble.character?.voice_type || 'male';
    const voiceLang = bubble.target_language || bubble.character?.voice_language || detectLanguage(text);
    // Map Kurdish to Arabic for browser TTS
    const ttsLang = voiceLang === 'ku' || voiceLang === 'fa' || voiceLang === 'ps' ? 'ar' : voiceLang;

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.volume = volume;
    utterance.rate = 0.9;
    utterance.pitch = voiceType === 'female' ? 1.15 : 0.85;

    const voice = findVoiceForLanguage(voiceLang, voiceType);
    if (voice) {
      utterance.voice = voice;
      utterance.lang = voice.lang;
    } else {
      utterance.lang = ttsLang;
    }

    utterance.onend = () => {
      if (playing && !paused) {
        currentIndex = index + 1;
        progressCallback?.(currentIndex);
        setTimeout(() => speakBubble(currentIndex), 300);
      }
    };

    utterance.onerror = () => {
      if (playing && !paused) {
        currentIndex = index + 1;
        setTimeout(() => speakBubble(currentIndex), 100);
      }
    };

    window.speechSynthesis.speak(utterance);
    progressCallback?.(index);
  };

  return {
    play: (bubbles, startIndex = 0, onProgress, onComplete) => {
      currentBubbles = bubbles;
      currentIndex = startIndex;
      playing = true;
      paused = false;
      progressCallback = onProgress || null;
      completeCallback = onComplete || null;
      if (voicesCache.length === 0) {
        loadVoices().then(() => speakBubble(currentIndex));
      } else {
        speakBubble(currentIndex);
      }
    },
    pause: () => {
      paused = true;
      playing = false;
      window.speechSynthesis.cancel();
    },
    resume: () => {
      if (paused) {
        paused = false;
        playing = true;
        speakBubble(currentIndex);
      }
    },
    replay: () => {
      currentIndex = 0;
      playing = true;
      paused = false;
      window.speechSynthesis.cancel();
      speakBubble(0);
    },
    stop: () => {
      playing = false;
      paused = false;
      currentIndex = 0;
      window.speechSynthesis.cancel();
    },
    setVolume: (vol: number) => {
      volume = Math.max(0, Math.min(1, vol));
    },
    isPlaying: () => playing && !paused,
    isPaused: () => paused,
  };
}

// === Translation ===
export async function translateBubbles(
  bubbles: ComicSpeechBubble[],
  targetLang: string
): Promise<{ translated: ComicSpeechBubble[]; error: string | null }> {
  const texts = bubbles.map((b) => b.text);
  if (texts.length === 0) return { translated: bubbles, error: null };

  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/comic-translate`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({ texts, target_lang: targetLang }),
    });
    if (!response.ok) {
      return { translated: bubbles, error: `Translation failed (${response.status})` };
    }
    const data = await response.json();
    if (data.error) {
      return { translated: bubbles, error: data.error };
    }
    const results = data.results || [];
    const translated = bubbles.map((b, i) => ({
      ...b,
      translated_text: results[i]?.translated || b.text,
      target_language: targetLang,
    }));

    // Save translations to database
    for (let i = 0; i < translated.length; i++) {
      if (results[i]?.translated) {
        await supabase
          .from('comic_speech_bubbles')
          .update({
            translated_text: results[i].translated,
            target_language: targetLang,
          })
          .eq('id', translated[i].id);
      }
    }

    return { translated, error: null };
  } catch (err: any) {
    return { translated: bubbles, error: err.message || 'Translation request failed' };
  }
}

export async function translateSingleText(
  text: string,
  targetLang: string
): Promise<{ translated: string; sourceLang: string | null; error: string | null }> {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/comic-translate`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({ texts: [text], target_lang: targetLang }),
    });
    if (!response.ok) {
      return { translated: text, sourceLang: null, error: `Translation failed (${response.status})` };
    }
    const data = await response.json();
    if (data.error) {
      return { translated: text, sourceLang: null, error: data.error };
    }
    const results = data.results || [];
    return {
      translated: results[0]?.translated || text,
      sourceLang: results[0]?.source_lang || null,
      error: null,
    };
  } catch (err: any) {
    return { translated: text, sourceLang: null, error: err.message || 'Translation failed' };
  }
}

// === Tap-to-Speak: speak a single bubble immediately ===
export function speakSingleBubble(bubble: ComicSpeechBubble, onEnd?: () => void): { spoken: boolean; error: string | null } {
  const text = bubble.translated_text || bubble.text;
  if (!text || !text.trim()) {
    return { spoken: false, error: 'هیچ دەقێک نییە بۆ ئەم قۆزی دەقە' };
  }

  const speakLang = bubble.target_language || detectLanguage(text);
  const voiceType = bubble.character?.voice_type || 'male';

  // Map Kurdish to Arabic for browser TTS (no native Kurdish voices exist)
  const ttsLang = speakLang === 'ku' || speakLang === 'fa' || speakLang === 'ps' ? 'ar' : speakLang;

  window.speechSynthesis.cancel();

  const doSpeak = () => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.volume = 1.0;
    utterance.rate = 0.9;
    utterance.pitch = voiceType === 'female' ? 1.15 : 0.85;

    const voice = findVoiceForLanguage(speakLang, voiceType);
    if (voice) {
      utterance.voice = voice;
      utterance.lang = voice.lang;
    } else {
      utterance.lang = ttsLang;
    }

    if (onEnd) utterance.onend = onEnd;
    utterance.onerror = () => onEnd?.();
    window.speechSynthesis.speak(utterance);
  };

  if (voicesCache.length === 0) {
    voicesCache = window.speechSynthesis.getVoices();
  }

  if (voicesCache.length === 0) {
    loadVoices().then(() => doSpeak());
  } else {
    doSpeak();
  }

  return { spoken: true, error: null };
}
