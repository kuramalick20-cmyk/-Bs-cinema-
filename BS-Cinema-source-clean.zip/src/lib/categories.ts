import type { ContentCategory } from './supabase';

export const CATEGORIES: { key: ContentCategory; label: string; icon: string }[] = [
  { key: 'comic', label: 'کۆمیک', icon: 'BookOpen' },
  { key: 'series', label: 'زنجیرە', icon: 'Tv' },
  { key: 'movie', label: 'فیلم', icon: 'Film' },
  { key: 'anime', label: 'ئەنیمی', icon: 'Sparkles' },
  { key: 'anime_series', label: 'زنجیرەی ئەنیمی', icon: 'Clapperboard' },
  { key: 'anime_movies', label: 'فیلمی ئەنیمی', icon: 'Film' },
  { key: 'animation', label: 'ئەنیمەیشن', icon: 'Clapperboard' },
  { key: 'cartoon_series', label: 'زنجیرەی کارتۆن', icon: 'Clapperboard' },
  { key: 'animation_series', label: 'زنجیرەی ئەنیمەیشن', icon: 'Clapperboard' },
  { key: 'movies', label: 'فیلمە گشتییەکان', icon: 'Film' },
];

export const CATEGORY_LABELS: Record<ContentCategory, string> = {
  comic: 'کۆمیک',
  series: 'زنجیرە',
  movie: 'فیلم',
  anime: 'ئەنیمی',
  anime_series: 'زنجیرەی ئەنیمی',
  anime_movies: 'فیلمی ئەنیمی',
  animation: 'ئەنیمەیشن',
  cartoon_series: 'زنجیرەی کارتۆن',
  animation_series: 'زنجیرەی ئەنیمەیشن',
  movies: 'فیلمە گشتییەکان',
};
