import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    storage: window.localStorage,
    detectSessionInUrl: true,
    flowType: 'implicit',
  } as any,
});

export type ContentCategory = 'comic' | 'series' | 'movie' | 'anime' | 'anime_series' | 'animation' | 'cartoon_series' | 'animation_series' | 'anime_movies' | 'movies';

export interface ContentItem {
  id: string;
  title: string;
  description: string | null;
  category: ContentCategory;
  cover_image_url: string | null;
  tags: string[] | null;
  dubbing_group: string | null;
  author_name: string | null;
  chapter_notice: string | null;
  is_vip: boolean;
  view_count?: number;
  star_count?: number;
  created_at: string;
}

export interface Episode {
  id: string;
  content_id: string;
  episode_number: number;
  title: string | null;
  video_type: 'upload' | 'link' | 'gdrive';
  video_url: string;
  created_at: string;
}

export interface ComicChapter {
  id: string;
  content_id: string;
  chapter_number: number;
  title: string | null;
  background_music_url: string | null;
  format: string;
  created_at: string;
}

export interface ComicPanel {
  id: string;
  chapter_id: string;
  image_url: string;
  panel_order: number;
  video_url: string | null;
  aspect_ratio: string;
  sound_url: string | null;
  created_at: string;
}

export type VipStatus = 'free' | 'trial' | 'vip';

export interface Profile {
  id: string;
  username: string | null;
  avatar_url: string | null;
  phone: string | null;
  vip_status: VipStatus;
  trial_start_date: string | null;
  trial_end_date: string | null;
  vip_start_date: string | null;
  vip_end_date: string | null;
  trial_used: boolean;
  is_admin: boolean;
  banned_at: string | null;
  ban_reason: string | null;
  created_at: string;
}

export type PaymentMethod = 'fastpay' | 'mobile_credit';
export type PaymentStatus = 'pending' | 'approved' | 'rejected';

export interface VipPayment {
  id: string;
  user_id: string;
  payment_method: PaymentMethod;
  payment_note: string | null;
  status: PaymentStatus;
  admin_note: string | null;
  created_at: string;
  reviewed_at: string | null;
  profiles?: { username: string | null; avatar_url: string | null; phone: string | null } | null;
}

export type ItemType = 'content' | 'episode' | 'comic_chapter';

export interface Comment {
  id: string;
  item_type: ItemType;
  item_id: string;
  user_id: string;
  text: string;
  created_at: string;
  profiles?: { username: string | null; avatar_url: string | null } | null;
}

export interface ToggleStarResult {
  starred: boolean;
  star_count: number;
}

export interface ComicMusicTrack {
  id: string;
  chapter_id: string;
  track_url: string;
  track_name: string | null;
  start_time: number | null;
  end_time: number | null;
  start_panel: number | null;
  end_panel: number | null;
  track_order: number;
  created_at: string;
}

export interface Subtitle {
  id: string;
  item_type: 'episode' | 'comic_panel';
  item_id: string;
  language: 'ku' | 'en';
  content: string;
  start_time: number | null;
  end_time: number | null;
  created_at: string;
  is_ai_generated?: boolean;
  ai_status?: string | null;
  source_text?: string | null;
}

export interface AiSubtitleJob {
  id: string;
  episode_id: string;
  language: 'ku' | 'en';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  error_message: string | null;
  created_at: string;
  completed_at: string | null;
}

export interface ChatConversation {
  id: string;
  user1_id: string;
  user2_id: string;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  conversation_id: string;
  sender_id: string;
  text: string | null;
  audio_url: string | null;
  image_url: string | null;
  video_url: string | null;
  message_type: 'text' | 'voice' | 'image' | 'video';
  read_at: string | null;
  edited_at: string | null;
  deleted_at: string | null;
  reactions: Record<string, string> | null;
  moderation_status: string | null;
  moderation_reason: string | null;
  created_at: string;
}

export interface GameChatMessage {
  id: string;
  match_id: string;
  sender_id: string;
  text: string;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  type: 'new_content' | 'new_episode' | 'new_chapter' | 'new_vip_content' | 'chat_message' | 'game_invite' | 'voice_call' | 'comment_reply';
  title: string;
  body: string | null;
  link_id: string | null;
  is_read: boolean;
  created_at: string;
}

export interface Ad {
  id: string;
  title: string | null;
  image_url: string | null;
  link_url: string | null;
  position: string;
  is_active: boolean;
  impressions: number;
  created_at: string;
}

export interface ComicImageTranslation {
  id: string;
  panel_id: string;
  user_id: string | null;
  source_language: string | null;
  target_language: string;
  original_text: string | null;
  translated_text: string;
  region_x: number;
  region_y: number;
  region_width: number;
  region_height: number;
  font_size: number;
  text_align: 'left' | 'center' | 'right';
  is_approved: boolean;
  created_at: string;
}

export interface ComicCharacter {
  id: string;
  content_id: string;
  name: string;
  voice_type: 'male' | 'female';
  voice_language: string;
  color: string | null;
  created_at: string;
}

export interface ComicChapterVideo {
  id: string;
  chapter_id: string;
  title: string | null;
  video_type: 'upload' | 'link' | 'gdrive';
  video_url: string;
  video_order: number;
  created_at: string;
}

export interface ComicSpeechBubble {
  id: string;
  panel_id: string;
  character_id: string | null;
  text: string;
  translated_text: string | null;
  target_language: string | null;
  region_x: number;
  region_y: number;
  region_width: number;
  region_height: number;
  bubble_order: number;
  created_at: string;
  character?: ComicCharacter | null;
}

// === AI Image-to-Video Comic Animation System ===

export interface AiVideoProvider {
  id: string;
  name: string;
  provider_type: 'image-to-video' | 'text-to-video';
  api_key: string | null;
  api_endpoint: string;
  model_name: string;
  is_enabled: boolean;
  is_default: boolean;
  config: Record<string, any> | null;
  created_at: string;
  updated_at: string;
}

export interface AiProviderSettings {
  id: string;
  openai_api_key: string | null;
  openai_model: string;
  default_video_provider_id: string | null;
  default_duration: number;
  max_duration: number;
  image_to_video_enabled: boolean;
  chatgpt_enabled: boolean;
  subtitle_ai_enabled: boolean;
  created_at: string;
  updated_at: string;
}

export type AnimationStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
export type CameraMotion = 'static' | 'zoom_in' | 'zoom_out' | 'pan_left' | 'pan_right' | 'subtle';

export interface ComicPanelAnimation {
  id: string;
  panel_id: string;
  status: AnimationStatus;
  provider_id: string | null;
  provider_name: string | null;
  model_used: string | null;
  video_url: string | null;
  duration: number;
  camera_motion: CameraMotion;
  animation_prompt: string | null;
  chatgpt_analysis: Record<string, any> | null;
  error_message: string | null;
  retry_count: number;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
}

export interface ComicPanelSubtitle {
  id: string;
  panel_id: string;
  text: string;
  start_time: number;
  end_time: number;
  language: string;
  position_x: number;
  position_y: number;
  font_family: string;
  font_size: number;
  text_color: string;
  bg_color: string;
  bg_opacity: number;
  text_align: 'left' | 'center' | 'right';
  is_ai_generated: boolean;
  created_at: string;
}

export interface ComicCharacterRef {
  id: string;
  content_id: string;
  character_id: string | null;
  name: string;
  description: string | null;
  clothing: string | null;
  hair: string | null;
  eye_color: string | null;
  reference_image_url: string | null;
  dialogue_sample: string | null;
  created_at: string;
  updated_at: string;
}
